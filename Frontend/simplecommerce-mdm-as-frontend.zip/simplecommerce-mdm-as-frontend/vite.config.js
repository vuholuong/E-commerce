import {fileURLToPath, URL} from 'node:url'
import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'

/**
 * VITE CONFIGURATION
 * 
 * Vấn đề: 
 * - Development: Cần proxy để tránh CORS khi gọi API
 * - Production: Không cần proxy, build thành static files
 * 
 * Giải pháp: Tự động detect command và áp dụng cấu hình phù hợp
 */

// https://vitejs.dev/config/
export default defineConfig(({ command, mode }) => {
    // Detect môi trường: 'serve' = development, 'build' = production
    const isDevelopment = command === 'serve'
    
    console.log(`🔧 Vite config loaded: ${isDevelopment ? 'Development' : 'Production'} mode`)
    
    return {
        /**
         * SERVER CONFIGURATION (chỉ áp dụng trong development)
         */
        server: {
            host: true, // Expose to network (có thể truy cập từ IP khác)
            
            /**
             * PROXY CONFIGURATION (chỉ trong development)
             * 
             * Mục đích: Tránh lỗi CORS khi frontend gọi API backend
             * 
             * Cách hoạt động:
             * 1. Frontend gọi: /api/v1/auth/login
             * 2. Vite proxy nhận: /api/v1/auth/login
             * 3. Proxy forward: https://sc-mdm-api.nammai.id.vn/api/v1/auth/login
             * 4. Backend trả về response
             * 5. Proxy forward response về frontend
             */
            proxy: isDevelopment ? {
                '/api': {
                    target: 'https://sc-mdm-api.nammai.id.vn', // Backend URL
                    changeOrigin: true, // Thay đổi Origin header để tránh CORS
                    secure: false, // Cho phép HTTP (nếu cần)
                    
                    // Rewrite path (giữ nguyên /api)
                    rewrite: (path) => path.replace(/^\/api/, '/api'),
                    
                    // Cấu hình thêm cho proxy
                    configure: (proxy, options) => {
                        // Thêm Origin header để backend không reject
                        proxy.on('proxyReq', (proxyReq, req, res) => {
                            proxyReq.setHeader('Origin', 'https://sc-mdm-api.nammai.id.vn');
                        });
                    }
                },
            } : {}, // Production: không có proxy
        },
        
        /**
         * PLUGINS
         */
        plugins: [vue()],
        
        /**
         * RESOLVE CONFIGURATION
         */
        resolve: {
            alias: {
                // Alias @ để import từ src folder
                '@': fileURLToPath(new URL('./src', import.meta.url))
            }
        },
        
        /**
         * BUILD CONFIGURATION (chỉ áp dụng khi build production)
         */
        build: {
            outDir: 'dist', // Thư mục output
            assetsDir: 'assets', // Thư mục chứa assets
            sourcemap: false, // Không tạo sourcemap để giảm kích thước
            
            // Rollup options để tối ưu bundle
            rollupOptions: {
                output: {
                    // Chia nhỏ bundle để tối ưu loading
                    manualChunks: {
                        vendor: ['vue', 'vue-router', 'pinia'], // Thư viện chính
                        axios: ['axios'] // HTTP client
                    }
                }
            }
        }
    }
})
<template>
  <div class="modal fade" :class="{ show: show }" :style="{ display: show ? 'block' : 'none' }" tabindex="-1"
    @click.self="$emit('close')">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Chi tiết sản phẩm</h5>
          <button type="button" class="btn-close" @click="$emit('close')"></button>
        </div>

        <div class="modal-body">
          <div class="row">
            <!-- Product Images -->
            <!-- Product Images -->
<div class="col-md-6">
  <div class="product-images">
    <!-- Ảnh lớn - hiển thị ảnh đang được chọn -->
    <img :src="selectedImage" :alt="product.name" class="img-fluid rounded mb-3"
      style="width: 100%; height: 300px; object-fit: cover;">
    
    <!-- Danh sách ảnh nhỏ -->
    <div class="d-flex gap-2 flex-wrap" v-if="product.images && product.images.length > 1">
      <!-- Thêm cả ảnh đầu tiên vào danh sách ảnh nhỏ -->
      <img 
        v-for="(image, index) in product.images" 
        :key="index" 
        :src="image"
        :alt="`${product.name} ${index + 1}`" 
        class="rounded"
        :class="{ 'border border-primary': image === selectedImage }"
        style="width: 60px; height: 60px; object-fit: cover; cursor: pointer;"
        @click="selectImage(image)"
      >
    </div>
  </div>
</div>

            <!-- Product Info -->
            <div class="col-md-6">
              <h4>{{ product.name }}</h4>
              <p class="text-muted mb-2">SKU: {{ product.sku || 'N/A' }}</p>

              <div class="mb-3">
                <span :class="`badge bg-${product.statusColor} fs-6`">{{ product.status }}</span>
              </div>

              <div class="row mb-3">
                <div class="col-sm-6">
                  <strong>Giá:</strong>
                  <div v-if="product.priceRange && product.hasVariants">
                    {{ product.priceRange.display }}
                  </div>
                  <div v-else>
                    {{ formatCurrency(product.price) }}
                  </div>
                </div>
                <div class="col-sm-6">
                  <strong>Tồn kho:</strong> {{ product.stock }}
                </div>
              </div>

              <div class="mb-3">
                <strong>Seller:</strong><br>
                {{ product.seller }}<br>
                <small class="text-muted">{{ product.sellerEmail }}</small>
              </div>

              <div class="mb-3">
                <strong>Danh mục:</strong> {{ product.category }}
              </div>

              <div class="mb-3">
                <strong>Ngày tạo:</strong> {{ product.createdAt }}
              </div>

              <div class="mb-3" v-if="product.approvedAt">
                <strong>Ngày duyệt:</strong> {{ product.approvedAt }}
              </div>

              <div class="mb-3" v-if="product.rejectionReason">
                <strong>Lý do từ chối:</strong>
                <div class="alert alert-danger mt-1">{{ product.rejectionReason }}</div>
              </div>
            </div>
          </div>

          <!-- Product Description -->
          <div class="row mt-4">
            <div class="col-12">
              <h6>Mô tả sản phẩm:</h6>
              <div class="border p-3 rounded bg-light">
                {{ product.description || 'Không có mô tả' }}
              </div>
            </div>
          </div>

          <!-- Product Variants -->
          <div class="row mt-4" v-if="product.variants && product.variants.length > 0">
            <div class="col-12">
              <h6>Phiên bản sản phẩm ({{ product.variants.length }}):</h6>
              <div class="table-responsive">
                <table class="table table-sm">
                  <thead>
                    <tr>
                      <th>SKU</th>
                      <th>Giá cuối</th>
                      <th>Giá so sánh</th>
                      <th>Tồn kho</th>
                      <th>Trạng thái</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="variant in product.variants" :key="variant.id">
                      <td>{{ variant.sku || 'N/A' }}</td>
                      <td>{{ formatCurrency(variant.finalPrice) }}</td>
                      <td>{{ variant.compareAtPrice ? formatCurrency(variant.compareAtPrice) : '-' }}</td>
                      <td>{{ variant.stockQuantity || 0 }}</td>
                      <td>
                        <span :class="`badge ${variant.isActive !== false ? 'bg-success' : 'bg-secondary'}`">
                          {{ variant.isActive !== false ? 'Hoạt động' : 'Không hoạt động' }}
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- Additional Info -->
          <div class="row mt-4" v-if="product.weightGrams || product.dimensions">
            <div class="col-12">
              <h6>Thông tin bổ sung:</h6>
              <div class="row">
                <div class="col-sm-6" v-if="product.weightGrams">
                  <strong>Khối lượng:</strong> {{ product.weightGrams }}g
                </div>
                <div class="col-sm-6" v-if="product.dimensions">
                  <strong>Kích thước:</strong> {{ product.dimensions }}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" @click="$emit('close')">Đóng</button>

          <!-- Action buttons based on status -->
          <div v-if="product.statusKey === 'PENDING_APPROVAL'">
            <button type="button" class="btn btn-success me-2" @click="$emit('approve', product)">
              <i class="bi bi-check-circle"></i> Duyệt
            </button>
            <button type="button" class="btn btn-danger" @click="$emit('reject', product)">
              <i class="bi bi-x-circle"></i> Từ chối
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal backdrop -->
  <div v-if="show" class="modal-backdrop fade show"></div>
</template>

<script setup>
import { ref } from 'vue';
import ProductAdminService from '@/services/admin/product'

const props = defineProps({
  show: {
    type: Boolean,
    default: false
  },
  product: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['close', 'approve', 'reject', 'block', 'unblock'])

const selectedImage = ref(props.product.images?.[0] || props.product.image || '/images/no-image.png');

const selectImage = (image) => {
  selectedImage.value = image;
};

const formatCurrency = (amount) => {
  return ProductAdminService.formatCurrency(amount)
}
</script>

<style scoped>
.modal {
  background-color: rgba(0, 0, 0, 0.5);
}
.product-images .rounded {
  transition: all 0.2s ease;
}
.product-images .rounded:hover {
  transform: scale(1.05);
  box-shadow: 0 0 5px rgba(0,0,0,0.2);
}
</style>
<template>
  <div class="modal fade" :class="{ show: show, 'd-block': show }" tabindex="-1" v-if="show">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">{{ title }}</h5>
          <button type="button" class="btn-close" @click="$emit('close')" :disabled="loading"></button>
        </div>
        <div class="modal-body">
          <p>{{ message }}</p>

          <!-- Reason Selection -->
          <div class="mb-3" v-if="showReason">
            <label class="form-label">
              {{ reasonLabel }} <span class="text-danger">*</span>
            </label>
            <select class="form-select" :value="reason" @input="$emit('update:reason', $event.target.value)"
              :class="{ 'is-invalid': showReason && !reason && attempted }">
              <option value="">{{ reasonPlaceholder }}</option>
              <option v-for="option in reasonOptions" :key="option.value" :value="option.value">
                {{ option.label }}
              </option>
            </select>
            <div class="invalid-feedback" v-if="showReason && !reason && attempted">
              Vui lòng chọn {{ reasonLabel.toLowerCase() }}
            </div>
          </div>

          <!-- Note Input -->
          <div class="mb-3" v-if="showNote || (showReason && reason)">
            <label class="form-label">
              {{ noteLabel }}
              <span v-if="showReason && reason === 'Khác'" class="text-danger">*</span>
              <span v-else-if="!showReason" class="text-muted"></span>
            </label>
            <textarea class="form-control" rows="3" :value="note" @input="$emit('update:note', $event.target.value)"
              :placeholder="notePlaceholder"
              :class="{ 'is-invalid': showReason && reason === 'Khác' && !note && attempted }"></textarea>
            <div class="invalid-feedback" v-if="showReason && reason === 'Khác' && !note && attempted">
              Vui lòng nhập ghi chú chi tiết khi chọn "Khác"
            </div>
            <small class="form-text text-muted" v-if="showNote || (showReason && reason)">
              Tối đa 500 ký tự
            </small>
          </div>

          <!-- Validation Summary -->
          <div class="alert alert-warning" v-if="validationErrors.length > 0">
            <small>
              <strong>Vui lòng hoàn thành:</strong>
              <ul class="mb-0 mt-1">
                <li v-for="error in validationErrors" :key="error">{{ error }}</li>
              </ul>
            </small>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" @click="$emit('close')" :disabled="loading">
            Hủy
          </button>
          <button type="button" :class="`btn ${confirmClass}`" @click="handleConfirm" :disabled="loading || !isValid">
            <span v-if="loading" class="spinner-border spinner-border-sm me-1"></span>
            {{ confirmText }}
          </button>
        </div>
      </div>
    </div>
  </div>
  <div class="modal-backdrop fade show" v-if="show"></div>
</template>

<script setup>
import { ref, computed, watch, defineEmits } from 'vue'

const props = defineProps({
  show: {
    type: Boolean,
    default: false
  },
  title: {
    type: String,
    required: true
  },
  message: {
    type: String,
    required: true
  },
  confirmText: {
    type: String,
    default: 'Xác nhận'
  },
  confirmClass: {
    type: String,
    default: 'btn-primary'
  },
  loading: {
    type: Boolean,
    default: false
  },
  showReason: {
    type: Boolean,
    default: false
  },
  reasonLabel: {
    type: String,
    default: 'Lý do'
  },
  reasonPlaceholder: {
    type: String,
    default: 'Chọn lý do'
  },
  reasonOptions: {
    type: Array,
    default: () => []
  },
  reason: {
    type: String,
    default: ''
  },
  showNote: {
    type: Boolean,
    default: false
  },
  noteLabel: {
    type: String,
    default: 'Ghi chú'
  },
  notePlaceholder: {
    type: String,
    default: 'Nhập ghi chú...'
  },
  note: {
    type: String,
    default: ''
  }
})

const emit = defineEmits(['close', 'confirm', 'update:reason', 'update:note'])

const attempted = ref(false)

// Computed validation
const isValid = computed(() => {
  if (props.showReason && !props.reason) {
    return false
  }
  if (props.showReason && props.reason === 'Khác' && !props.note) {
    return false
  }
  return true
})

const validationErrors = computed(() => {
  const errors = []
  if (props.showReason && !props.reason) {
    errors.push(`Chọn ${props.reasonLabel.toLowerCase()}`)
  }
  if (props.showReason && props.reason === 'Khác' && !props.note) {
    errors.push('Nhập ghi chú chi tiết')
  }
  return errors
})

const handleConfirm = () => {
  attempted.value = true

  if (!isValid.value) {
    return
  }

  emit('confirm')
}

// Reset attempted when modal closes
watch(() => props.show, (newVal) => {
  if (!newVal) {
    attempted.value = false
  }
})
</script>

<style scoped>
.form-control:focus,
.form-select:focus {
  border-color: #86b7fe;
  box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

.is-invalid {
  border-color: #dc3545;
}

.is-invalid:focus {
  border-color: #dc3545;
  box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
}

.invalid-feedback {
  display: block;
  width: 100%;
  margin-top: 0.25rem;
  font-size: 0.875em;
  color: #dc3545;
}

.alert {
  padding: 0.75rem;
  margin-bottom: 0;
  border: 1px solid transparent;
  border-radius: 0.375rem;
}

.alert-warning {
  color: #664d03;
  background-color: #fff3cd;
  border-color: #ffecb5;
}
</style>
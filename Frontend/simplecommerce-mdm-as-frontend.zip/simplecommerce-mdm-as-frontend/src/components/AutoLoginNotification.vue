<template>
  <div v-if="showNotification" class="auto-login-notification">
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <div class="d-flex align-items-center">
        <i class="bi bi-check-circle-fill me-2"></i>
        <div>
          <strong>🎉 Đăng nhập tự động thành công!</strong>
          <p class="mb-0 mt-1">
            Chào mừng bạn, {{ userData?.firstName || userData?.username || 'User' }}!
            <span v-if="userData?.role?.[0]?.authority" class="badge bg-primary ms-2">
              {{ userData.role[0].authority }}
            </span>
          </p>
        </div>
      </div>
      <button 
        type="button" 
        class="btn-close" 
        @click="hideNotification"
        aria-label="Close"
      ></button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useAuthStore } from '@/stores/auth'

const authStore = useAuthStore()
const showNotification = ref(false)
const userData = ref(null)

// Lắng nghe event userLoggedIn
const handleUserLoggedIn = (event) => {
  console.log('🎯 Nhận được event userLoggedIn:', event.detail)
  userData.value = event.detail.userData
  showNotification.value = true
  
  // Tự động ẩn notification sau 5 giây
  setTimeout(() => {
    hideNotification()
  }, 5000)
}

// Ẩn notification
const hideNotification = () => {
  showNotification.value = false
}

// Kiểm tra xem user đã đăng nhập chưa
const checkUserLoginStatus = () => {
  if (authStore.isAuthenticated && authStore.currentUser) {
    userData.value = authStore.currentUser
    showNotification.value = true
    
    // Tự động ẩn sau 3 giây nếu đã đăng nhập
    setTimeout(() => {
      hideNotification()
    }, 3000)
  }
}

onMounted(() => {
  // Lắng nghe event từ AutoLoginService
  window.addEventListener('userLoggedIn', handleUserLoggedIn)
  
  // Kiểm tra trạng thái đăng nhập hiện tại
  checkUserLoginStatus()
})

onUnmounted(() => {
  // Cleanup event listener
  window.removeEventListener('userLoggedIn', handleUserLoggedIn)
})
</script>

<style scoped>
.auto-login-notification {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 9999;
  max-width: 400px;
  animation: slideInRight 0.3s ease-out;
}

.auto-login-notification .alert {
  border: none;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  margin-bottom: 0;
}

.auto-login-notification .bi-check-circle-fill {
  font-size: 1.5rem;
  color: #28a745;
}

.auto-login-notification .badge {
  font-size: 0.75rem;
}

@keyframes slideInRight {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

/* Responsive */
@media (max-width: 768px) {
  .auto-login-notification {
    top: 10px;
    right: 10px;
    left: 10px;
    max-width: none;
  }
}
</style>

<template>
  <div class="seller-layout">
    <!-- Mobile Overlay -->
    <div v-if="isMobile && !sidebarCollapsed" class="mobile-overlay" @click="closeSidebar"></div>

    <!-- Sidebar -->
    <nav class="sidebar fw-bold" :class="{
      'collapsed': sidebarCollapsed,
      'mobile-open': isMobile && !sidebarCollapsed
    }">
      <div class="sidebar-header p-3">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <img src="@/assets/logoMuadima2.png" v-if="!sidebarCollapsed || isMobile" style="max-width: 60%" />
            <p v-else class="text-light">SP</p>
          </div>
          <!-- Close button for mobile -->
          <button v-if="isMobile && !sidebarCollapsed" @click="closeSidebar" class="btn btn-sm btn-outline-light ms-2">
            <i class="bi bi-x-lg"></i>
          </button>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <ul class="nav flex-column">
        <li class="nav-item mb-2">
          <router-link to="/seller/dashboard" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Dashboard' : ''" @click="handleNavClick">
            <i class="bi bi-speedometer2"></i>
            <span v-if="!sidebarCollapsed || isMobile">Dashboard</span>
          </router-link>
        </li>
        <li class="nav-item mb-2">
          <router-link to="/seller/products" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý sản phẩm' : ''" @click="handleNavClick">
            <i class="bi bi-box"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý sản phẩm</span>
          </router-link>
        </li>
        <li class="nav-item mb-2">
          <router-link to="/seller/orders" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý đơn hàng' : ''" @click="handleNavClick">
            <i class="bi bi-cart"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý đơn hàng</span>
          </router-link>
        </li>
        <!-- <li class="nav-item mb-2">
          <router-link to="/seller/vouchers" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý mã giảm giá' : ''" @click="handleNavClick">
            <i class="bi bi-gift"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý mã giảm giá</span>
          </router-link>
        </li>
        <li class="nav-item mb-2">
          <router-link to="/seller/banners" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý Banners' : ''" @click="handleNavClick">
            <i class="bi bi-calendar2-week"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý Banners</span>
          </router-link>
        </li> -->
        <li class="nav-item mb-2">
          <router-link to="/seller/revenue" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Thống kê doanh thu' : ''" @click="handleNavClick">
            <i class="bi bi-currency-dollar"></i>
            <span v-if="!sidebarCollapsed || isMobile">Thống kê doanh thu</span>
          </router-link>
        </li>
        <!-- <li class="nav-item mb-2">
          <router-link to="/seller/transactions" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Lịch sử giao dịch' : ''" @click="handleNavClick">
            <i class="bi bi-credit-card"></i>
            <span v-if="!sidebarCollapsed || isMobile">Lịch sử giao dịch</span>
          </router-link>
        </li> -->
        <li class="nav-item mb-2">
          <router-link to="/seller/support" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Đánh giá bình luận' : ''" @click="handleNavClick">
            <i class="bi bi-headset"></i>
            <span v-if="!sidebarCollapsed || isMobile">Đánh giá bình luận</span>
          </router-link>
        </li>
        <!-- cài đặt shop -->
        <li class="nav-item mb-2">
          <router-link to="/seller/settings" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Cài đặt cửa hàng' : ''" @click="handleNavClick">
            <i class="bi bi-gear"></i>
            <span v-if="!sidebarCollapsed || isMobile">Cài đặt cửa hàng</span>
          </router-link>
        </li>
      </ul>

      <!-- User info in sidebar -->
      <div class="sidebar-user mt-auto p-3 border-top border-light">
        <!-- Loading state -->
        <div v-if="isLoadingProfile" class="text-center mb-2">
          <div class="spinner-border spinner-border-sm text-light" role="status">
            <span class="visually-hidden">Đang tải...</span>
          </div>
          <div class="small text-light mt-1">Đang tải...</div>
        </div>

        <!-- Profile loaded -->
        <div v-else-if="!profileLoadError" class="mb-2">
          <div v-if="!sidebarCollapsed || isMobile" class="d-flex align-items-center">
            <img :src="getUserAvatar()" :alt="getUserDisplayName()" class="rounded-circle me-2" width="32" height="32"
              @error="handleAvatarError">
            <div class="flex-grow-1 text-truncate ms-2">
              <div class="small fw-bold text-center">{{ getUserRole() }}</div>
              <div class="fw-bold small text-truncate text-white">{{ getUserDisplayName() }}</div>
            </div>
          </div>

          <!-- Collapsed sidebar avatar -->
          <div v-else class="text-center">
            <img :src="getUserAvatar()" :alt="getUserDisplayName()" class="rounded-circle" width="40" height="40"
              @error="handleAvatarError" :title="getUserDisplayName()">
          </div>
        </div>

        <!-- Error state -->
        <div v-else class="text-center mb-2">
          <i class="bi bi-exclamation-triangle text-warning"></i>
          <div class="small text-light mt-1">Lỗi tải thông tin</div>
        </div>

        <button @click="confirmLogout" class="btn btn-outline-danger btn-sm w-100"
          :title="sidebarCollapsed && !isMobile ? 'Đăng xuất' : ''">
          <i class="bi bi-box-arrow-right"></i>
          <span v-if="!sidebarCollapsed || isMobile"> Đăng xuất</span>
        </button>
      </div>
    </nav>

    <!-- Main content -->
    <div class="main-content" :class="{ 'sidebar-collapsed': sidebarCollapsed }">
      <!-- Header -->
      <header class="header bg-white shadow-sm border-bottom">
        <div class="container-fluid">
          <div class="d-flex justify-content-between align-items-center p-3">
            <div class="d-flex align-items-center">
              <button @click="toggleSidebar" class="btn btn-outline-secondary me-3">
                <i class="bi bi-list"></i>
              </button>
              <h5 class="mb-0 d-none d-sm-block">{{ pageTitle }}</h5>
              <h6 class="mb-0 d-sm-none">{{ pageTitle.length > 20 ? pageTitle.substring(0, 20) + '...' : pageTitle }}
              </h6>
            </div>

            <!-- User Header Info -->
            <div class="d-flex align-items-center">
              <!-- Notifications - Hidden on very small screens -->
              <!-- <div class="me-2 me-md-3 d-none d-sm-block">
                <button class="btn btn-outline-secondary position-relative" @click="showNotifications">
                  <i class="bi bi-bell"></i>
                  <span v-if="notificationCount > 0"
                    class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
                    {{ notificationCount > 99 ? '99+' : notificationCount }}
                  </span>
                </button>
              </div> -->

              <!-- User Dropdown -->
              <div class="dropdown position-relative">
                <button class="btn btn-outline-secondary dropdown-toggle d-flex align-items-center" type="button"
                  ref="dropdownButton" @click="toggleDropdown" :disabled="isLoadingProfile" aria-expanded="false">
                  <!-- Loading avatar -->
                  <div v-if="isLoadingProfile" class="rounded-circle me-2 placeholder-glow"
                    style="width: 32px; height: 32px;">
                    <div class="placeholder rounded-circle w-100 h-100"></div>
                  </div>
                  <!-- Loaded avatar -->
                  <img v-else :src="getUserAvatar()" :alt="getUserDisplayName()" class="rounded-circle me-2" width="32"
                    height="32" @error="handleAvatarError">

                  <!-- User info - Hidden on small screens -->
                  <div class="d-none d-lg-block text-start">
                    <div v-if="isLoadingProfile" class="placeholder-glow">
                      <div class="placeholder col-8 fw-bold small"></div>
                      <div class="placeholder col-6 text-muted small"></div>
                    </div>
                    <div v-else>
                      <div class="fw-bold small">{{ getUserDisplayName() }}</div>
                      <div class="text-muted small">{{ getUserRole() }}</div>
                    </div>
                  </div>
                  <i class="bi bi-chevron-down ms-2 d-none d-md-inline"></i>
                </button>

                <!-- Dropdown Menu with better positioning -->
                <ul class="dropdown-menu dropdown-menu-end shadow border-0" :class="{ 'show': dropdownOpen }"
                  ref="dropdownMenu">
                  <!-- User Info Header -->
                  <li class="dropdown-header bg-light">
                    <div v-if="isLoadingProfile" class="d-flex align-items-center">
                      <div class="placeholder-glow me-2">
                        <div class="placeholder rounded-circle" style="width: 40px; height: 40px;"></div>
                      </div>
                      <div class="flex-grow-1 placeholder-glow">
                        <div class="placeholder col-8 fw-bold"></div>
                        <div class="placeholder col-10 text-muted small"></div>
                        <div class="placeholder col-4 badge bg-success small mt-1"></div>
                      </div>
                    </div>
                    <div v-else-if="!profileLoadError" class="d-flex align-items-center">
                      <img :src="getUserAvatar()" :alt="getUserDisplayName()" class="rounded-circle me-2" width="40"
                        height="40" @error="handleAvatarError">
                      <div class="flex-grow-1">
                        <div class="fw-bold text-truncate">{{ getUserDisplayName() }}</div>
                        <div class="text-muted small text-truncate">{{ getUserEmail() }}</div>
                        <div class="badge bg-success small mt-1">{{ getUserRole() }} Portal</div>
                      </div>
                    </div>
                    <div v-else class="text-center text-muted">
                      <i class="bi bi-exclamation-triangle"></i>
                      <div class="small">Không thể tải thông tin</div>
                    </div>
                  </li>
                  <li>
                    <hr class="dropdown-divider my-1">
                  </li>

                  <!-- User Stats -->
                  <!-- <li class="dropdown-header bg-light border-top">
                    <div class="row text-center">
                      <div class="col-4">
                        <div class="fw-bold text-success">{{ userStats.loginCount }}</div>
                        <small class="text-muted">Đăng nhập</small>
                      </div>
                      <div class="col-4 border-start border-end">
                        <div class="fw-bold text-primary">{{ formatLastLogin() }}</div>
                        <small class="text-muted">Lần cuối</small>
                      </div>
                      <div class="col-4">
                        <div class="fw-bold text-info">{{ getOnlineTime() }}</div>
                        <small class="text-muted">Online</small>
                      </div>
                    </div>
                  </li>
                  <li>
                    <hr class="dropdown-divider my-1">
                  </li> -->

                  <!-- Notifications - Only show on small screens -->
                  <li class="d-sm-none">
                    <a class="dropdown-item" href="#" @click.prevent="showNotifications">
                      <i class="bi bi-bell me-2"></i>
                      Thông báo
                      <span v-if="notificationCount > 0" class="badge bg-success ms-auto">
                        {{ notificationCount > 99 ? '99+' : notificationCount }}
                      </span>
                    </a>
                  </li>
                  <li class="d-sm-none">
                    <hr class="dropdown-divider my-1">
                  </li>

                  <!-- Seller specific menu items -->
                  <!-- <li>
                    <a class="dropdown-item" href="#" @click.prevent="goToShopProfile">
                      <i class="bi bi-shop me-2"></i>Thông tin cửa hàng
                    </a>
                  </li> -->
                  <li>
                    <a class="dropdown-item" href="#" @click.prevent="goToProfile">
                      <i class="bi bi-person me-2"></i>Hồ sơ cá nhân
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="#" @click.prevent="openChangePasswordModal">
                      <i class="bi bi-lock me-2"></i>Đổi mật khẩu
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="#" @click.prevent="goToSettings">
                      <i class="bi bi-gear me-2"></i>Cài đặt cửa hàng
                    </a>
                  </li>
                  <li>
                    <hr class="dropdown-divider my-1">
                  </li>
                  <li>
                    <a class="dropdown-item text-danger" href="#" @click.prevent="confirmLogout">
                      <i class="bi bi-box-arrow-right me-2"></i>Đăng xuất
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main class="content p-3">
        <slot />
      </main>
    </div>

    <!-- Change Password Modal -->
    <div class="modal fade" :class="{ 'show': changePasswordModalOpen }"
      :style="{ display: changePasswordModalOpen ? 'block' : 'none' }" tabindex="-1"
      aria-labelledby="changePasswordModalLabel">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="changePasswordModalLabel">
              <i class="bi bi-lock me-2"></i>Đổi mật khẩu
            </h5>
            <button type="button" class="btn-close" @click="closeChangePasswordModal"></button>
          </div>
          <!-- Cập nhật các input trong modal -->
          <div class="modal-body">
            <form @submit.prevent="changePassword">
              <div class="mb-3">
                <label for="currentPassword" class="form-label">Mật khẩu hiện tại <span
                    class="text-danger">*</span></label>
                <div class="input-group">
                  <input :type="showCurrentPassword ? 'text' : 'password'" class="form-control" id="currentPassword"
                    v-model="passwordForm.currentPassword" :class="{ 'is-invalid': passwordErrors.currentPassword }"
                    placeholder="Nhập mật khẩu hiện tại" required autocomplete="current-password">
                  <button class="btn btn-outline-secondary" type="button"
                    @click="showCurrentPassword = !showCurrentPassword">
                    <i :class="showCurrentPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                  </button>
                </div>
                <div v-if="passwordErrors.currentPassword" class="invalid-feedback d-block">
                  {{ passwordErrors.currentPassword }}
                </div>
              </div>

              <div class="mb-3">
                <label for="newPassword" class="form-label">Mật khẩu mới <span class="text-danger">*</span></label>
                <div class="input-group">
                  <input :type="showNewPassword ? 'text' : 'password'" class="form-control" id="newPassword"
                    v-model="passwordForm.newPassword" :class="{ 'is-invalid': passwordErrors.newPassword }"
                    placeholder="Nhập mật khẩu mới" required autocomplete="new-password">
                  <button class="btn btn-outline-secondary" type="button" @click="showNewPassword = !showNewPassword">
                    <i :class="showNewPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                  </button>
                </div>
                <div v-if="passwordErrors.newPassword" class="invalid-feedback d-block">
                  {{ passwordErrors.newPassword }}
                </div>
                <small class="text-muted">Mật khẩu phải có ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường và số</small>
              </div>

              <div class="mb-3">
                <label for="confirmPassword" class="form-label">Xác nhận mật khẩu mới <span
                    class="text-danger">*</span></label>
                <div class="input-group">
                  <input :type="showConfirmPassword ? 'text' : 'password'" class="form-control" id="confirmPassword"
                    v-model="passwordForm.confirmPassword" :class="{ 'is-invalid': passwordErrors.confirmPassword }"
                    placeholder="Nhập lại mật khẩu mới" required autocomplete="new-password">
                  <button class="btn btn-outline-secondary" type="button"
                    @click="showConfirmPassword = !showConfirmPassword">
                    <i :class="showConfirmPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                  </button>
                </div>
                <div v-if="passwordErrors.confirmPassword" class="invalid-feedback d-block">
                  {{ passwordErrors.confirmPassword }}
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeChangePasswordModal">Hủy</button>
            <button type="button" class="btn btn-success" @click="changePassword" :disabled="passwordLoading">
              <span v-if="passwordLoading" class="spinner-border spinner-border-sm me-2"></span>
              <i v-else class="bi bi-check-lg me-1"></i>
              {{ passwordLoading ? 'Đang xử lý...' : 'Đổi mật khẩu' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Backdrop -->
    <div v-if="changePasswordModalOpen" class="modal-backdrop fade show" @click="closeChangePasswordModal"></div>
  </div>
</template>

<script setup>
import { computed, ref, onMounted, onUnmounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { profileService, profileUtils } from '@/services/auth/profile.js'
import { changepassService } from '@/services/auth/change-pass'
import Swal from 'sweetalert2'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

// State
const sidebarCollapsed = ref(false)
const isMobile = ref(false)
const dropdownOpen = ref(false)
const notificationCount = ref(3) // Mock notification count for seller
const dropdownButton = ref(null)
const dropdownMenu = ref(null)
const changePasswordModalOpen = ref(false)
const passwordLoading = ref(false)
const showCurrentPassword = ref(false)
const showNewPassword = ref(false)
const showConfirmPassword = ref(false)
const loginTime = ref(new Date()) // Track when user logged in

// User profile data
const userProfile = ref({
  uuid: null,
  fullName: '',
  firstName: '',
  lastName: '',
  email: '',
  phoneNumber: '',
  avatarUrl: null,
  metadata: null
})

// Loading states
const isLoadingProfile = ref(false)
const profileLoadError = ref(null)

// User stats for display
const userStats = ref({
  loginCount: 0,
  lastLogin: null,
  onlineTime: 0
})

// Form data
const passwordForm = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const passwordErrors = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: ''
})

// Computed
const pageTitle = computed(() => {
  const titles = {
    '/seller/dashboard': 'Dashboard',
    '/seller/products': 'Quản lý sản phẩm',
    '/seller/orders': 'Quản lý đơn hàng',
    '/seller/vouchers': 'Quản lý mã giảm giá',
    '/seller/revenue': 'Thống kê doanh thu',
    '/seller/support': 'Hỗ trợ khách hàng',
    '/seller/banners': 'Quản lý banner',
    '/seller/transactions': 'Lịch sử giao dịch',
    '/seller/profile': 'Hồ sơ cá nhân',
    '/seller/shop-profile': 'Thông tin cửa hàng',
    '/seller/settings': 'Cài đặt cửa hàng'
  }
  return titles[route.path] || 'Seller Panel'
})

// User info methods
const getUserDisplayName = () => {
  if (userProfile.value.firstName && userProfile.value.lastName) {
    return `${userProfile.value.firstName} ${userProfile.value.lastName}`
  }

  if (userProfile.value.fullName) {
    return userProfile.value.fullName
  }

  return userProfile.value.email || authStore.currentUser?.email || 'Seller User'
}

const getFirstName = () => {
  if (userProfile.value.firstName) {
    return userProfile.value.firstName
  }

  // Fallback to authStore or email
  return authStore.currentUser?.firstName ||
    userProfile.value.email?.split('@')[0] ||
    'Seller'
}

const getUserEmail = () => {
  return userProfile.value.email || authStore.currentUser?.email || 'seller@example.com'
}

const getUserRole = () => {
  return authStore.getUserRole() || 'Seller'
}

const getUserAvatar = () => {
  if (userProfile.value.avatarUrl) {
    return userProfile.value.avatarUrl
  }

  // Generate avatar from initials
  return generateAvatarUrl(getUserDisplayName())
}

const generateAvatarUrl = (name) => {
  // Use profileUtils to get initials
  const initials = profileUtils.getInitials(
    userProfile.value.firstName,
    userProfile.value.lastName
  )

  if (initials) {
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(initials)}&background=20c997&color=ffffff&size=128`
  }

  return '/src/assets/logoMuadima2.png'
}

const formatLastLogin = () => {
  const lastLogin = userStats.value.lastLogin || loginTime.value
  const now = new Date()
  const diffMs = now - lastLogin
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
  const diffMins = Math.floor(diffMs / (1000 * 60))

  if (diffHours > 0) {
    return `${diffHours}h`
  } else if (diffMins > 0) {
    return `${diffMins}m`
  } else {
    return 'Vừa xong'
  }
}

const getOnlineTime = () => {
  const now = new Date()
  const diffMs = now - loginTime.value
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
  const diffMins = Math.floor(diffMs / (1000 * 60))

  if (diffHours > 0) {
    return `${diffHours}h${diffMins % 60}m`
  } else {
    return `${diffMins}m`
  }
}

// Load user profile from API
const loadUserProfile = async () => {
  if (isLoadingProfile.value) return

  isLoadingProfile.value = true
  profileLoadError.value = null

  try {
   // console.log('Loading seller profile for layout...')
    const result = await profileService.getCurrentUserProfile()

    if (result.success) {
      const formattedData = profileService.formatUserData(result.data)
      userProfile.value = formattedData
      //console.log('Seller profile loaded for layout:', formattedData)
    } else {
      profileLoadError.value = result.message
      console.error('Failed to load seller profile for layout:', result.message)
    }
  } catch (error) {
    profileLoadError.value = 'Lỗi kết nối khi tải thông tin seller'
    console.error('Error loading seller profile for layout:', error)
  } finally {
    isLoadingProfile.value = false
  }
}

// Load user statistics
const loadUserStats = async () => {
  try {
    // Mock data - replace with actual API call to get seller stats
    userStats.value = {
      loginCount: Math.floor(Math.random() * 150) + 25, // Random login count for seller
      lastLogin: new Date(Date.now() - Math.random() * 12 * 60 * 60 * 1000), // Random time within last 12h
      onlineTime: 0
    }

    // Update online time every minute
    const onlineInterval = setInterval(() => {
      userStats.value.onlineTime = Math.floor((new Date() - loginTime.value) / 60000)
    }, 60000)

   

  } catch (error) {
    console.error('Error loading seller stats:', error)
  }
}

// Methods
const checkMobile = () => {
  const wasMobile = isMobile.value
  isMobile.value = window.innerWidth <= 768

  if (!wasMobile && isMobile.value) {
    sidebarCollapsed.value = true
  } else if (wasMobile && !isMobile.value) {
    sidebarCollapsed.value = false
  }

  // Close dropdown on resize to prevent positioning issues
  if (dropdownOpen.value) {
    closeDropdown()
  }
}

const toggleSidebar = () => {
  sidebarCollapsed.value = !sidebarCollapsed.value
}

const closeSidebar = () => {
  if (isMobile.value) {
    sidebarCollapsed.value = true
  }
}

const handleNavClick = () => {
  if (isMobile.value) {
    sidebarCollapsed.value = true
  }
  closeDropdown()
}

const toggleDropdown = async () => {
  dropdownOpen.value = !dropdownOpen.value

  if (dropdownOpen.value) {
    await nextTick()
    adjustDropdownPosition()
  }
}

const adjustDropdownPosition = () => {
  const dropdown = document.querySelector('.dropdown-menu')
  const button = document.querySelector('.dropdown-toggle')

  if (!dropdown || !button) return

  const buttonRect = button.getBoundingClientRect()
  const dropdownRect = dropdown.getBoundingClientRect()
  const viewportWidth = window.innerWidth
  const viewportHeight = window.innerHeight

  // Reset any previous positioning
  dropdown.style.transform = ''
  dropdown.style.left = ''
  dropdown.style.right = ''
  dropdown.style.top = ''

  // Check if dropdown goes beyond right edge
  if (buttonRect.right + dropdownRect.width > viewportWidth) {
    dropdown.style.right = '0'
    dropdown.style.left = 'auto'
  }

  // Check if dropdown goes beyond bottom edge
  if (buttonRect.bottom + dropdownRect.height > viewportHeight) {
    dropdown.style.top = 'auto'
    dropdown.style.bottom = '100%'
    dropdown.style.marginBottom = '0.25rem'
  }
}

const closeDropdown = () => {
  dropdownOpen.value = false
}

const handleAvatarError = (event) => {
  // Try to regenerate avatar URL first
  const fallbackAvatar = generateAvatarUrl(getUserDisplayName())
  if (event.target.src !== fallbackAvatar) {
    event.target.src = fallbackAvatar
  } else {
    // If even the generated avatar fails, use default
    event.target.src = '/src/assets/logoMuadima2.png'
  }
}

const showNotifications = () => {
  closeDropdown()
  Swal.fire({
    title: 'Thông báo Seller',
    html: `
      <div class="text-start">
        <p><i class="bi bi-info-circle text-primary me-2"></i>Bạn có 2 đơn hàng mới cần xử lý</p>
        <p><i class="bi bi-exclamation-triangle text-warning me-2"></i>Sản phẩm "ABC" sắp hết hàng</p>
        <p><i class="bi bi-check-circle text-success me-2"></i>Doanh thu tháng này tăng 15%</p>
      </div>
    `,
    icon: 'info',
    confirmButtonText: 'Đóng',
    confirmButtonColor: '#20c997'
  })
}

// Navigation functions
const goToShopProfile = () => {
  closeDropdown()
  router.push('/seller/shop-profile')
}

const goToProfile = () => {
  closeDropdown()
  router.push('/seller/profile')
}

const goToSettings = () => {
  closeDropdown()
  router.push('/seller/settings')
}

// Modal functions
const openChangePasswordModal = () => {
  closeDropdown()
  changePasswordModalOpen.value = true
  document.body.style.overflow = 'hidden'
  resetPasswordForm()
}

const closeChangePasswordModal = () => {
  changePasswordModalOpen.value = false
  document.body.style.overflow = 'auto'
  resetPasswordForm()
}

const resetPasswordForm = () => {
  passwordForm.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  }
  passwordErrors.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  }
  showCurrentPassword.value = false
  showNewPassword.value = false
  showConfirmPassword.value = false
}

const changePassword = async () => {
  if (!validatePassword()) {
    return;
  }

  try {
    passwordLoading.value = true;

    const payload = {
      oldPassword: passwordForm.value.currentPassword,
      newPassword: passwordForm.value.newPassword,
      confirmPassword: passwordForm.value.confirmPassword
    };

    const result = await changepassService.changePassword(payload);

    if (result.success) {
      closeChangePasswordModal();

      // Hiển thị thông báo thành công và sẽ tự động đăng xuất
      await Swal.fire({
        title: 'Đổi mật khẩu thành công',
        html: `
          <div class="text-start">
            <p>Mật khẩu của bạn đã được thay đổi thành công.</p>
            <p class="fw-bold mt-2 text-success">Bạn sẽ được đăng xuất tự động để áp dụng mật khẩu mới.</p>
          </div>
        `,
        icon: 'success',
        confirmButtonText: 'Đồng ý',
        confirmButtonColor: '#20c997',
        timer: 5000, // Tự động đóng sau 5 giây
        timerProgressBar: true,
        allowOutsideClick: false,
        didOpen: () => {
          // Bắt đầu đếm ngược để đăng xuất
          setTimeout(async () => {
            await authStore.logout();
            router.push('/seller/login');
          }, 5000);
        }
      });

      // Đăng xuất ngay lập tức (có thể bỏ setTimeout nếu muốn đăng xuất ngay)
      await authStore.logout();
      router.push('/seller/login');

    } else {
      // Xử lý lỗi từ server
      if (result.message.includes('Mật khẩu hiện tại')) {
        passwordErrors.value.currentPassword = result.message;
      } else {
        await Swal.fire({
          icon: 'error',
          title: 'Lỗi!',
          text: result.message,
          confirmButtonText: 'Đóng',
          confirmButtonColor: '#dc3545'
        });
      }
    }
  } catch (error) {
    console.error('Change password error:', error);
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Có lỗi xảy ra khi đổi mật khẩu. Vui lòng thử lại.',
      confirmButtonText: 'Đóng',
      confirmButtonColor: '#dc3545'
    });
  } finally {
    passwordLoading.value = false;
  }
};

const validatePassword = () => {
  passwordErrors.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  };

  let isValid = true;

  // Validate mật khẩu hiện tại
  if (!passwordForm.value.currentPassword) {
    passwordErrors.value.currentPassword = 'Vui lòng nhập mật khẩu hiện tại';
    isValid = false;
  }

  // Validate mật khẩu mới
  const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  
  if (!passwordForm.value.newPassword) {
    passwordErrors.value.newPassword = 'Vui lòng nhập mật khẩu mới';
    isValid = false;
  } else if (!strongPasswordRegex.test(passwordForm.value.newPassword)) {
    passwordErrors.value.newPassword = 'Mật khẩu phải chứa ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường, số và ký tự đặc biệt (@$!%*?&)';
    isValid = false;
  } else if (passwordForm.value.newPassword === passwordForm.value.currentPassword) {
    passwordErrors.value.newPassword = 'Mật khẩu mới phải khác mật khẩu hiện tại';
    isValid = false;
  }

  // Validate xác nhận mật khẩu
  if (!passwordForm.value.confirmPassword) {
    passwordErrors.value.confirmPassword = 'Vui lòng xác nhận mật khẩu mới';
    isValid = false;
  } else if (passwordForm.value.confirmPassword !== passwordForm.value.newPassword) {
    passwordErrors.value.confirmPassword = 'Mật khẩu xác nhận không khớp';
    isValid = false;
  }

  return isValid;
};

const confirmLogout = async () => {
  closeDropdown()

  const result = await Swal.fire({
    title: 'Xác nhận đăng xuất',
    text: 'Bạn có chắc chắn muốn đăng xuất khỏi Seller Portal?',
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Đăng xuất',
    cancelButtonText: 'Hủy'
  })

  if (result.isConfirmed) {
    try {
      // Show loading
      Swal.fire({
        title: 'Đang đăng xuất...',
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        didOpen: () => {
          Swal.showLoading()
        }
      })

      // Call logout from store
      await authStore.logout()

      // Close loading
      Swal.close()

      // Redirect to login
      await router.replace('/seller/login')

      // Reload page to ensure clean state
      window.location.reload()

      // Show success message
      await Swal.fire({
        icon: 'success',
        title: 'Đã đăng xuất',
        text: 'Bạn đã đăng xuất thành công khỏi Seller Portal',
        timer: 2000,
        showConfirmButton: false
      })
    } catch (error) {
      console.error('Logout error:', error)

      Swal.close()

      await Swal.fire({
        icon: 'error',
        title: 'Lỗi đăng xuất',
        text: 'Có lỗi xảy ra khi đăng xuất. Vui lòng thử lại.',
        confirmButtonText: 'Đóng',
        confirmButtonColor: '#dc3545'
      })
    }
  }
}

// Event handlers
const handleClickOutside = (event) => {
  if (dropdownButton.value && dropdownMenu.value) {
    if (!dropdownButton.value.contains(event.target) &&
      !dropdownMenu.value.contains(event.target)) {
      closeDropdown()
    }
  }
}

const handleKeyPress = (event) => {
  if (event.key === 'Escape') {
    if (changePasswordModalOpen.value) {
      closeChangePasswordModal()
    } else if (isMobile.value && !sidebarCollapsed.value) {
      closeSidebar()
    } else if (dropdownOpen.value) {
      closeDropdown()
    }
  }
}

// Lifecycle
onMounted(async () => {
  await nextTick()

  // Initialize auth store
  authStore.initializeAuth()

  // Check authentication
  if (!authStore.isAuthenticated || !authStore.hasRole('SELLER')) {
    console.log('User not authenticated or not seller, redirecting to login')
    await router.replace('/seller/login')
    return
  }

  checkMobile()
  loadUserProfile() // Load user profile first
  loadUserStats()   // Then load stats

  window.addEventListener('resize', checkMobile)
  document.addEventListener('keydown', handleKeyPress)
  document.addEventListener('click', handleClickOutside)

  // Close dropdown on scroll to prevent positioning issues
  window.addEventListener('scroll', () => {
    if (dropdownOpen.value) {
      closeDropdown()
    }
  })

  // Watch for auth store changes to reload profile
  const unwatch = authStore.$subscribe((mutation, state) => {
    if (state.isAuthenticated && !isLoadingProfile.value) {
      // Reload profile when auth state changes
      loadUserProfile()
    }
  })

})

onUnmounted(() => {
  window.removeEventListener('resize', checkMobile)
  document.removeEventListener('keydown', handleKeyPress)
  document.removeEventListener('click', handleClickOutside)
  document.body.style.overflow = 'auto'
})
</script>

<style scoped>
.seller-layout {
  display: flex;
  min-height: 100vh;
  position: relative;
}

/* Sidebar Styles */
.sidebar {
  width: 250px;
  position: fixed;
  height: 100vh;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  z-index: 1000;
  transition: width 0.3s ease, transform 0.3s ease;
  background: linear-gradient(135deg, #181818, #20c997 100%);
  color: #181818;
}

.sidebar.collapsed {
  width: 60px;
}

.sidebar-user {
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 0.5rem;
  margin: 0 0.5rem;
}

/* Main Content */
.main-content {
  margin-left: 250px;
  width: calc(100% - 250px);
  background-color: #f8f9fa;
  min-height: 100vh;
  transition: margin-left 0.3s ease, width 0.3s ease;
}

.main-content.sidebar-collapsed {
  margin-left: 60px;
  width: calc(100% - 60px);
}

/* Header */
.header {
  position: sticky;
  top: 0;
  z-index: 999;
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(0, 0, 0, 0.1) !important;
}

/* Navigation Links */
.nav-link {
  padding: 0.75rem 1rem;
  border-radius: 0.5rem;
  margin: 0 0.5rem;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
}

.nav-link:hover {
  background-color: rgba(255, 255, 255, 0.1);
  transform: translateX(2px);
}

.nav-link.active,
.nav-link.router-link-active {
  background-color: rgba(255, 255, 255, 0.2);
}

.nav-link i {
  width: 1.25rem;
  text-align: center;
  margin-right: 0.5rem;
}

.sidebar.collapsed .nav-link {
  padding: 0.75rem;
  text-align: center;
}

.sidebar.collapsed .nav-link i {
  margin-right: 0;
}

.sidebar.collapsed .nav-link span {
  display: none;
}

/* Dropdown Improvements */
.dropdown {
  position: relative;
}

.dropdown-menu {
  border: none;
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
  min-width: 280px;
  max-width: 320px;
  border-radius: 0.5rem;
  overflow: hidden;
  z-index: 1050;
  margin-top: 0.25rem;
}

.dropdown-menu.show {
  display: block;
  animation: dropdownSlideIn 0.15s ease-out;
}

@keyframes dropdownSlideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dropdown-header {
  padding: 1rem;
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
  white-space: normal;
}

.dropdown-item {
  padding: 0.75rem 1rem;
  transition: all 0.15s ease;
  display: flex;
  align-items: center;
  white-space: nowrap;
}

.dropdown-item:hover {
  background-color: #f8f9fa;
  transform: translateX(2px);
}

.dropdown-item.text-danger:hover {
  background-color: #f8d7da;
  color: #721c24 !important;
}

.dropdown-divider {
  margin: 0.25rem 0;
}

/* Mobile Overlay */
.mobile-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 999;
}

/* Responsive Design */
@media (max-width: 768px) {
  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.mobile-open {
    transform: translateX(0);
  }

  .main-content {
    margin-left: 0;
  }

  .main-content.sidebar-collapsed {
    margin-left: 0;
  }

  .dropdown-menu {
    min-width: 260px;
    max-width: calc(100vw - 2rem);
    position: fixed !important;
    right: 1rem !important;
    left: auto !important;
    transform: none !important;
  }
}

@media (max-width: 576px) {
  .dropdown-menu {
    min-width: 240px;
    font-size: 0.875rem;
  }

  .dropdown-item {
    padding: 0.625rem 0.875rem;
  }

  .dropdown-header {
    padding: 0.875rem;
  }
}

@media (max-width: 420px) {
  .dropdown-menu {
    min-width: calc(100vw - 1rem);
    right: 0.5rem !important;
  }

  .main-content .p-3 {
    padding: 1rem !important;
  }
}

/* Modal z-index fix */
.modal {
  z-index: 1060;
}

.modal-backdrop {
  z-index: 1040;
}

/* Avatar improvements */
img.rounded-circle {
  object-fit: cover;
  border: 2px solid rgba(255, 255, 255, 0.2);
  transition: all 0.15s ease;
}

img.rounded-circle:hover {
  border-color: rgba(255, 255, 255, 0.4);
  transform: scale(1.05);
}

/* Badge improvements */
.badge {
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
}

/* Text truncation improvements */
.text-truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Button hover effects */
.btn {
  transition: all 0.15s ease;
}

.btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 0.25rem 0.5rem rgba(0, 0, 0, 0.1);
}

.btn:active {
  transform: translateY(0);
}

/* Scrollbar styling */
.sidebar::-webkit-scrollbar {
  width: 4px;
}

.sidebar::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.1);
}

.sidebar::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.3);
  border-radius: 2px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.5);
}

/* Success theme colors */
.btn-success {
  background-color: #20c997;
  border-color: #20c997;
}

.btn-success:hover {
  background-color: #1aa179;
  border-color: #1aa179;
}

.text-success {
  color: #20c997 !important;
}

.bg-success {
  background-color: #20c997 !important;
}

/* Smooth animations */
* {
  transition: all 0.15s ease;
}

/* Placeholder styling for loading states */
.placeholder {
  display: inline-block;
  min-height: 1em;
  vertical-align: middle;
  cursor: wait;
  background-color: currentColor;
  opacity: 0.5;
}

.placeholder.col-4 {
  width: 33.33%;
}

.placeholder.col-6 {
  width: 50%;
}

.placeholder.col-8 {
  width: 66.66%;
}

.placeholder.col-10 {
  width: 83.33%;
}

.placeholder-glow .placeholder {
  animation: placeholder-glow 2s ease-in-out infinite alternate;
}

@keyframes placeholder-glow {
  50% {
    opacity: 0.2;
  }
}

.placeholder.rounded-circle {
  border-radius: 50% !important;
}
</style>
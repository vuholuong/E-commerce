<template>
  <div class="auto-login-demo">
    <div class="card">
      <div class="card-header">
        <h5 class="mb-0">
          <i class="bi bi-link-45deg"></i> Auto Login Demo
        </h5>
      </div>
      <div class="card-body">
        <div class="row">
          <!-- Token Input -->
          <div class="col-md-6 mb-3">
            <label for="tokenInput" class="form-label">JWT Token</label>
            <textarea
              id="tokenInput"
              v-model="tokenInput"
              class="form-control"
              rows="3"
              placeholder="Nhập JWT token để test..."
            ></textarea>
            <div class="form-text">
              Nhập JWT token để test tính năng auto login
            </div>
          </div>
          
          <!-- URL Preview -->
          <div class="col-md-6 mb-3">
            <label class="form-label">URL Preview</label>
            <div class="url-preview">
              <div v-if="shopUrl" class="mb-2">
                <strong>Shop Management:</strong>
                <div class="text-break small text-muted">{{ shopUrl }}</div>
              </div>
              <div v-if="adminUrl" class="mb-2">
                <strong>Admin Management:</strong>
                <div class="text-break small text-muted">{{ adminUrl }}</div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Action Buttons -->
        <div class="row">
          <div class="col-12">
            <div class="d-flex gap-2 flex-wrap">
              <!-- Test Auto Login -->
              <button 
                @click="testAutoLogin"
                class="btn btn-primary"
                :disabled="!tokenInput"
              >
                <i class="bi bi-play-circle"></i> Test Auto Login
              </button>
              
              <!-- Open Shop Management -->
              <button 
                @click="openShopManagement"
                class="btn btn-success"
                :disabled="!tokenInput"
              >
                <i class="bi bi-shop"></i> Mở Quản lý Shop
              </button>
              
              <!-- Open Admin Management -->
              <button 
                @click="openAdminManagement"
                class="btn btn-warning"
                :disabled="!tokenInput"
              >
                <i class="bi bi-gear"></i> Mở Quản lý Admin
              </button>
              
              <!-- Copy URLs -->
              <button 
                @click="copyShopUrl"
                class="btn btn-outline-success"
                :disabled="!shopUrl"
              >
                <i class="bi bi-clipboard"></i> Copy Shop URL
              </button>
              
              <button 
                @click="copyAdminUrl"
                class="btn btn-outline-warning"
                :disabled="!adminUrl"
              >
                <i class="bi bi-clipboard"></i> Copy Admin URL
              </button>
            </div>
          </div>
        </div>
        
        <!-- Status -->
        <div v-if="status" class="mt-3">
          <div :class="`alert alert-${status.type}`" role="alert">
            <i :class="`bi bi-${status.icon}`"></i> {{ status.message }}
          </div>
        </div>
      </div>
    </div>
    
    <!-- Instructions -->
    <div class="card mt-3">
      <div class="card-header">
        <h6 class="mb-0">
          <i class="bi bi-info-circle"></i> Hướng dẫn sử dụng
        </h6>
      </div>
      <div class="card-body">
        <ol class="mb-0">
          <li>Nhập JWT token vào ô input</li>
          <li>Click "Test Auto Login" để test tính năng tự động đăng nhập</li>
          <li>Click "Mở Quản lý Shop/Admin" để mở tab mới với token</li>
          <li>Copy URL để chia sẻ hoặc test</li>
          <li>Khi mở URL với token, trang sẽ tự động đăng nhập</li>
        </ol>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import { 
  createShopManagementUrl, 
  createAdminManagementUrl,
  openShopManagementInNewTab,
  openAdminManagementInNewTab
} from '@/utils/redirectUtils'

const tokenInput = ref('')
const status = ref(null)

// Computed URLs
const shopUrl = computed(() => {
  if (!tokenInput.value) return null
  return createShopManagementUrl(tokenInput.value)
})

const adminUrl = computed(() => {
  if (!tokenInput.value) return null
  return createAdminManagementUrl(tokenInput.value)
})

// Watch token input để update URLs
watch(tokenInput, (newToken) => {
  if (newToken) {
    console.log('🔑 Token đã được nhập, cập nhật URLs...')
  }
})

// Test Auto Login
const testAutoLogin = () => {
  try {
    if (!tokenInput.value) {
      showStatus('warning', 'exclamation-triangle', 'Vui lòng nhập JWT token')
      return
    }
    
    // Lưu token vào localStorage để test
    localStorage.setItem('app_access_token', tokenInput.value)
    
    // Trigger auto login
    window.dispatchEvent(new CustomEvent('userLoggedIn', {
      detail: { 
        userData: { 
          username: 'test-user',
          role: [{ authority: 'ROLE_SELLER' }]
        } 
      }
    }))
    
    showStatus('success', 'check-circle', 'Auto login test thành công! Kiểm tra notification.')
    
  } catch (error) {
    console.error('❌ Lỗi khi test auto login:', error)
    showStatus('danger', 'x-circle', 'Lỗi khi test auto login: ' + error.message)
  }
}

// Open Shop Management
const openShopManagement = () => {
  try {
    if (!tokenInput.value) {
      showStatus('warning', 'exclamation-triangle', 'Vui lòng nhập JWT token')
      return
    }
    
    openShopManagementInNewTab(tokenInput.value)
    showStatus('success', 'check-circle', 'Đã mở tab mới quản lý shop')
    
  } catch (error) {
    console.error('❌ Lỗi khi mở shop management:', error)
    showStatus('danger', 'x-circle', 'Lỗi khi mở shop management: ' + error.message)
  }
}

// Open Admin Management
const openAdminManagement = () => {
  try {
    if (!tokenInput.value) {
      showStatus('warning', 'exclamation-triangle', 'Vui lòng nhập JWT token')
      return
    }
    
    openAdminManagementInNewTab(tokenInput.value)
    showStatus('success', 'check-circle', 'Đã mở tab mới quản lý admin')
    
  } catch (error) {
    console.error('❌ Lỗi khi mở admin management:', error)
    showStatus('danger', 'x-circle', 'Lỗi khi mở admin management: ' + error.message)
  }
}

// Copy Shop URL
const copyShopUrl = async () => {
  try {
    if (!shopUrl.value) return
    
    await navigator.clipboard.writeText(shopUrl.value)
    showStatus('success', 'check-circle', 'Đã copy shop URL vào clipboard')
    
  } catch (error) {
    console.error('❌ Lỗi khi copy shop URL:', error)
    showStatus('danger', 'x-circle', 'Lỗi khi copy URL: ' + error.message)
  }
}

// Copy Admin URL
const copyAdminUrl = async () => {
  try {
    if (!adminUrl.value) return
    
    await navigator.clipboard.writeText(adminUrl.value)
    showStatus('success', 'check-circle', 'Đã copy admin URL vào clipboard')
    
  } catch (error) {
    console.error('❌ Lỗi khi copy admin URL:', error)
    showStatus('danger', 'x-circle', 'Lỗi khi copy URL: ' + error.message)
  }
}

// Show status message
const showStatus = (type, icon, message) => {
  status.value = { type, icon, message }
  
  // Auto hide sau 5 giây
  setTimeout(() => {
    status.value = null
  }, 5000)
}

// Load sample token từ localStorage nếu có
onMounted(() => {
  const existingToken = localStorage.getItem('app_access_token')
  if (existingToken) {
    tokenInput.value = existingToken
    console.log('🔑 Loaded existing token from localStorage')
  }
})
</script>

<style scoped>
.auto-login-demo {
  max-width: 800px;
  margin: 0 auto;
}

.url-preview {
  background-color: #f8f9fa;
  border: 1px solid #dee2e6;
  border-radius: 0.375rem;
  padding: 0.75rem;
  min-height: 100px;
}

.text-break {
  word-break: break-all;
}

.btn {
  white-space: nowrap;
}

@media (max-width: 768px) {
  .d-flex.gap-2 {
    flex-direction: column;
  }
  
  .btn {
    width: 100%;
    margin-bottom: 0.5rem;
  }
}
</style>

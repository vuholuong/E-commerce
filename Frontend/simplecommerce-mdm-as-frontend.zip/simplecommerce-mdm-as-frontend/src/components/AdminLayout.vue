<template>
  <div class="admin-layout">
    <!-- Mobile Overlay -->
    <div v-if="isMobile && !sidebarCollapsed" class="mobile-overlay" @click="closeSidebar"></div>

    <!-- Sidebar -->
    <nav class="sidebar bg-dark fw-bold text-white"
      :class="{'collapsed': sidebarCollapsed,'mobile-open': isMobile && !sidebarCollapsed}">
      <div class="sidebar-header p-3">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h4 v-if="!sidebarCollapsed || isMobile">Admin Panel</h4>
            <h6 v-else>AP</h6>
          </div>
          <!-- Close button for mobile -->
          <button v-if="isMobile && !sidebarCollapsed" @click="closeSidebar" class="btn btn-sm btn-outline-light ms-2">
            <i class="bi bi-x-lg"></i>
          </button>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <ul class="nav flex-column">
        <li class="nav-item mb-1">
          <router-link to="/admin/dashboard" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Dashboard' : ''" @click="handleNavClick">
            <i class="bi bi-speedometer2"></i>
            <span v-if="!sidebarCollapsed || isMobile">Dashboard</span>
          </router-link>
        </li>
        <li class="nav-item mb-1">
          <router-link to="/admin/products" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý sản phẩm' : ''" @click="handleNavClick">
            <i class="bi bi-box"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý sản phẩm</span>
          </router-link>
        </li>
        <li class="nav-item mb-1">
          <router-link to="/admin/categories" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý danh mục' : ''" @click="handleNavClick">
            <i class="bi bi-tags"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý danh mục</span>
          </router-link>
        </li>
        <li class="nav-item mb-1">
          <router-link to="/admin/users" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý người dùng' : ''" @click="handleNavClick">
            <i class="bi bi-people"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý người dùng</span>
          </router-link>
        </li>
        <li class="nav-item mb-1">
          <router-link to="/admin/sellers" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý cửa hàng' : ''" @click="handleNavClick">
            <i class="bi bi-shop"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý cửa hàng</span>
          </router-link>
        </li>
        <li class="nav-item mb-1">
          <router-link to="/admin/orders" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý đơn hàng shop' : ''" @click="handleNavClick">
            <i class="bi bi-cart"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý đơn hàng shop</span>
          </router-link>
        </li>
        <!-- thêm quản lí đơn hàng tổng -->
         <li class="nav-item mb-1">
          <router-link to="/admin/vouchers" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý đơn hàng tổng' : ''" @click="handleNavClick">
            <i class="bi bi-ticket-perforated"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý đơn hàng tổng</span>
          </router-link>
        </li>

        <li class="nav-item mb-1">
          <router-link to="/admin/banners" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Quản lý bài đánh giá' : ''" @click="handleNavClick">
            <i class="bi bi-calendar2-week"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý bài đánh giá</span>
          </router-link>
        </li>
        <!-- <li class="nav-item mb-1">
          <router-link to="/admin/vouchers" class="nav-link text-white"
                       :title="sidebarCollapsed && !isMobile ? 'Quản lý vouchers' : ''"
                       @click="handleNavClick">
            <i class="bi bi-ticket-perforated"></i>
            <span v-if="!sidebarCollapsed || isMobile">Quản lý vouchers</span>
          </router-link>
        </li> -->
        <li class="nav-item mb-1">
          <router-link to="/admin/reports" class="nav-link text-white"
            :title="sidebarCollapsed && !isMobile ? 'Địa chỉ' : ''" @click="handleNavClick">
            <i class="bi bi-geo-alt"></i>
            <span v-if="!sidebarCollapsed || isMobile">Địa chỉ</span>
          </router-link>
        </li>
      </ul>

      <!-- User info in sidebar -->
      <div class="sidebar-user mt-auto p-3 border-top border-secondary">
        <!-- Loading state -->
        <div v-if="isLoadingProfile" class="text-center mb-2">
          <div class="spinner-border spinner-border-sm text-light" role="status">
            <span class="visually-hidden">Đang tải...</span>
          </div>
          <div class="small text-light mt-1">Đang tải...</div>
        </div>

        <!-- Profile loaded -->
        <div v-else-if="!profileLoadError" class="mb-2">
          <div v-if="!sidebarCollapsed || isMobile" class="d-flex align-items-center">
            <img :src="getUserAvatar()" :alt="getUserDisplayName()" class="rounded-circle me-2" width="32" height="32"
              @error="handleAvatarError">
            <div class="flex-grow-1 text-truncate ms-2">
              <div class="small fw-bold text-center">{{ getUserRole() }}</div>
              <div class="fw-bold small text-truncate">{{ getUserDisplayName() }}</div>
            </div>
          </div>

          <!-- Collapsed sidebar avatar -->
          <div v-else class="text-center">
            <img :src="getUserAvatar()" :alt="getUserDisplayName()" class="rounded-circle" width="40" height="40"
              @error="handleAvatarError" :title="getUserDisplayName()">
          </div>
        </div>

        <!-- Error state -->
        <div v-else class="text-center mb-2">
          <i class="bi bi-exclamation-triangle text-warning"></i>
          <div class="small text-light mt-1">Lỗi tải thông tin</div>
        </div>

        <button @click="confirmLogout" class="btn btn-outline-light btn-sm w-100 fw-bold"
          :title="sidebarCollapsed && !isMobile ? 'Đăng xuất' : ''">
          <i class="bi bi-box-arrow-right"></i>
          <span v-if="!sidebarCollapsed || isMobile"> Đăng xuất</span>
        </button>
      </div>
    </nav>

    <!-- Main content -->
    <div class="main-content" :class="{ 'sidebar-collapsed': sidebarCollapsed }">
      <!-- Header -->
      <header class="header bg-white shadow-sm border-bottom">
        <div class="container-fluid">
          <div class="d-flex justify-content-between align-items-center p-3">
            <div class="d-flex align-items-center">
              <button @click="toggleSidebar" class="btn btn-outline-secondary me-3">
                <i class="bi bi-list"></i>
              </button>
              <h5 class="mb-0 d-none d-sm-block">{{ pageTitle }}</h5>
              <h6 class="mb-0 d-sm-none">{{ pageTitle.length > 20 ? pageTitle.substring(0, 20) + '...' : pageTitle }}
              </h6>
            </div>

            <!-- User Header Info -->
            <div class="d-flex align-items-center">
              <!-- Notifications - Hidden on very small screens -->
              <!-- <div class="me-2 me-md-3 d-none d-sm-block">
                <button class="btn btn-outline-secondary position-relative" @click="showNotifications">
                  <i class="bi bi-bell"></i>
                  <span v-if="notificationCount > 0"
                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    {{ notificationCount > 99 ? '99+' : notificationCount }}
                  </span>
                </button>
              </div> -->

              <!-- User Dropdown -->
              <div class="dropdown position-relative">
                <button class="btn btn-outline-secondary dropdown-toggle d-flex align-items-center" type="button"
                  ref="dropdownButton" @click="toggleDropdown" :disabled="isLoadingProfile" aria-expanded="false">
                  <!-- Loading avatar -->
                  <div v-if="isLoadingProfile" class="rounded-circle me-2 placeholder-glow"
                    style="width: 32px; height: 32px;">
                    <div class="placeholder rounded-circle w-100 h-100"></div>
                  </div>
                  <!-- Loaded avatar -->
                  <img v-else :src="getUserAvatar()" :alt="getUserDisplayName()" class="rounded-circle me-2" width="32"
                    height="32" @error="handleAvatarError">

                  <!-- User info - Hidden on small screens -->
                  <div class="d-none d-lg-block text-start">
                    <div v-if="isLoadingProfile" class="placeholder-glow">
                      <div class="placeholder col-8 fw-bold small"></div>
                      <div class="placeholder col-6 text-muted small"></div>
                    </div>
                    <div v-else>
                      <div class="fw-bold small">{{ getUserDisplayName() }}</div>
                      <!-- <div class="text-muted small">{{ getUserRole() }}</div> -->
                    </div>
                  </div>
                  <i class="bi bi-chevron-down ms-2 d-none d-md-inline"></i>
                </button>

                <!-- Dropdown Menu with better positioning -->
                <ul class="dropdown-menu dropdown-menu-end shadow border-0" :class="{ 'show': dropdownOpen }"
                  ref="dropdownMenu">
                  <!-- User Info Header -->
                  <li class="dropdown-header bg-light">
                    <div v-if="isLoadingProfile" class="d-flex align-items-center">
                      <div class="placeholder-glow me-2">
                        <div class="placeholder rounded-circle" style="width: 40px; height: 40px;"></div>
                      </div>
                      <div class="flex-grow-1 placeholder-glow">
                        <div class="placeholder col-8 fw-bold"></div>
                        <div class="placeholder col-10 text-muted small"></div>
                        <div class="placeholder col-4 badge bg-primary small mt-1"></div>
                      </div>
                    </div>
                    <div v-else-if="!profileLoadError" class="d-flex align-items-center">
                      <img :src="getUserAvatar()" :alt="getUserDisplayName()" class="rounded-circle me-2" width="40"
                        height="40" @error="handleAvatarError">
                      <div class="flex-grow-1">
                        <div class="fw-bold text-truncate">{{ getUserDisplayName() }}</div>
                        <div class="text-muted small text-truncate">{{ getUserEmail() }}</div>
                        <div class="badge bg-primary small mt-1">{{ getUserRole() }}</div>
                      </div>
                    </div>
                    <div v-else class="text-center text-muted">
                      <i class="bi bi-exclamation-triangle"></i>
                      <div class="small">Không thể tải thông tin</div>
                    </div>
                  </li>
                  <li>
                    <hr class="dropdown-divider my-1">
                  </li>

                  <!-- User Stats -->
                  <!-- <li class="dropdown-header bg-light border-top">
                    <div class="row text-center">
                      <div class="col-4">
                        <div class="fw-bold text-primary">{{ userStats.loginCount }}</div>
                        <small class="text-muted">Đăng nhập</small>
                      </div>
                      <div class="col-4 border-start border-end">
                        <div class="fw-bold text-success">{{ formatLastLogin() }}</div>
                        <small class="text-muted">Lần cuối</small>
                      </div>
                      <div class="col-4">
                        <div class="fw-bold text-info">{{ getOnlineTime() }}</div>
                        <small class="text-muted">Online</small>
                      </div>
                    </div>
                  </li> -->
                  <li>
                    <hr class="dropdown-divider my-1">
                  </li>

                  <!-- Notifications - Only show on small screens -->
                  <li class="d-sm-none">
                    <a class="dropdown-item" href="#" @click.prevent="showNotifications">
                      <i class="bi bi-bell me-2"></i>
                      Thông báo
                      <span v-if="notificationCount > 0" class="badge bg-danger ms-auto">
                        {{ notificationCount > 99 ? '99+' : notificationCount }}
                      </span>
                    </a>
                  </li>
                  <li class="d-sm-none">
                    <hr class="dropdown-divider my-1">
                  </li>

                  <!-- Menu Items -->
                  <li>
                    <a class="dropdown-item" href="#" @click.prevent="goToProfile">
                      <i class="bi bi-person me-2"></i>Hồ sơ cá nhân
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="#" @click.prevent="openChangePasswordModal">
                      <i class="bi bi-lock me-2"></i>Đổi mật khẩu
                    </a>
                  </li>
                  <!-- <li>
                    <a class="dropdown-item" href="#" @click.prevent="openSettingsModal">
                      <i class="bi bi-gear me-2"></i>Cài đặt
                    </a>
                  </li> -->
                  <li>
                    <hr class="dropdown-divider my-1">
                  </li>
                  <li>
                    <a class="dropdown-item text-danger" href="#" @click.prevent="confirmLogout">
                      <i class="bi bi-box-arrow-right me-2"></i>Đăng xuất
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main class="content p-3">
        <slot />
      </main>
    </div>

    <!-- Change Password Modal -->
    <div class="modal fade" :class="{ 'show': changePasswordModalOpen }"
      :style="{ display: changePasswordModalOpen ? 'block' : 'none' }" tabindex="-1"
      aria-labelledby="changePasswordModalLabel">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="changePasswordModalLabel">
              <i class="bi bi-lock me-2"></i>Đổi mật khẩu
            </h5>
            <button type="button" class="btn-close" @click="closeChangePasswordModal"></button>
          </div>
          <!-- Cập nhật các input trong modal -->
          <div class="modal-body">
            <form @submit.prevent="changePassword">
              <div class="mb-3">
                <label for="currentPassword" class="form-label">Mật khẩu hiện tại <span
                    class="text-danger">*</span></label>
                <div class="input-group">
                  <input :type="showCurrentPassword ? 'text' : 'password'" class="form-control" id="currentPassword"
                    v-model="passwordForm.currentPassword" :class="{ 'is-invalid': passwordErrors.currentPassword }"
                    placeholder="Nhập mật khẩu hiện tại" required autocomplete="current-password">
                  <button class="btn btn-outline-secondary" type="button"
                    @click="showCurrentPassword = !showCurrentPassword">
                    <i :class="showCurrentPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                  </button>
                </div>
                <div v-if="passwordErrors.currentPassword" class="invalid-feedback d-block">
                  {{ passwordErrors.currentPassword }}
                </div>
              </div>

              <div class="mb-3">
                <label for="newPassword" class="form-label">Mật khẩu mới <span class="text-danger">*</span></label>
                <div class="input-group">
                  <input :type="showNewPassword ? 'text' : 'password'" class="form-control" id="newPassword"
                    v-model="passwordForm.newPassword" :class="{ 'is-invalid': passwordErrors.newPassword }"
                    placeholder="Nhập mật khẩu mới" required autocomplete="new-password">
                  <button class="btn btn-outline-secondary" type="button" @click="showNewPassword = !showNewPassword">
                    <i :class="showNewPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                  </button>
                </div>
                <div v-if="passwordErrors.newPassword" class="invalid-feedback d-block">
                  {{ passwordErrors.newPassword }}
                </div>
                <small class="text-muted">Mật khẩu phải có ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường và số</small>
              </div>

              <div class="mb-3">
                <label for="confirmPassword" class="form-label">Xác nhận mật khẩu mới <span
                    class="text-danger">*</span></label>
                <div class="input-group">
                  <input :type="showConfirmPassword ? 'text' : 'password'" class="form-control" id="confirmPassword"
                    v-model="passwordForm.confirmPassword" :class="{ 'is-invalid': passwordErrors.confirmPassword }"
                    placeholder="Nhập lại mật khẩu mới" required autocomplete="new-password">
                  <button class="btn btn-outline-secondary" type="button"
                    @click="showConfirmPassword = !showConfirmPassword">
                    <i :class="showConfirmPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                  </button>
                </div>
                <div v-if="passwordErrors.confirmPassword" class="invalid-feedback d-block">
                  {{ passwordErrors.confirmPassword }}
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeChangePasswordModal">Hủy</button>
            <button type="button" class="btn btn-primary" @click="changePassword" :disabled="passwordLoading">
              <span v-if="passwordLoading" class="spinner-border spinner-border-sm me-2"></span>
              <i v-else class="bi bi-check-lg me-1"></i>
              {{ passwordLoading ? 'Đang xử lý...' : 'Đổi mật khẩu' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Settings Modal -->
    <div class="modal fade" :class="{ 'show': settingsModalOpen }"
      :style="{ display: settingsModalOpen ? 'block' : 'none' }" tabindex="-1" aria-labelledby="settingsModalLabel">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="settingsModalLabel">
              <i class="bi bi-gear me-2"></i>Cài đặt hệ thống
            </h5>
            <button type="button" class="btn-close" @click="closeSettingsModal"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-12">
                <h6 class="fw-bold mb-3">Cài đặt chung</h6>
                <div class="mb-3">
                  <label for="systemName" class="form-label">Tên hệ thống</label>
                  <input type="text" class="form-control" id="systemName" v-model="settings.systemName">
                </div>
                <div class="mb-3">
                  <label for="systemEmail" class="form-label">Email hệ thống</label>
                  <input type="email" class="form-control" id="systemEmail" v-model="settings.systemEmail">
                </div>
                <div class="mb-3">
                  <label for="systemPhone" class="form-label">Số điện thoại</label>
                  <input type="tel" class="form-control" id="systemPhone" v-model="settings.systemPhone">
                </div>
                <hr>
                <h6 class="fw-bold mb-3">Cài đặt bảo mật</h6>
                <div class="mb-3">
                  <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="maintenanceMode"
                      v-model="settings.maintenanceMode">
                    <label class="form-check-label" for="maintenanceMode">Chế độ bảo trì</label>
                  </div>
                </div>
                <div class="mb-3">
                  <label for="sessionTimeout" class="form-label">Thời gian hết hạn phiên (phút)</label>
                  <input type="number" class="form-control" id="sessionTimeout" v-model="settings.sessionTimeout"
                    min="1" max="1440">
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeSettingsModal">Hủy</button>
            <button type="button" class="btn btn-primary" @click="saveSettings">
              <i class="bi bi-check-lg me-1"></i>Lưu cài đặt
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Backdrop -->
    <div v-if="settingsModalOpen || changePasswordModalOpen" class="modal-backdrop fade show" @click="closeAllModals">
    </div>
  </div>
</template>

<script setup>
import {computed, ref, onMounted, onUnmounted, nextTick} from 'vue'
import {useRoute, useRouter} from 'vue-router'
import {useAuthStore} from '@/stores/auth'
import { profileService, profileUtils } from '@/services/auth/profile.js'
import { changepassService } from '@/services/auth/change-pass'
import Swal from 'sweetalert2'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

// State
const sidebarCollapsed = ref(false)
const isMobile = ref(false)
const dropdownOpen = ref(false)
const notificationCount = ref(5) // Mock notification count
const loginTime = ref(new Date()) // Track when user logged in

// User profile data
const userProfile = ref({
  uuid: null,
  fullName: '',
  firstName: '',
  lastName: '',
  email: '',
  phoneNumber: '',
  avatarUrl: null,
  metadata: null
})

// Loading states
const isLoadingProfile = ref(false)
const profileLoadError = ref(null)

// User stats for display
const userStats = ref({
  loginCount: 0,
  lastLogin: null,
  onlineTime: 0
})

// Modal states
const settingsModalOpen = ref(false)
const changePasswordModalOpen = ref(false)
const passwordLoading = ref(false)
const showCurrentPassword = ref(false)
const showNewPassword = ref(false)
const showConfirmPassword = ref(false)

// Form data
const passwordForm = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const passwordErrors = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const settings = ref({
  systemName: 'Admin Panel',
  systemEmail: 'admin@example.com',
  systemPhone: '+84 123 456 789',
  maintenanceMode: false,
  sessionTimeout: 60
})

// Computed
const pageTitle = computed(() => {
  const titles = {
    '/admin/dashboard': 'Dashboard',
    '/admin/products': 'Quản lý sản phẩm',
    '/admin/categories': 'Quản lý danh mục',
    '/admin/users': 'Quản lý người dùng',
    '/admin/sellers': 'Quản lý cửa hàng',
    '/admin/orders': 'Quản lý đơn hàng shop',
    '/admin/banners': 'Quản lý bài đánh giá',
    '/admin/vouchers': 'Quản lý đơn hàng tổng',
    '/admin/reports': 'Địa chỉ',
    '/admin/profile': 'Hồ sơ cá nhân'
  }
  return titles[route.path] || 'Admin Panel'
})

// User info methods
const getUserDisplayName = () => {
  if (userProfile.value.firstName && userProfile.value.lastName) {
    return `${userProfile.value.firstName} ${userProfile.value.lastName}`
  }
  
  if (userProfile.value.fullName) {
    return userProfile.value.fullName
  }
  
  return userProfile.value.email || authStore.currentUser?.email || 'Admin User'
}

const getFirstName = () => {
  if (userProfile.value.firstName) {
    return userProfile.value.firstName
  }
  
  // Fallback to authStore or email
  return authStore.currentUser?.firstName || 
         userProfile.value.email?.split('@')[0] || 
         'Admin'
}

const getUserEmail = () => {
  return userProfile.value.email || authStore.currentUser?.email || 'admin@example.com'
}

const getUserRole = () => {
  return authStore.getUserRole() || 'Administrator'
}

const getUserAvatar = () => {
  if (userProfile.value.avatarUrl) {
    return userProfile.value.avatarUrl
  }
  
  // Generate avatar from initials
  return generateAvatarUrl(getUserDisplayName())
}

const generateAvatarUrl = (name) => {
  // Use profileUtils to get initials
  const initials = profileUtils.getInitials(
    userProfile.value.firstName, 
    userProfile.value.lastName
  )
  
  if (initials) {
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(initials)}&background=007bff&color=ffffff&size=128`
  }
  
  return '/src/assets/logoMuadima2.png'
}

const formatLastLogin = () => {
  const lastLogin = userStats.value.lastLogin || loginTime.value
  const now = new Date()
  const diffMs = now - lastLogin
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
  const diffMins = Math.floor(diffMs / (1000 * 60))
  
  if (diffHours > 0) {
    return `${diffHours}h`
  } else if (diffMins > 0) {
    return `${diffMins}m`
  } else {
    return 'Vừa xong'
  }
}

const getOnlineTime = () => {
  const now = new Date()
  const diffMs = now - loginTime.value
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
  const diffMins = Math.floor(diffMs / (1000 * 60))
  
  if (diffHours > 0) {
    return `${diffHours}h${diffMins % 60}m`
  } else {
    return `${diffMins}m`
  }
}

// Load user profile from API
const loadUserProfile = async () => {
  if (isLoadingProfile.value) return
  
  isLoadingProfile.value = true
  profileLoadError.value = null

  try {
    console.log('Loading user profile for layout...')
    const result = await profileService.getCurrentUserProfile()

    if (result.success) {
      const formattedData = profileService.formatUserData(result.data)
      userProfile.value = formattedData
    //  console.log('User profile loaded for layout:', formattedData)
    } else {
      profileLoadError.value = result.message
      console.error('Failed to load user profile for layout:', result.message)
    }
  } catch (error) {
    profileLoadError.value = 'Lỗi kết nối khi tải thông tin user'
    console.error('Error loading user profile for layout:', error)
  } finally {
    isLoadingProfile.value = false
  }
}

// Load user statistics
const loadUserStats = async () => {
  try {
    // Mock data - replace with actual API call to get user stats
    userStats.value = {
      loginCount: Math.floor(Math.random() * 200) + 50, // Random login count
      lastLogin: new Date(Date.now() - Math.random() * 24 * 60 * 60 * 1000), // Random time within last 24h
      onlineTime: 0
    }
    
    // Update online time every minute
    const onlineInterval = setInterval(() => {
      userStats.value.onlineTime = Math.floor((new Date() - loginTime.value) / 60000)
    }, 60000)
    
    // Cleanup interval on component unmount
    onUnmounted(() => {
      clearInterval(onlineInterval)
    })
    
  } catch (error) {
    console.error('Error loading user stats:', error)
  }
}

// Methods
const checkMobile = () => {
  const wasMobile = isMobile.value
  isMobile.value = window.innerWidth <= 768

  if (!wasMobile && isMobile.value) {
    sidebarCollapsed.value = true
  } else if (wasMobile && !isMobile.value) {
    sidebarCollapsed.value = false
  }

  // Close dropdown on resize to prevent positioning issues
  if (dropdownOpen.value) {
    closeDropdown()
  }
}

const toggleSidebar = () => {
  sidebarCollapsed.value = !sidebarCollapsed.value
}

const closeSidebar = () => {
  if (isMobile.value) {
    sidebarCollapsed.value = true
  }
}

const handleNavClick = () => {
  if (isMobile.value) {
    sidebarCollapsed.value = true
  }
  closeDropdown()
}

const toggleDropdown = async () => {
  dropdownOpen.value = !dropdownOpen.value

  if (dropdownOpen.value) {
    await nextTick()
    adjustDropdownPosition()
  }
}

const adjustDropdownPosition = () => {
  const dropdown = document.querySelector('.dropdown-menu')
  const button = document.querySelector('.dropdown-toggle')

  if (!dropdown || !button) return

  const buttonRect = button.getBoundingClientRect()
  const dropdownRect = dropdown.getBoundingClientRect()
  const viewportWidth = window.innerWidth
  const viewportHeight = window.innerHeight

  // Reset any previous positioning
  dropdown.style.transform = ''
  dropdown.style.left = ''
  dropdown.style.right = ''
  dropdown.style.top = ''

  // Check if dropdown goes beyond right edge
  if (buttonRect.right + dropdownRect.width > viewportWidth) {
    dropdown.style.right = '0'
    dropdown.style.left = 'auto'
  }

  // Check if dropdown goes beyond bottom edge
  if (buttonRect.bottom + dropdownRect.height > viewportHeight) {
    dropdown.style.top = 'auto'
    dropdown.style.bottom = '100%'
    dropdown.style.marginBottom = '0.25rem'
  }
}

const closeDropdown = () => {
  dropdownOpen.value = false
}

const handleAvatarError = (event) => {
  // Try to regenerate avatar URL first
  const fallbackAvatar = generateAvatarUrl(getUserDisplayName())
  if (event.target.src !== fallbackAvatar) {
    event.target.src = fallbackAvatar
  } else {
    // If even the generated avatar fails, use default
    event.target.src = '/src/assets/logoMuadima2.png'
  }
}

const showNotifications = () => {
  closeDropdown()
  Swal.fire({
    title: 'Thông báo',
    text: 'Chức năng thông báo đang được phát triển',
    icon: 'info'
  })
}

const goToProfile = () => {
  closeDropdown()
  router.push('/admin/profile')
}

const confirmLogout = async () => {
  closeDropdown()

  const result = await Swal.fire({
    title: 'Xác nhận đăng xuất',
    text: 'Bạn có chắc chắn muốn đăng xuất?',
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Đăng xuất',
    cancelButtonText: 'Hủy'
  })

  if (result.isConfirmed) {
    try {
      // Hiển thị loading khi đang xử lý
      Swal.fire({
        title: 'Đang đăng xuất...',
        allowOutsideClick: false,
        showConfirmButton: false,
        willOpen: () => {
          Swal.showLoading()
        }
      })

      // Thực hiện đăng xuất
      await authStore.logout()

      // Hiển thị thông báo thành công
      await Swal.fire({
        title: 'Đã đăng xuất!',
        text: 'Bạn đã đăng xuất thành công',
        icon: 'success',
        timer: 1500,
        showConfirmButton: false
      })

      // Chuyển hướng đến trang login
      await router.push('/admin/login')

      // Reload trang để đảm bảo dữ liệu được làm mới hoàn toàn
      window.location.reload()

    } catch (error) {
      console.error('Lỗi khi đăng xuất:', error)
      
      // Đóng loading nếu có lỗi
      Swal.close()

      // Hiển thị thông báo lỗi
      await Swal.fire({
        title: 'Lỗi!',
        text: 'Đã có lỗi xảy ra khi đăng xuất. Vui lòng thử lại.',
        icon: 'error',
        confirmButtonColor: '#d33',
        confirmButtonText: 'Đóng'
      })
    }
  }
}

// Modal functions
const openSettingsModal = () => {
  closeDropdown()
  settingsModalOpen.value = true
  document.body.style.overflow = 'hidden'
}

const closeSettingsModal = () => {
  settingsModalOpen.value = false
  if (!changePasswordModalOpen.value) {
    document.body.style.overflow = 'auto'
  }
}

const openChangePasswordModal = () => {
  closeDropdown()
  changePasswordModalOpen.value = true
  document.body.style.overflow = 'hidden'
  resetPasswordForm()
}

const closeChangePasswordModal = () => {
  changePasswordModalOpen.value = false
  if (!settingsModalOpen.value) {
    document.body.style.overflow = 'auto'
  }
  resetPasswordForm()
}

const closeAllModals = () => {
  closeChangePasswordModal()
  closeSettingsModal()
}

const resetPasswordForm = () => {
  passwordForm.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  }
  passwordErrors.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  }
}

const changePassword = async () => {
  if (!validatePassword()) {
    return;
  }

  try {
    passwordLoading.value = true;

    const payload = {
      oldPassword: passwordForm.value.currentPassword,
      newPassword: passwordForm.value.newPassword,
      confirmPassword: passwordForm.value.confirmPassword
    };

    const result = await changepassService.changePassword(payload);

    if (result.success) {
      closeChangePasswordModal();

      // Hiển thị thông báo thành công và sẽ tự động đăng xuất
      await Swal.fire({
        title: 'Đổi mật khẩu thành công',
        html: `
          <div class="text-start">
            <p>Mật khẩu của bạn đã được thay đổi thành công.</p>
            <p class="fw-bold mt-2 text-success">Bạn sẽ được đăng xuất tự động để áp dụng mật khẩu mới.</p>
          </div>
        `,
        icon: 'success',
        confirmButtonText: 'Đồng ý',
        confirmButtonColor: '#20c997',
        timer: 5000, // Tự động đóng sau 5 giây
        timerProgressBar: true,
        allowOutsideClick: false,
        didOpen: () => {
          // Bắt đầu đếm ngược để đăng xuất
          setTimeout(async () => {
            await authStore.logout();
            router.push('/admin/login');
          }, 5000);
        }
      });

      // Đăng xuất ngay lập tức (có thể bỏ setTimeout nếu muốn đăng xuất ngay)
      await authStore.logout();
      router.push('/admin/login');

    } else {
      // Xử lý lỗi từ server
      if (result.message.includes('Mật khẩu hiện tại')) {
        passwordErrors.value.currentPassword = result.message;
      } else {
        await Swal.fire({
          icon: 'error',
          title: 'Lỗi!',
          text: result.message,
          confirmButtonText: 'Đóng',
          confirmButtonColor: '#dc3545'
        });
      }
    }
  } catch (error) {
    console.error('Change password error:', error);
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Có lỗi xảy ra khi đổi mật khẩu. Vui lòng thử lại.',
      confirmButtonText: 'Đóng',
      confirmButtonColor: '#dc3545'
    });
  } finally {
    passwordLoading.value = false;
  }
};

const validatePassword = () => {
  passwordErrors.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  };

  let isValid = true;

  // Validate mật khẩu hiện tại
  if (!passwordForm.value.currentPassword) {
    passwordErrors.value.currentPassword = 'Vui lòng nhập mật khẩu hiện tại';
    isValid = false;
  }

  // Validate mật khẩu mới
  const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  
  if (!passwordForm.value.newPassword) {
    passwordErrors.value.newPassword = 'Vui lòng nhập mật khẩu mới';
    isValid = false;
  } else if (!strongPasswordRegex.test(passwordForm.value.newPassword)) {
    passwordErrors.value.newPassword = 'Mật khẩu phải chứa ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường, số và ký tự đặc biệt (@$!%*?&)';
    isValid = false;
  } else if (passwordForm.value.newPassword === passwordForm.value.currentPassword) {
    passwordErrors.value.newPassword = 'Mật khẩu mới phải khác mật khẩu hiện tại';
    isValid = false;
  }

  // Validate xác nhận mật khẩu
  if (!passwordForm.value.confirmPassword) {
    passwordErrors.value.confirmPassword = 'Vui lòng xác nhận mật khẩu mới';
    isValid = false;
  } else if (passwordForm.value.confirmPassword !== passwordForm.value.newPassword) {
    passwordErrors.value.confirmPassword = 'Mật khẩu xác nhận không khớp';
    isValid = false;
  }

  return isValid;
};

const saveSettings = async () => {
  try {
    Swal.fire({
      title: 'Đang lưu cài đặt...',
      allowOutsideClick: false,
      didOpen: () => Swal.showLoading()
    })

    await new Promise(resolve => setTimeout(resolve, 1500))
    closeSettingsModal()

    await Swal.fire({
      icon: 'success',
      title: 'Thành công!',
      text: 'Cài đặt đã được lưu thành công',
      timer: 2000,
      showConfirmButton: false
    })
  } catch (error) {
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Có lỗi xảy ra khi lưu cài đặt'
    })
  }
}

// Lifecycle
onMounted(() => {
  checkMobile()
  loadUserProfile() // Load user profile first
  loadUserStats()   // Then load stats
  
  window.addEventListener('resize', checkMobile)

  // Close dropdown when clicking outside
  document.addEventListener('click', (event) => {
    if (dropdownOpen.value && !event.target.closest('.dropdown')) {
      closeDropdown()
    }
  })

  // Close dropdown on scroll to prevent positioning issues
  window.addEventListener('scroll', () => {
    if (dropdownOpen.value) {
      closeDropdown()
    }
  })
  
  // Watch for auth store changes to reload profile
  const unwatch = authStore.$subscribe((mutation, state) => {
    if (state.isAuthenticated && !isLoadingProfile.value) {
      // Reload profile when auth state changes
      loadUserProfile()
    }
  })
  
  // Cleanup on unmount
  onUnmounted(() => {
    unwatch()
  })
})

onUnmounted(() => {
  window.removeEventListener('resize', checkMobile)
  document.body.style.overflow = 'auto'
})
</script>

<style scoped>
.admin-layout {
  display: flex;
  min-height: 100vh;
}

/* Sidebar Styles */
.sidebar {
  width: 280px;
  min-height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1000;
  transition: transform 0.3s ease;
  overflow-y: auto;
}

.sidebar.collapsed {
  width: 80px;
}

.sidebar-user {
  background-color: rgba(255, 255, 255, 0.1);
}

/* Main Content */
.main-content {
  flex: 1;
  margin-left: 280px;
  transition: margin-left 0.3s ease;
  min-height: 100vh;
}

.main-content.sidebar-collapsed {
  margin-left: 80px;
}

/* Header */
.header {
  position: sticky;
  top: 0;
  z-index: 999;
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(0,0,0,0.1) !important;
}

/* Dropdown Improvements */
.dropdown {
  position: relative;
}

.dropdown-menu {
  border: none;
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
  min-width: 280px;
  max-width: 320px;
  border-radius: 0.5rem;
  overflow: hidden;
  z-index: 1050;
  margin-top: 0.25rem;
}

.dropdown-menu.show {
  display: block;
  animation: dropdownSlideIn 0.15s ease-out;
}

@keyframes dropdownSlideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dropdown-header {
  padding: 1rem;
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
  white-space: normal;
}

.dropdown-item {
  padding: 0.75rem 1rem;
  transition: all 0.15s ease;
  display: flex;
  align-items: center;
  white-space: nowrap;
}

.dropdown-item:hover {
  background-color: #f8f9fa;
  transform: translateX(2px);
}

.dropdown-item.text-danger:hover {
  background-color: #f8d7da;
  color: #721c24 !important;
}

.dropdown-divider {
  margin: 0.25rem 0;
}

/* Navigation Links */
.nav-link {
  padding: 0.75rem 1rem;
  border-radius: 0.5rem;
  margin: 0 0.5rem;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
}

.nav-link:hover {
  background-color: rgba(255, 255, 255, 0.1);
  transform: translateX(2px);
}

.nav-link.active,
.nav-link.router-link-active {
  background-color: rgba(255, 255, 255, 0.2);
}

.nav-link i {
  width: 1.25rem;
  text-align: center;
  margin-right: 0.5rem;
}

/* Mobile Overlay */
.mobile-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 999;
}

/* Responsive Design */
@media (max-width: 768px) {
  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.mobile-open {
    transform: translateX(0);
  }

  .main-content {
    margin-left: 0;
  }

  .main-content.sidebar-collapsed {
    margin-left: 0;
  }

  .dropdown-menu {
    min-width: 260px;
    max-width: calc(100vw - 2rem);
    position: fixed !important;
    right: 1rem !important;
    left: auto !important;
    transform: none !important;
  }

  .header .container-fluid {
    padding-left: 0.75rem;
    padding-right: 0.75rem;
  }
}

@media (max-width: 576px) {
  .dropdown-menu {
    min-width: 240px;
    font-size: 0.875rem;
  }

  .dropdown-item {
    padding: 0.625rem 0.875rem;
  }

  .dropdown-header {
    padding: 0.875rem;
  }

  .header h5, .header h6 {
    font-size: 1rem;
  }
}

/* Very small screens */
@media (max-width: 420px) {
  .dropdown-menu {
    min-width: calc(100vw - 1rem);
    right: 0.5rem !important;
  }

  .main-content .p-3 {
    padding: 1rem !important;
  }
}

/* Modal z-index fix */
.modal {
  z-index: 1060;
}

.modal-backdrop {
  z-index: 1040;
}

/* Smooth animations */
* {
  transition: all 0.15s ease;
}

/* Button hover effects */
.btn {
  transition: all 0.15s ease;
}

.btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 0.25rem 0.5rem rgba(0,0,0,0.1);
}

.btn:active {
  transform: translateY(0);
}

/* Badge improvements */
.badge {
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
}

/* Avatar improvements */
img.rounded-circle {
  object-fit: cover;
  border: 2px solid rgba(255,255,255,0.1);
  transition: all 0.15s ease;
}

img.rounded-circle:hover {
  border-color: rgba(255,255,255,0.3);
  transform: scale(1.05);
}

/* Text truncation improvements */
.text-truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Scrollbar styling */
.sidebar::-webkit-scrollbar {
  width: 4px;
}

.sidebar::-webkit-scrollbar-track {
  background: rgba(255,255,255,0.1);
}

.sidebar::-webkit-scrollbar-thumb {
  background: rgba(255,255,255,0.3);
  border-radius: 2px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
  background: rgba(255,255,255,0.5);
}
</style>
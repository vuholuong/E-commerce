import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Tạo instance axios riêng cho đổi mật khẩu
const api = axios.create({
  baseURL: '/api/v1/users', // Đường dẫn API cho authentication
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor để thêm auth token
api.interceptors.request.use(
  (config) => {
    const authStore = useAuthStore()
    const token = authStore.getAccessToken()

    if (token) {
      config.headers.Authorization = `Bearer ${token}`
      authStore.updateLastActivity()
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor cho error handling
api.interceptors.response.use(
  (response) => {
    return response
  },
  async (error) => {
    const authStore = useAuthStore()

    if (error.response?.status === 401) {
      // Token expired, try refresh
      const refreshSuccess = await authStore.refreshTokenAction()

      if (refreshSuccess) {
        // Retry original request
        const token = authStore.getAccessToken()
        error.config.headers.Authorization = `Bearer ${token}`
        return api.request(error.config)
      } else {
        // Refresh failed, redirect to login
        authStore.logout()
        window.location.href = '/admin/login'
      }
    }

    return Promise.reject(error)
  }
)

// Phương thức đổi mật khẩu
const changePassword = async (passwordData) => {
  try {
    const response = await api.post('/change-password', passwordData);
    return {
      success: true,
      data: response.data,
      message: 'Đổi mật khẩu thành công'
    };
  } catch (error) {
    console.error('Change password error:', error);
    
    let errorMessage = 'Đã xảy ra lỗi khi đổi mật khẩu';
    if (error.response) {
      if (error.response.status === 400) {
        // Xử lý lỗi validation từ backend
        if (error.response.data.errors) {
          const errors = error.response.data.errors;
          errorMessage = Object.values(errors).join('\n');
        } else {
          errorMessage = error.response.data.message || 'Dữ liệu không hợp lệ';
        }
      } else if (error.response.status === 401) {
        errorMessage = 'Phiên đăng nhập hết hạn, vui lòng đăng nhập lại';
      }
    }
    
    return {
      success: false,
      message: errorMessage
    };
  }
};

// Xuất service
export const changepassService = {
  changePassword
}
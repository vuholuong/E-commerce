// services/forgotPasswordService.js
import axios from 'axios'

const API_BASE_URL = '/api/v1'

// Tạo axios instance với cấu hình mặc định
const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
})

// Service để quản lý quên mật khẩu
export const forgotPasswordService = {
  /**
   * Gửi OTP về email cho việc quên mật khẩu
   * @param {string} email - Email người dùng
   * @returns {Promise} Response từ API
   */
  async sendOTP(email) {
    try {
      const response = await apiClient.post('/auth/forgotpassword', {
        email: email.trim().toLowerCase()
      })
      
      return {
        success: true,
        data: response.data.data,
        message: response.data.message || 'OTP đã được gửi thành công'
      }
    } catch (error) {
      // Xử lý các loại lỗi khác nhau
      if (error.response) {
        // Lỗi từ server (4xx, 5xx)
        const status = error.response.status
        const message = error.response.data.message || error.response.data.error
        
        switch (status) {
          case 400:
            throw new Error(message || 'Dữ liệu không hợp lệ')
          case 404:
            throw new Error('Email không tồn tại trong hệ thống')
          case 429:
            throw new Error('Quá nhiều yêu cầu. Vui lòng thử lại sau')
          case 500:
            throw new Error('Lỗi server. Vui lòng thử lại sau')
          default:
            throw new Error(message || 'Có lỗi xảy ra khi gửi OTP')
        }
      } else if (error.request) {
        // Lỗi network
        throw new Error('Không thể kết nối đến server. Vui lòng kiểm tra kết nối mạng')
      } else {
        // Lỗi khác
        throw new Error('Có lỗi xảy ra. Vui lòng thử lại')
      }
    }
  },

  /**
   * Đổi mật khẩu mới với OTP
   * @param {string} email - Email người dùng
   * @param {string} otpCode - Mã OTP
   * @param {string} newPassword - Mật khẩu mới
   * @returns {Promise} Response từ API
   */
  async changePassword(email, otpCode, newPassword) {
    try {
      const response = await apiClient.post('/auth/changepassword', {
        email: email.trim().toLowerCase(),
        otpCode: otpCode.trim(),
        newPassword
      })
      
      return {
        success: true,
        data: response.data.data,
        message: response.data.message || 'Mật khẩu đã được đổi thành công'
      }
    } catch (error) {
      if (error.response) {
        const status = error.response.status
        const message = error.response.data.message || error.response.data.error
        
        switch (status) {
          case 400:
            if (message && message.toLowerCase().includes('otp')) {
              throw new Error('Mã OTP không hợp lệ hoặc đã hết hạn')
            } else if (message && message.toLowerCase().includes('password')) {
              throw new Error('Mật khẩu không đủ mạnh')
            }
            throw new Error(message || 'Dữ liệu không hợp lệ')
          case 404:
            throw new Error('Email không tồn tại trong hệ thống')
          case 429:
            throw new Error('Quá nhiều yêu cầu. Vui lòng thử lại sau')
          case 500:
            throw new Error('Lỗi server. Vui lòng thử lại sau')
          default:
            throw new Error(message || 'Có lỗi xảy ra khi đổi mật khẩu')
        }
      } else if (error.request) {
        throw new Error('Không thể kết nối đến server. Vui lòng kiểm tra kết nối mạng')
      } else {
        throw new Error('Có lỗi xảy ra. Vui lòng thử lại')
      }
    }
  },

  /**
   * Alias cho changePassword để tương thích với component cũ
   * @param {string} email - Email người dùng
   * @param {string} otpCode - Mã OTP
   * @param {string} newPassword - Mật khẩu mới
   * @returns {Promise} Response từ API
   */
  async resetPassword(email, otpCode, newPassword) {
    return this.changePassword(email, otpCode, newPassword);
  },

  /**
   * Validate email format
   * @param {string} email - Email để validate
   * @returns {boolean} True nếu email hợp lệ
   */
  validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  },

  /**
   * Validate password strength
   * @param {string} password - Password để validate
   * @returns {object} Kết quả validation
   */
  validatePassword(password) {
    const result = {
      isValid: false,
      errors: []
    }

    if (!password || password.length < 8) {
      result.errors.push('Mật khẩu phải có ít nhất 8 ký tự')
    }

    if (!/(?=.*[a-z])/.test(password)) {
      result.errors.push('Mật khẩu phải chứa ít nhất 1 chữ thường')
    }

    if (!/(?=.*[A-Z])/.test(password)) {
      result.errors.push('Mật khẩu phải chứa ít nhất 1 chữ hoa')
    }

    if (!/(?=.*\d)/.test(password)) {
      result.errors.push('Mật khẩu phải chứa ít nhất 1 số')
    }

    if (!/(?=.*[!@#$%^&*(),.?":{}|<>])/.test(password)) {
      result.errors.push('Mật khẩu phải chứa ít nhất 1 ký tự đặc biệt')
    }

    result.isValid = result.errors.length === 0
    return result
  },

  /**
   * Validate OTP format
   * @param {string} otp - OTP để validate
   * @returns {boolean} True nếu OTP hợp lệ
   */
  validateOTP(otp) {
    const otpRegex = /^\d{6}$/
    return otpRegex.test(otp)
  }
}
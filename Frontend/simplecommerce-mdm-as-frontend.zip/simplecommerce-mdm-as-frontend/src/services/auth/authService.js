import { apiClient } from '@/config/api'
import { useAuthStore } from '@/stores/auth'

const API_BASE_URL = '/v1/auth'

// Sử dụng apiClient từ config

export const authService = {
    // Đăng nhập seller
    async loginSeller(loginData) {
        const loginRequest = {
            email: loginData.email,
            password: loginData.password,
            platform: 'web',
            deviceToken: null,
            versionApp: '1.0.0'
        }

     //   console.log('Sending seller login request:', loginRequest)

        try {
            const response = await apiClient.post('/v1/auth/login', loginRequest)
            console.log('Seller login response:', response.data)
            return response.data
        } catch (error) {
            console.error('Seller login API error:', error)
            throw error
        }
    },

    // Đăng nhập admin
    async loginAdmin(loginData) {
        const loginRequest = {
            email: loginData.email,
            password: loginData.password,
            platform: 'web',
            deviceToken: null,
            versionApp: '1.0.0'
        }

//        console.log('Sending admin login request:', loginRequest)

        try {
            const response = await apiClient.post('/v1/auth/login', loginRequest)
            console.log('Admin login response:', response.data)
            return response.data
        } catch (error) {
            console.error('Admin login API error:', error)
            throw error
        }
    },

    // Đăng xuất
    async logout() {
        try {
            const authStore = useAuthStore()
            const token = authStore.getAccessToken()
            if (token) {
                await apiClient.post('/logout', {}, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })
            }
        } catch (error) {
            console.error('Logout error:', error)
            // Không throw error để vẫn clear local data
        }
    },

    // Refresh token
    async refreshToken(refreshToken) {
        const response = await apiClient.post('/refresh-token', {
            refreshToken
        })
        return response.data
    },

    // Kiểm tra token có hợp lệ không
    isAuthenticated() {
        const authStore = useAuthStore()
        return authStore.isAuthenticated
    },

    // Lấy thông tin user từ token
    getUserInfo() {
        const authStore = useAuthStore()
        return authStore.currentUser
    },

    // Kiểm tra token có hết hạn không
    isTokenExpired() {
        const authStore = useAuthStore()
        return authStore.isTokenExpired
    },

    // Verify token với backend
    async verifyToken(token) {
        try {
            const response = await apiClient.post('/verify', {}, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
            
            return {
                success: true,
                data: response.data.data || response.data,
                message: response.data.message || 'Token verified successfully'
            }
        } catch (error) {
            console.error('Token verification error:', error)
            return {
                success: false,
                message: error.response?.data?.message || 'Token verification failed',
                error
            }
        }
    }
}
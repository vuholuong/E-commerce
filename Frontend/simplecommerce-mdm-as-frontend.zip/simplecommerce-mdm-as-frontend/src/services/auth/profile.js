import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance với cấu hình cho profile API
const api = axios.create({
    baseURL: '/api/v1/users',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor để thêm auth token
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            console.log('Adding token to profile request')
            authStore.updateLastActivity()
        } else {
            console.log('No token found for profile request')
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor cho error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        console.error('Profile API Error:', error.response?.status, error.response?.data)

        if (error.response?.status === 401) {
            // Token expired, try refresh
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                // Retry original request
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                // Refresh failed, redirect to login
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

export const profileService = {
    // Lấy thông tin profile user hiện tại
    async getCurrentUserProfile() {
        try {
            //console.log('Fetching current user profile...')
            const response = await api.get('/profile')
          //  console.log('Profile response:', response.data)

            return {
                success: true,
                data: response.data.data,
                message: response.data.message
            }
        } catch (error) {
            console.error('Error fetching user profile:', error)
            return {
                success: false,
                data: null,
                message: error.response?.data?.message || 'Không thể tải thông tin cá nhân'
            }
        }
    },

    // Cập nhật thông tin profile (JSON only)
    async updateProfile(profileData) {
        try {
            console.log('Updating user profile:', profileData)
            const response = await api.put('/profile', profileData, {
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            console.log('Update profile response:', response.data)

            return {
                success: true,
                data: response.data.data,
                message: response.data.message || 'Cập nhật thông tin thành công'
            }
        } catch (error) {
            console.error('Error updating profile:', error)
            return {
                success: false,
                data: null,
                message: error.response?.data?.message || 'Không thể cập nhật thông tin cá nhân'
            }
        }
    },

    // Cập nhật profile với avatar (multipart form data)
    async updateProfileWithAvatar(profileData, avatarFile) {
        try {
            console.log('Updating profile with avatar:', { profileData, hasAvatar: !!avatarFile })

            const formData = new FormData()

            // Thêm profile data dưới dạng JSON
            const profileBlob = new Blob([JSON.stringify(profileData)], {
                type: 'application/json'
            })
            formData.append('profile', profileBlob)

            // Thêm avatar file nếu có
            if (avatarFile) {
                formData.append('avatar', avatarFile)
            }

            const response = await api.put('/profile', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })

            console.log('Update profile with avatar response:', response.data)

            return {
                success: true,
                data: response.data.data,
                message: response.data.message || 'Cập nhật thông tin thành công'
            }
        } catch (error) {
            console.error('Error updating profile with avatar:', error)
            return {
                success: false,
                data: null,
                message: error.response?.data?.message || 'Không thể cập nhật thông tin cá nhân'
            }
        }
    },

    // Helper method để validate profile data
    validateProfileData(profileData) {
        const errors = {}

        // Validate firstName
        if (!profileData.firstName?.trim()) {
            errors.firstName = 'Họ là bắt buộc'
        } else if (profileData.firstName.trim().length < 2) {
            errors.firstName = 'Họ phải có ít nhất 2 ký tự'
        } else if (profileData.firstName.trim().length > 50) {
            errors.firstName = 'Họ không được vượt quá 50 ký tự'
        }

        // Validate lastName
        if (!profileData.lastName?.trim()) {
            errors.lastName = 'Tên là bắt buộc'
        } else if (profileData.lastName.trim().length < 2) {
            errors.lastName = 'Tên phải có ít nhất 2 ký tự'
        } else if (profileData.lastName.trim().length > 50) {
            errors.lastName = 'Tên không được vượt quá 50 ký tự'
        }

        // Validate phoneNumber (optional)
        if (profileData.phoneNumber) {
            if (!/^\d{10}$/.test(profileData.phoneNumber)) {
                errors.phoneNumber = 'Số điện thoại phải có đúng 10 chữ số'
            }
        }

        return {
            isValid: Object.keys(errors).length === 0,
            errors
        }
    },

    // Helper để format user data cho display
    formatUserData(userData) {
        return {
            uuid: userData.uuid || null,
            fullName: `${userData.firstName || ''} ${userData.lastName || ''}`.trim(),
            firstName: userData.firstName || '',
            lastName: userData.lastName || '',
            email: userData.email || '',
            phoneNumber: userData.phoneNumber || '',
            avatarUrl: userData.avatarUrl || null,
            metadata: userData.metadata || null
        }
    },

    // Helper để prepare data cho API request
    prepareUpdateData(formData) {
        const updateData = {}

        if (formData.firstName?.trim()) {
            updateData.firstName = formData.firstName.trim()
        }

        if (formData.lastName?.trim()) {
            updateData.lastName = formData.lastName.trim()
        }

        if (formData.phoneNumber?.trim()) {
            updateData.phoneNumber = formData.phoneNumber.trim()
        }

        // metadata có thể là object hoặc string
        if (formData.metadata) {
            updateData.metadata = typeof formData.metadata === 'string'
                ? formData.metadata
                : JSON.stringify(formData.metadata)
        }

        return updateData
    }
}

// Utility functions
export const profileUtils = {
    // Generate initials from name
    getInitials(firstName, lastName) {
        const first = firstName?.charAt(0)?.toUpperCase() || ''
        const last = lastName?.charAt(0)?.toUpperCase() || ''
        return first + last
    },

    // Validate avatar file
    validateAvatarFile(file) {
        const errors = []

        // Check file type
        if (!file.type.startsWith('image/')) {
            errors.push('File phải là hình ảnh')
        }

        // Check file size (5MB)
        const maxSize = 5 * 1024 * 1024
        if (file.size > maxSize) {
            errors.push('Kích thước file không được vượt quá 5MB')
        }

        // Check image dimensions (optional)
        return new Promise((resolve) => {
            if (errors.length > 0) {
                resolve({ isValid: false, errors })
                return
            }

            const img = new Image()
            img.onload = () => {
                if (img.width < 100 || img.height < 100) {
                    errors.push('Hình ảnh phải có kích thước tối thiểu 100x100 pixel')
                }
                resolve({
                    isValid: errors.length === 0,
                    errors,
                    dimensions: { width: img.width, height: img.height }
                })
            }
            img.onerror = () => {
                errors.push('File hình ảnh không hợp lệ')
                resolve({ isValid: false, errors })
            }
            img.src = URL.createObjectURL(file)
        })
    },

    // Format phone number for display
    formatPhoneNumber(phoneNumber) {
        if (!phoneNumber) return ''

        // Format: 0123456789 -> 0123 456 789
        if (phoneNumber.length === 10) {
            return phoneNumber.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3')
        }
        return phoneNumber
    },

    // Parse full name
    parseFullName(fullName) {
        if (!fullName?.trim()) {
            return { firstName: '', lastName: '' }
        }

        const parts = fullName.trim().split(' ')
        if (parts.length === 1) {
            return { firstName: parts[0], lastName: '' }
        }

        const firstName = parts[0]
        const lastName = parts.slice(1).join(' ')
        return { firstName, lastName }
    }
}

export default profileService
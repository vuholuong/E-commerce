import { useAuthStore } from '@/stores/auth'
import { authService } from './authService'
import { profileService } from './profile'

/**
 * Auto Login Service - Xử lý tự động đăng nhập khi user được redirect với token
 */
export class AutoLoginService {
  constructor() {
    this.authStore = null
    this.isProcessing = false
  }

  // Lazy load auth store khi cần
  getAuthStore() {
    if (!this.authStore) {
      try {
        this.authStore = useAuthStore()
      } catch (error) {
        console.warn('⚠️ Auth store chưa sẵn sàng:', error)
        return null
      }
    }
    return this.authStore
  }

  /**
   * Khởi tạo auto login service
   */
  init() {
    console.log('🚀 Khởi tạo Auto Login Service...')
    
    // Kiểm tra token hiện tại
    this.checkExistingToken()
    
    // Kiểm tra token từ URL
    this.autoLoginWithToken()
  }

  /**
   * Kiểm tra token hiện tại trong localStorage
   */
  async checkExistingToken() {
    try {
      const token = localStorage.getItem('app_access_token')
      if (token) {
        console.log('🔐 Tìm thấy token trong localStorage, kiểm tra tính hợp lệ...')
        await this.verifyTokenWithBackend(token)
      }
    } catch (error) {
      console.error('❌ Lỗi khi kiểm tra token hiện tại:', error)
    }
  }

  /**
   * Tự động đăng nhập với token từ URL
   */
  async autoLoginWithToken() {
    try {
      if (this.isProcessing) {
        console.log('⏳ Đang xử lý đăng nhập, bỏ qua...')
        return
      }

      // Lấy token từ URL parameter
      const urlParams = new URLSearchParams(window.location.search)
      const token = urlParams.get('token')
      
      if (token) {
        console.log('🎯 Nhận được token từ URL, bắt đầu tự động đăng nhập...')
        this.isProcessing = true
        
        // Lưu token vào localStorage
        localStorage.setItem('app_access_token', token)
        console.log('💾 Token đã được lưu vào localStorage')
        
        // Verify token với backend
        const isValid = await this.verifyTokenWithBackend(token)
        
        if (isValid) {
          // Tự động load user profile
          await this.loadUserProfile()
          
          // Xóa token khỏi URL để bảo mật
          this.removeTokenFromURL()
          
          console.log('✅ Tự động đăng nhập thành công!')
          
          // Redirect về dashboard sau khi đăng nhập thành công
          this.redirectToDashboard()
        } else {
          console.log('❌ Token không hợp lệ, yêu cầu đăng nhập lại')
          localStorage.removeItem('app_access_token')
        }
        
        this.isProcessing = false
      } else {
        console.log('ℹ️ Không có token trong URL, yêu cầu đăng nhập thủ công')
      }
    } catch (error) {
      console.error('❌ Lỗi khi tự động đăng nhập:', error)
      this.isProcessing = false
    }
  }

  /**
   * Verify token với backend
   */
  async verifyTokenWithBackend(token) {
    try {
      console.log('🔍 Đang verify token với backend...')
      
      // Sử dụng authService để verify token
      const response = await authService.verifyToken(token)
      
      if (response && response.success) {
        console.log('✅ Token hợp lệ, user data:', response.data)
        
        // Cập nhật auth store nếu có
        const authStore = this.getAuthStore()
        if (authStore) {
          authStore.setUserInfo(response.data)
          authStore.setAuthenticated(true)
        }
        
        return true
      } else {
        console.log('❌ Token không hợp lệ:', response?.message)
        return false
      }
    } catch (error) {
      console.error('❌ Lỗi khi verify token:', error)
      return false
    }
  }

  /**
   * Load user profile sau khi đăng nhập thành công
   */
  async loadUserProfile() {
    try {
      console.log('👤 Đang load user profile...')
      
      const response = await profileService.getUserProfile()
      
      if (response && response.success) {
        console.log('✅ User profile loaded:', response.data)
        
        // Cập nhật user info trong store nếu có
        const authStore = this.getAuthStore()
        if (authStore) {
          authStore.setUserInfo(response.data)
        }
        
        // Cập nhật UI nếu cần
        this.updateUIForLoggedInUser(response.data)
        
        return true
      } else {
        console.log('⚠️ Không thể load user profile:', response?.message)
        return false
      }
    } catch (error) {
      console.error('❌ Lỗi khi load user profile:', error)
      return false
    }
  }

  /**
   * Xóa token khỏi URL để bảo mật
   */
  removeTokenFromURL() {
    try {
      const url = new URL(window.location)
      url.searchParams.delete('token')
      window.history.replaceState({}, document.title, url)
      console.log('🔒 Đã xóa token khỏi URL để bảo mật')
    } catch (error) {
      console.error('❌ Lỗi khi xóa token khỏi URL:', error)
    }
  }

  /**
   * Cập nhật UI cho user đã đăng nhập
   */
  updateUIForLoggedInUser(userData) {
    try {
      // Ẩn form đăng nhập nếu có
      const loginForm = document.getElementById('login-form')
      if (loginForm) {
        loginForm.style.display = 'none'
        console.log('👁️ Đã ẩn form đăng nhập')
      }
      
      // Hiển thị thông tin user nếu có
      const userInfo = document.getElementById('user-info')
      if (userInfo) {
        userInfo.innerHTML = `
          <div class="user-welcome">
            <h4>👋 Chào mừng, ${userData.firstName || userData.username || 'User'}!</h4>
            <p>Role: ${userData.role?.[0]?.authority || userData.roles?.[0] || 'Unknown'}</p>
          </div>
        `
        console.log('👤 Đã cập nhật thông tin user')
      }
      
      // Hiển thị dashboard nếu có
      const dashboard = document.getElementById('dashboard')
      if (dashboard) {
        dashboard.style.display = 'block'
        console.log('📊 Đã hiển thị dashboard')
      }
      
      // Trigger custom event để các component khác có thể lắng nghe
      window.dispatchEvent(new CustomEvent('userLoggedIn', { 
        detail: { userData } 
      }))
      
    } catch (error) {
      console.error('❌ Lỗi khi cập nhật UI:', error)
    }
  }

  /**
   * Redirect về dashboard sau khi đăng nhập thành công
   */
  redirectToDashboard() {
    try {
      console.log('🔄 Redirecting to dashboard...')
      
      // Lấy user role từ token hoặc store
      const token = localStorage.getItem('app_access_token')
      let userRole = 'SELLER' // Default
      
      if (token) {
        try {
          // Decode JWT token để lấy role
          const payload = JSON.parse(atob(token.split('.')[1]))
          if (payload.role && payload.role[0]) {
            userRole = payload.role[0].authority
          }
        } catch (error) {
          console.warn('⚠️ Không thể decode token, sử dụng default role')
        }
      }
      
      // Redirect theo role
      if (userRole === 'ROLE_ADMIN') {
        window.location.href = '/admin/dashboard'
      } else if (userRole === 'ROLE_SELLER') {
        window.location.href = '/seller/dashboard'
      } else {
        window.location.href = '/'
      }
      
      console.log(`✅ Redirected to ${userRole} dashboard`)
    } catch (error) {
      console.error('❌ Lỗi khi redirect:', error)
      // Fallback redirect
      window.location.href = '/seller/dashboard'
    }
  }

  /**
   * Kiểm tra xem user có cần redirect không
   */
  checkRedirectNeeded() {
    try {
      const currentPath = window.location.pathname
      const authStore = this.getAuthStore()
      
      if (!authStore) {
        console.log('⚠️ Auth store chưa sẵn sàng, bỏ qua redirect check')
        return false
      }
      
      const isAuthenticated = authStore.isAuthenticated
      
      // Nếu đã đăng nhập và đang ở trang login, redirect về dashboard
      if (isAuthenticated && (currentPath.includes('/login') || currentPath.includes('/register'))) {
        const userRole = authStore.getUserRole()
        
        if (userRole === 'ROLE_ADMIN') {
          window.location.href = '/admin/dashboard'
        } else if (userRole === 'ROLE_SELLER') {
          window.location.href = '/seller/dashboard'
        } else {
          window.location.href = '/'
        }
        
        return true
      }
      
      return false
    } catch (error) {
      console.error('❌ Lỗi khi kiểm tra redirect:', error)
      return false
    }
  }

  /**
   * Xử lý logout và cleanup
   */
  async logout() {
    try {
      console.log('🚪 Đang đăng xuất...')
      
      // Gọi logout API
      await authService.logout()
      
      // Clear local storage
      localStorage.removeItem('app_access_token')
      localStorage.removeItem('app_refresh_token')
      localStorage.removeItem('app_user_session')
      
      // Reset auth store nếu có
      const authStore = this.getAuthStore()
      if (authStore) {
        authStore.logout()
      }
      
      // Redirect về trang login
      window.location.href = '/login'
      
      console.log('✅ Đăng xuất thành công')
    } catch (error) {
      console.error('❌ Lỗi khi đăng xuất:', error)
      
      // Force logout ngay cả khi API fail
      localStorage.clear()
      const authStore = this.getAuthStore()
      if (authStore) {
        authStore.logout()
      }
      window.location.href = '/login'
    }
  }
}

// Export singleton instance
export const autoLoginService = new AutoLoginService()
export default autoLoginService

import axios from 'axios'
import { getAccessToken, clearAccessToken } from './authToken'

const FALLBACK_BASE_URL = 'https://sc-mdm-api.nammai.id.vn'
const baseURL = import.meta.env.VITE_API_BASE_URL || FALLBACK_BASE_URL

export const api = axios.create({
	baseURL,
	withCredentials: false,
	headers: { 'Content-Type': 'application/json' }
})

api.interceptors.request.use((config) => {
	const token = getAccessToken()
	if (token) {
		config.headers = config.headers || {}
		config.headers.Authorization = `Bearer ${token}`
	}
	return config
})

api.interceptors.response.use(
	(res) => res,
	(err) => {
		const status = err?.response?.status
		if (status === 401) {
			try { clearAccessToken() } catch {}
			window.dispatchEvent(new CustomEvent('auth:unauthorized'))
		}
		return Promise.reject(err)
	}
)

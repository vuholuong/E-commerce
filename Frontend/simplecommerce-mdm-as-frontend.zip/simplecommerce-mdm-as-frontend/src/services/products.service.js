import { api } from './api'

export async function getProducts(params) {
	const res = await api.get('/api/v1/products', { params })
	return res.data
}

import { api } from './api'

export async function getUserStatistics() {
	const res = await api.get('/api/v1/admin/users/statistics')
	return res.data
}

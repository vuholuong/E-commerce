import axios from "axios";
import { useAuthStore } from "@/stores/auth";

const api = axios.create({
  baseURL: "/api/v1",
  timeout: 15000,
});

// Request interceptor
api.interceptors.request.use(
  async (config) => {
    const authStore = useAuthStore();
    const token = authStore.getAccessToken();

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      authStore.updateLastActivity();
    }

    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
      return config;
    }

    if (config.data && typeof config.data === "object") {
      config.headers["Content-Type"] = "application/json";
    }

    return config;
  },
  (error) => {
    console.error("Request interceptor error:", error);
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const authStore = useAuthStore();

    if (error.response?.status === 401) {
      try {
        await authStore.refreshTokenAction();
        const newToken = authStore.getAccessToken();
        error.config.headers.Authorization = `Bearer ${newToken}`;
        return api.request(error.config);
      } catch (refreshError) {
        authStore.logout();
        window.location.href = "/seller/login";
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// Review Service
export const reviewService = {
  /**
   * Lấy danh sách tất cả reviews của shop
   */
  async getShopReviews(params = {}) {
    const {
      page = 0,
      size = 10,
      sortBy = "createdAt",
      sortDir = "desc"
    } = params;

    try {
      const response = await api.get("/seller/reviews", {
        params: { page, size, sortBy, sortDir }
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching shop reviews:", error);
      throw error;
    }
  },

  /**
   * Lấy danh sách reviews của một sản phẩm cụ thể trong shop
   */
  async getShopProductReviews(productId, params = {}) {
    const {
      page = 0,
      size = 20,
      sortBy = "createdAt",
      sortDir = "desc"
    } = params;

    try {
      const response = await api.get(`/seller/reviews/product/${productId}`, {
        params: { page, size, sortBy, sortDir }
      });
      return response.data;
    } catch (error) {
      console.error(`Error fetching reviews for product ${productId}:`, error);
      throw error;
    }
  },

  // Trong reviewService.js, cập nhật hàm getShopReviewStatistics
async getShopReviewStatistics() {
  try {
    const response = await api.get("/seller/reviews/statistics", {
      timeout: 10000,
      // Thêm timestamp để tránh cache
      params: { t: new Date().getTime() }
    });
    
    // Đảm bảo response có cấu trúc nhất quán
    if (response.data && typeof response.data === 'object') {
      return {
        statusCode: response.status,
        data: response.data
      };
    }
    
    return response.data;
  } catch (error) {
    console.error("Error fetching shop review statistics:", error);
    
    // Trả về object lỗi có cấu trúc thống nhất
    return {
      statusCode: error.response?.status || 500,
      message: error.message,
      data: null
    };
  }
},

  /**
   * Lấy thống kê reviews của một sản phẩm cụ thể
   */
  async getProductReviewStatistics(productId) {
    try {
      const response = await api.get(`/seller/reviews/product/${productId}/statistics`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching review statistics for product ${productId}:`, error);
      throw error;
    }
  },

  /**
   * Helper function để format ngày tháng
   */
  formatDate(dateString) {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) {
      const hours = Math.floor(diff / (1000 * 60 * 60));
      if (hours === 0) {
        const minutes = Math.floor(diff / (1000 * 60));
        return `${minutes} phút trước`;
      }
      return `${hours} giờ trước`;
    } else if (days === 1) {
      return 'Hôm qua';
    } else if (days < 7) {
      return `${days} ngày trước`;
    } else {
      return date.toLocaleDateString('vi-VN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    }
  },

  /**
   * Helper function để tạo mảng sao cho rating
   */
  getStarsArray(rating) {
    return Array.from({ length: 5 }, (_, index) => index < rating);
  }
};

export default reviewService;
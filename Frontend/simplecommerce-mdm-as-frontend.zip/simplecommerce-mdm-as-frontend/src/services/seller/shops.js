import axios from "axios";
import { useAuthStore } from "@/stores/auth";

const api = axios.create({
  baseURL: "/api/v1",
  timeout: 15000,
});

// Request interceptor
api.interceptors.request.use(
  async (config) => {
    const authStore = useAuthStore();
    const token = authStore.getAccessToken();

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      authStore.updateLastActivity();
    }

    // QUAN TRỌNG: Không set Content-Type cho FormData
    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
      return config;
    }

    // Set mặc định cho JSON data
    if (config.data && typeof config.data === "object") {
      config.headers["Content-Type"] = "application/json";
    }

    return config;
  },
  (error) => {
    console.error("Request interceptor error:", error);
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const authStore = useAuthStore();

    if (error.response?.status === 401) {
      try {
        await authStore.refreshTokenAction();
        const newToken = authStore.getAccessToken();
        error.config.headers.Authorization = `Bearer ${newToken}`;
        return api.request(error.config);
      } catch (refreshError) {
        authStore.logout();
        window.location.href = "/seller/login";
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export const shopService = {
  // Lấy thông tin shop hiện tại
  async getCurrentShop() {
    try {
      const response = await api.get("/seller/shop");
      return response.data;
    } catch (error) {
      console.error("Error getting current shop:", error);
      throw error;
    }
  },

  // Lấy thông tin thống kê shop
  async getShopStats() {
    try {
      const response = await api.get("/seller/shop/stats");
      return response.data;
    } catch (error) {
      console.error("Error getting shop stats:", error);
      throw error;
    }
  },
  // Lấy thông tin địa chỉ shop
  async getShopAddress() {
    try {
      const response = await api.get("/addresses");
      return response.data;
    } catch (error) {
      console.error("Error getting shop address:", error);
      throw error;
    }
  },

  // Cập nhật địa chỉ shop bằng userAddressId
  async updateShopAddress(userAddressId) {
    try {
      const response = await api.put("/seller/shop/address", {
        userAddressId: userAddressId
      });
      return response.data;
    } catch (error) {
      console.error("Error updating shop address:", error);
      throw error;
    }
  },


  // Cập nhật logo shop
  async updateShopLogo(logoFile) {
    try {
      const formData = new FormData();
      formData.append("file", logoFile);

      const response = await api.put("/user/shop/logo", formData);
      return response.data;
    } catch (error) {
      console.error("Error updating shop logo:", error);
      throw error;
    }
  },
  // Cập nhật ảnh bìa shop
  async updateShopCover(coverFile) {
    try {
      const formData = new FormData();
      formData.append("file", coverFile);

      const response = await api.put("/user/shop/cover", formData);
      return response.data;
    } catch (error) {
      console.error("Error updating shop cover:", error);
      throw error;
    }
  },
};

export default shopService;

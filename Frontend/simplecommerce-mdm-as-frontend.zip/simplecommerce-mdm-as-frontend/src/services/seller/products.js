import axios from "axios";
import { useAuthStore } from "@/stores/auth";

const api = axios.create({
  baseURL: "/api/v1/seller/products",
  timeout: 120000,
});

// Request interceptor
api.interceptors.request.use(
  async (config) => {
    const authStore = useAuthStore();
    const token = authStore.getAccessToken();

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      authStore.updateLastActivity();
    }

    // QUAN TRỌNG: Không set Content-Type cho FormData
    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
      return config;
    }

    // Set mặc định cho JSON data
    if (config.data && typeof config.data === "object") {
      config.headers["Content-Type"] = "application/json";
    }

    return config;
  },
  (error) => {
    console.error("Request interceptor error:", error);
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const authStore = useAuthStore();

    if (error.response?.status === 401) {
      try {
        await authStore.refreshTokenAction();
        const newToken = authStore.getAccessToken();
        error.config.headers.Authorization = `Bearer ${newToken}`;
        return api.request(error.config);
      } catch (refreshError) {
        authStore.logout();
        window.location.href = "/seller/login";
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// Helper functions
function normalizeVariant(variant) {
  return {
    id: variant.id || null, // Thêm dòng này
    sku: variant.sku || "",
    finalPrice: Number(variant.finalPrice || 0),
    stockQuantity: Number(variant.stockQuantity || 0),
    options:
      typeof variant.options === "string"
        ? variant.options
        : JSON.stringify(variant.options || {}),
    compareAtPrice:
      variant.compareAtPrice != null
        ? Number(variant.compareAtPrice)
        : undefined,
    weightGrams:
      variant.weightGrams != null ? Number(variant.weightGrams) : undefined,
    dimensions: variant.dimensions,
  };
}

function stripUndefined(obj) {
  return Object.fromEntries(
    Object.entries(obj).filter(([_, v]) => v !== undefined)
  );
}

export const productService = {
  // Lấy danh sách sản phẩm
  async getSellerProducts(params = {}) {
    try {
      const response = await api.get("", { params });
      return {
        success: true,
        data: response.data.data || response.data,
        message: response.data.message || "Lấy danh sách sản phẩm thành công",
      };
    } catch (error) {
      console.error("Error getting seller products:", error);
      return {
        success: false,
        data: null,
        message:
          error.response?.data?.message || "Không thể tải danh sách sản phẩm",
      };
    }
  },

  // Lấy chi tiết sản phẩm
  async getSellerProductById(productId) {
    try {
      const response = await api.get(`/${productId}`);
      return {
        success: true,
        data: response.data.data,
        message: response.data.message || "Lấy thông tin sản phẩm thành công",
      };
    } catch (error) {
      console.error("Error getting product by ID:", error);
      return {
        success: false,
        data: null,
        message:
          error.response?.data?.message || "Không thể tải thông tin sản phẩm",
      };
    }
  },

  // Tạo sản phẩm mới (với hình ảnh)
  async createProductWithImages(formData) {
    try {
      const response = await api.post("", formData, {
        headers: {},
      });

      return {
        success: true,
        data: response.data.data,
        message: response.data.message || "Tạo sản phẩm thành công",
      };
    } catch (error) {
      console.error("Error creating product with images:", error);
      return {
        success: false,
        message: error.response?.data?.message || "Không thể tạo sản phẩm",
        errors: error.response?.data?.errors || {},
      };
    }
  },

  // New: cập nhật sản phẩm kèm ảnh mới (multipart: product + newImages)
  async updateProductWithImages(productId, payload, files = []) {
    try {
      const form = new FormData();
      const productBlob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
      form.append('product', productBlob, 'product.json');
      (files || []).forEach((f, i) => form.append('newImages', f, f.name || `image_${i}`));

      const response = await api.put(`/${productId}`, form);
      // Một số backend có thể trả 202/204 khi xử lý async
      if ([200,201,202,204].includes(response.status)) {
        return {
          success: true,
          data: response.data?.data || response.data || null,
          message: response.data?.message || 'Cập nhật sản phẩm thành công'
        };
      }
      return {
        success: false,
        message: response.data?.message || 'Cập nhật sản phẩm thất bại'
      };
    } catch (error) {
      // Timeout hoặc network error
      if (error.code === 'ECONNABORTED') {
        return {
          success: false,
          message: 'Tải ảnh hơi lâu, đang tiếp tục xử lý trên máy chủ... ',
          timeout: true
        };
      }
      console.error('Error updating product with images:', error);
      return this.handleUpdateError(error);
    }
  },

  async updateProduct(productId, productData, images = []) {
  try {
    // Chuẩn bị payload JSON
    const payload = {
      name: productData.name,
      description: productData.description || null,
      basePrice: Number(productData.basePrice),
      categoryId: Number(productData.categoryId),
      variants: productData.variants.map(variant => ({
        ...(variant.id && variant.id !== 0 && { id: variant.id }), // Chỉ gửi ID nếu có và khác 0
        sku: variant.sku || '',
        finalPrice: Number(variant.finalPrice) || 0,
        compareAtPrice: variant.compareAtPrice ? Number(variant.compareAtPrice) : null,
        stockQuantity: Number(variant.stockQuantity) || 0,
        options: variant.options || '',
        reorderThreshold: Number(variant.reorderThreshold) || 0,
        weightGrams: Number(variant.weightGrams) || 0,
        dimensions: variant.dimensions || '',
        isActive: variant.isActive !== false
      })),
      attributes: productData.attributes || '',
      weightGrams: Number(productData.weightGrams) || 0,
      dimensions: productData.dimensions || '',
      status: productData.status || 'ACTIVE'
    };

    // Nếu có ảnh mới, sử dụng FormData
    if (images.length > 0) {
      const formData = new FormData();
      const productBlob = new Blob([JSON.stringify(payload)], {
        type: 'application/json'
      });
      formData.append('product', productBlob, 'product.json');
      
      images.forEach((file, index) => {
        formData.append('images', file, file.name || `image_${index}`);
      });

      const response = await api.put(`/${productId}`, formData);
      return {
        success: true,
        data: response.data.data || response.data,
        message: response.data.message || 'Cập nhật sản phẩm thành công'
      };
    } else {
      // Nếu không có ảnh mới, gửi JSON trực tiếp
      const response = await api.put(`/${productId}`, payload, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      return {
        success: true,
        data: response.data.data || response.data,
        message: response.data.message || 'Cập nhật sản phẩm thành công'
      };
    }
  } catch (error) {
    console.error('Error updating product:', error);
    
    let message = 'Lỗi khi cập nhật sản phẩm';
    let errors = {};
    
    if (error.response) {
      message = error.response.data.message || message;
      errors = error.response.data.errors || {};
      
      if (error.response.data.message?.includes('duplicate key')) {
        const duplicateSkus = error.response.data.errors?.variants || [];
        message = `Các SKU sau đã tồn tại: ${duplicateSkus.join(', ')}`;
      }
    }
    
    return {
      success: false,
      message,
      errors,
      isDuplicateError: message.includes('SKU') || message.includes('duplicate')
    };
  }
},

  // Các helper methods
  appendProductFields(formData, productData) {
    const fields = [
      "name",
      "description",
      "basePrice",
      "categoryId",
      "status",
      "slug",
      "weightGrams",
      "dimensions",
      "metaTitle",
      "metaDescription",
    ];

    fields.forEach((field) => {
      if (productData[field] !== undefined && productData[field] !== null) {
        formData.append(field, productData[field]);
      }
    });
  },

  appendVariants(formData, variants) {
    variants.forEach((variant, index) => {
      const normalized = this.normalizeVariant(variant);
      const variantFields = [
        "id",
        "sku",
        "finalPrice",
        "stockQuantity",
        "options",
        "compareAtPrice",
        "weightGrams",
        "dimensions",
        "barcode",
      ];

      variantFields.forEach((field) => {
        if (normalized[field] !== undefined && normalized[field] !== null) {
          formData.append(`variants[${index}][${field}]`, normalized[field]);
        }
      });
    });
  },

  appendExistingImages(formData, imageUrls) {
    imageUrls.forEach((url, index) => {
      if (url) {
        formData.append(`imageUrls[${index}]`, url);
      }
    });
  },

  appendNewImages(formData, images) {
    images.forEach((file, index) => {
      if (file instanceof File || file instanceof Blob) {
        const fileName =
          file.name || `image_${index}.${file.type.split("/")[1] || "jpg"}`;
        formData.append("images", file, fileName);
      }
    });
  },

  normalizeVariant(variant) {
    return {
      id: variant.id || "",
      sku: variant.sku || "",
      finalPrice: Number(variant.finalPrice || 0),
      stockQuantity: Number(variant.stockQuantity || 0),
      options:
        typeof variant.options === "string"
          ? variant.options
          : JSON.stringify(variant.options || {}),
      compareAtPrice: variant.compareAtPrice
        ? Number(variant.compareAtPrice)
        : undefined,
      weightGrams: variant.weightGrams
        ? Number(variant.weightGrams)
        : undefined,
      dimensions: variant.dimensions || undefined,
      barcode: variant.barcode || undefined,
    };
  },

  handleUpdateError(error) {
    const defaultMessage = "Không thể cập nhật sản phẩm";

    if (error.code === 'ECONNABORTED') {
      return {
        success: false,
        data: null,
        message: 'Quá thời gian chờ. Máy chủ có thể vẫn đang xử lý, vui lòng kiểm tra lại sau.',
        timeout: true,
      };
    }

    // Xử lý lỗi validation từ server
    if (error.response?.status === 422) {
      return {
        success: false,
        data: null,
        message: error.response.data.message || defaultMessage,
        errors: error.response.data.errors || {},
        validationError: true,
      };
    }

    return {
      success: false,
      data: null,
      message: error.response?.data?.message || defaultMessage,
      errors: error.response?.data?.errors || {},
    };
  },

  // Xóa sản phẩm
  async deleteProduct(productId) {
    try {
      const response = await api.delete(`/${productId}`);
      return {
        success: true,
        data: null,
        message: response.data?.message || "Xóa sản phẩm thành công",
      };
    } catch (error) {
      console.error("Error deleting product:", error);
      return {
        success: false,
        data: null,
        message: error.response?.data?.message || "Không thể xóa sản phẩm",
      };
    }
  },

  // Cập nhật trạng thái sản phẩm
  async updateProductStatus(
    productId,
    newStatus,
    currentProductSnapshot = null
  ) {
    try {
      let base = currentProductSnapshot;
      if (!base) {
        const res = await this.getSellerProductById(productId);
        if (!res.success) throw new Error(res.message);
        base = res.data;
      }

      const payload = {
        ...base,
        status: newStatus.toUpperCase(),
      };

      return await this.updateProduct(productId, payload, []);
    } catch (error) {
      console.error("Error updating product status:", error);
      return {
        success: false,
        data: null,
        message: error.message || "Không thể cập nhật trạng thái",
      };
    }
  },

  // Cập nhật biến thể
  async updateProductVariants(
    productId,
    variants = [],
    currentProductSnapshot = null
  ) {
    try {
      let base = currentProductSnapshot;
      if (!base) {
        const res = await this.getSellerProductById(productId);
        if (!res.success) throw new Error(res.message);
        base = res.data;
      }

      const payload = {
        ...base,
        variants: variants.map(normalizeVariant),
      };

      return await this.updateProduct(productId, payload, []);
    } catch (error) {
      console.error("Error updating variants:", error);
      return {
        success: false,
        data: null,
        message: error.message || "Không thể cập nhật biến thể",
      };
    }
  },
  // xóa biến thể trong sản phẩm 
  async deleteProductVariant(productId, variantId) {
    try {
      const response = await api.delete(`/${productId}/variants/${variantId}`);
      return {
        success: true,
        data: response.data.data || response.data,
        message: response.data.message || "Xóa biến thể thành công",
      };
    } catch (error) {
      console.error("Error deleting product variant:", error);
      return {
        success: false,
        data: null,
        message:
          error.response?.data?.message || "Không thể xóa biến thể sản phẩm",
      };
    }
  },

  // Cập nhật tồn kho
  async updateProductStock(
    productId,
    stocks = [],
    currentProductSnapshot = null
  ) {
    try {
      let base = currentProductSnapshot;
      if (!base) {
        const res = await this.getSellerProductById(productId);
        if (!res.success) throw new Error(res.message);
        base = res.data;
      }

      const stockMap = new Map(
        stocks.map((s) => [s.sku, Number(s.stockQuantity || 0)])
      );

      const updatedVariants = (base.variants || []).map((v) => ({
        ...normalizeVariant(v),
        stockQuantity: stockMap.has(v.sku)
          ? stockMap.get(v.sku)
          : Number(v.stockQuantity || 0),
      }));

      return this.updateProductVariants(productId, updatedVariants, base);
    } catch (error) {
      console.error("Error updating stock:", error);
      return {
        success: false,
        data: null,
        message: error.message || "Không thể cập nhật số lượng",
      };
    }
  },

  // Validate product data
  validateProductData(productData) {
    const errors = {};

    if (!productData.name?.trim()) {
      errors.name = "Tên sản phẩm là bắt buộc";
    }

    if (!productData.basePrice || productData.basePrice <= 0) {
      errors.basePrice = "Giá sản phẩm phải lớn hơn 0";
    }

    if (!productData.categoryId) {
      errors.categoryId = "Danh mục là bắt buộc";
    }

    if (
      !productData.variants ||
      !Array.isArray(productData.variants) ||
      productData.variants.length === 0
    ) {
      errors.variants = "Sản phẩm phải có ít nhất một variant";
    } else {
      productData.variants.forEach((v, i) => {
        if (!v.sku?.trim()) {
          errors[`variants.${i}.sku`] = "SKU là bắt buộc";
        }
        if (!v.finalPrice || v.finalPrice <= 0) {
          errors[`variants.${i}.finalPrice`] = "Giá bán phải lớn hơn 0";
        }
        if (
          v.stockQuantity === null ||
          v.stockQuantity === undefined ||
          v.stockQuantity < 0
        ) {
          errors[`variants.${i}.stockQuantity`] = "Số lượng không hợp lệ";
        }
      });
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors,
    };
  },

  // Helper methods
  getStatusText(status) {
    const statusTextMap = {
      PENDING_APPROVAL: "Chờ duyệt",
      APPROVED: "Đã duyệt",
      REJECTED: "Bị từ chối",
      ACTIVE: "Đang bán",
      INACTIVE: "Tạm ngưng",
      OUT_OF_STOCK: "Hết hàng",
    };
    return statusTextMap[status] || status;
  },

  getStatusColor(status) {
    const statusColorMap = {
      PENDING_APPROVAL: "warning",
      APPROVED: "success",
      REJECTED: "danger",
      ACTIVE: "success",
      INACTIVE: "secondary",
      OUT_OF_STOCK: "danger",
    };
    return statusColorMap[status] || "secondary";
  },

  // New: danh sách ảnh của sản phẩm
  async listProductImages(productId) {
    try {
      const response = await api.get(`/${productId}/images`)
      return {
        success: true,
        data: response.data?.data,
        message: response.data?.message || 'Lấy danh sách ảnh thành công'
      }
    } catch (error) {
      console.error('Error listing product images:', error)
      return {
        success: false,
        data: null,
        message: error.response?.data?.message || 'Không thể lấy danh sách ảnh'
      }
    }
  },

  // New: xóa các ảnh theo danh sách id
  async deleteProductImages(productId, imageIds = []) {
    try {
      const response = await api.delete(`/${productId}/images`, {
        data: { imageIds }
      })
      return {
        success: true,
        data: null,
        message: response.data?.message || 'Xóa ảnh thành công'
      }
    } catch (error) {
      console.error('Error deleting product images:', error)
      return {
        success: false,
        data: null,
        message: error.response?.data?.message || 'Không thể xóa ảnh'
      }
    }
  },
};

export const productUtils = {
  formatCurrency(amount) {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(amount || 0);
  },

  validateImageFiles(files) {
    const errors = [];
    const MAX_SIZE = 5 * 1024 * 1024; // 5MB
    const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"];

    files.forEach((file, index) => {
      if (!ALLOWED_TYPES.includes(file.type)) {
        errors.push(`File ${index + 1}: Chỉ hỗ trợ định dạng JPG, PNG, WEBP`);
      }

      if (file.size > MAX_SIZE) {
        errors.push(`File ${index + 1}: Vượt quá 5MB`);
      }
    });

    return {
      isValid: errors.length === 0,
      errors,
    };
  },
};

export default productService;


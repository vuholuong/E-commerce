import axios from "axios";
import { useAuthStore } from "@/stores/auth";

const api = axios.create({
  baseURL: "/api/v1",
  timeout: 15000,
});

// Request interceptor
api.interceptors.request.use(
  async (config) => {
    const authStore = useAuthStore();
    const token = authStore.getAccessToken();

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      authStore.updateLastActivity();
    }

    // QUAN TRỌNG: Không set Content-Type cho FormData
    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
      return config;
    }

    // Set mặc định cho JSON data
    if (config.data && typeof config.data === "object") {
      config.headers["Content-Type"] = "application/json";
    }

    return config;
  },
  (error) => {
    console.error("Request interceptor error:", error);
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const authStore = useAuthStore();

    if (error.response?.status === 401) {
      try {
        await authStore.refreshTokenAction();
        const newToken = authStore.getAccessToken();
        error.config.headers.Authorization = `Bearer ${newToken}`;
        return api.request(error.config);
      } catch (refreshError) {
        authStore.logout();
        window.location.href = "/seller/login";
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// Order Service
export const orderService = {
  /**
   * Lấy danh sách đơn hàng của seller
   * @param {Object} params - Tham số tìm kiếm
   * @param {number} params.page - Số trang (0-based)
   * @param {number} params.size - Kích thước trang
   * @param {string} params.status - Trạng thái đơn hàng (optional)
   * @returns {Promise<Object>} Response data với pagination
   */
  async getSellerOrders(params = {}) {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.page !== undefined) queryParams.append('page', params.page);
      if (params.size !== undefined) queryParams.append('size', params.size);
      if (params.status) queryParams.append('status', params.status);
      
      const response = await api.get(`/seller/orders?${queryParams.toString()}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching seller orders:', error);
      throw this.handleApiError(error);
    }
  },

  /**
   * Cập nhật trạng thái đơn hàng
   * @param {number} orderId - ID đơn hàng
   * @param {Object} updateData - Dữ liệu cập nhật
   * @param {string} updateData.orderStatus - Trạng thái mới
   * @param {string} updateData.internalNotes - Ghi chú nội bộ
   * @returns {Promise<Object>} Response data
   */
  async updateOrderStatus(orderId, updateData) {
    try {
      const response = await api.put(`/seller/orders/${orderId}/status`, updateData);
      return response.data;
    } catch (error) {
      console.error('Error updating order status:', error);
      throw this.handleApiError(error);
    }
  },

  /**
   * Lấy chi tiết đơn hàng
   * @param {number} orderId - ID đơn hàng
   * @returns {Promise<Object>} Chi tiết đơn hàng
   */
  async getOrderDetail(orderId) {
    try {
      const response = await api.get(`/seller/orders/${orderId}`);
      // Cập nhật để phù hợp với response mới
      if (response.data && response.data.data) {
        return response.data.data; // Trả về data thay vì toàn bộ response
      }
      return response.data;
    } catch (error) {
      console.error('Error fetching order detail:', error);
      throw this.handleApiError(error);
    }
  },

  /**
   * Xuất báo cáo đơn hàng
   * @param {Object} params - Tham số báo cáo
   * @param {string} params.startDate - Ngày bắt đầu
   * @param {string} params.endDate - Ngày kết thúc
   * @param {string} params.status - Trạng thái (optional)
   * @returns {Promise<Blob>} File báo cáo
   */
  async exportOrderReport(params = {}) {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.startDate) queryParams.append('startDate', params.startDate);
      if (params.endDate) queryParams.append('endDate', params.endDate);
      if (params.status) queryParams.append('status', params.status);
      
      const response = await api.get(`/seller/orders/export?${queryParams.toString()}`, {
        responseType: 'blob'
      });
      
      return response.data;
    } catch (error) {
      console.error('Error exporting order report:', error);
      throw this.handleApiError(error);
    }
  },

  /**
   * Xử lý lỗi API
   * @param {Object} error - Lỗi từ axios
   * @returns {Object} Lỗi đã được format
   */
  handleApiError(error) {
    if (error.response) {
      // Server response với status code lỗi
      const { status, data } = error.response;
      return {
        status,
        message: data?.message || 'Có lỗi xảy ra từ server',
        details: data?.details || null
      };
    } else if (error.request) {
      // Request được gửi nhưng không có response
      return {
        status: 0,
        message: 'Không thể kết nối đến server',
        details: null
      };
    } else {
      // Lỗi khác
      return {
        status: 0,
        message: error.message || 'Có lỗi không xác định',
        details: null
      };
    }
  }
};

// Các constants cho order status
export const ORDER_STATUS = {
  PENDING_PAYMENT: 'PENDING_PAYMENT',
  AWAITING_CONFIRMATION: 'AWAITING_CONFIRMATION',
  PROCESSING: 'PROCESSING',
  SHIPPED: 'SHIPPED',
  DELIVERED: 'DELIVERED',
  COMPLETED: 'COMPLETED',
  CANCELLED_BY_USER: 'CANCELLED_BY_USER',
  CANCELLED_BY_SELLER: 'CANCELLED_BY_SELLER',
  CANCELLED_BY_ADMIN: 'CANCELLED_BY_ADMIN',
  RETURN_REQUESTED: 'RETURN_REQUESTED',
  RETURN_APPROVED: 'RETURN_APPROVED',
  RETURNED: 'RETURNED',
  FAILED: 'FAILED'
};

// Mapping trạng thái tiếng Việt
export const ORDER_STATUS_LABELS = {
  [ORDER_STATUS.PENDING_PAYMENT]: 'Chờ thanh toán',
  [ORDER_STATUS.AWAITING_CONFIRMATION]: 'Chờ xác nhận',
  [ORDER_STATUS.PROCESSING]: 'Đang xử lý',
  [ORDER_STATUS.SHIPPED]: 'Đã gửi hàng',
  [ORDER_STATUS.DELIVERED]: 'Đã giao hàng',
  [ORDER_STATUS.COMPLETED]: 'Hoàn thành',
  [ORDER_STATUS.CANCELLED_BY_USER]: 'Khách hàng hủy',
  [ORDER_STATUS.CANCELLED_BY_SELLER]: 'Seller hủy',
  [ORDER_STATUS.CANCELLED_BY_ADMIN]: 'Admin hủy',
  [ORDER_STATUS.RETURN_REQUESTED]: 'Yêu cầu trả hàng',
  [ORDER_STATUS.RETURN_APPROVED]: 'Chấp nhận trả hàng',
  [ORDER_STATUS.RETURNED]: 'Đã trả hàng',
  [ORDER_STATUS.FAILED]: 'Thất bại'
};

// Mapping màu sắc badge
export const ORDER_STATUS_COLORS = {
  [ORDER_STATUS.PENDING_PAYMENT]: 'warning',
  [ORDER_STATUS.AWAITING_CONFIRMATION]: 'warning',
  [ORDER_STATUS.PROCESSING]: 'info',
  [ORDER_STATUS.SHIPPED]: 'primary',
  [ORDER_STATUS.DELIVERED]: 'success',
  [ORDER_STATUS.COMPLETED]: 'success',
  [ORDER_STATUS.CANCELLED_BY_USER]: 'danger',
  [ORDER_STATUS.CANCELLED_BY_SELLER]: 'danger',
  [ORDER_STATUS.CANCELLED_BY_ADMIN]: 'dark',
  [ORDER_STATUS.RETURN_REQUESTED]: 'warning',
  [ORDER_STATUS.RETURN_APPROVED]: 'info',
  [ORDER_STATUS.RETURNED]: 'secondary',
  [ORDER_STATUS.FAILED]: 'danger'
};

export default api;
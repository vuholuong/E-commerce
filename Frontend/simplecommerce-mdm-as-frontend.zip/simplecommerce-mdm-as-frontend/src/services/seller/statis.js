// services/statsService.js
import axios from "axios";
import { useAuthStore } from "@/stores/auth";

const api = axios.create({
  baseURL: "/api/v1",
  timeout: 15000,
});

// Request interceptor
api.interceptors.request.use(
  async (config) => {
    const authStore = useAuthStore();
    const token = authStore.getAccessToken();

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    console.error("Request interceptor error:", error);
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => {
    // Trả về data trực tiếp thay vì toàn bộ response
    return response.data;
  },
  async (error) => {
    const authStore = useAuthStore();

    if (error.response?.status === 401) {
      try {
        await authStore.refreshTokenAction();
        const newToken = authStore.getAccessToken();
        error.config.headers.Authorization = `Bearer ${newToken}`;
        return api.request(error.config);
      } catch (refreshError) {
        authStore.logout();
        window.location.href = "/seller/login";
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export const statsService = {
  async getOverview() {
    try {
      return await api.get('/seller/stats/overview');
    } catch (error) {
      console.error('Error fetching overview stats:', error);
      throw error;
    }
  },

  async getSalesSeries(range = '7d') {
    try {
      return await api.get('/seller/stats/sales-series', {
        params: { range }
      });
    } catch (error) {
      console.error('Error fetching sales series:', error);
      throw error;
    }
  },

  // Lấy phân tích thanh toán
  async getPaymentBreakdown(range = '7d') {
    try {
      const response = await api.get('/seller/stats/payment-breakdown', {
        params: { range }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching payment breakdown:', error);
      throw error;
    }
  },

  // Lấy giá trị đơn hàng trung bình
  async getAvgOrderValue(range = '30d') {
    try {
      const response = await api.get('/seller/stats/avg-order-value', {
        params: { range }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching average order value:', error);
      throw error;
    }
  },

  // Lấy số lượng trả hàng
  async getReturns(range = '30d') {
    try {
      const response = await api.get('/seller/stats/returns', {
        params: { range }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching returns:', error);
      throw error;
    }
  },

  // Lấy sản phẩm bán chạy
  async getTopProducts(sortBy = 'quantity', limit = 10) {
    try {
      const response = await api.get('/seller/stats/top-products', {
        params: { sortBy, limit }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching top products:', error);
      throw error;
    }
  },

  // Lấy danh sách sản phẩm sắp hết hàng
  async getLowStock(threshold = 5) {
    try {
      const response = await api.get('/seller/stats/low-stock', {
        params: { threshold }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching low stock items:', error);
      throw error;
    }
  }
};

export default statsService;
import { api } from './api'
import { setAccessToken } from './authToken'

export async function login(payload) {
	const body = {
		...payload,
		platform: 'web',
		deviceToken: null,
		versionApp: '1.0.0'
	}
	const res = await api.post('/api/v1/auth/login', body)
	const token = (res.data?.data?.accessToken) || res.data?.accessToken
	if (token) setAccessToken(token)
	return res.data
}

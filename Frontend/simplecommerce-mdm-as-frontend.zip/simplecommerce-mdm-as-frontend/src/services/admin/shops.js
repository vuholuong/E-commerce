import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance with base configuration
const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            authStore.updateLastActivity()
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        if (error.response?.status === 401) {
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

class ShopAdminService {
  /**
   * Get all shops for admin with filtering and pagination
   */
  async getShops(params = {}) {
    try {
      const response = await api.get('/admin/shops', { 
        params: {
          searchTerm: params.searchTerm || undefined,
          status: params.status || undefined,
          sellerEmail: params.sellerEmail || undefined,
          city: params.city || undefined,
          country: params.country || undefined,
          page: params.page || 0,
          size: params.size || 20,
          sortBy: params.sortBy || 'createdAt',
          sortDirection: params.sortDirection || 'desc'
        }
      })
      return response.data
    } catch (error) {
      console.error('Error fetching shops:', error)
      throw this.handleError(error)
    }
  }

  /**
   * Get shop details by ID for admin
   */
  async getShopById(shopId) {
    try {
      const response = await api.get(`/admin/shops/${shopId}`)
      return response.data
    } catch (error) {
      console.error('Error fetching shop details:', error)
      throw this.handleError(error)
    }
  }

  /**
   * Approve a shop
   */
  async approveShop(shopId, approvalData = {}) {
    try {
      const response = await api.put(`/admin/shops/${shopId}/approve`, approvalData)
      return response.data
    } catch (error) {
      console.error('Error approving shop:', error)
      throw this.handleError(error)
    }
  }

  /**
   * Reject a shop
   */
  async rejectShop(shopId, rejectionData) {
    try {
      const response = await api.put(`/admin/shops/${shopId}/reject`, {
        rejectionReason: rejectionData.rejectionReason
      })
      return response.data
    } catch (error) {
      console.error('Error rejecting shop:', error)
      throw this.handleError(error)
    }
  }

  /**
   * Suspend a shop
   */
  async suspendShop(shopId, suspensionData) {
    try {
      const response = await api.put(`/admin/shops/${shopId}/suspend`, {
        rejectionReason: suspensionData.rejectionReason
      })
      return response.data
    } catch (error) {
      console.error('Error suspending shop:', error)
      throw this.handleError(error)
    }
  }

  /**
   * Reactivate a shop
   */
  async reactivateShop(shopId) {
    try {
      const response = await api.put(`/admin/shops/${shopId}/reactivate`)
      return response.data
    } catch (error) {
      console.error('Error reactivating shop:', error)
      throw this.handleError(error)
    }
  }

  /**
   * Handle API errors
   */
  handleError(error) {
    if (error.response) {
      return {
        message: error.response.data?.message || 'Có lỗi xảy ra',
        status: error.response.status,
        data: error.response.data
      }
    } else if (error.request) {
      return {
        message: 'Không thể kết nối đến server',
        status: 0
      }
    } else {
      return {
        message: error.message || 'Có lỗi xảy ra',
        status: 0
      }
    }
  }

  /**
   * Map shop status from backend to Vietnamese
   */
  mapShopStatus(shop) {
    let status = 'Không xác định'
    let statusColor = 'secondary'
    
    if (shop.isActive && shop.approvedAt) {
      status = 'Hoạt động'
      statusColor = 'success'
    } else if (!shop.isActive && shop.approvedAt) {
      status = 'Bị tạm ngưng'
      statusColor = 'warning'
    } else if (!shop.approvedAt) {
      status = 'Chờ duyệt'
      statusColor = 'warning'
    }
    
    return { status, statusColor }
  }

  /**
   * Calculate shop statistics
   */
  calculateShopStats(shops) {
    const stats = {
      total: shops.length,
      active: 0,
      pending: 0,
      suspended: 0
    }

    shops.forEach(shop => {
      if (shop.isActive && shop.approvedAt) {
        stats.active++
      } else if (!shop.isActive && shop.approvedAt) {
        stats.suspended++
      } else if (!shop.approvedAt) {
        stats.pending++
      }
    })

    return stats
  }
}

export default new ShopAdminService()

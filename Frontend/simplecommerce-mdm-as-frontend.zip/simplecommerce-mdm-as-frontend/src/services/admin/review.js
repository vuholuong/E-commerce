import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance with base configuration
const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            authStore.updateLastActivity()
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        if (error.response?.status === 401) {
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

// Review Admin Service
export const reviewAdminService = {
    // Get all reviews with pagination
    async getAllReviews(page = 0, size = 5, sortBy = 'createdAt', sortDir = 'desc') {
        try {
            const response = await api.get('/admin/reviews', {
                params: { page, size, sortBy, sortDir }
            })
            return response.data
        } catch (error) {
            console.error('Error fetching all reviews:', error)
            throw error
        }
    },

    // Get pending reviews
    async getPendingReviews(page = 0, size = 5, sortBy = 'createdAt', sortDir = 'desc') {
        try {
            const response = await api.get('/admin/reviews/pending', {
                params: { page, size, sortBy, sortDir }
            })
            return response.data
        } catch (error) {
            console.error('Error fetching pending reviews:', error)
            throw error
        }
    },

    // Get reported reviews
    async getReportedReviews(page = 0, size = 5, sortBy = 'createdAt', sortDir = 'desc') {
        try {
            const response = await api.get('/admin/reviews/reported', {
                params: { page, size, sortBy, sortDir }
            })
            return response.data
        } catch (error) {
            console.error('Error fetching reported reviews:', error)
            throw error
        }
    },

    // Get review details
    async getReviewDetails(reviewId) {
        try {
            const response = await api.get(`/admin/reviews/${reviewId}`)
            return response.data
        } catch (error) {
            console.error('Error fetching review details:', error)
            throw error
        }
    },

    // Moderate review (approve/reject)
    async moderateReview(reviewId, isApproved, moderatorNotes = '') {
        try {
            const response = await api.put(`/admin/reviews/${reviewId}/moderate`, null, {
                params: { isApproved, moderatorNotes }
            })
            return response.data
        } catch (error) {
            console.error('Error moderating review:', error)
            throw error
        }
    },

    // Delete review
    async deleteReview(reviewId) {
        try {
            const response = await api.delete(`/admin/reviews/${reviewId}`)
            return response.data
        } catch (error) {
            console.error('Error deleting review:', error)
            throw error
        }
    },

    // Get review statistics overview
    async getStatisticsOverview() {
        try {
            const response = await api.get('/admin/reviews/statistics/overview')
            return response.data
        } catch (error) {
            console.error('Error fetching statistics overview:', error)
            throw error
        }
    }
}

export default api
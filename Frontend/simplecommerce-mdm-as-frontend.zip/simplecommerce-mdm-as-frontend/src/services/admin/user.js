import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            authStore.updateLastActivity()
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor
api.interceptors.response.use(
    (response) => response,
    async (error) => {
        const authStore = useAuthStore()
        if (error.response?.status === 401) {
            const refreshSuccess = await authStore.refreshTokenAction()
            if (refreshSuccess) {
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }
        return Promise.reject(error)
    }
)

class AdminUserService {
    constructor() {
        this.basePath = '/admin/users'
    }

    async getAllUsers(params = {}) {
        const response = await api.get(this.basePath, { params })
        return response.data
    }

    async getUserById(userId) {
        const response = await api.get(`${this.basePath}/${userId}`)
        return response.data
    }

    async updateUserActiveStatus(userId, isActive) {
        const response = await api.patch(`${this.basePath}/${userId}/status`, { isActive })
        return response.data
    }

    async updateUserRoles(userId, roleNames) {
        const response = await api.patch(`${this.basePath}/${userId}/status`, { roleNames })
        return response.data
    }

    async verifyUserEmail(userId) {
        const response = await api.patch(`${this.basePath}/${userId}/verify-email`)
        return response.data
    }

    async verifyUserPhone(userId) {
        const response = await api.patch(`${this.basePath}/${userId}/verify-phone`)
        return response.data
    }

    async deleteUser(userId) {
        const response = await api.delete(`${this.basePath}/${userId}`)
        return response.data
    }

    async restoreUser(userId) {
        const response = await api.patch(`${this.basePath}/${userId}/restore`)
        return response.data
    }

    async getUserStatistics() {
        const response = await api.get(`${this.basePath}/statistics`)
        return response.data
    }
}

export const adminUserService = new AdminUserService()
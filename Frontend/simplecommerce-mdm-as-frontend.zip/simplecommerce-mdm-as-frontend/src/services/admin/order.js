import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance with base configuration
const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            authStore.updateLastActivity()
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        if (error.response?.status === 401) {
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

export class OrderService {
    
    /**
     * Get all orders with pagination
     * Tương ứng với API: GET /api/v1/admin/orders
     */
    async getAllOrders(page = 0, size = 10) {
        try {
            const params = { page, size }
            
            const response = await api.get('/admin/orders', { params })
            return {
                success: true,
                data: response.data.data, // This contains the Page object with content, totalPages, etc.
                message: response.data.message
            }
        } catch (error) {
            return {
                success: false,
                message: error.response?.data?.message || 'Không thể tải danh sách đơn hàng',
                error
            }
        }
    }

    /**
 * Get order details by ID
 * Tương ứng với API: GET /api/v1/admin/orders/${orderId}
 */
async getOrderDetail(orderId) {
    try {
        const response = await api.get(`/admin/orders/${orderId}`)
        
        // Kiểm tra cả response structure và data tồn tại
        if (response.data && response.data.data) {
            return {
                success: true,
                data: response.data.data,
                message: response.data.message || 'Order details retrieved successfully'
            }
        } else {
            // Nếu API trả về success nhưng không có data
            return {
                success: false,
                data: null,
                message: response.data?.message || 'Order not found or data is missing'
            }
        }
    } catch (error) {
        console.error('Error getting order detail:', error)
        return {
            success: false,
            message: error.response?.data?.message || 'Không thể tải chi tiết đơn hàng',
            error: error.response?.data
        }
    }
}

    /**
     * Search orders by keyword
     * Tương ứng với API: GET /api/v1/admin/orders/search
     */
    async searchOrders(keyword, page = 0, size = 10) {
        try {
            const response = await api.get('/admin/orders/search', {
                params: { keyword, page, size }
            })
            return {
                success: true,
                data: response.data.data,
                message: response.data.message
            }
        } catch (error) {
            return {
                success: false,
                message: error.response?.data?.message || 'Không thể tìm kiếm đơn hàng',
                error
            }
        }
    }

    /**
     * Get order statistics
     * Tương ứng với API: GET /api/v1/admin/orders/statistics
     */
    async getOrderStatistics() {
        try {
            const response = await api.get('/admin/orders/statistics')
            
            // Transform data to match component expected format
            const statsData = response.data.data;
            const transformedData = {
                total: statsData.totalOrders || 0,
                pending: statsData.pendingOrders || 0,
                shipping: statsData.shippedOrders || 0,
                completed: statsData.completedOrders || 0,
                awaitingConfirmation: statsData.awaitingConfirmationOrders || 0,
                processing: statsData.processingOrders || 0,
                delivered: statsData.deliveredOrders || 0,
                cancelled: statsData.cancelledOrders || 0,
                // Giữ lại các trường gốc để dùng sau này nếu cần
                rawData: statsData
            }
            
            return {
                success: true,
                data: transformedData,
                message: response.data.message
            }
        } catch (error) {
            return {
                success: false,
                message: error.response?.data?.message || 'Không thể tải thống kê đơn hàng',
                error
            }
        }
    }

    /**
     * Update order status
     * Tương ứng với API: PUT /api/v1/admin/orders/{orderId}/status
     */
    async updateOrderStatus(orderId, status, note = '') {
        try {
            //console.log('Calling API with:', { orderId, status, note })
            
            const response = await api.put(`/admin/orders/${orderId}/status`, {
                status,
                note
            })
            
            // console.log('API response:', response.data)
            
            return {
                success: true,
                data: response.data.data,
                message: response.data.message
            }
        } catch (error) {
            console.error('API error:', error.response?.data || error)
            return {
                success: false,
                message: error.response?.data?.message || 'Không thể cập nhật trạng thái đơn hàng',
                error: error.response?.data
            }
        }
    }

    /**
     * Get order status options
     */
    getOrderStatusOptions() {
        return [
            { value: 'PENDING_PAYMENT', label: 'Chờ thanh toán' },
            { value: 'AWAITING_CONFIRMATION', label: 'Chờ xác nhận' },
            { value: 'PROCESSING', label: 'Đang xử lý' },
            { value: 'SHIPPED', label: 'Đã gửi hàng' },
            { value: 'DELIVERED', label: 'Đã giao hàng' },
            { value: 'COMPLETED', label: 'Hoàn thành' },
            { value: 'CANCELLED_BY_USER', label: 'Khách hàng hủy' },
            { value: 'CANCELLED_BY_SELLER', label: 'Seller hủy' },
            { value: 'CANCELLED_BY_ADMIN', label: 'Admin hủy' },
            { value: 'RETURN_REQUESTED', label: 'Yêu cầu trả hàng' },
            { value: 'RETURN_APPROVED', label: 'Chấp nhận trả hàng' },
            { value: 'RETURNED', label: 'Đã trả hàng' },
            { value: 'FAILED', label: 'Thất bại'     }
        ]
    }

    /**
     * Get status badge color
     */
    getStatusBadgeColor(status) {
        const statusColors = {
            'PENDING_PAYMENT': 'warning',
            'AWAITING_CONFIRMATION': 'info',
            'PROCESSING': 'primary',
            'SHIPPED': 'success',
            'DELIVERED': 'success',
            'COMPLETED': 'success',
            'CANCELLED_BY_USER': 'danger',
            'CANCELLED_BY_SELLER': 'danger',
            'CANCELLED_BY_ADMIN': 'danger',
            'RETURN_REQUESTED': 'warning',
            'RETURN_APPROVED': 'info',
            'RETURNED': 'success',
            'FAILED': 'danger'
        }
        return statusColors[status] || 'secondary'
    }

    /**
     * Format status text for display
     */
    formatStatusText(status) {
        const statusTexts = {
            'PENDING_PAYMENT': 'Chờ thanh toán',
            'AWAITING_CONFIRMATION': 'Chờ xác nhận',
            'PROCESSING': 'Đang xử lý',
            'SHIPPED': 'Đã gửi hàng',
            'DELIVERED': 'Đã giao hàng',
            'COMPLETED': 'Hoàn thành',
            'CANCELLED_BY_USER': 'Khách hàng hủy',
            'CANCELLED_BY_SELLER': 'Seller hủy',
            'CANCELLED_BY_ADMIN': 'Admin hủy',
            'RETURN_REQUESTED': 'Yêu cầu trả hàng',
            'RETURN_APPROVED': 'Chấp nhận trả hàng',
            'RETURNED': 'Đã trả hàng',
            'FAILED': 'Thất bại'
        }
        return statusTexts[status] || status
    }

    /**
     * Format order data for display
     */
    formatOrderForDisplay(order) {
        return {
          id: order.id, // GIỮ NGUYÊN ID GỐC từ API
          orderNumber: order.orderNumber, // Thêm orderNumber riêng nếu cần
          orderDate: this.formatDate(order.orderedAt), // Sử dụng hàm để định dạng ngày
          customerName: order.customerEmail, // Sử dụng email làm tên tạm thời
          customerAddress: order.shippingAddress, // Thêm customerAddress nếu
          customerEmail: order.customerEmail,
          sellerName: order.shopName,
          productCount: order.totalItems,
          quantity: order.totalQuantity,
          total: order.totalAmount,
          subtotal: order.subtotalAmount,
          shippingFee: order.shippingFee,
          status: this.formatStatusText(order.orderStatus),
          statusColor: this.getStatusBadgeColor(order.orderStatus),
          rawStatus: order.orderStatus,
          createdAt: this.formatDate(order.orderedAt),
          orderGroupNumber: order.orderGroupNumber,
        };
    }

    /**
     * Format date for display
     */
    formatDate(dateString) {
        if (!dateString) return ''
        const date = new Date(dateString)
        return date.toLocaleDateString('vi-VN')
    }

    /**
     * Format currency for display
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount || 0)
    }
}

// Export singleton instance
export default new OrderService()
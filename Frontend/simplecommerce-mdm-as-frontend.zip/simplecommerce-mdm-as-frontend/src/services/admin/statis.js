import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance with base configuration
const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            authStore.updateLastActivity()
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        if (error.response?.status === 401) {
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

class AdminStatsService {
    /**
     * Get admin overview statistics
     * @returns {Promise} Admin overview data
     */
    async getOverview() {
        try {
            const response = await api.get('/admin/stats/overview')
            return response.data
        } catch (error) {
            console.error('Error fetching admin overview:', error)
            throw error
        }
    }

    /**
     * Get sales series data
     * @param {string} range - Time range (7d, 30d, 90d, 1y)
     * @returns {Promise} Sales series data
     */
    async getSalesSeries(range = '7d') {
        try {
            const response = await api.get('/admin/stats/sales-series', {
                params: { range }
            })
            return response.data
        } catch (error) {
            console.error('Error fetching sales series:', error)
            throw error
        }
    }

    /**
     * Get payment method breakdown
     * @param {string} range - Time range (7d, 30d, 90d, 1y)
     * @returns {Promise} Payment breakdown data
     */
    async getPaymentBreakdown(range = '30d') {
        try {
            const response = await api.get('/admin/stats/payment-breakdown', {
                params: { range }
            })
            return response.data
        } catch (error) {
            console.error('Error fetching payment breakdown:', error)
            throw error
        }
    }

    /**
     * Get top shops by revenue
     * @param {number} limit - Number of top shops to return
     * @returns {Promise} Top shops data
     */
    async getTopShops(limit = 10) {
        try {
            const response = await api.get('/admin/stats/top-shops', {
                params: { limit }
            })
            return response.data
        } catch (error) {
            console.error('Error fetching top shops:', error)
            throw error
        }
    }

    /**
     * Transform range parameter to match backend expectations
     * @param {string} selectedPeriod - Frontend period format
     * @param {number} selectedYear - Selected year
     * @returns {string} Backend range format
     */
    transformPeriodToRange(selectedPeriod, selectedYear) {
        const currentYear = new Date().getFullYear()
        
        if (selectedPeriod === 'year') {
            return selectedYear === currentYear ? '1y' : `${selectedYear}`
        }
        
        if (selectedPeriod.startsWith('q')) {
            return '90d' // Quarter approximation
        }
        
        if (selectedPeriod.startsWith('month')) {
            return '30d' // Month approximation
        }
        
        return '7d' // Default
    }

    /**
     * Export statistics data to Excel
     * @param {Object} filters - Current filter settings
     * @returns {Promise} Export status
     */
    async exportToExcel(filters) {
        try {
            const response = await api.post('/admin/stats/export', filters, {
                responseType: 'blob'
            })
            
            // Create blob and download
            const blob = new Blob([response.data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            })
            
            const url = window.URL.createObjectURL(blob)
            const link = document.createElement('a')
            link.href = url
            link.download = `admin_stats_${new Date().toISOString().split('T')[0]}.xlsx`
            
            document.body.appendChild(link)
            link.click()
            document.body.removeChild(link)
            
            window.URL.revokeObjectURL(url)
            
            return { success: true }
        } catch (error) {
            console.error('Error exporting Excel:', error)
            throw error
        }
    }
}

export default new AdminStatsService()
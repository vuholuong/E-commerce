import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance with base configuration
const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        // Sử dụng auth store để lấy token
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            console.log('Adding token to request')
            // Update last activity
            authStore.updateLastActivity()
        } else {
            console.log('No token found')
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        console.error('API Error:', error.response?.status, error.response?.data)

        if (error.response?.status === 401) {
            // Token expired, try refresh
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                // Retry original request
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                // Refresh failed, redirect to login
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

// Các API methods giữ nguyên như cũ...
export const categoriesApi = {
    async getAll() {
        try {
            console.log('Fetching categories from /admin/categories')
            const response = await api.get('/admin/categories')
            console.log('Categories response:', response.data)
            return {
                success: true,
                data: response.data.data || [],
                message: response.data.message
            }
        } catch (error) {
            console.error('Error fetching categories:', error)
            return {
                success: false,
                data: [],
                message: error.response?.data?.message || 'Không thể tải danh sách danh mục'
            }
        }
    },

    // Các method khác giữ nguyên...
    async getById(id) {
        try {
            const response = await api.get(`/admin/categories/${id}`)
            return {
                success: true,
                data: response.data.data,
                message: response.data.message
            }
        } catch (error) {
            console.error('Error fetching category:', error)
            return {
                success: false,
                data: null,
                message: error.response?.data?.message || 'Không thể tải thông tin danh mục'
            }
        }
    },

    async create(categoryData) {
        try {
            const response = await api.post('/admin/categories', categoryData)
            return {
                success: true,
                data: response.data.data,
                message: response.data.message || 'Danh mục đã được tạo thành công'
            }
        } catch (error) {
            console.error('Error creating category:', error)
            return {
                success: false,
                data: null,
                message: error.response?.data?.message || 'Không thể tạo danh mục mới'
            }
        }
    },

    async update(id, categoryData) {
        try {
            const response = await api.put(`/admin/categories/${id}`, categoryData)
            return {
                success: true,
                data: response.data.data,
                message: response.data.message || 'Danh mục đã được cập nhật thành công'
            }
        } catch (error) {
            console.error('Error updating category:', error)
            return {
                success: false,
                data: null,
                message: error.response?.data?.message || 'Không thể cập nhật danh mục'
            }
        }
    },

    async delete(id) {
        try {
            const response = await api.delete(`/admin/categories/${id}`)
            return {
                success: true,
                message: response.data.message || 'Danh mục đã được xóa thành công'
            }
        } catch (error) {
            console.error('Error deleting category:', error)
            return {
                success: false,
                message: error.response?.data?.message || 'Không thể xóa danh mục'
            }
        }
    },

    async getPublicCategories() {
        try {
            const response = await axios.get('/api/v1/categories')
            return {
                success: true,
                data: response.data.data || [],
                message: response.data.message
            }
        } catch (error) {
            console.error('Error fetching public categories:', error)
            return {
                success: false,
                data: [],
                message: 'Không thể tải danh sách danh mục'
            }
        }
    }
}

// Utility functions giữ nguyên như cũ...
export const categoryUtils = {
    generateSlug(text) {
        if (!text) return ''

        return text
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/đ/g, 'd')
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .trim('-')
    },

    validateCategory(categoryData) {
        const errors = {}

        if (!categoryData.name?.trim()) {
            errors.name = 'Tên danh mục là bắt buộc'
        } else if (categoryData.name.trim().length < 2) {
            errors.name = 'Tên danh mục phải có ít nhất 2 ký tự'
        } else if (categoryData.name.trim().length > 255) {
            errors.name = 'Tên danh mục không được vượt quá 255 ký tự'
        }

        if (!categoryData.slug?.trim()) {
            errors.slug = 'Slug là bắt buộc'
        } else if (!/^[a-z0-9-]+$/.test(categoryData.slug.trim())) {
            errors.slug = 'Slug chỉ được chứa chữ thường, số và dấu gạch ngang'
        } else if (categoryData.slug.trim().length > 255) {
            errors.slug = 'Slug không được vượt quá 255 ký tự'
        }

        if (categoryData.description && categoryData.description.length > 1000) {
            errors.description = 'Mô tả không được vượt quá 1000 ký tự'
        }

        return {
            isValid: Object.keys(errors).length === 0,
            errors
        }
    },

    buildCategoryTree(categories) {
        const categoryMap = new Map()
        const rootCategories = []

        categories.forEach(category => {
            categoryMap.set(category.id, {...category, children: []})
        })

        categories.forEach(category => {
            const categoryNode = categoryMap.get(category.id)

            if (category.parentId) {
                const parent = categoryMap.get(category.parentId)
                if (parent) {
                    parent.children.push(categoryNode)
                }
            } else {
                rootCategories.push(categoryNode)
            }
        })

        return rootCategories
    },

    getCategoryPath(categoryId, categories) {
        const path = []
        const categoryMap = new Map(categories.map(cat => [cat.id, cat]))

        let currentCategory = categoryMap.get(categoryId)

        while (currentCategory) {
            path.unshift(currentCategory)
            currentCategory = currentCategory.parentId ? categoryMap.get(currentCategory.parentId) : null
        }

        return path
    },

    getSubcategories(parentId, categories) {
        return categories.filter(category => category.parentId === parentId)
    },

    hasChildren(categoryId, categories) {
        return categories.some(category => category.parentId === categoryId)
    }
}

export default categoriesApi
import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance with base configuration
const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            authStore.updateLastActivity()
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        if (error.response?.status === 401) {
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

export const addressService = {
  /**
   * Lấy danh sách tất cả địa chỉ với phân trang và lọc
   * @param {Object} searchParams - Tham số tìm kiếm
   * @returns {Promise}
   */
  async getAllAddresses(searchParams = {}) {
    try {
      const response = await api.get('/admin/addresses', {
        params: searchParams
      })
      return response.data
    } catch (error) {
      console.error('Error fetching addresses:', error)
      throw error
    }
  },

  /**
   * Lấy địa chỉ theo ID
   * @param {number} addressId - ID của địa chỉ
   * @returns {Promise}
   */
  async getAddressById(userAddressId) {
    try {
      const response = await api.get(`/admin/addresses/${userAddressId}`)
      return response.data
    } catch (error) {
      console.error('Error fetching address by ID:', error)
      throw error
    }
  },

  /**
   * Lấy danh sách địa chỉ theo User ID
   * @param {number} userId - ID của người dùng
   * @returns {Promise}
   */
  async getAddressesByUserId(userId) {
    try {
      const response = await api.get(`/admin/addresses/user/${userId}`)
      return response.data
    } catch (error) {
      console.error('Error fetching addresses by user ID:', error)
      throw error
    }
  },

  /**
   * Xóa địa chỉ
   * @param {number} addressId - ID của địa chỉ
   * @param {Object} deleteData - Dữ liệu xóa (adminId, reason)
   * @returns {Promise}
   */
  async deleteAddress(addressId, deleteData = {}) {
    try {
      const response = await api.delete(`/admin/addresses/${addressId}`, {
        data: deleteData
      })
      return response.data
    } catch (error) {
      console.error('Error deleting address:', error)
      throw error
    }
  }
}
import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance with base configuration
const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            authStore.updateLastActivity()
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        if (error.response?.status === 401) {
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

// Product status mapping
export const PRODUCT_STATUS = {
    'PENDING_APPROVAL': { label: 'Chờ duyệt', color: 'warning' },
    'APPROVED': { label: 'Đã duyệt', color: 'success' },
    'REJECTED': { label: 'Bị từ chối', color: 'danger' },
    'ACTIVE': { label: 'Đang bán', color: 'primary' },
    'INACTIVE': { label: 'Tạm ngưng', color: 'secondary' },
    'OUT_OF_STOCK': { label: 'Hết hàng', color: 'warning' }
}

class ProductAdminService {
    /**
     * Get all products with filters and pagination
     */
    async getAllProducts(filters = {}) {
        try {
            const params = new URLSearchParams()
            
            Object.keys(filters).forEach(key => {
                if (filters[key] !== null && filters[key] !== undefined && filters[key] !== '') {
                    params.append(key, filters[key])
                }
            })

            const response = await api.get(`/admin/products?${params.toString()}`)
            
            // Check if response has the expected structure
            if (response.data?.statusCode === 200 || response.data?.statusCode === 0) {
                const responseData = response.data.data
                
                // Transform product content
                if (responseData.content && Array.isArray(responseData.content)) {
                    responseData.content = responseData.content.map(this.transformProduct)
                }
                
                return {
                    success: true,
                    message: response.data.message,
                    data: responseData
                }
            } else {
                throw new Error(response.data?.message || 'Invalid response format')
            }
        } catch (error) {
            console.error('Error fetching products:', error)
            throw new Error(error.response?.data?.message || 'Không thể tải danh sách sản phẩm')
        }
    }

    /**
     * Get pending products for approval
     */
    async getPendingProducts(filters = {}) {
        try {
            const params = new URLSearchParams()
            
            Object.keys(filters).forEach(key => {
                if (filters[key] !== null && filters[key] !== undefined && filters[key] !== '') {
                    params.append(key, filters[key])
                }
            })

            const response = await api.get(`/admin/products/pending?${params.toString()}`)
            
            if (response.data?.statusCode === 200 || response.data?.statusCode === 0) {
                const responseData = response.data.data
                
                if (responseData.content && Array.isArray(responseData.content)) {
                    responseData.content = responseData.content.map(this.transformProduct)
                }
                
                return {
                    success: true,
                    message: response.data.message,
                    data: responseData
                }
            } else {
                throw new Error(response.data?.message || 'Invalid response format')
            }
        } catch (error) {
            console.error('Error fetching pending products:', error)
            throw new Error(error.response?.data?.message || 'Không thể tải sản phẩm chờ duyệt')
        }
    }

    /**
     * Get product by ID
     */
    async getProductById(id) {
        try {
            const response = await api.get(`/admin/products/${id}`)
            
            if (response.data?.statusCode === 200 || response.data?.statusCode === 0) {
                return {
                    success: true,
                    message: response.data.message,
                    data: this.transformProduct(response.data.data)
                }
            } else {
                throw new Error(response.data?.message || 'Invalid response format')
            }
        } catch (error) {
            console.error('Error fetching product:', error)
            throw new Error(error.response?.data?.message || 'Không thể tải thông tin sản phẩm')
        }
    }

    /**
     * Approve a product
     */
    async approveProduct(id, note = '') {
        try {
            const payload = note.trim() ? { approvalNote: note } : {}
            const response = await api.put(`/admin/products/${id}/approve`, payload)
            
            if (response.data?.statusCode === 200) {
                return {
                    success: true,
                    message: response.data.message,
                    data: response.data.data ? this.transformProduct(response.data.data) : null
                }
            } else {
                throw new Error(response.data?.message || 'Approval failed')
            }
        } catch (error) {
            console.error('Error approving product:', error)
            throw new Error(error.response?.data?.message || 'Không thể duyệt sản phẩm')
        }
    }

    /**
     * Reject a product
     */
    async rejectProduct(id, rejectionReason, rejectionNote = '') {
        try {
            const response = await api.put(`/admin/products/${id}/reject`, {
                rejectionReason: rejectionReason + (rejectionNote ? ` - ${rejectionNote}` : '')
            })
            
            if (response.data?.statusCode === 200) {
                return {
                    success: true,
                    message: response.data.message,
                    data: response.data.data ? this.transformProduct(response.data.data) : null
                }
            } else {
                throw new Error(response.data?.message || 'Rejection failed')
            }
        } catch (error) {
            console.error('Error rejecting product:', error)
            throw new Error(error.response?.data?.message || 'Không thể từ chối sản phẩm')
        }
    }
    /**
     * Transform product data from API to component format
     */
    transformProduct(product) {
    const status = PRODUCT_STATUS[product.status] || { label: product.status, color: 'secondary' };
    
    // Xử lý variants - đảm bảo luôn là array và có ít nhất 1 item
    const variants = Array.isArray(product.variants) && product.variants.length > 0 
        ? product.variants 
        : [{
            id: product.id, // Sử dụng product id nếu không có variant
            sku: product.sku || 'N/A',
            finalPrice: product.basePrice || 0,
            compareAtPrice: null,
            stockQuantity: 0, // Mặc định 0 nếu không có variant
            options: typeof product.options === 'string' ? JSON.parse(product.options || '{}') : (product.options || {}),
            isActive: true
        }];

    // Tính tổng stock từ tất cả biến thể
    const totalStock = variants.reduce((total, variant) => {
        return total + (variant.stockQuantity || 0);
    }, 0);

    // Tìm giá thấp nhất từ các biến thể
    const lowestPrice = Math.min(...variants.map(v => v.finalPrice || 0));

    // Chuẩn bị dữ liệu options
    const parseOptions = (options) => {
        try {
            return typeof options === 'string' ? JSON.parse(options) : options;
        } catch {
            return {};
        }
    };

    return {
        id: product.id,
        name: product.name,
        slug: product.slug,
        sku: product.sku || variants[0]?.sku || 'N/A',
        seller: product.shopName,
        sellerEmail: product.sellerEmail,
        category: product.categoryName,
        price: lowestPrice,
        basePrice: product.basePrice,
        stock: totalStock,
        status: status.label,
        statusColor: status.color,
        statusKey: product.status,
        createdAt: product.createdAt ? ProductAdminService.formatDate(product.createdAt) : 'N/A',
        approvedAt: product.approvedAt ? ProductAdminService.formatDate(product.approvedAt) : 'N/A',
        publishedAt: product.publishedAt ? ProductAdminService.formatDate(product.publishedAt) : 'N/A',
        image: product.imageUrls?.[0] || '/images/no-image.png',
        images: product.imageUrls || [],
        description: product.description || 'Không có mô tả',
        rejectionReason: product.rejectionReason,
        isFeatured: product.isFeatured || false,
        weightGrams: product.weightGrams || 0,
        dimensions: product.dimensions || 'N/A',
        attributes: product.attributes || 'N/A',
        variants: variants.map(v => ({
            id: v.id,
            sku: v.sku || 'N/A',
            finalPrice: v.finalPrice || 0,
            compareAtPrice: v.compareAtPrice || null,
            stockQuantity: v.stockQuantity || 0,
            options: parseOptions(v.options),
            isActive: v.isActive !== false
        })),
        shopId: product.shopId,
        categoryId: product.categoryId,
        hasVariants: product.variants?.length > 1 || false,
        variantCount: product.variants?.length || 1,
        priceRange: ProductAdminService.calculatePriceRange(variants)
    };
}

    /**
     * Calculate price range from variants
     */
    static calculatePriceRange(variants) {
        if (!variants || variants.length === 0) {
            return null
        }

        const prices = variants.map(v => v.finalPrice || v.compareAtPrice || 0).filter(p => p > 0)
        
        if (prices.length === 0) {
            return null
        }

        const minPrice = Math.min(...prices)
        const maxPrice = Math.max(...prices)

        if (minPrice === maxPrice) {
            return {
                min: minPrice,
                max: maxPrice,
                display: ProductAdminService.formatCurrency(minPrice)
            }
        }

        return {
            min: minPrice,
            max: maxPrice,
            display: `${ProductAdminService.formatCurrency(minPrice)} - ${ProductAdminService.formatCurrency(maxPrice)}`
        }
    }

    /**
     * Format date to Vietnamese format
     */
    static formatDate(dateString) {
        if (!dateString) return ''
        
        const date = new Date(dateString)
        return date.toLocaleDateString('vi-VN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        })
    }

    /**
     * Format currency to Vietnamese format
     */
    static formatCurrency(amount) {
        if (!amount) return '0 ₫'
        
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount)
    }

    /**
     * Get filter options for UI
     */
    getStatusOptions() {
        return [
            { value: '', label: 'Tất cả trạng thái' },
            ...Object.entries(PRODUCT_STATUS).map(([key, value]) => ({
                value: key,
                label: value.label
            }))
        ]
    }

     // Thêm vào instance
  formatCurrency(amount) {
    return ProductAdminService.formatCurrency(amount)
  }
}

// Create singleton instance
const productAdminService = new ProductAdminService()
export default productAdminService
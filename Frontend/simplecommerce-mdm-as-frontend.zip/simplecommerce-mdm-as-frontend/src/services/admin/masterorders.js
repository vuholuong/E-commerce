// services/masterOrderService.js
import axios from 'axios'
import { useAuthStore } from '@/stores/auth'

// Create axios instance with base configuration
const api = axios.create({
    baseURL: '/api/v1',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const authStore = useAuthStore()
        const token = authStore.getAccessToken()

        if (token) {
            config.headers.Authorization = `Bearer ${token}`
            authStore.updateLastActivity()
        }
        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response
    },
    async (error) => {
        const authStore = useAuthStore()

        if (error.response?.status === 401) {
            const refreshSuccess = await authStore.refreshTokenAction()

            if (refreshSuccess) {
                const token = authStore.getAccessToken()
                error.config.headers.Authorization = `Bearer ${token}`
                return api.request(error.config)
            } else {
                authStore.logout()
                window.location.href = '/admin/login'
            }
        }

        return Promise.reject(error)
    }
)

// Master Order Service
export const masterOrderService = {
    // Get all master orders with pagination and filters
    async getAllMasterOrders(params = {}) {
        try {
            const response = await api.get('/admin/orders/master', { params })
            return response.data
        } catch (error) {
            console.error('Error fetching master orders:', error)
            throw error
        }
    },

    // Get master order details by ID
    async getMasterOrderById(masterOrderId) {
        try {
            const response = await api.get(`/admin/orders/master/${masterOrderId}`)
            return response.data
        } catch (error) {
            console.error('Error fetching master order details:', error)
            throw error
        }
    },

    // Helper method to format currency
    formatCurrency(amount) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount)
    },

    // Helper method to format date
    formatDate(dateString) {
        return new Date(dateString).toLocaleString('vi-VN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        })
    },

    // Helper method to get status badge class
    getStatusBadgeClass(status) {
        const statusClasses = {
            'PENDING': 'badge-warning',
            'PROCESSING': 'badge-info',
            'SHIPPED': 'badge-primary',
            'DELIVERED': 'badge-success',
            'COMPLETED': 'badge-success',
            'CANCELLED': 'badge-danger',
            'REFUNDED': 'badge-secondary'
        }
        return statusClasses[status] || 'badge-secondary'
    }
}
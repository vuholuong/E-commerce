import {createApp} from 'vue'
import App from './App.vue'
import router from './router'
// Bootstrap imports
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import 'bootstrap-icons/font/bootstrap-icons.css'
import 'bootstrap/dist/js/bootstrap.bundle'
import {createPinia} from "pinia";

// Auto Login Service
import { autoLoginService } from '@/services/auth/autoLoginService'

// Create and mount the app
const app = createApp(App)
const pinia = createPinia()
app.use(pinia)
app.use(router)

// Khởi tạo Auto Login Service sau khi app đã mount
app.config.globalProperties.$autoLoginService = autoLoginService

// Mount app
app.mount('#app')

// Khởi tạo Auto Login Service sau khi app đã mount
app.config.globalProperties.$autoLoginService = autoLoginService

// Khởi tạo auto login sau khi Pinia đã sẵn sàng
setTimeout(() => {
  console.log('⚡ Vue app ready, khởi tạo Auto Login Service...')
  
  try {
    autoLoginService.init()
  } catch (error) {
    console.warn('⚠️ AutoLoginService chưa thể khởi tạo:', error)
  }
}, 500)
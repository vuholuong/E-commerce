<template>
  <div class="error-page">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8 text-center">
          <!-- 404 Icon -->
          <div class="error-icon mb-4">
            <div class="error-number">4</div>
            <div class="error-zero">
              <i class="bi bi-emoji-dizzy"></i>
            </div>
            <div class="error-number">4</div>
          </div>
          
          <!-- Error Message -->
          <h1 class="error-title mb-3">Oops! Trang không tồn tại</h1>
          <p class="error-description mb-4">
            Trang bạn đang tìm kiếm có thể đã bị di chuyển, xóa hoặc URL không chính xác.
          </p>
          
          <!-- Search Box -->
          <div class="search-box mb-4">
            <div class="input-group">
              <input 
                type="text" 
                class="form-control" 
                placeholder="Tìm kiếm trang..."
                v-model="searchQuery"
                @keyup.enter="handleSearch"
              >
              <button class="btn btn-primary" @click="handleSearch">
                <i class="bi bi-search"></i>
              </button>
            </div>
          </div>
          
          <!-- Action Buttons -->
          <div class="action-buttons mb-4">
            <router-link to="/" class="btn btn-primary btn-lg me-3">
              <i class="bi bi-house-door"></i>
              Về trang chủ
            </router-link>
            <button @click="$router.go(-1)" class="btn btn-outline-secondary btn-lg me-3">
              <i class="bi bi-arrow-left"></i>
              Quay lại
            </button>
            <button @click="refreshPage" class="btn btn-outline-info btn-lg">
              <i class="bi bi-arrow-clockwise"></i>
              Làm mới
            </button>
          </div>
          
          <!-- Quick Links -->
          <div class="quick-links">
            <h6 class="text-muted mb-3">Có thể bạn quan tâm:</h6>
            <div class="row justify-content-center">
              <div class="col-md-4 mb-2">
                <router-link to="/login" class="btn btn-outline-primary btn-sm w-100">
                  <i class="bi bi-box-arrow-in-right"></i> Đăng nhập
                </router-link>
              </div>
              <div class="col-md-4 mb-2">
                <router-link to="/admin/login" class="btn btn-outline-success btn-sm w-100">
                  <i class="bi bi-shield-lock"></i> Admin
                </router-link>
              </div>
              <div class="col-md-4 mb-2">
                <router-link to="/seller/login" class="btn btn-outline-warning btn-sm w-100">
                  <i class="bi bi-shop"></i> Seller
                </router-link>
              </div>
            </div>
          </div>
          
          <!-- Help Section -->
          <div class="help-section mt-5">
            <div class="card border-0 bg-light">
              <div class="card-body text-center">
                <i class="bi bi-question-circle text-primary mb-2" style="font-size: 2rem;"></i>
                <h6>Bạn cần hỗ trợ?</h6>
                <p class="text-muted mb-2">Liên hệ với chúng tôi để được hỗ trợ nhanh chóng</p>
                <div class="d-flex justify-content-center gap-2">
                  <button class="btn btn-outline-primary btn-sm">
                    <i class="bi bi-envelope"></i> Email
                  </button>
                  <button class="btn btn-outline-success btn-sm">
                    <i class="bi bi-chat-dots"></i> Chat
                  </button>
                  <button class="btn btn-outline-info btn-sm">
                    <i class="bi bi-telephone"></i> Hotline
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const searchQuery = ref('')

// Set page title
onMounted(() => {
  document.title = '404 - Trang không tồn tại | MUADIMA'
  
  // Add some fun animation
  setTimeout(() => {
    const errorIcon = document.querySelector('.error-icon')
    if (errorIcon) {
      errorIcon.classList.add('animate-bounce')
    }
  }, 500)
})

// Handle search
const handleSearch = () => {
  if (searchQuery.value.trim()) {
    // Redirect to search results or show search modal
    console.log('Searching for:', searchQuery.value)
    // You can implement search functionality here
  }
}

// Refresh page
const refreshPage = () => {
  window.location.reload()
}
</script>

<style scoped>
.error-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 2rem 0;
}

.error-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  margin-bottom: 2rem;
}

.error-number {
  font-size: 8rem;
  font-weight: 900;
  color: #fff;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
  line-height: 1;
}

.error-zero {
  font-size: 6rem;
  color: #ffd700;
  animation: pulse 2s infinite;
}

.error-title {
  font-size: 2.5rem;
  font-weight: 700;
  color: #fff;
  text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}

.error-description {
  font-size: 1.1rem;
  color: rgba(255,255,255,0.9);
  line-height: 1.6;
}

.search-box {
  max-width: 400px;
  margin: 0 auto;
}

.search-box .form-control {
  border: none;
  border-radius: 25px 0 0 25px;
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.search-box .btn {
  border-radius: 0 25px 25px 0;
  padding: 0.75rem 1.5rem;
  border: none;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.action-buttons .btn {
  border-radius: 25px;
  padding: 0.75rem 1.5rem;
  font-weight: 600;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.action-buttons .btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.15);
}

.quick-links .btn {
  border-radius: 20px;
  transition: all 0.3s ease;
}

.quick-links .btn:hover {
  transform: scale(1.05);
}

.help-section .card {
  border-radius: 20px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
}

.help-section .btn {
  border-radius: 20px;
  transition: all 0.3s ease;
}

.help-section .btn:hover {
  transform: translateY(-1px);
}

/* Animations */
@keyframes pulse {
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
}

.animate-bounce {
  animation: bounce 1s infinite;
}

@keyframes bounce {
  0%, 20%, 53%, 80%, 100% {
    transform: translate3d(0,0,0);
  }
  40%, 43% {
    transform: translate3d(0,-30px,0);
  }
  70% {
    transform: translate3d(0,-15px,0);
  }
  90% {
    transform: translate3d(0,-4px,0);
  }
}

/* Responsive Design */
@media (max-width: 768px) {
  .error-page {
    padding: 1rem 0;
  }
  
  .error-number {
    font-size: 5rem;
  }
  
  .error-zero {
    font-size: 4rem;
  }
  
  .error-title {
    font-size: 2rem;
  }
  
  .error-description {
    font-size: 1rem;
  }
  
  .action-buttons .btn {
    display: block;
    width: 100%;
    margin-bottom: 1rem;
  }
  
  .action-buttons .btn:last-child {
    margin-bottom: 0;
  }
  
  .quick-links .row {
    gap: 0.5rem;
  }
}

@media (max-width: 576px) {
  .error-number {
    font-size: 4rem;
  }
  
  .error-zero {
    font-size: 3rem;
  }
  
  .error-title {
    font-size: 1.75rem;
  }
  
  .search-box {
    max-width: 100%;
  }
}

/* Dark mode support */
@media (prefers-color-scheme: dark) {
  .error-page {
    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
  }
  
  .help-section .card {
    background-color: #2c3e50 !important;
    color: #fff;
  }
  
  .help-section .text-muted {
    color: rgba(255,255,255,0.7) !important;
  }
}
</style>

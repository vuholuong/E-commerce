
<template>
  <div class="login-container d-flex align-items-center justify-content-center min-vh-100">
    <div class="card selection-form">
      <div class="card-body text-center">
        <i class="bi bi-building display-3 text-primary mb-4"></i>
        <h2 class="card-title mb-4">Hệ thống quản lý E-commerce</h2>
        <p class="text-muted mb-4">Vui lòng chọn loại tài khoản để đăng nhập</p>
        
        <div class="d-grid gap-3">
          <router-link to="/admin/login" class="btn btn-primary btn-lg">
            <i class="bi bi-shield-check me-2"></i>
            Đăng nhập Admin
            <br>
            <small class="opacity-75">Quản trị hệ thống</small>
          </router-link>
          
          <router-link to="/seller/login" class="btn btn-success btn-lg">
            <i class="bi bi-shop me-2"></i>
            Đăng nhập Seller
            <br>
            <small class="opacity-75">Quản lý cửa hàng</small>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
// Trang chọn loại đăng nhập
</script>

<style scoped>
.login-container {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 1rem;
}

.selection-form {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 15px;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
  max-width: 500px;
  width: 100%;
  margin: 0 auto;
}

.btn-lg {
  padding: 1rem 2rem;
  border-radius: 10px;
  text-decoration: none;
  transition: all 0.3s ease;
}

.btn-primary {
  background: linear-gradient(45deg, #667eea, #764ba2);
  border: none;
}

.btn-primary:hover {
  background: linear-gradient(45deg, #764ba2, #667eea);
  transform: translateY(-3px);
  box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
}

.btn-success {
  background: linear-gradient(45deg, #f093fb, #f5576c);
  border: none;
}

.btn-success:hover {
  background: linear-gradient(45deg, #f5576c, #f093fb);
  transform: translateY(-3px);
  box-shadow: 0 10px 25px rgba(240, 147, 251, 0.3);
}

/* Mobile responsive */
@media (max-width: 768px) {
  .login-container {
    padding: 0.5rem;
  }

  .selection-form {
    margin: 1rem auto;
    border-radius: 10px;
  }

  .card-body {
    padding: 2rem 1.5rem;
  }

  h2 {
    font-size: 1.5rem;
  }

  .btn-lg {
    padding: 0.875rem 1.5rem;
    font-size: 1rem;
  }

  .display-3 {
    font-size: 2.5rem;
  }
}

@media (max-width: 576px) {
  .selection-form {
    margin: 0.5rem auto;
  }

  .card-body {
    padding: 1.5rem 1rem;
  }

  .btn-lg {
    padding: 0.75rem 1rem;
  }

  .display-3 {
    font-size: 2rem;
  }
}
</style>

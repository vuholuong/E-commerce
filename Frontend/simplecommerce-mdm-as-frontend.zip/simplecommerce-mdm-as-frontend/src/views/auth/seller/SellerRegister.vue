<script setup>
import { ref, reactive, onMounted, watch } from 'vue'
import { RouterLink } from 'vue-router'
import Swal from 'sweetalert2'

// Form data
const formData = reactive({
  name: '',
  description: '',
  contactEmail: '',
  contactPhone: '',
  addressLine1: '',
  addressLine2: '',
  city: '', // Tỉnh/thành
  district: '', // Quận/huyện
  state: '',
  country: '',
  postalCode: ''
})

// Lỗi
const errors = ref({})
const isLoading = ref(false)

// Danh sách tỉnh/thành, quận/huyện
const provinces = ref([])
const districts = ref([])

// Lấy dữ liệu tỉnh/thành từ API
const fetchProvinces = async () => {
  try {
    const res = await fetch('https://provinces.open-api.vn/api/p/')
    provinces.value = await res.json()
  } catch (err) {
    console.error('Lỗi khi tải danh sách tỉnh/thành:', err)
  }
}

// Lấy dữ liệu quận/huyện theo tỉnh đã chọn
const fetchDistricts = async (provinceCode) => {
  try {
    const res = await fetch(`https://provinces.open-api.vn/api/p/${provinceCode}?depth=2`)
    const data = await res.json()
    districts.value = data.districts || []
  } catch (err) {
    console.error('Lỗi khi tải danh sách quận/huyện:', err)
  }
}

// Theo dõi khi chọn tỉnh/thành để load quận/huyện
watch(
  () => formData.city,
  (newVal) => {
    const selectedProvince = provinces.value.find(p => p.name === newVal)
    if (selectedProvince) {
      formData.district = '' // reset quận/huyện
      fetchDistricts(selectedProvince.code)
    } else {
      districts.value = []
    }
  }
)

onMounted(() => {
  fetchProvinces()
})

// Validate
const validateForm = () => {
  errors.value = {}

  if (!formData.name.trim()) {
    errors.value.name = 'Tên shop là bắt buộc'
  }
  if (!formData.description.trim()) {
    errors.value.description = 'Mô tả shop là bắt buộc'
  }
  if (!formData.contactEmail.trim()) {
    errors.value.contactEmail = 'Email liên hệ là bắt buộc'
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.contactEmail)) {
    errors.value.contactEmail = 'Email không hợp lệ'
  }
  if (!formData.contactPhone.trim()) {
    errors.value.contactPhone = 'Số điện thoại liên hệ là bắt buộc'
  } else if (!/^[0-9]{10,11}$/.test(formData.contactPhone.replace(/\s/g, ''))) {
    errors.value.contactPhone = 'Số điện thoại không hợp lệ'
  }
  if (!formData.addressLine1.trim()) {
    errors.value.addressLine1 = 'Địa chỉ 1 là bắt buộc'
  }
  if (!formData.city.trim()) {
    errors.value.city = 'Thành phố là bắt buộc'
  }
  if (!formData.district.trim()) {
    errors.value.district = 'Quận/huyện là bắt buộc'
  }
  if (!formData.country.trim()) {
    errors.value.country = 'Quốc gia là bắt buộc'
  }
  if (!formData.postalCode.trim()) {
    errors.value.postalCode = 'Mã bưu điện là bắt buộc'
  }

  return Object.keys(errors.value).length === 0
}

// Submit
const submitForm = async () => {
  if (!validateForm()) return

  isLoading.value = true
  try {
    // API thật ở đây
    await new Promise(r => setTimeout(r, 1500))
    await Swal.fire({
      icon: 'success',
      title: 'Đăng ký thành công!',
      text: 'Shop của bạn đã được gửi để phê duyệt.',
      confirmButtonText: 'OK'
    })
    resetForm()
  } catch (err) {
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Không thể tạo shop, vui lòng thử lại.',
      confirmButtonText: 'OK'
    })
  } finally {
    isLoading.value = false
  }
}

// Reset
const resetForm = () => {
  for (let key in formData) formData[key] = ''
  errors.value = {}
}
</script>

<template>
  <div class="container py-1 bg-light">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6">
        <div class="card shadow border-0">
          <div class="card-header bg-success text-white text-center">
            <h4><i class="fas fa-store me-2"></i> Đăng ký Shop</h4>
            <p class="mb-0 small">Hoàn tất thông tin bên dưới để bắt đầu bán hàng</p>
          </div>

          <div class="card-body p-4">
            <form @submit.prevent="submitForm" novalidate>
              <!-- Thông tin shop -->
              <h5 class="text-success border-bottom pb-2 mb-3"><i class="fas fa-info-circle me-2"></i>Thông tin shop
              </h5>
              <div class="mb-3">
                <label class="form-label">Tên shop *</label>
                <input v-model="formData.name" type="text" class="form-control" :class="{ 'is-invalid': errors.name }">
                <div v-if="errors.name" class="invalid-feedback">{{ errors.name }}</div>
              </div>
              <div class="mb-3">
                <label class="form-label">Mô tả *</label>
                <textarea v-model="formData.description" rows="3" class="form-control"
                  :class="{ 'is-invalid': errors.description }"></textarea>
                <div v-if="errors.description" class="invalid-feedback">{{ errors.description }}</div>
              </div>

              <!-- Liên hệ -->
              <h5 class="text-success border-bottom pb-2 mb-3"><i class="fas fa-phone me-2"></i>Thông tin liên hệ</h5>
              <div class="mb-3">
                <label class="form-label">Email liên hệ *</label>
                <input v-model="formData.contactEmail" type="email" class="form-control"
                  :class="{ 'is-invalid': errors.contactEmail }">
                <div v-if="errors.contactEmail" class="invalid-feedback">{{ errors.contactEmail }}</div>
              </div>
              <div class="mb-3">
                <label class="form-label">Số điện thoại liên hệ *</label>
                <input v-model="formData.contactPhone" type="tel" class="form-control"
                  :class="{ 'is-invalid': errors.contactPhone }">
                <div v-if="errors.contactPhone" class="invalid-feedback">{{ errors.contactPhone }}</div>
              </div>

              <!-- Địa chỉ -->
              <h5 class="text-success border-bottom pb-2 mb-3"><i class="fas fa-map-marker-alt me-2"></i>Địa chỉ</h5>
              <div class="mb-3">
                <label class="form-label">Địa chỉ 1 *</label>
                <input v-model="formData.addressLine1" type="text" class="form-control"
                  :class="{ 'is-invalid': errors.addressLine1 }">
                <div v-if="errors.addressLine1" class="invalid-feedback">{{ errors.addressLine1 }}</div>
              </div>
              <div class="mb-3">
                <label class="form-label">Địa chỉ 2</label>
                <input v-model="formData.addressLine2" type="text" class="form-control">
              </div>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Tỉnh/Thành phố *</label>
                  <select v-model="formData.city" class="form-select" :class="{ 'is-invalid': errors.city }">
                    <option value="">-- Chọn tỉnh/thành --</option>
                    <option v-for="p in provinces" :key="p.code" :value="p.name">{{ p.name }}</option>
                  </select>
                  <div v-if="errors.city" class="invalid-feedback">{{ errors.city }}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Quận/Huyện *</label>
                  <select v-model="formData.district" class="form-select" :class="{ 'is-invalid': errors.district }"
                    :disabled="!districts.length">
                    <option value="">-- Chọn quận/huyện --</option>
                    <option v-for="d in districts" :key="d.code" :value="d.name">{{ d.name }}</option>
                  </select>
                  <div v-if="errors.district" class="invalid-feedback">{{ errors.district }}</div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Quốc gia *</label>
                  <input v-model="formData.country" type="text" class="form-control"
                    :class="{ 'is-invalid': errors.country }">
                  <div v-if="errors.country" class="invalid-feedback">{{ errors.country }}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Mã bưu điện *</label>
                  <input v-model="formData.postalCode" type="text" class="form-control"
                    :class="{ 'is-invalid': errors.postalCode }">
                  <div v-if="errors.postalCode" class="invalid-feedback">{{ errors.postalCode }}</div>
                </div>
              </div>

              <!-- Nút -->
              <div class="d-grid gap-2 mt-3">
                <button type="submit" class="btn btn-success btn-lg" :disabled="isLoading">
                  <span v-if="isLoading" class="spinner-border spinner-border-sm me-2"></span>
                  {{ isLoading ? 'Đang xử lý...' : 'Đăng ký Shop' }}
                </button>
              </div>
            </form>

            <!-- Link đăng nhập -->
            <div class="text-center mt-3 border-top pt-3">
              <p class="text-muted mb-0">
                Đã có tài khoản seller?
                <RouterLink to="/seller/login" class="text-success fw-bold">Đăng nhập</RouterLink>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<template>
  <div class="seller-login-container d-flex align-items-center justify-content-center min-vh-100">
    <div class="card seller-login-form">
      <div class="card-body">
        <div class="text-center mb-4">
          <i class="bi bi-shop display-4 text-success"></i>
          <h2 class="card-title mt-3">Seller Portal</h2>
          <p class="text-muted">Đăng nhập vào cửa hàng của bạn</p>
        </div>

        <!-- Alert cho thông báo lỗi -->
        <div v-if="authStore.error" class="alert alert-danger" role="alert">
          <i class="bi bi-exclamation-circle me-2"></i>
          {{ authStore.error }}
        </div>

        <!-- Alert cho thông báo thành công -->
        <div v-if="successMessage" class="alert alert-success" role="alert">
          <i class="bi bi-check-circle me-2"></i>
          {{ successMessage }}
        </div>

        <form @submit.prevent="handleSellerLogin">
          <div class="mb-3">
            <label for="seller-email" class="form-label">Email Seller</label>
            <input
                type="email"
                class="form-control"
                id="seller-email"
                v-model="sellerForm.email"
                placeholder="seller@example.com"
                required
                :disabled="authStore.isLoading"
            >
          </div>
          <div class="mb-3">
            <label for="seller-password" class="form-label">Mật khẩu</label>
            <input
                type="password"
                class="form-control"
                id="seller-password"
                v-model="sellerForm.password"
                placeholder="Nhập mật khẩu seller"
                required
                :disabled="authStore.isLoading"
            >
          </div>
          <button
              type="submit"
              class="btn btn-success w-100 mb-3"
              :disabled="authStore.isLoading"
          >
            <span v-if="authStore.isLoading" class="spinner-border spinner-border-sm me-2" role="status"
                  aria-hidden="true"></span>
            <i v-else class="bi bi-box-arrow-in-right me-2"></i>
            {{ authStore.isLoading ? 'Đang đăng nhập...' : 'Đăng nhập Seller' }}
          </button>
        </form>
        <hr>
        <div class="d-flex justify-content-center align-items-center mt-3">
          <router-link to="/seller/forgot-password" class="me-auto">Quên mật khẩu?</router-link>
          <!-- <router-link to="/seller/register">Đăng kí tài khoản</router-link> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import {ref, onMounted, nextTick} from 'vue'
import {useRouter} from 'vue-router'
import {useAuthStore} from '@/stores/auth'
import Swal from 'sweetalert2'

const router = useRouter()
const authStore = useAuthStore()

const sellerForm = ref({
  email: '',
  password: ''
})

const successMessage = ref('')

// Kiểm tra nếu đã đăng nhập
onMounted(() => {
  authStore.initializeAuth()

  console.log('SellerLogin mounted:', {
    isAuthenticated: authStore.isAuthenticated,
    userRole: authStore.userRole,
    hasSellerRole: authStore.hasRole('SELLER')
  })

  if (authStore.isAuthenticated && authStore.hasRole('SELLER')) {
    console.log('Already authenticated, redirecting...')
    router.replace('/seller/dashboard')
  }
})

const handleSellerLogin = async () => {
  // Reset messages
  successMessage.value = ''

  // Validation
  if (!sellerForm.value.email || !sellerForm.value.password) {
    Swal.fire({
      title: 'Thông tin thiếu!',
      text: 'Vui lòng nhập đầy đủ thông tin đăng nhập!',
      icon: 'warning',
      confirmButtonText: 'OK'
    })
    return
  }

  try {
    console.log('Starting login process...')

    // Gọi action login từ store
    const result = await authStore.loginSeller({
      email: sellerForm.value.email,
      password: sellerForm.value.password
    })

    console.log('Login result:', result)

    if (result.success) {
      // Hiển thị thông báo thành công
      successMessage.value = 'Đăng nhập thành công!'

      // Kiểm tra lại state
      // console.log('Final auth state:', {
      //   isAuthenticated: authStore.isAuthenticated,
      //   userRole: authStore.userRole,
      //   hasSellerRole: authStore.hasRole('SELLER')
      // })

      // Hiển thị SweetAlert thành công
      await Swal.fire({
        title: 'Đăng nhập thành công!',
        text: 'Chào mừng bạn đến với Seller Portal',
        icon: 'success',
        timer: 1500,
        showConfirmButton: false
      })

      // Chuyển hướng với replace để tránh back button issue
      console.log('Redirecting to dashboard...')
      await router.replace('/seller/dashboard')

    } else {
      // Lỗi đã được xử lý trong store
      Swal.fire({
        title: 'Đăng nhập thất bại!',
        text: result.error || authStore.error,
        icon: 'error',
        confirmButtonText: 'Thử lại'
      })
    }

  } catch (error) {
    console.error('Unexpected login error:', error)
    Swal.fire({
      title: 'Lỗi không mong muốn!',
      text: 'Có lỗi xảy ra, vui lòng thử lại!',
      icon: 'error',
      confirmButtonText: 'Thử lại'
    })
  }
}
</script>
<style scoped>
.seller-login-container {
  background: linear-gradient(135deg, #d8bbdb 0%, #8ddad7 100%);
  padding: 1rem;
}

.seller-login-form {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 15px;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
  max-width: 450px;
  width: 100%;
  margin: 0 auto;
}

.form-control:focus {
  border-color: #f093fb;
  box-shadow: 0 0 0 0.2rem rgba(240, 147, 251, 0.25);
}

.btn-success {
  background: linear-gradient(45deg, #f093fb, #f5576c);
  border: none;
  padding: 0.75rem;
  transition: all 0.3s ease;
}

.btn-success:hover:not(:disabled) {
  background: linear-gradient(45deg, #f5576c, #f093fb);
  transform: translateY(-2px);
}

.btn-success:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.btn-outline-primary:hover {
  transform: translateY(-1px);
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

.alert {
  border-radius: 10px;
  border: none;
}

/* Mobile responsive */
@media (max-width: 768px) {
  .seller-login-container {
    padding: 0.5rem;
  }

  .seller-login-form {
    margin: 1rem auto;
    border-radius: 10px;
  }

  .card-body {
    padding: 1.5rem;
  }

  h2 {
    font-size: 1.5rem;
  }

  .btn {
    padding: 0.75rem 1rem;
    font-size: 1rem;
  }

  .form-control {
    font-size: 16px;
    padding: 0.75rem;
  }
}

@media (max-width: 576px) {
  .seller-login-form {
    margin: 0.5rem auto;
  }

  .card-body {
    padding: 1rem;
  }

  .display-4 {
    font-size: 2rem;
  }
}
</style>
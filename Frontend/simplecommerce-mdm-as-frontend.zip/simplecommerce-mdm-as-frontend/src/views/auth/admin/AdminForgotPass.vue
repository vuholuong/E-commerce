<script setup>
import { ref, reactive, computed } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import Swal from 'sweetalert2'
import { forgotPasswordService } from '@/services/auth/forgotPass'

const router = useRouter()

// Form data
const formData = reactive({
  email: '',
  otpCode: '',
  newPassword: '',
  confirmPassword: ''
})

// States
const errors = ref({})
const isLoading = ref(false)
const currentStep = ref('email') // 'email' hoặc 'reset'
const otpTimer = ref(0)
const canResendOTP = computed(() => otpTimer.value === 0)

// Countdown timer for OTP resend
let timerInterval = null

const startOTPTimer = () => {
  otpTimer.value = 60 // 60 seconds
  timerInterval = setInterval(() => {
    otpTimer.value--
    if (otpTimer.value <= 0) {
      clearInterval(timerInterval)
    }
  }, 1000)
}

const clearTimer = () => {
  if (timerInterval) {
    clearInterval(timerInterval)
    timerInterval = null
  }
}

// Validate email
const validateEmail = () => {
  errors.value.email = ''
  
  if (!formData.email.trim()) {
    errors.value.email = 'Email là bắt buộc'
    return false
  }

  if (!forgotPasswordService.validateEmail(formData.email)) {
    errors.value.email = 'Email không hợp lệ'
    return false
  }

  return true
}

// Validate OTP
const validateOTP = () => {
  errors.value.otpCode = ''
  
  if (!formData.otpCode.trim()) {
    errors.value.otpCode = 'Mã OTP là bắt buộc'
    return false
  }

  if (!forgotPasswordService.validateOTP(formData.otpCode)) {
    errors.value.otpCode = 'Mã OTP phải là 6 chữ số'
    return false
  }

  return true
}

// Validate password
const validatePassword = () => {
  errors.value.newPassword = ''
  errors.value.confirmPassword = ''
  
  const passwordValidation = forgotPasswordService.validatePassword(formData.newPassword)
  if (!passwordValidation.isValid) {
    errors.value.newPassword = passwordValidation.errors[0]
    return false
  }

  if (formData.newPassword !== formData.confirmPassword) {
    errors.value.confirmPassword = 'Mật khẩu xác nhận không khớp'
    return false
  }

  return true
}

// Gửi OTP
const sendOTP = async () => {
  if (!validateEmail()) return

  isLoading.value = true

  try {
    await forgotPasswordService.sendOTP(formData.email)
    currentStep.value = 'reset'
    startOTPTimer()
    
    await Swal.fire({
      icon: 'success',
      title: 'Gửi OTP thành công!',
      text: `Mã OTP đã được gửi tới ${formData.email}`,
      confirmButtonText: 'OK'
    })
  } catch (error) {
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: error.message,
      confirmButtonText: 'OK'
    })
  } finally {
    isLoading.value = false
  }
}

// Gửi lại OTP
const resendOTP = async () => {
  if (!canResendOTP.value) return
  await sendOTP()
}

// Đổi mật khẩu
const changePassword = async () => {
  if (!validateOTP() || !validatePassword()) return

  isLoading.value = true

  try {
    await forgotPasswordService.changePassword(
      formData.email,
      formData.otpCode,
      formData.newPassword
    )

    clearTimer()
    
    await Swal.fire({
      icon: 'success',
      title: 'Đổi mật khẩu thành công!',
      text: 'Mật khẩu của bạn đã được cập nhật. Vui lòng đăng nhập với mật khẩu mới.',
      confirmButtonText: 'Đăng nhập ngay'
    })

    router.push('/seller/login')
  } catch (error) {
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: error.message,
      confirmButtonText: 'OK'
    })
  } finally {
    isLoading.value = false
  }
}

// Quay lại bước trước
const goBack = () => {
  clearTimer()
  currentStep.value = 'email'
  formData.otpCode = ''
  formData.newPassword = ''
  formData.confirmPassword = ''
  errors.value = {}
}
</script>

<template>
  <div class="container-fluid min-vh-100 d-flex align-items-center justify-content-center bg-light">
    <div class="row justify-content-center w-100">
      <div class="col-md-6 col-lg-4">
        <div class="card shadow-lg border-0">
          <div class="card-header bg-success text-white text-center">
            <div class="mb-2">
              <i class="fas fa-store fa-3x"></i>
            </div>
            <h4 class="mb-0">Quên mật khẩu Seller</h4>
          </div>

          <div class="card-body p-4">
            <!-- Bước nhập email -->
            <div v-if="currentStep === 'email'">
              <div class="text-center mb-4">
                <h5 class="text-muted">Nhập email để nhận mã OTP</h5>
                <p class="text-muted small">
                  Chúng tôi sẽ gửi mã xác thực tới email đăng ký của shop
                </p>
              </div>

              <form @submit.prevent="sendOTP" novalidate>
                <div class="mb-3">
                  <label for="email" class="form-label">
                    <i class="fas fa-envelope me-2"></i>
                    Email đăng ký <span class="text-danger">*</span>
                  </label>
                  <input 
                    type="email" 
                    id="email" 
                    v-model="formData.email"
                    class="form-control form-control-lg"
                    :class="{ 'is-invalid': errors.email }" 
                    placeholder="seller@example.com" 
                    :disabled="isLoading"
                    autocomplete="email">
                  <div v-if="errors.email" class="invalid-feedback">
                    {{ errors.email }}
                  </div>
                </div>

                <div class="d-grid gap-2 mb-3">
                  <button type="submit" class="btn btn-success btn-lg" :disabled="isLoading">
                    <span v-if="isLoading" class="spinner-border spinner-border-sm me-2" role="status"></span>
                    <i v-else class="fas fa-paper-plane me-2"></i>
                    {{ isLoading ? 'Đang gửi...' : 'Gửi mã OTP' }}
                  </button>
                  
                  <RouterLink to="/admin/login" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i>
                    Quay lại đăng nhập
                  </RouterLink>
                </div>
              </form>
            </div>

            <!-- Bước đổi mật khẩu -->
            <div v-else-if="currentStep === 'reset'">
              <div class="text-center mb-4">
                <i class="fas fa-key fa-3x text-success mb-3"></i>
                <h5 class="text-success">Đặt lại mật khẩu</h5>
                <p class="text-muted">
                  Vui lòng nhập mã OTP và mật khẩu mới cho tài khoản:<br>
                  <strong>{{ formData.email }}</strong>
                </p>
              </div>

              <form @submit.prevent="changePassword" novalidate>
                <div class="mb-3">
                  <label for="otpCode" class="form-label">
                    <i class="fas fa-shield-alt me-2"></i>
                    Mã OTP <span class="text-danger">*</span>
                  </label>
                  <div class="input-group">
                    <input 
                      type="text" 
                      id="otpCode" 
                      v-model="formData.otpCode"
                      class="form-control form-control-lg"
                      :class="{ 'is-invalid': errors.otpCode }" 
                      placeholder="123456" 
                      maxlength="6"
                      :disabled="isLoading"
                      autocomplete="one-time-code">
                    <button 
                      @click="resendOTP"
                      class="btn btn-outline-success" 
                      type="button"
                      :disabled="isLoading || !canResendOTP">
                      <i class="fas fa-redo me-1"></i>
                      {{ canResendOTP ? 'Gửi lại' : `Gửi lại sau ${otpTimer}s` }}
                    </button>
                  </div>
                  <div v-if="errors.otpCode" class="invalid-feedback">
                    {{ errors.otpCode }}
                  </div>
                </div>

                <div class="mb-3">
                  <label for="newPassword" class="form-label">
                    <i class="fas fa-lock me-2"></i>
                    Mật khẩu mới <span class="text-danger">*</span>
                  </label>
                  <input 
                    type="password" 
                    id="newPassword" 
                    v-model="formData.newPassword"
                    class="form-control form-control-lg"
                    :class="{ 'is-invalid': errors.newPassword }" 
                    placeholder="Nhập mật khẩu mới" 
                    :disabled="isLoading"
                    autocomplete="new-password">
                  <div v-if="errors.newPassword" class="invalid-feedback">
                    {{ errors.newPassword }}
                  </div>
                  <div class="form-text small text-muted">
                    Mật khẩu phải có ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường, số và ký tự đặc biệt
                  </div>
                </div>

                <div class="mb-4">
                  <label for="confirmPassword" class="form-label">
                    <i class="fas fa-lock me-2"></i>
                    Xác nhận mật khẩu <span class="text-danger">*</span>
                  </label>
                  <input 
                    type="password" 
                    id="confirmPassword" 
                    v-model="formData.confirmPassword"
                    class="form-control form-control-lg"
                    :class="{ 'is-invalid': errors.confirmPassword }" 
                    placeholder="Nhập lại mật khẩu mới" 
                    :disabled="isLoading"
                    autocomplete="new-password">
                  <div v-if="errors.confirmPassword" class="invalid-feedback">
                    {{ errors.confirmPassword }}
                  </div>
                </div>

                <div class="d-grid gap-2 mb-3">
                  <button type="submit" class="btn btn-success btn-lg" :disabled="isLoading">
                    <span v-if="isLoading" class="spinner-border spinner-border-sm me-2" role="status"></span>
                    <i v-else class="fas fa-save me-2"></i>
                    {{ isLoading ? 'Đang xử lý...' : 'Đổi mật khẩu' }}
                  </button>

                  <button type="button" @click="goBack" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-2"></i>
                    Quay lại
                  </button>
                </div>
              </form>
            </div>

            <!-- <div class="text-center border-top pt-3">
              <p class="text-muted small mb-0">
                Chưa có tài khoản?
                <RouterLink to="/seller/register" class="text-decoration-none fw-bold text-success">
                  Đăng ký bán hàng
                </RouterLink>
              </p>
            </div> -->
          </div>
        </div>

        <div class="text-center mt-3">
          <p class="text-muted small">
            <i class="fas fa-shield-alt me-1"></i>
            Thông tin của bạn được bảo mật và an toàn
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* Giữ nguyên các style như trước */
.min-vh-100 {
  min-height: 100vh;
}

.bg-light {
  background-color: #f8f9fa !important;
}

.card {
  border-radius: 15px;
  overflow: hidden;
}

.card-header {
  background: linear-gradient(135deg, #198754 0%, #eb961f 100%) !important;
  padding: 2rem 1.5rem;
  border: none;
}

.card-body {
  background: #ffffff;
}

.form-control {
  border-radius: 10px;
  border: 2px solid #e9ecef;
  padding: 0.75rem 1rem;
  transition: all 0.3s ease;
}

.form-control:focus {
  border-color: #198754;
  box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.25);
}

.btn {
  border-radius: 10px;
  font-weight: 600;
  transition: all 0.3s ease;
}

.btn-success {
  background: linear-gradient(135deg, #198754 0%, #0d6635 100%);
  border: none;
}

.btn-success:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(25, 135, 84, 0.4);
}

.btn-outline-success {
  border: 2px solid #6a8719;
  color: #0a2f1e;
}

.btn-outline-success:hover:not(:disabled) {
  background: #e4c169;
  border-color: #ddd42b;
  color: #fff;
}

.shadow-lg {
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important;
}

@media (max-width: 768px) {
  .card-header {
    padding: 1.5rem 1rem;
  }
  
  .card-body {
    padding: 1.5rem !important;
  }
}
</style>
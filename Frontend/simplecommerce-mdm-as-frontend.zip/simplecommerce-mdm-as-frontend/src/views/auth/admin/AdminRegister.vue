<script setup>
import { ref, reactive } from 'vue'
import { RouterLink } from 'vue-router'
import Swal from 'sweetalert2'

// Form data
const formData = reactive({
  fullName: '',
  email: '',
  identityCard: '',
  password: '',
  confirmPassword: '',
  phone: ''
})

// Form validation
const errors = ref({})
const isLoading = ref(false)

// Validate form
const validateForm = () => {
  errors.value = {}

  if (!formData.fullName.trim()) {
    errors.value.fullName = 'Họ và tên là bắt buộc'
  }

  if (!formData.email.trim()) {
    errors.value.email = 'Email là bắt buộc'
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.value.email = 'Email không hợp lệ'
  }

  if (!formData.identityCard.trim()) {
    errors.value.identityCard = 'Số căn cước công dân là bắt buộc'
  } else if (!/^\d{12}$/.test(formData.identityCard.replace(/\s/g, ''))) {
    errors.value.identityCard = 'Số căn cước công dân phải có 12 chữ số'
  }

  if (!formData.password) {
    errors.value.password = 'Mật khẩu là bắt buộc'
  } else if (formData.password.length < 6) {
    errors.value.password = 'Mật khẩu phải có ít nhất 6 ký tự'
  }

  if (formData.password !== formData.confirmPassword) {
    errors.value.confirmPassword = 'Mật khẩu xác nhận không khớp'
  }

  return Object.keys(errors.value).length === 0
}

// Format identity card number
const formatIdentityCard = () => {
  let value = formData.identityCard.replace(/\D/g, '')
  if (value.length > 12) {
    value = value.substring(0, 12)
  }
  formData.identityCard = value.replace(/(\d{3})(\d{3})(\d{3})(\d{3})/, '$1 $2 $3 $4')
}

// Submit form
const submitForm = async () => {
  if (!validateForm()) {
    return
  }

  isLoading.value = true

  try {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000))

    // Success message
    await Swal.fire({
      icon: 'success',
      title: 'Thành công!',
      text: 'Tài khoản admin đã được tạo thành công',
      confirmButtonText: 'OK'
    })

    // Reset form
    Object.keys(formData).forEach(key => {
      formData[key] = ''
    })

  } catch (error) {
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Có lỗi xảy ra khi tạo tài khoản',
      confirmButtonText: 'OK'
    })
  } finally {
    isLoading.value = false
  }
}

// Reset form
const resetForm = () => {
  Object.keys(formData).forEach(key => {
    formData[key] = ''
  })
  errors.value = {}
}
</script>

<template>
  <div class="container-fluid mt-3">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6">
        <div class="card shadow">
          <div class="card-header bg-primary text-white">
            <h5 class="fw-bold text-center">
              Đăng ký tài khoản Admin
            </h5>
          </div>

          <div class="card-body">
            <form @submit.prevent="submitForm" novalidate>
              <!-- Họ và tên -->
              <div class="mb-2">
                <label for="fullName" class="form-label">
                  Họ và tên <span class="text-danger">*</span>
                </label>
                <input type="text" id="fullName" v-model="formData.fullName" class="form-control"
                  :class="{ 'is-invalid': errors.fullName }" placeholder="Nhập họ và tên">
                <div v-if="errors.fullName" class="invalid-feedback">
                  {{ errors.fullName }}
                </div>
              </div>

              <!-- Email -->
              <div class="mb-2">
                <label for="email" class="form-label">
                  Email <span class="text-danger">*</span>
                </label>
                <input type="email" id="email" v-model="formData.email" class="form-control"
                  :class="{ 'is-invalid': errors.email }" placeholder="admin@example.com">
                <div v-if="errors.email" class="invalid-feedback">
                  {{ errors.email }}
                </div>
              </div>

              <!-- Căn cước công dân -->
              <div class="mb-2">
                <label for="identityCard" class="form-label">
                  Số căn cước công dân <span class="text-danger">*</span>
                </label>
                <input type="text" id="identityCard" v-model="formData.identityCard" @input="formatIdentityCard"
                  class="form-control" :class="{ 'is-invalid': errors.identityCard }" placeholder="123 456 789 012"
                  maxlength="15">
                <div v-if="errors.identityCard" class="invalid-feedback">
                  {{ errors.identityCard }}
                </div>
              </div>

              <!-- Mật khẩu -->
              <div class="row">
                <div class="col-md-6 mb-2">
                  <label for="password" class="form-label">
                    Mật khẩu <span class="text-danger">*</span>
                  </label>
                  <input type="password" id="password" v-model="formData.password" class="form-control"
                    :class="{ 'is-invalid': errors.password }" placeholder="Nhập mật khẩu">
                  <div v-if="errors.password" class="invalid-feedback">
                    {{ errors.password }}
                  </div>
                </div>

                <div class="col-md-6 mb-3">
                  <label for="confirmPassword" class="form-label">
                    Xác nhận mật khẩu <span class="text-danger">*</span>
                  </label>
                  <input type="password" id="confirmPassword" v-model="formData.confirmPassword" class="form-control"
                    :class="{ 'is-invalid': errors.confirmPassword }" placeholder="Nhập lại mật khẩu">
                  <div v-if="errors.confirmPassword" class="invalid-feedback">
                    {{ errors.confirmPassword }}
                  </div>
                </div>
              </div>

              <!-- Số điện thoại -->
              <div class="mb-3">
                <label for="phone" class="form-label">Số điện thoại</label>
                <input type="tel" id="phone" v-model="formData.phone" class="form-control" placeholder="0123456789">
              </div>

              <!-- Buttons -->
              <div class="d-grid  d-ms-flex justify-content-md-center">
                <button type="submit" class="btn btn-primary" :disabled="isLoading">
                  <span v-if="isLoading" class="spinner-border spinner-border-sm me-2" role="status"></span>
                  <i v-else class="fas fa-save me-2"></i>
                  {{ isLoading ? 'Đang xử lý...' : 'Đăng ký' }}
                </button>
              </div>
            </form>

            <!-- Link đăng nhập -->
            <div class="text-center mt-1">
              <div class="border-top pt-3">
                <p class="text-muted">
                  Đã có tài khoản?
                  <RouterLink to="/admin/login" class="text-decoration-none fw-bold">
                    <i class="fas fa-sign-in-alt me-1"></i>
                    Đăng nhập ngay
                  </RouterLink>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.card {
  border: none;
  border-radius: 10px;
}

.card-header {
  border-radius: 10px 10px 0 0 !important;
  padding: 1rem;
}

.form-label {
  font-weight: 600;
  color: #495057;
}

.form-control,
.form-select {
  border-radius: 8px;
  border: 1px solid #ddd;
  padding: 0.75rem;
  transition: all 0.3s ease;
}

.form-control:focus,
.form-select:focus {
  border-color: #0d6efd;
  box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
}

.form-text {
  font-size: 0.875rem;
  color: #6c757d;
}

.btn {
  border-radius: 8px;
  padding: 0.75rem 1.5rem;
  font-weight: 600;
  transition: all 0.3s ease;
}

.btn-primary {
  background: linear-gradient(135deg, #0d6efd 0%, #0056b3 100%);
  border: none;
}

.btn-primary:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(13, 110, 253, 0.3);
}

.btn-secondary {
  background: #6c757d;
  border: none;
}

.btn-secondary:hover {
  background: #5a6268;
  transform: translateY(-1px);
}

.text-danger {
  color: #dc3545 !important;
}

.invalid-feedback {
  font-size: 0.875rem;
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

.border-top {
  border-top: 1px solid #dee2e6 !important;
}

.text-decoration-none {
  text-decoration: none !important;
}

.text-decoration-none:hover {
  text-decoration: underline !important;
}

.fw-bold {
  font-weight: 700 !important;
}
</style>
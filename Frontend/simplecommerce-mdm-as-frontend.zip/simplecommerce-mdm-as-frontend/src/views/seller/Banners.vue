<template>
  <SellerLayout>
    <!-- Header với nút thêm banner -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2></h2>
      <button class="btn btn-primary" @click="showAddModal">
        <i class="fas fa-plus me-2"></i>Thêm Banner
      </button>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Trạng thái</label>
            <select v-model="filterStatus" class="form-select">
              <option value="">Tất cả</option>
              <option value="active">Đang hiển thị</option>
              <option value="inactive">Ẩn</option>
              <option value="scheduled">Đã lên lịch</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Vị trí</label>
            <select v-model="filterPosition" class="form-select">
              <option value="">Tất cả vị trí</option>
              <option value="homepage_main">Trang chủ - Chính</option>
              <option value="homepage_secondary">Trang chủ - Phụ</option>
              <option value="category_top">Danh mục - Đầu trang</option>
              <option value="product_sidebar">Sản phẩm - Sidebar</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Sự kiện</label>
            <select v-model="filterEvent" class="form-select">
              <option value="">Tất cả</option>
              <option value="tet">Tết Nguyên Đán</option>
              <option value="valentine">Valentine</option>
              <option value="womens_day">8/3</option>
              <option value="black_friday">Black Friday</option>
              <option value="christmas">Giáng Sinh</option>
              <option value="summer_sale">Khuyến mãi hè</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Tìm kiếm</label>
            <input v-model="searchKeyword" type="text" class="form-control" placeholder="Tên banner...">
          </div>
        </div>
      </div>
    </div>

    <!-- Banner List -->
    <div class="card">
      <div class="card-header">
        <h5>Danh sách Banner ({{ filteredBanners.length }})</h5>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
            <tr>
              <th style="width: 100px;">Hình ảnh</th>
              <th>Thông tin</th>
              <th style="width: 120px;">Vị trí</th>
              <th style="width: 120px;">Sự kiện</th>
              <th style="width: 100px;">Trạng thái</th>
              <th style="width: 150px;">Thời gian</th>
              <th style="width: 100px;">Thao tác</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="banner in paginatedBanners" :key="banner.id">
              <td>
                <img :src="banner.image" :alt="banner.title"
                     class="img-thumbnail" style="width: 80px; height: 50px; object-fit: cover;">
              </td>
              <td>
                <div>
                  <strong>{{ banner.title }}</strong>
                  <p class="text-muted small mb-1">{{ banner.description }}</p>
                  <div v-if="banner.link">
                    <small class="text-info">
                      <i class="fas fa-link me-1"></i>{{ banner.link }}
                    </small>
                  </div>
                  <div class="mt-1">
                    <span class="badge bg-secondary me-1">Thứ tự: {{ banner.order }}</span>
                    <span v-if="banner.clickCount > 0" class="badge bg-info">{{ banner.clickCount }} clicks</span>
                  </div>
                </div>
              </td>
              <td>
                <span class="badge bg-primary">{{ getPositionName(banner.position) }}</span>
              </td>
              <td>
                <span v-if="banner.event" class="badge bg-warning">{{ getEventName(banner.event) }}</span>
                <span v-else class="text-muted">-</span>
              </td>
              <td>
                  <span class="badge" :class="getStatusClass(banner.status)">
                    {{ getStatusName(banner.status) }}
                  </span>
              </td>
              <td>
                <div class="small">
                  <div v-if="banner.startDate">
                    <strong>Bắt đầu:</strong> {{ formatDate(banner.startDate) }}
                  </div>
                  <div v-if="banner.endDate">
                    <strong>Kết thúc:</strong> {{ formatDate(banner.endDate) }}
                  </div>
                </div>
              </td>
              <td>
                <div class="btn-group-vertical btn-group-sm" role="group">
                  <button class="btn btn-outline-primary btn-sm" @click="editBanner(banner)">
                    <i class="bi bi-pencil-square"></i>
                  </button>
                  <!-- Nút bật/tắt trạng thái -->
                  <button class="btn btn-outline-success btn-sm"
                          @click="toggleStatus(banner)"
                          :title="banner.status === 'active' ? 'Ẩn banner' : 'Hiển thị banner'">
                    <i :class="banner.status === 'active' ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                  </button>
                  <!-- Nút xóa -->
                  <button class="btn btn-outline-danger btn-sm" @click="deleteBanner(banner)">
                    <i class="bi bi-trash"></i>
                  </button>
                </div>
              </td>
            </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <nav class="mt-4">
          <ul class="pagination justify-content-center">
            <li class="page-item"><a class="page-link" href="#">Trước</a></li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">Sau</a></li>
          </ul>
        </nav>
      </div>
    </div>

    <!-- Modal Add/Edit Banner -->
    <div class="modal fade" id="bannerModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">{{ isEditing ? 'Chỉnh sửa Banner' : 'Thêm Banner Mới' }}</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="saveBanner">
              <div class="row g-3">
                <!-- Upload Image -->
                <div class="col-12">
                  <label class="form-label">Hình ảnh Banner *</label>
                  <input type="file" ref="imageInput" class="form-control" @change="handleImageUpload" accept="image/*" multiple>
                  <div v-if="form.image" class="mt-2">
                    <img :src="form.image" alt="Preview" class="img-thumbnail" style="max-height: 10%; width: 25%;" >
                  </div>
                </div>

                <!-- Title -->
                <div class="col-md-6">
                  <label class="form-label">Tiêu đề *</label>
                  <input v-model="form.title" type="text" class="form-control"
                         required placeholder="Nhập tiêu đề banner">
                </div>

                <!-- Description -->
                <div class="col-12">
                  <label class="form-label">Mô tả</label>
                  <textarea v-model="form.description" class="form-control" rows="2"
                            placeholder="Mô tả ngắn về banner"></textarea>
                </div>

                <!-- Link -->
                <div class="col-md-8">
                  <label class="form-label">Link đích</label>
                  <input v-model="form.link" type="url" class="form-control"
                         placeholder="https://example.com/promotion">
                </div>

                <!-- Event -->
                <div class="col-md-6">
                  <label class="form-label">Sự kiện/Dịp lễ</label>
                  <select v-model="form.event" class="form-select">
                    <option value="">Không gắn sự kiện</option>
                    <option value="tet">Tết Nguyên Đán</option>
                    <option value="valentine">Valentine</option>
                    <option value="womens_day">Ngày Phụ nữ 8/3</option>
                    <option value="black_friday">Black Friday</option>
                    <option value="christmas">Giáng Sinh</option>
                    <option value="summer_sale">Khuyến mãi hè</option>
                  </select>
                </div>

                <!-- Status -->
                <div class="col-md-6">
                  <label class="form-label">Trạng thái</label>
                  <select v-model="form.status" class="form-select">
                    <option value="active">Hiển thị ngay</option>
                    <option value="inactive">Ẩn</option>
                    <option value="scheduled">Lên lịch hiển thị</option>
                  </select>
                </div>

                <!-- Schedule dates -->
                <div v-if="form.status === 'scheduled'" class="col-12">
                  <div class="row g-3">
                    <div class="col-md-6">
                      <label class="form-label">Ngày bắt đầu</label>
                      <input v-model="form.startDate" type="datetime-local" class="form-control">
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Ngày kết thúc</label>
                      <input v-model="form.endDate" type="datetime-local" class="form-control">
                    </div>
                  </div>
                </div>

              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
            <button type="button" class="btn btn-primary" @click="saveBanner">
              {{ isEditing ? 'Cập nhật' : 'Thêm mới' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </SellerLayout>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import SellerLayout from '../../components/SellerLayout.vue'
import Swal from 'sweetalert2'
import { Modal } from 'bootstrap'

// Data
const banners = ref([
  {
    id: 1,
    title: 'Khuyến mãi Tết 2025',
    description: 'Giảm giá lên đến 50% tất cả sản phẩm',
    image: 'https://via.placeholder.com/800x300/ff6b6b/ffffff?text=Tet+2025',
    link: 'https://example.com/tet-2025',
    position: 'homepage_main',
    event: 'tet',
    status: 'scheduled',
    order: 1,
    startDate: '2025-01-20T00:00:00',
    endDate: '2025-02-15T23:59:59',
    targetDevice: ['desktop', 'mobile'],
    clickCount: 1250,
    createdAt: '2024-12-20',
    updatedAt: '2024-12-20'
  },
  {
    id: 2,
    title: 'Black Friday Sale',
    description: 'Ưu đãi khủng trong ngày Black Friday',
    image: 'https://via.placeholder.com/800x300/2c3e50/ffffff?text=Black+Friday',
    link: 'https://example.com/black-friday',
    position: 'homepage_main',
    event: 'black_friday',
    status: 'inactive',
    order: 1,
    startDate: '2024-11-29T00:00:00',
    endDate: '2024-11-29T23:59:59',
    targetDevice: ['desktop', 'mobile', 'tablet'],
    clickCount: 2890,
    createdAt: '2024-11-15',
    updatedAt: '2024-11-30'
  },
  {
    id: 3,
    title: 'Sản phẩm mới 2025',
    description: 'Khám phá bộ sưu tập mới nhất',
    image: 'https://via.placeholder.com/400x200/27ae60/ffffff?text=New+Collection',
    link: 'https://example.com/new-collection',
    position: 'homepage_secondary',
    event: '',
    status: 'active',
    order: 2,
    startDate: null,
    endDate: null,
    targetDevice: ['desktop', 'mobile'],
    clickCount: 580,
    createdAt: '2024-12-01',
    updatedAt: '2024-12-15'
  }
])

// Form data
const form = ref({
  title: '',
  description: '',
  image: '',
  link: '',
  position: '',
  event: '',
  status: 'active',
  order: 1,
  startDate: '',
  endDate: '',
  targetDevice: ['desktop', 'mobile']
})

// State
const isEditing = ref(false)
const editingId = ref(null)
const imageInput = ref(null)

// Filters
const filterStatus = ref('')
const filterPosition = ref('')
const filterEvent = ref('')
const searchKeyword = ref('')

// Pagination
const currentPage = ref(1)
const itemsPerPage = 10

// Modal instance
let bannerModal = null

// Computed
const filteredBanners = computed(() => {
  let filtered = banners.value

  if (filterStatus.value) {
    filtered = filtered.filter(banner => banner.status === filterStatus.value)
  }

  if (filterPosition.value) {
    filtered = filtered.filter(banner => banner.position === filterPosition.value)
  }

  if (filterEvent.value) {
    filtered = filtered.filter(banner => banner.event === filterEvent.value)
  }

  if (searchKeyword.value) {
    filtered = filtered.filter(banner =>
        banner.title.toLowerCase().includes(searchKeyword.value.toLowerCase()) ||
        banner.description.toLowerCase().includes(searchKeyword.value.toLowerCase())
    )
  }

  return filtered.sort((a, b) => a.order - b.order)
})

const totalPages = computed(() => Math.ceil(filteredBanners.value.length / itemsPerPage))

const paginatedBanners = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage
  const end = start + itemsPerPage
  return filteredBanners.value.slice(start, end)
})

const visiblePages = computed(() => {
  const pages = []
  const start = Math.max(1, currentPage.value - 2)
  const end = Math.min(totalPages.value, currentPage.value + 2)

  for (let i = start; i <= end; i++) {
    pages.push(i)
  }
  return pages
})

// Helper functions
const getPositionName = (position) => {
  const positions = {
    'homepage_main': 'Trang chủ - Chính',
    'homepage_secondary': 'Trang chủ - Phụ',
    'category_top': 'Danh mục - Đầu',
    'product_sidebar': 'SP - Sidebar'
  }
  return positions[position] || position
}

const getEventName = (event) => {
  const events = {
    'tet': 'Tết',
    'valentine': 'Valentine',
    'womens_day': '8/3',
    'black_friday': 'Black Friday',
    'christmas': 'Giáng Sinh',
    'summer_sale': 'Khuyến mãi hè'
  }
  return events[event] || event
}

const getStatusName = (status) => {
  const statuses = {
    'active': 'Đang hiển thị',
    'inactive': 'Đã ẩn',
    'scheduled': 'Đã lên lịch'
  }
  return statuses[status] || status
}

const getStatusClass = (status) => {
  const classes = {
    'active': 'bg-success',
    'inactive': 'bg-secondary',
    'scheduled': 'bg-warning'
  }
  return classes[status] || 'bg-secondary'
}

const formatDate = (dateString) => {
  if (!dateString) return ''
  return new Date(dateString).toLocaleString('vi-VN')
}

// Actions
const showAddModal = () => {
  isEditing.value = false
  editingId.value = null
  resetForm()
  bannerModal.show()
}

const editBanner = (banner) => {
  isEditing.value = true
  editingId.value = banner.id

  form.value = {
    title: banner.title,
    description: banner.description,
    image: banner.image,
    link: banner.link,
    position: banner.position,
    event: banner.event,
    status: banner.status,
    order: banner.order,
    startDate: banner.startDate,
    endDate: banner.endDate,
    targetDevice: [...banner.targetDevice]
  }

  bannerModal.show()
}

const resetForm = () => {
  form.value = {
    title: '',
    description: '',
    image: '',
    link: '',
    position: '',
    event: '',
    status: 'active',
    order: 1,
    startDate: '',
    endDate: '',
    targetDevice: ['desktop', 'mobile']
  }
  if (imageInput.value) {
    imageInput.value.value = ''
  }
}

const handleImageUpload = (event) => {
  const file = event.target.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (e) => {
      form.value.image = e.target.result
    }
    reader.readAsDataURL(file)
  }
}

const saveBanner = () => {
  if (!form.value.title || !form.value.position || !form.value.image) {
    Swal.fire('Lỗi', 'Vui lòng điền đầy đủ thông tin bắt buộc', 'error')
    return
  }

  if (isEditing.value) {
    // Update existing banner
    const index = banners.value.findIndex(b => b.id === editingId.value)
    if (index !== -1) {
      banners.value[index] = {
        ...banners.value[index],
        ...form.value,
        updatedAt: new Date().toISOString().split('T')[0]
      }
    }

    Swal.fire('Thành công', 'Banner đã được cập nhật', 'success')
  } else {
    // Add new banner
    const newBanner = {
      id: Date.now(),
      ...form.value,
      clickCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0]
    }
    banners.value.push(newBanner)

    Swal.fire('Thành công', 'Banner mới đã được thêm', 'success')
  }

  bannerModal.hide()
  resetForm()
}

const toggleStatus = (banner) => {
  const newStatus = banner.status === 'active' ? 'inactive' : 'active'
  const action = newStatus === 'active' ? 'hiển thị' : 'ẩn'

  Swal.fire({
    title: `Xác nhận ${action} banner?`,
    text: `Banner sẽ được ${action} trên website`,
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'Xác nhận',
    cancelButtonText: 'Hủy'
  }).then((result) => {
    if (result.isConfirmed) {
      banner.status = newStatus
      banner.updatedAt = new Date().toISOString().split('T')[0]
      Swal.fire('Thành công', `Banner đã được ${action}`, 'success')
    }
  })
}

const deleteBanner = (banner) => {
  Swal.fire({
    title: 'Xác nhận xóa banner?',
    text: 'Hành động này không thể hoàn tác',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy'
  }).then((result) => {
    if (result.isConfirmed) {
      const index = banners.value.findIndex(b => b.id === banner.id)
      if (index !== -1) {
        banners.value.splice(index, 1)
        Swal.fire('Đã xóa', 'Banner đã được xóa thành công', 'success')
      }
    }
  })
}

// Lifecycle
onMounted(() => {
  bannerModal = new Modal(document.getElementById('bannerModal'))
})
</script>

<style scoped>
.img-thumbnail {
  border-radius: 8px;
}

.btn-group-vertical .btn {
  margin-bottom: 2px;
}

.form-check-group {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

.badge {
  font-size: 0.75em;
}

.table td {
  vertical-align: middle;
}

.modal-lg {
  max-width: 40%;
}

.page-link {
  cursor: pointer;
}

.page-item.disabled .page-link {
  cursor: not-allowed;
}
</style>
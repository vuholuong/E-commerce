<template>
  <SellerLayout>
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h4></h4>
      <div class="d-flex gap-2">
        <button class="btn btn-outline-secondary" @click="showCategoryModal = true">
          <i class="bi bi-tags"></i> Danh mục
        </button>
        <button class="btn btn-primary" @click="showAddModal = true">
          <i class="bi bi-plus"></i> Thêm sản phẩm mới
        </button>
      </div>
    </div>

    <!-- Product Stats -->
    <div class="row mb-4">
      <div class="col-md-3">
        <div class="card bg-primary text-white">
          <div class="card-body text-center">
            <h3>{{ productStats.total }}</h3>
            <small>Tổng sản phẩm</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-success text-white">
          <div class="card-body text-center">
            <h3>{{ productStats.active }}</h3>
            <small>Đang bán</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-warning text-white">
          <div class="card-body text-center">
            <h3>{{ productStats.pending }}</h3>
            <small>Chờ duyệt</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-danger text-white">
          <div class="card-body text-center">
            <h3>{{ productStats.lowStock }}</h3>
            <small>Sắp hết hàng</small>
          </div>
        </div>
      </div>
    </div>

    <!-- Products Table -->
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
          <h5>Danh sách sản phẩm</h5>
          <div class="d-flex gap-2">
            <input type="text" class="form-control" placeholder="Tìm kiếm..." style="width: 200px;"
              v-model="searchTerm">
            <select class="form-select" style="width: 150px;" v-model="selectedStatus">
              <option v-for="option in statusOptions" :key="option.value" :value="option.value">
                {{ option.label }}
              </option>
            </select>
          </div>
        </div>
      </div>
      <div class="card-body">
        <!-- Loading indicator -->
        <div v-if="loading" class="text-center py-4">
          <div class="spinner-border" role="status">
            <span class="visually-hidden">Đang tải...</span>
          </div>
        </div>

        <!-- Products table -->
        <div v-else class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Sản phẩm</th>
                <th>Giá</th>
                <th>Tồn kho</th>
                <th>Đã bán</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="product in products" :key="product.id">
                <td>
                  <div class="d-flex align-items-center">
                    <img :src="product.image" alt="" class="rounded me-2"
                      style="width: 50px; height: 50px; object-fit: cover;" @error="onImgError">
                    <div>
                      <strong>{{ product.name }}</strong><br>
                      <small class="text-muted">{{ product.category }}</small>
                    </div>
                  </div>
                </td>
                <td>{{ formatCurrency(product.basePrice) }}</td>
                <td>
                  <span :class="product.totalStock < 10 ? 'text-danger' : ''">
                    {{ product.totalStock }}
                  </span>
                </td>
                <td>{{ product.sold || 0 }}</td>
                <td>
                  <span :class="`badge bg-${product.statusColor}`">{{ productService.getStatusText(product.status)
                  }}</span>
                </td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary" @click="openUnifiedModal(product)">
                      <i class="bi bi-pencil-square"></i> Chỉnh sửa
                    </button>
                    <button class="btn btn-outline-danger ms-2" @click="deleteProduct(product.id, product.name)">
                      <i class="bi bi-trash-fill"></i> Xóa
                    </button>
                  </div>
                </td>
              </tr>
              <tr v-if="products.length === 0">
                <td colspan="7" class="text-center py-4 text-muted">
                  Không có sản phẩm nào
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <nav class="mt-4" v-if="pagination.totalPages > 1">
          <ul class="pagination justify-content-center">
            <li class="page-item" :class="{ disabled: pagination.first }">
              <button class="page-link" @click="changePage(currentPage - 1)" :disabled="pagination.first">
                Trước
              </button>
            </li>
            <li v-for="page in visiblePages" :key="page" class="page-item" :class="{ active: page === currentPage }">
              <button class="page-link" @click="changePage(page)">{{ page + 1 }}</button>
            </li>
            <li class="page-item" :class="{ disabled: pagination.last }">
              <button class="page-link" @click="changePage(currentPage + 1)" :disabled="pagination.last">
                Sau
              </button>
            </li>
          </ul>
        </nav>
      </div>
    </div>

    <!-- Unified View/Edit Modal -->
    <div class="modal fade" :class="{ show: showUnifiedModal, 'd-block': showUnifiedModal }" tabindex="-1"
      v-if="showUnifiedModal">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">
              <i class="bi bi-box me-2"></i>
              {{ isEditMode ? 'Chỉnh sửa sản phẩm' : 'Chi tiết sản phẩm' }}
            </h5>
            <button type="button" class="btn-close" @click="closeUnifiedModal"></button>
          </div>

          <div class="modal-body">
            <!-- Loading State -->
            <div v-if="unifiedLoading" class="text-center py-4">
              <div class="spinner-border" role="status">
                <span class="visually-hidden">Đang tải...</span>
              </div>
              <div class="mt-2 text-muted">Đang tải thông tin sản phẩm...</div>
            </div>

            <!-- Product Details/Edit Form -->
            <div v-else-if="unifiedProduct" class="container-fluid">
              <div class="row">
                <!-- Product Images -->
                <div class="col-md-4">
                  <!-- View mode: slider -->
                  <div v-if="!isEditMode" class="slider">
                    <div class="slider-viewport">
                      <div v-for="(img, idx) in sliderImages" :key="idx" class="slide" :class="{ active: sliderIndex === idx }">
                        <img :src="img" class="w-100 h-100 object-fit-cover rounded border" @error="onImgError" />
                      </div>
                    </div>
                    <button class="slider-btn prev" @click="prevSlide" aria-label="Prev"><i class="bi bi-chevron-left"></i></button>
                    <button class="slider-btn next" @click="nextSlide" aria-label="Next"><i class="bi bi-chevron-right"></i></button>
                    <div class="slider-dots mt-2 text-center">
                      <button v-for="(img, i) in sliderImages" :key="`dot-${i}`" class="dot" :class="{ active: sliderIndex === i }" @click="goSlide(i)" aria-label="Go to slide"></button>
                    </div>
                  </div>

                  <!-- Edit mode: image management + upload -->
                  <div class="mt-3 border rounded p-2 bg-light" v-if="isEditMode">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                      <label class="form-label m-0">Quản lý ảnh</label>
                      <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-danger" @click="deleteSelectedImages" :disabled="!selectedImageIds.length || unifiedSaving">
                          <i class="bi bi-trash"></i> Xóa đã chọn
                        </button>
                      </div>
                    </div>

                    <!-- Current images grid with selection -->
                    <div v-if="currentImages.length" class="image-scroll-grid">
                      <div v-for="(img, idx) in currentImages" :key="img.id || idx" class="image-scroll-item">
                        <div class="image-grid-item position-relative rounded">
                          <img :src="img.url" class="w-100 h-100 object-fit-cover rounded" @click="previewImage = img.url" @error="onImgError" />
                          <div class="form-check position-absolute top-0 start-0 m-1 bg-white rounded px-1 shadow-sm">
                            <input class="form-check-input" type="checkbox" :value="img.id" v-model="selectedImageIds">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div v-else class="text-center text-muted py-2">
                      <small>Chưa có ảnh nào cho sản phẩm này</small>
                    </div>

                    <!-- Image Upload (Edit Mode) -->
                    <div class="mt-3">
                      <label class="form-label">Thêm hình ảnh mới</label>
                      <input type="file" class="form-control" multiple accept="image/*" @change="handleUnifiedImageChange"
                        ref="unifiedImageInput">
                      <small class="text-muted">Tối đa 10 ảnh, mỗi ảnh không quá 5MB.</small>
                      <div class="row mt-2" v-if="selectedUnifiedImages.length">
                        <div v-for="(img, idx) in selectedUnifiedImages" :key="idx" class="col-6 mb-2">
                          <div class="position-relative">
                            <img :src="img.preview" class="img-thumbnail" style="height: 80px; object-fit: cover; width: 100%;" @error="onImgError">
                            <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0"
                              @click="removeSelectedUnifiedImage(idx)">
                              <i class="bi bi-x"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Product Information -->
                <div class="col-md-8">
                  <!-- Basic Info Section -->
                  <div class="row mb-3">
                    <div class="col-md-6">
                      <label class="form-label">Tên sản phẩm</label>
                      <input v-if="isEditMode" type="text" class="form-control" v-model="unifiedProduct.name"
                        :class="{ 'is-invalid': !unifiedProduct.name?.trim() && hasTriedSubmit }">
                      <div v-else class="form-control-plaintext fw-bold">{{ unifiedProduct.name }}</div>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Danh mục</label>
                      <select v-if="isEditMode" class="form-select" v-model="unifiedProduct.categoryId"
                        :class="{ 'is-invalid': !unifiedProduct.categoryId && hasTriedSubmit }">
                        <option value="">-- Chọn danh mục --</option>
                        <option v-for="c in categoryOptions" :key="c.id" :value="c.id">{{ c.name }}</option>
                      </select>
                      <div v-else class="form-control-plaintext">{{ getCategoryName(unifiedProduct.categoryId) }}</div>
                    </div>
                  </div>

                  <div class="row mb-3">
                    <div class="col-md-6">
                      <label class="form-label">Giá cơ bản</label>
                      <input v-if="isEditMode" type="number" class="form-control"
                        v-model.number="unifiedProduct.basePrice" min="1000" step="1000"
                        :class="{ 'is-invalid': (!unifiedProduct.basePrice || unifiedProduct.basePrice <= 0) && hasTriedSubmit }">
                      <div v-else class="form-control-plaintext fw-semibold">{{ formatCurrency(unifiedProduct.basePrice)
                      }}</div>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Trọng lượng (gram)</label>
                      <input v-if="isEditMode" type="number" class="form-control"
                        v-model.number="unifiedProduct.weightGrams" min="0" step="1">
                      <div v-else class="form-control-plaintext">{{ unifiedProduct.weightGrams || 0 }} gram</div>
                    </div>
                  </div>

                  <!-- Description -->
                  <div class="mb-3">
                    <label class="form-label">Mô tả</label>
                    <textarea v-if="isEditMode" class="form-control" rows="3"
                      v-model="unifiedProduct.description"></textarea>
                    <div v-else class="border rounded p-2"
                      style="min-height: 60px; max-height: 100px; overflow-y: auto;">
                      {{ unifiedProduct.description || '—' }}
                    </div>
                  </div>

                  <!-- Dimensions and Attributes -->
                  <div class="row mb-3">
                    <div class="col-md-6">
                      <label class="form-label">Kích thước</label>
                      <input v-if="isEditMode" type="text" class="form-control" v-model="unifiedProduct.dimensions"
                        placeholder="VD: 10x20x30 cm">
                      <div v-else class="form-control-plaintext">{{ unifiedProduct.dimensions || '—' }}</div>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Thuộc tính</label>
                      <input v-if="isEditMode" type="text" class="form-control" v-model="unifiedProduct.attributes"
                        placeholder="VD: Chất liệu, Màu sắc...">
                      <div v-else class="form-control-plaintext">{{ unifiedProduct.attributes || '—' }}</div>
                    </div>
                  </div>

                  <!-- Status Update Section -->
                  <div class="mb-3">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-label">Trạng thái hiện tại</div>
                        <span :class="`badge bg-${productService.getStatusColor(unifiedProduct.status)} fs-6`">
                          {{ productService.getStatusText(unifiedProduct.status) }}
                        </span>
                      </div>
                      <!-- <div class="col-md-6">
                        <div class="form-label">Cập nhật trạng thái</div>
                        <div class="d-flex gap-2">
                          <select class="form-select" v-model="statusEdit"
                            :disabled="!isStatusEditable || unifiedSaving">
                            <option v-for="opt in statusChangeOptions" :key="opt.value" :value="opt.value">
                              {{ opt.label }}
                            </option>
                          </select>
                          <button class="btn btn-primary btn-sm" @click="saveStatus"
                            :disabled="!isStatusEditable || unifiedSaving || statusEdit === unifiedProduct.status">
                            <span v-if="unifiedSaving">
                              <i class="bi bi-arrow-clockwise spin"></i>
                            </span>
                            <span v-else><i class="bi bi-save"></i></span>
                          </button>
                        </div>
                        <small v-if="!isStatusEditable" class="text-muted">
                          Trạng thái hiện tại không thể cập nhật.
                        </small>
                      </div> -->
                    </div>
                  </div>

                  

                  <!-- Timestamps -->
                  <div class="row mt-3 pt-3 border-top">
                    <div class="col-6">
                      <small class="text-muted">
                        <strong>Tạo lúc:</strong><br>
                        {{ unifiedProduct.createdAt ? new Date(unifiedProduct.createdAt).toLocaleString('vi-VN') : '—'
                        }}
                      </small>
                    </div>
                    <div class="col-6">
                      <small class="text-muted">
                        <strong>Cập nhật:</strong><br>
                        {{ unifiedProduct.updatedAt ? new Date(unifiedProduct.updatedAt).toLocaleString('vi-VN') : '—'
                        }}
                      </small>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Enhanced Variants Section -->
                  <div class="mt-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                      <div class="form-label m-0">Quản lý biến thể</div>
                      <div class="d-flex gap-2">
                        <button v-if="isEditMode" class="btn btn-outline-primary btn-sm" @click="addUnifiedVariant">
                          <i class="bi bi-plus"></i> Thêm
                        </button>
                        <button class="btn btn-success btn-sm" @click="saveVariants" :disabled="unifiedSaving">
                          <span v-if="unifiedSaving">
                            <i class="bi bi-arrow-clockwise spin"></i> Đang lưu...
                          </span>
                          <span v-else><i class="bi bi-save"></i> Lưu biến thể</span>
                        </button>
                      </div>
                    </div>
                    <!-- biến thể sản phẩm -->
                    <div class="table-responsive">
                      <table class="table table-sm align-middle">
                        <thead>
                          <tr>
                            <th>ID</th>
                            <th>SKU</th>
                            <th>Giá bán</th>
                            <th>Giá so sánh</th>
                            <th>Tồn kho</th>
                            <th>Ngưỡng đặt lại</th>
                            <th>Trọng lượng (g)</th>
                            <th>Kích thước</th>
                            <th>Tùy chọn</th>
                            <th>Trạng thái</th>
                            <th v-if="isEditMode" style="width:50px;"></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="(v, i) in variantsEdit" :key="`variant-${i}-${v.id || v.sku}`">
                            <!-- trường id -->
                            <td>
                              <input type="hidden" v-model="v.id">
                              <span v-if="!isEditMode">{{ v.id || '—' }}</span>
                              <input v-else type="text" class="form-control form-control-sm" v-model="v.id"
                                :readonly="!isEditMode"
                                :class="{ 'is-invalid': !v.id && isEditMode && hasTriedSubmit }">
                            </td>

                            <td>
                              <input type="text" class="form-control form-control-sm" v-model="v.sku"
                                :readonly="!isEditMode"
                                :class="{ 'is-invalid': !v.sku?.trim() && isEditMode && hasTriedSubmit }">
                            </td>
                            <td>
                              <input type="number" class="form-control form-control-sm" v-model.number="v.finalPrice"
                                min="1000" step="1000" :readonly="!isEditMode"
                                :class="{ 'is-invalid': (!v.finalPrice || v.finalPrice <= 0) && isEditMode && hasTriedSubmit }">
                            </td>
                            <td>
                              <input type="number" class="form-control form-control-sm"
                                v-model.number="v.compareAtPrice" min="0" step="1000" :readonly="!isEditMode">
                            </td>
                            <td>
                              <input type="number" class="form-control form-control-sm" min="0" step="1"
                                v-model.number="v.stockQuantity" :disabled="unifiedSaving" />
                            </td>
                            <td>
                              <input type="number" class="form-control form-control-sm"
                                v-model.number="v.reorderThreshold" min="0" step="1" :readonly="!isEditMode">
                            </td>
                            <td>
                              <input type="number" class="form-control form-control-sm" v-model.number="v.weightGrams"
                                min="0" step="1" :readonly="!isEditMode">
                            </td>
                            <td>
                              <input type="text" class="form-control form-control-sm" v-model="v.dimensions"
                                :readonly="!isEditMode" placeholder="10x20x30">
                            </td>
                            <td>
                              <input type="text" class="form-control form-control-sm" v-model="v.options"
                                :readonly="!isEditMode" placeholder="Màu đỏ, Size M">
                            </td>
                            <td>
                              <div v-if="isEditMode">
                                <input type="checkbox" class="form-check-input" v-model="v.isActive">
                                <small class="ms-1">{{ v.isActive ? 'Kích hoạt' : 'Tạm ngưng' }}</small>
                              </div>
                              <span v-else :class="`badge bg-${v.isActive ? 'success' : 'secondary'} fs-6`">
                                {{ v.isActive ? 'Kích hoạt' : 'Tạm ngưng' }}
                              </span>
                            </td>
                            <td v-if="isEditMode">
                              <button class="btn btn-sm btn-danger"
                                @click="removeUnifiedVariant(unifiedProduct.id, v.id, i)">
                                Xóa <i class="bi bi-x"></i>
                              </button>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
            </div>

            <!-- No Data State -->
            <div v-else class="text-center text-muted py-4">
              <i class="bi bi-exclamation-triangle fs-1 mb-3"></i>
              <div>Không tìm thấy dữ liệu sản phẩm</div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeUnifiedModal" :disabled="unifiedSaving">
              Đóng
            </button>
            <button v-if="!isEditMode" type="button" class="btn btn-primary" @click="toggleEditMode">
              <i class="bi bi-pencil-square"></i> Chỉnh sửa
            </button>
            <div v-else class="d-flex gap-2">
              <button type="button" class="btn btn-outline-secondary" @click="toggleEditMode" :disabled="unifiedSaving">
                <i class="bi bi-eye"></i> Chỉ xem
              </button>
              <button type="button" class="btn btn-primary" @click="saveProduct" :disabled="unifiedSaving">
                <span v-if="unifiedSaving">
                  <i class="bi bi-arrow-clockwise spin"></i> Đang lưu...
                </span>
                <span v-else>
                  <i class="bi bi-save"></i> Lưu thay đổi
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop fade show" v-if="showUnifiedModal"></div>

    <!-- Add Product Modal (unchanged) -->
    <div class="modal fade" :class="{ show: showAddModal, 'd-block': showAddModal }" tabindex="-1" v-if="showAddModal">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Thêm sản phẩm mới</h5>
            <button type="button" class="btn-close" @click="closeAddModal"></button>
          </div>

          <div class="modal-body">
            <form @submit.prevent="addProduct" ref="addProductForm">
              <!-- Thông tin chung -->
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Tên sản phẩm *</label>
                  <input type="text" class="form-control" v-model="newProduct.name"
                    :class="{ 'is-invalid': !newProduct.name.trim() && hasTriedSubmit }"
                    placeholder="Nhập tên sản phẩm..." required>
                  <div class="invalid-feedback" v-if="!newProduct.name.trim() && hasTriedSubmit">
                    Tên sản phẩm là bắt buộc
                  </div>
                </div>

                <div class="col-md-6 mb-3">
                  <label class="form-label">Slug</label>
                  <input type="text" class="form-control" v-model="newProduct.slug"
                    placeholder="Tự động tạo nếu để trống">
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Danh mục *</label>
                  <select class="form-select" v-model="newProduct.categoryId"
                    :class="{ 'is-invalid': !newProduct.categoryId && hasTriedSubmit }" required>
                    <option value="">-- Chọn danh mục --</option>
                    <option v-for="c in categoryOptions" :key="c.id" :value="c.id">{{ c.name }}</option>
                  </select>
                  <div class="invalid-feedback" v-if="!newProduct.categoryId && hasTriedSubmit">
                    Vui lòng chọn danh mục
                  </div>
                </div>

                <div class="col-md-6 mb-3">
                  <label class="form-label">Giá gốc (VND) *</label>
                  <input type="number" class="form-control" v-model.number="newProduct.basePrice"
                    :class="{ 'is-invalid': (!newProduct.basePrice || newProduct.basePrice <= 0) && hasTriedSubmit }"
                    min="1000" step="1000" required>
                  <div class="invalid-feedback"
                    v-if="(!newProduct.basePrice || newProduct.basePrice <= 0) && hasTriedSubmit">
                    Giá phải lớn hơn 0
                  </div>
                </div>
              </div>

              <!-- Mô tả -->
              <div class="mb-3">
                <label class="form-label">Mô tả</label>
                <textarea class="form-control" rows="3" v-model="newProduct.description"></textarea>
              </div>

              <!-- Variants -->
              <div class="mb-3">
                <label class="form-label">Biến thể sản phẩm *</label>
                <table class="table table-bordered align-middle">
                  <thead>
                    <tr>
                      <th>SKU *</th>
                      <th>Giá bán (VND) *</th>
                      <th>Số lượng *</th>
                      <th>Tùy chọn</th>
                      <th style="width: 50px;"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(v, idx) in newProduct.variants" :key="idx">
                      <td>
                        <input type="text" class="form-control" v-model="v.sku"
                          :class="{ 'is-invalid': !v.sku.trim() && hasTriedSubmit }" required>
                      </td>
                      <td>
                        <input type="number" class="form-control" v-model.number="v.finalPrice" min="1000" step="1000"
                          required>
                      </td>
                      <td>
                        <input type="number" class="form-control" v-model.number="v.stockQuantity" min="0" required>
                      </td>
                      <td>
                        <input type="text" class="form-control" v-model="v.options" placeholder="VD: 128GB, Màu đỏ">
                      </td>
                      <td>
                        <button type="button" class="btn btn-danger btn-sm" @click="removeVariant(idx)"
                          :disabled="newProduct.variants.length <= 1">
                          <i class="bi bi-x"></i>
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <button type="button" class="btn btn-outline-primary btn-sm" @click="addVariant">
                  <i class="bi bi-plus"></i> Thêm biến thể
                </button>
              </div>

              <!-- Hình ảnh -->
              <div class="mb-3">
                <label class="form-label">Hình ảnh</label>
                <input type="file" class="form-control" multiple accept="image/*" @change="handleImageChange"
                  ref="imageInput">
                <small class="text-muted">Tối đa 10 ảnh, mỗi ảnh không quá 5MB.</small>
                <div class="row mt-2" v-if="selectedImages.length">
                  <div v-for="(img, idx) in selectedImages" :key="idx" class="col-md-2 mb-2">
                    <div class="position-relative">
                      <img :src="img.preview" class="img-thumbnail" style="height: 100px; object-fit: cover;">
                      <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0"
                        @click="removeImage(idx)">
                        <i class="bi bi-x"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeAddModal">Hủy</button>
            <button type="button" class="btn btn-primary" @click="addProduct" :disabled="submitting">
              <span v-if="submitting"><i class="bi bi-arrow-clockwise spin"></i> Đang tạo...</span>
              <span v-else>Thêm sản phẩm</span>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop fade show" v-if="showAddModal"></div>

    <!-- Category Management Modal (unchanged) -->
    <div class="modal fade" :class="{ show: showCategoryModal, 'd-block': showCategoryModal }" tabindex="-1"
      v-if="showCategoryModal">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">
              <i class="bi bi-tags me-2"></i>
              Danh sách danh mục
            </h5>
            <button type="button" class="btn-close" @click="showCategoryModal = false"></button>
          </div>
          <div class="modal-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Tên danh mục</th>
                    <th>Danh mục cha</th>
                    <th>Trạng thái</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="category in categories" :key="category.id">
                    <td>{{ category.id }}</td>
                    <td>{{ category.name }}</td>
                    <td>{{ category.parentId ? 'Con' : 'Gốc' }}</td>
                    <td>
                      <span :class="`badge bg-${category.isActive ? 'success' : 'secondary'}`">
                        {{ category.isActive ? 'Kích hoạt' : 'Tạm ngưng' }}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="showCategoryModal = false">
              Đóng
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop fade show" v-if="showCategoryModal"></div>
  </SellerLayout>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'
import { useRouter } from 'vue-router'
import SellerLayout from '../../components/SellerLayout.vue'
import { productService, productUtils } from '@/services/seller/products'
import { categoriesApi } from '@/services/admin/categories'
import { useAuthStore } from '@/stores/auth'
import Swal from 'sweetalert2'

const router = useRouter()
const authStore = useAuthStore()

// Template refs
const imageInput = ref(null)
const unifiedImageInput = ref(null)
const addProductForm = ref(null)

// Loading states
const loading = ref(false)
const loadingCategories = ref(false)
const submitting = ref(false)
const initializing = ref(true)
const hasTriedSubmit = ref(false)

// Search và pagination
const searchTerm = ref('')
const selectedStatus = ref('')
const currentPage = ref(0)
const pageSize = ref(5)
const sortBy = ref('createdAt')
const sortDirection = ref('desc')

// Data
const products = ref([])
const categories = ref([])
const selectedImages = ref([])
const selectedUnifiedImages = ref([])
const productStats = ref({
  total: 0,
  active: 0,
  pending: 0,
  lowStock: 0
})
const pagination = ref({
  page: 0,
  size: 10,
  totalElements: 0,
  totalPages: 0,
  first: true,
  last: true,
  hasNext: false,
  hasPrevious: false
})

// Modal states
const showAddModal = ref(false)
const showCategoryModal = ref(false)
const showUnifiedModal = ref(false)

// Unified Modal states
const unifiedLoading = ref(false)
const unifiedSaving = ref(false)
const unifiedProduct = ref(null)
const originalProduct = ref(null) // Backup for canceling edits
const isEditMode = ref(false)
const statusEdit = ref('')
const previewImage = ref('')
const variantsEdit = ref([])

// Form data
const newProduct = ref({
  id: null,
  name: '',
  slug: '',
  description: '',
  basePrice: 0,
  categoryId: '',
  variants: [
    {
      id: null,
      sku: '',
      finalPrice: 0,
      stockQuantity: 0,
      options: ''
    }
  ],
  imageUrls: []
})

// Status options
const statusOptions = [
  { value: '', label: 'Tất cả' },
  { value: 'PENDING_APPROVAL', label: 'Chờ duyệt' },
  { value: 'APPROVED', label: 'Đã duyệt' },
  { value: 'ACTIVE', label: 'Đang bán' },
  { value: 'INACTIVE', label: 'Tạm ngưng' },
  { value: 'OUT_OF_STOCK', label: 'Hết hàng' },
  { value: 'REJECTED', label: 'Bị từ chối' }
]

// Các lựa chọn trạng thái được phép đổi
const statusChangeOptions = [
  { value: 'ACTIVE', label: 'Đang bán' },
  { value: 'INACTIVE', label: 'Tạm ngưng' },
  { value: 'OUT_OF_STOCK', label: 'Hết hàng' }
]

// Computed properties
const activeCategories = computed(() => {
  return categories.value.filter(cat => cat.isActive !== false)
})

const categoryOptions = computed(() => {
  const options = []

  const addCategoryOption = (category, level = 0) => {
    const prefix = level > 0 ? ''.repeat(level) + ' ' : ''
    options.push({
      id: category.id,
      name: `${prefix}${category.name}`,
      category: category
    })

    const children = categories.value.filter(cat => cat.parentId === category.id)
    children.forEach(child => {
      addCategoryOption(child, level + 1)
    })
  }

  const rootCategories = categories.value.filter(cat => !cat.parentId && cat.isActive !== false)
  rootCategories.forEach(category => {
    addCategoryOption(category)
  })

  return options
})

const visiblePages = computed(() => {
  const total = pagination.value.totalPages
  const current = currentPage.value
  const pages = []

  let start = Math.max(0, current - 2)
  let end = Math.min(total - 1, current + 2)

  for (let i = start; i <= end; i++) {
    pages.push(i)
  }

  return pages
})

const isAuthenticated = computed(() => authStore.isAuthenticated)
const hasSellerRole = computed(() => {
  return authStore.hasRole('SELLER') || authStore.hasRole('ADMIN')
})

// Chỉ cho phép đổi trạng thái nếu không chờ duyệt/từ chối
const isStatusEditable = computed(() => {
  const st = unifiedProduct.value?.status
  return st && !['PENDING_APPROVAL', 'REJECTED'].includes(st)
})

// Methods
function totalStock(p) {
  return (p?.variants || []).reduce((sum, variant) => sum + (variant.stockQuantity || 0), 0)
}

const checkAuthAndPermissions = async () => {
  if (!authStore.isAuthenticated) {
    authStore.initializeAuth()
  }

  if (!authStore.isAuthenticated) {
    await Swal.fire({
      icon: 'warning',
      title: 'Chưa đăng nhập',
      text: 'Vui lòng đăng nhập để tiếp tục.',
      confirmButtonText: 'Đồng ý'
    })
    router.push('/seller/login')
    return false
  }

  if (!hasSellerRole.value) {
    await Swal.fire({
      icon: 'error',
      title: 'Không có quyền truy cập',
      text: 'Tài khoản của bạn không có quyền truy cập trang này.',
      confirmButtonText: 'Đồng ý'
    })
    router.push('/seller/dashboard')
    return false
  }

  return true
}

const loadCategories = async () => {
  try {
    loadingCategories.value = true
    const result = await categoriesApi.getPublicCategories()

    if (result.success && result.data) {
      categories.value = result.data.map(cat => ({
        id: cat.id,
        name: cat.name,
        code: cat.code || '',
        description: cat.description || '',
        parentId: cat.parentId || null,
        isActive: cat.isActive !== false
      }))
    } else {
      categories.value = []
    }
  } catch (error) {
    console.error('Error loading categories:', error)
    categories.value = []
  } finally {
    loadingCategories.value = false
  }
}

async function loadProducts() {
  if (!authStore.isAuthenticated || !hasSellerRole.value) {
    return
  }

  loading.value = true
  try {
    const result = await productService.getSellerProducts({
      searchTerm: searchTerm.value,
      status: selectedStatus.value || undefined,
      page: currentPage.value,
      size: pageSize.value,
      sortBy: sortBy.value,
      sortDirection: sortDirection.value
    })

    if (result.success && result.data) {
      const productListResponse = result.data
      const rawProducts = productListResponse.products || []

      products.value = rawProducts.map(product => {
        const totalStockCount = product.variants?.reduce((sum, variant) => sum + (variant.stockQuantity || 0), 0) || 0

        return {
          id: product.id,
          name: product.name,
          slug: product.slug,
          description: product.description,
          basePrice: product.basePrice,
          status: product.status,
          categoryId: product.categoryId,
          shopId: product.shopId,
          variants: product.variants || [],
          imageUrls: product.imageUrls || [],
          createdAt: product.createdAt,
          updatedAt: product.updatedAt,
          totalStock: totalStockCount,
          sold: product.sold || 0,
          image: product.imageUrls?.[0] || fallbackLogo,
          category: getCategoryName(product.categoryId),
          statusColor: productService.getStatusColor(product.status)
        }
      })

      pagination.value = {
        page: productListResponse.currentPage || 0,
        size: productListResponse.pageSize || pageSize.value,
        totalElements: productListResponse.totalElements || 0,
        totalPages: productListResponse.totalPages || 0,
        first: (productListResponse.currentPage || 0) === 0,
        last: (productListResponse.currentPage || 0) >= ((productListResponse.totalPages || 1) - 1),
        hasNext: productListResponse.hasNext || false,
        hasPrevious: productListResponse.hasPrevious || false
      }

      updateProductStats()
    } else {
      products.value = []
      pagination.value = {
        page: 0, size: pageSize.value, totalElements: 0, totalPages: 0,
        first: true, last: true, hasNext: false, hasPrevious: false
      }

      if (result.message && result.message !== 'Lấy danh sách sản phẩm thành công') {
        await Swal.fire({
          title: 'Không thể tải sản phẩm',
          text: result.message,
          icon: 'error',
          confirmButtonText: 'OK'
        })
      }
    }
  } catch (error) {
    console.error('Error loading products:', error)
    products.value = []

    await Swal.fire({
      title: 'Lỗi hệ thống',
      text: 'Không thể kết nối đến server. Vui lòng thử lại sau.',
      icon: 'error',
      confirmButtonText: 'OK'
    })
  } finally {
    loading.value = false
  }
}

function getCategoryName(categoryId) {
  if (!categoryId) return 'Chưa phân loại'
  const category = categories.value.find(cat => cat.id === categoryId)
  return category?.name || 'Unknown'
}

function updateProductStats() {
  const total = products.value.length
  const active = products.value.filter(p => p.status === 'ACTIVE' || p.status === 'APPROVED').length
  const pending = products.value.filter(p => p.status === 'PENDING_APPROVAL').length
  const lowStock = products.value.filter(p => (p.totalStock || 0) < 10).length

  productStats.value = { total, active, pending, lowStock }
}

async function openUnifiedModal(product) {
  try {
    showUnifiedModal.value = true;
    unifiedLoading.value = true;
    isEditMode.value = false;
    variantsEdit.value = [];

    const res = await productService.getSellerProductById(product.id);

    if (res.success && res.data) {
      unifiedProduct.value = {
        ...res.data,
        attributes: res.data.attributes || '',
        weightGrams: res.data.weightGrams || 0,
        dimensions: res.data.dimensions || ''
      };
      originalProduct.value = JSON.parse(JSON.stringify(unifiedProduct.value));

      // Khởi tạo variantsEdit với đầy đủ thuộc tính
      variantsEdit.value = (unifiedProduct.value.variants || []).map(v => ({
        id: v.id || 0,
        sku: v.sku || '',
        finalPrice: Number(v.finalPrice || 0),
        compareAtPrice: Number(v.compareAtPrice || 0),
        stockQuantity: Number(v.stockQuantity || 0),
        options: v.options || '{}',
        reorderThreshold: Number(v.reorderThreshold || 0),
        weightGrams: Number(v.weightGrams || 0),
        dimensions: v.dimensions || '',
        isActive: v.isActive !== false
      }));

      previewImage.value = unifiedProduct.value.imageUrls?.[0] || '';
    }
  } catch (error) {
    console.error('Error loading product:', error);
    await Swal.fire('Lỗi', 'Không thể tải chi tiết sản phẩm', 'error');
    closeUnifiedModal();
  } finally {
    unifiedLoading.value = false;
  }
}

function closeUnifiedModal() {
  showUnifiedModal.value = false
  unifiedProduct.value = null
  originalProduct.value = null
  variantsEdit.value = []
  statusEdit.value = ''
  previewImage.value = ''
  unifiedSaving.value = false
  unifiedLoading.value = false
  isEditMode.value = false
  selectedUnifiedImages.value = []
  hasTriedSubmit.value = false
}

function toggleEditMode() {
  if (isEditMode.value) {
    // Switching from edit to view - restore original data
    if (originalProduct.value) {
      unifiedProduct.value = JSON.parse(JSON.stringify(originalProduct.value))
      variantsEdit.value = (originalProduct.value.variants || []).map(v => ({
        id: v.id || 0,
        sku: v.sku || '',
        finalPrice: Number(v.finalPrice || 0),
        compareAtPrice: Number(v.compareAtPrice || 0),
        stockQuantity: Number(v.stockQuantity || 0),
        options: v.options || '',
        reorderThreshold: Number(v.reorderThreshold || 0),
        weightGrams: Number(v.weightGrams || 0),
        dimensions: v.dimensions || '',
        isActive: v.isActive !== false
      }))
      statusEdit.value = originalProduct.value.status
      selectedUnifiedImages.value = []
      if (unifiedImageInput.value) {
        unifiedImageInput.value.value = ''
      }
    }
    hasTriedSubmit.value = false
  }
  isEditMode.value = !isEditMode.value
}

async function saveStatus() {
  if (!unifiedProduct.value) return
  if (statusEdit.value === unifiedProduct.value.status) return

  try {
    unifiedSaving.value = true

    const res = await productService.updateProductStatus(
      unifiedProduct.value.id,
      statusEdit.value,
      unifiedProduct.value
    )

    if (res.success && res.data) {
      unifiedProduct.value = res.data
      originalProduct.value = JSON.parse(JSON.stringify(res.data))
      variantsEdit.value = (res.data.variants || []).map(v => ({
        id: v.id || 0,
        sku: v.sku || '',
        finalPrice: Number(v.finalPrice || 0),
        compareAtPrice: Number(v.compareAtPrice || 0),
        stockQuantity: Number(v.stockQuantity || 0),
        options: v.options || '',
        reorderThreshold: Number(v.reorderThreshold || 0),
        weightGrams: Number(v.weightGrams || 0),
        dimensions: v.dimensions || '',
        isActive: v.isActive !== false
      }))

      const idx = products.value.findIndex(p => p.id === unifiedProduct.value.id)
      if (idx !== -1) {
        products.value[idx].status = unifiedProduct.value.status
        products.value[idx].statusColor = productService.getStatusColor(unifiedProduct.value.status)
      }

      await Swal.fire({
        icon: 'success',
        title: 'Thành công',
        text: res.message || 'Đã cập nhật trạng thái',
        timer: 2000,
        showConfirmButton: false
      })
    } else {
      await Swal.fire({
        icon: 'error',
        title: 'Thất bại',
        text: res.message || 'Không thể cập nhật trạng thái'
      })
      statusEdit.value = unifiedProduct.value.status
    }
  } catch (e) {
    console.error('Error saving status:', e)
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi',
      text: 'Không thể cập nhật trạng thái'
    })
    statusEdit.value = unifiedProduct.value.status
  } finally {
    unifiedSaving.value = false
  }
}

async function saveVariants() {
  if (!unifiedProduct.value) return

  try {
    unifiedSaving.value = true

    const res = await productService.updateProductVariants(
      unifiedProduct.value.id,
      variantsEdit.value,
      unifiedProduct.value
    )

    if (res.success && res.data) {
      unifiedProduct.value = res.data
      originalProduct.value = JSON.parse(JSON.stringify(res.data))
      variantsEdit.value = (res.data.variants || []).map(v => ({
        id: v.id || 0,
        sku: v.sku || '',
        finalPrice: Number(v.finalPrice || 0),
        compareAtPrice: Number(v.compareAtPrice || 0),
        stockQuantity: Number(v.stockQuantity || 0),
        options: v.options || '',
        reorderThreshold: Number(v.reorderThreshold || 0),
        weightGrams: Number(v.weightGrams || 0),
        dimensions: v.dimensions || '',
        isActive: v.isActive !== false
      }))

      const idx = products.value.findIndex(p => p.id === unifiedProduct.value.id)
      if (idx !== -1) {
        products.value[idx].variants = res.data.variants || []
        products.value[idx].totalStock = totalStock(res.data)
      }

      await Swal.fire({
        icon: 'success',
        title: 'Thành công',
        text: res.message || 'Đã cập nhật biến thể',
        timer: 2000,
        showConfirmButton: false
      })
    } else {
      throw new Error(res.message || 'Không thể cập nhật biến thể')
    }
  } catch (e) {
    console.error('Error saving variants:', e)
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi',
      text: e.message || 'Không thể cập nhật biến thể'
    })
  } finally {
    unifiedSaving.value = false
  }
}
// update product
async function saveProduct() {
  hasTriedSubmit.value = true;

  // Validate dữ liệu
  const validationErrors = [];

  if (!unifiedProduct.value.name?.trim()) {
    validationErrors.push('Tên sản phẩm là bắt buộc');
  }

  if (!unifiedProduct.value.basePrice || unifiedProduct.value.basePrice <= 0) {
    validationErrors.push('Giá sản phẩm phải lớn hơn 0');
  }

  if (!unifiedProduct.value.categoryId) {
    validationErrors.push('Danh mục là bắt buộc');
  }

  if (variantsEdit.value.length === 0) {
    validationErrors.push('Sản phẩm phải có ít nhất 1 biến thể');
  } else {
    // Kiểm tra SKU trùng
    const skus = variantsEdit.value.map(v => v.sku?.toLowerCase()).filter(Boolean);
    const uniqueSkus = new Set(skus);

    if (uniqueSkus.size !== skus.length) {
      validationErrors.push('Có SKU trùng lặp trong các biến thể');
    }
  }

  if (validationErrors.length > 0) {
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi dữ liệu',
      html: validationErrors.join('<br>')
    });
    return;
  }

  unifiedSaving.value = true;

  try {
    // Chuẩn bị dữ liệu variants
    const variantsData = variantsEdit.value.map(variant => ({
      ...(variant.id && variant.id !== 0 && { id: variant.id }), // Chỉ gửi ID nếu có và khác 0
      sku: variant.sku || '',
      finalPrice: Number(variant.finalPrice) || 0,
      compareAtPrice: variant.compareAtPrice ? Number(variant.compareAtPrice) : null,
      stockQuantity: Number(variant.stockQuantity) || 0,
      options: variant.options || '',
      reorderThreshold: Number(variant.reorderThreshold) || 0,
      weightGrams: Number(variant.weightGrams) || 0,
      dimensions: variant.dimensions || '',
      isActive: variant.isActive !== false
    }));

    // Hiển thị tiến trình lâu (nếu cần có thể dùng NProgress/placeholder)
    const result = await productService.updateProductWithImages(
      unifiedProduct.value.id,
      {
        name: unifiedProduct.value.name.trim(),
        description: unifiedProduct.value.description?.trim() || null,
        basePrice: Number(unifiedProduct.value.basePrice),
        categoryId: Number(unifiedProduct.value.categoryId),
        variants: variantsData,
        attributes: unifiedProduct.value.attributes?.trim() || '',
        weightGrams: Number(unifiedProduct.value.weightGrams) || 0,
        dimensions: unifiedProduct.value.dimensions?.trim() || '',
        status: unifiedProduct.value.status || 'ACTIVE'
      },
      selectedUnifiedImages.value.map(img => img.file)
    );

    if (result.success) {
      // Sau khi server cập nhật xong, tải lại chi tiết để thấy ảnh mới mà không reload trang
      await refreshProductAfterUpdate(unifiedProduct.value.id, 3, 1200)

      selectedUnifiedImages.value = [];
      hasTriedSubmit.value = false;

      await Swal.fire({
        icon: 'success',
        title: 'Thành công',
        text: result.message || 'Cập nhật sản phẩm thành công',
        timer: 1800
      });

      isEditMode.value = false;
    } else if (result.timeout) {
      await Swal.fire({
        icon: 'warning',
        title: 'Đang xử lý',
        text: result.message + ' (Bạn có thể kiểm tra lại sau vài giây).'
      })
    } else {
      throw new Error(result.message || 'Lỗi khi cập nhật sản phẩm');
    }
  } catch (error) {
    console.error('Error saving product:', error);

    let errorMessage = error.message || 'Lỗi khi cập nhật sản phẩm';

    if (error.message?.includes('SKU')) {
      errorMessage = error.message;
    } else if (error.response?.status === 422) {
      errorMessage = 'Dữ liệu không hợp lệ. Vui lòng kiểm tra lại.';
    }

    await Swal.fire({
      icon: 'error',
      title: 'Lỗi',
      text: errorMessage
    });
  } finally {
    unifiedSaving.value = false;
  }
}
// Hàm validate được cải thiện
function validateProductData() {
  const errors = [];

  // Validate tên sản phẩm
  if (!unifiedProduct.value?.name?.trim()) {
    errors.push('Tên sản phẩm là bắt buộc');
  }

  // Validate giá
  if (!unifiedProduct.value?.basePrice || unifiedProduct.value.basePrice <= 0) {
    errors.push('Giá sản phẩm phải lớn hơn 0');
  }

  // Validate danh mục
  if (!unifiedProduct.value?.categoryId) {
    errors.push('Danh mục là bắt buộc');
  }

  // Validate biến thể
  if (!variantsEdit.value || variantsEdit.value.length === 0) {
    errors.push('Sản phẩm phải có ít nhất 1 biến thể');
  } else {
    // Kiểm tra từng biến thể
    const skus = [];
    variantsEdit.value.forEach((variant, index) => {
      if (!variant.sku?.trim()) {
        errors.push(`Biến thể ${index + 1}: SKU là bắt buộc`);
      } else {
        const sku = variant.sku.trim().toLowerCase();
        if (skus.includes(sku)) {
          errors.push(`Biến thể ${index + 1}: SKU "${variant.sku}" bị trùng lặp`);
        }
        skus.push(sku);
      }

      if (!variant.finalPrice || variant.finalPrice <= 0) {
        errors.push(`Biến thể ${index + 1}: Giá bán phải lớn hơn 0`);
      }

      if (variant.stockQuantity < 0) {
        errors.push(`Biến thể ${index + 1}: Số lượng tồn kho không thể âm`);
      }
    });
  }

  if (errors.length > 0) {
    Swal.fire({
      icon: 'error',
      title: 'Lỗi dữ liệu',
      html: errors.join('<br>'),
      confirmButtonText: 'Đồng ý'
    });
    return false;
  }

  return true;
}

const addUnifiedVariant = () => {
  const generateTempSku = () => {
    const existingSkus = variantsEdit.value.map(v => v.sku?.toLowerCase()).filter(Boolean);
    let tempSku;
    let counter = 1;

    do {
      tempSku = `TEMP-${Date.now()}-${counter}`;
      counter++;
    } while (existingSkus.includes(tempSku.toLowerCase()));

    return tempSku;
  };

  variantsEdit.value.push({
    id: 0, // ID = 0 cho biến thể mới
    sku: generateTempSku(),
    finalPrice: unifiedProduct.value?.basePrice || 0,
    compareAtPrice: 0,
    stockQuantity: 0,
    options: '{}',
    reorderThreshold: 0,
    weightGrams: 0,
    dimensions: '',
    isActive: true
  });
};

// Hàm xóa biến thể trong chế độ chỉnh sửa
const removeUnifiedVariant = async (productId, variantId, index) => {
  const pid = productId || unifiedProduct.value?.id; // fallback

  if (!pid) {
    Swal.fire({
      icon: 'error',
      title: 'Lỗi',
      text: 'Thiếu productId khi xóa biến thể',
      confirmButtonText: 'Đồng ý'
    })
    return;
  }

  // if (!variantId) {
  //   // biến thể mới tạo, chưa lưu DB => chỉ xoá UI
  //   variantsEdit.value.splice(index, 1)
  //   return;
  // }

  if (variantsEdit.value.length > 1) {
    try {
      const result = await productService.deleteProductVariant(pid, variantId);
      if (result.success) {
        variantsEdit.value.splice(index, 1);
        Swal.fire({
          icon: 'success',
          title: 'Thành công',
          text: result.message,
          confirmButtonText: 'Đồng ý'
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Lỗi',
          text: result.message,
          confirmButtonText: 'Đồng ý'
        });
      }
    } catch (err) {
      console.error(err);
      Swal.fire({
        icon: 'error',
        title: 'Lỗi',
        text: 'Đã xảy ra lỗi khi xóa biến thể',
        confirmButtonText: 'Đồng ý'
      });
    }
  } else {
    Swal.fire({
      icon: 'warning',
      title: 'Không thể xóa',
      text: 'Sản phẩm phải có ít nhất 1 biến thể',
      confirmButtonText: 'Đồng ý'
    });
  }
};




const handleUnifiedImageChange = (e) => {
  const files = Array.from(e.target.files)
  const validation = productUtils.validateImageFiles(files)

  if (!validation.isValid) {
    Swal.fire({
      icon: 'warning',
      title: 'Lỗi hình ảnh',
      html: validation.errors.join('<br>'),
      confirmButtonText: 'Đồng ý'
    })
    e.target.value = ''
    return
  }

  selectedUnifiedImages.value = files.map(file => ({
    file,
    preview: URL.createObjectURL(file)
  }))
}

const handleUnifiedDrop = (e) => {
  const files = Array.from(e.dataTransfer.files || [])
  const validation = productUtils.validateImageFiles(files)
  if (!validation.isValid) {
    Swal.fire({ icon: 'error', title: 'Lỗi ảnh', html: validation.errors.join('<br>') })
    return
  }
  const maxRemain = Math.max(0, 10 - selectedUnifiedImages.value.length)
  const picked = files.slice(0, maxRemain)
  selectedUnifiedImages.value.push(
    ...picked.map(file => ({ file, preview: URL.createObjectURL(file) }))
  )
}

const removeSelectedUnifiedImage = (index) => {
  selectedUnifiedImages.value.splice(index, 1)
  if (selectedUnifiedImages.value.length === 0 && unifiedImageInput.value) {
    unifiedImageInput.value.value = ''
  }
}

const openUnifiedPicker = () => {
  if (unifiedImageInput?.value) {
    unifiedImageInput.value.click()
  }
}

// Watch basePrice changes in edit mode để tự động cập nhật giá variants
watch(() => unifiedProduct.value?.basePrice, (newVal) => {
  if (isEditMode.value && newVal) {
    variantsEdit.value.forEach(variant => {
      if (!variant.finalPrice || variant.finalPrice === 0) {
        variant.finalPrice = newVal
      }
    })
  }
})

// Add Product Modal Functions (unchanged from original)
const resetNewProduct = () => {
  newProduct.value = {
    name: '',
    slug: '',
    description: '',
    basePrice: 0,
    categoryId: '',
    variants: [
      {
        sku: '',
        finalPrice: 0,
        stockQuantity: 0,
        options: ''
      }
    ],
    imageUrls: []
  }

  hasTriedSubmit.value = false
  selectedImages.value = []

  if (imageInput.value) {
    imageInput.value.value = ''
  }
}

const closeAddModal = () => {
  showAddModal.value = false
  resetNewProduct()
}

const removeImage = (index) => {
  selectedImages.value.splice(index, 1)
  if (selectedImages.value.length === 0 && imageInput.value) {
    imageInput.value.value = ''
  }
}

const addVariant = () => {
  newProduct.value.variants.push({
    sku: '',
    finalPrice: newProduct.value.basePrice,
    stockQuantity: 0,
    options: ''
  })
}

const removeVariant = (index) => {
  if (newProduct.value.variants.length > 1) {
    newProduct.value.variants.splice(index, 1)
  } else {
    Swal.fire({
      icon: 'warning',
      title: 'Không thể xóa',
      text: 'Sản phẩm phải có ít nhất 1 biến thể',
      confirmButtonText: 'Đồng ý'
    })
  }
}

watch(() => newProduct.value.basePrice, (newVal) => {
  newProduct.value.variants.forEach(variant => {
    variant.finalPrice = newVal
  })
})

const handleImageChange = (e) => {
  const files = Array.from(e.target.files)
  const validation = productUtils.validateImageFiles(files)

  if (!validation.isValid) {
    Swal.fire({
      icon: 'warning',
      title: 'Lỗi hình ảnh',
      html: validation.errors.join('<br>'),
      confirmButtonText: 'Đồng ý'
    })
    e.target.value = ''
    return
  }

  selectedImages.value = files.map(file => ({
    file,
    preview: URL.createObjectURL(file)
  }))
}

const addProduct = async () => {
  hasTriedSubmit.value = true;

  // Validate dữ liệu
  const errors = []
  if (!newProduct.value.name?.trim()) errors.push('Tên sản phẩm là bắt buộc')
  if (!newProduct.value.categoryId) errors.push('Danh mục là bắt buộc')
  if (!newProduct.value.basePrice || newProduct.value.basePrice <= 0) errors.push('Giá sản phẩm phải lớn hơn 0')
  if (!newProduct.value.variants || newProduct.value.variants.length === 0) errors.push('Sản phẩm phải có ít nhất 1 biến thể')

  // Validate từng biến thể
  const seenSkus = new Set()
  newProduct.value.variants.forEach((v, i) => {
    const row = i + 1
    if (!v.sku?.trim()) errors.push(`Biến thể ${row}: SKU là bắt buộc`)
    const skuKey = v.sku?.trim().toLowerCase()
    if (skuKey) {
      if (seenSkus.has(skuKey)) errors.push(`Biến thể ${row}: SKU bị trùng lặp (${v.sku})`)
      seenSkus.add(skuKey)
    }
    if (!v.finalPrice || v.finalPrice <= 0) errors.push(`Biến thể ${row}: Giá bán phải lớn hơn 0`)
    if (v.stockQuantity == null || v.stockQuantity < 0) errors.push(`Biến thể ${row}: Số lượng không hợp lệ`)
  })

  if (errors.length > 0) {
    await Swal.fire({ icon: 'error', title: 'Lỗi dữ liệu', html: errors.join('<br>') })
    return
  }

  submitting.value = true;

  try {
    const formData = new FormData();

    const productData = {
      name: newProduct.value.name.trim(),
      description: newProduct.value.description || '',
      basePrice: Number(newProduct.value.basePrice),
      categoryId: Number(newProduct.value.categoryId),
      variants: newProduct.value.variants.map(v => ({
        sku: v.sku.trim(),
        finalPrice: Number(v.finalPrice),
        stockQuantity: Number(v.stockQuantity),
        options: v.options || ''
      }))
    };

    formData.append('product', new Blob([JSON.stringify(productData)], { type: 'application/json' }), 'product.json');

    selectedImages.value.forEach((img, index) => {
      formData.append('images', img.file, `image_${index}.${img.file.name.split('.').pop()}`);
    });

    const result = await productService.createProductWithImages(formData);

    if (result.success) {
      await Swal.fire('Thành công', 'Tạo sản phẩm thành công', 'success');
      closeAddModal();
      loadProducts();
    } else {
      throw new Error(result.message || 'Lỗi khi tạo sản phẩm');
    }
  } catch (error) {
    console.error('Error adding product:', error);
    await Swal.fire('Lỗi', error.message || 'Không thể tạo sản phẩm', 'error');
  } finally {
    submitting.value = false;
  }
};

const deleteProduct = async (productId, productName) => {
  const confirmResult = await Swal.fire({
    icon: 'warning',
    title: 'Xác nhận xóa',
    html: `Bạn có chắc chắn muốn xóa sản phẩm<br><strong>"${productName}"</strong>?`,
    showCancelButton: true,
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy',
    confirmButtonColor: '#dc3545'
  })

  if (!confirmResult.isConfirmed) {
    return
  }

  try {
    const result = await productService.deleteProduct(productId)

    if (result.success) {
      await Swal.fire({
        icon: 'success',
        title: 'Thành công!',
        text: result.message || 'Sản phẩm đã được xóa.',
        confirmButtonText: 'OK'
      })

      await loadProducts()
    } else {
      throw new Error(result.message)
    }
  } catch (error) {
    console.error('Error deleting product:', error)
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: error.message || 'Không thể xóa sản phẩm.',
      confirmButtonText: 'OK'
    })
  }
}

const changePage = (page) => {
  if (page >= 0 && page < pagination.value.totalPages) {
    currentPage.value = page
    loadProducts()
  }
}

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND'
  }).format(amount || 0)
}

// Watch for search and filter changes
let searchTimeout
watch([searchTerm, selectedStatus], () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    currentPage.value = 0
    loadProducts()
  }, 500)
})

// OnMounted
onMounted(async () => {
  // Reset filters
  selectedStatus.value = ''
  searchTerm.value = ''
  currentPage.value = 0

  // Check auth first
  const authOk = await checkAuthAndPermissions()
  if (!authOk) return

  try {
    // Load categories and products in parallel
    await Promise.all([
      loadCategories(),
      loadProducts()
    ])
  } catch (error) {
    console.error('Error during component initialization:', error)
  } finally {
    initializing.value = false
  }
})

// Cleanup on component unmount
onBeforeUnmount(() => {
  if (searchTimeout) {
    clearTimeout(searchTimeout)
  }

  // Cleanup object URLs to prevent memory leaks
  selectedImages.value.forEach(img => {
    if (img.preview) {
      URL.revokeObjectURL(img.preview)
    }
  })

  selectedUnifiedImages.value.forEach(img => {
    if (img.preview) {
      URL.revokeObjectURL(img.preview)
    }
  })
})

const addCacheBuster = (url) => {
  if (!url) return url
  const sep = url.includes('?') ? '&' : '?'
  return `${url}${sep}v=${Date.now()}`
}

async function refreshProductAfterUpdate(productId, maxTries = 3, delayMs = 1200) {
  for (let i = 0; i < maxTries; i++) {
    const refreshed = await productService.getSellerProductById(productId)
    if (refreshed.success && refreshed.data) {
      // Bust cache for images
      const withBustedImages = {
        ...refreshed.data,
        imageUrls: (refreshed.data.imageUrls || []).map(addCacheBuster)
      }
      unifiedProduct.value = withBustedImages
      originalProduct.value = JSON.parse(JSON.stringify(withBustedImages))
      variantsEdit.value = (withBustedImages.variants || []).map(v => ({
        id: v.id || 0,
        sku: v.sku || '',
        finalPrice: Number(v.finalPrice || 0),
        compareAtPrice: Number(v.compareAtPrice || 0),
        stockQuantity: Number(v.stockQuantity || 0),
        options: v.options || '',
        reorderThreshold: Number(v.reorderThreshold || 0),
        weightGrams: Number(v.weightGrams || 0),
        dimensions: v.dimensions || '',
        isActive: v.isActive !== false
      }))

      const idx = products.value.findIndex(p => p.id === productId)
      if (idx !== -1) {
        products.value[idx] = {
          ...products.value[idx],
          ...withBustedImages,
          totalStock: (withBustedImages.variants || []).reduce((sum, v) => sum + (v.stockQuantity || 0), 0),
          image: addCacheBuster(withBustedImages.imageUrls?.[0] || fallbackLogo),
          statusColor: productService.getStatusColor(withBustedImages.status)
        }
      }
      return true
    }
    // wait then retry
    await new Promise(r => setTimeout(r, delayMs))
  }
  return false
}

// State for image management
const currentImages = ref([])
const selectedImageIds = ref([])

async function loadCurrentImages(productId) {
  const res = await productService.listProductImages(productId)
  if (res.success && res.data) {
    currentImages.value = res.data.images || []
  } else {
    currentImages.value = []
  }
}

async function deleteSelectedImages() {
  if (!selectedImageIds.value.length || !unifiedProduct.value?.id) return
  const confirm = await Swal.fire({
    icon: 'warning',
    title: 'Xóa ảnh?',
    text: `Bạn chắc chắn xóa ${selectedImageIds.value.length} ảnh đã chọn?`,
    showCancelButton: true,
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy'
  })
  if (!confirm.isConfirmed) return

  try {
    unifiedSaving.value = true
    const res = await productService.deleteProductImages(unifiedProduct.value.id, selectedImageIds.value)
    if (res.success) {
      await loadCurrentImages(unifiedProduct.value.id)
      await refreshProductAfterUpdate(unifiedProduct.value.id, 2, 800)
      selectedImageIds.value = []
      Swal.fire('Thành công', res.message, 'success')
    } else {
      Swal.fire('Lỗi', res.message, 'error')
    }
  } finally {
    unifiedSaving.value = false
  }
}

// Load when opening unified modal
watch(unifiedProduct, (val) => {
  if (val?.id) {
    loadCurrentImages(val.id)
  }
})

// Slider state for view mode
const sliderIndex = ref(0)
const sliderImages = computed(() => (unifiedProduct.value?.imageUrls && unifiedProduct.value.imageUrls.length > 0)
  ? unifiedProduct.value.imageUrls
  : [fallbackLogo]
)
const nextSlide = () => { sliderIndex.value = (sliderIndex.value + 1) % sliderImages.value.length }
const prevSlide = () => { sliderIndex.value = (sliderIndex.value - 1 + sliderImages.value.length) % sliderImages.value.length }
const goSlide = (i) => { sliderIndex.value = i }

watch(unifiedProduct, () => { sliderIndex.value = 0 })

// Fallback image and onError handler
const fallbackImage = '/error404.png'
const onImgError = (e) => { if (e?.target) e.target.src = fallbackImage }

</script>

<style scoped>
.spin {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
}

.table th {
  background-color: #f8f9fa;
  border-top: none;
}

.badge {
  font-size: 0.75em;
}

.btn-group-sm>.btn {
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
}

.modal-backdrop {
  background-color: rgba(0, 0, 0, 0.5);
}

.position-relative .btn {
  border-radius: 50%;
  width: 24px;
  height: 24px;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Enhanced table styling for variant management */
.table-responsive {
  max-height: 400px;
  overflow-y: auto;
}

.form-control-sm {
  font-size: 0.875rem;
}

.form-check-input {
  margin-top: 0.125rem;
}

/* Improved modal size for better viewing */
.modal-xl {
  max-width: 1000px;
}

/* Better spacing for form elements */
.form-label {
  font-weight: 600;
  margin-bottom: 0.5rem;
}

.invalid-feedback {
  font-size: 0.875rem;
}

/* Custom styling for image previews */
.img-thumbnail {
  border: 2px solid #dee2e6;
  transition: border-color 0.15s ease-in-out;
}

.img-thumbnail:hover {
  border-color: #0d6efd;
}

.upload-dropzone {
  border: 2px dashed #ced4da;
  border-radius: 8px;
  padding: 16px;
  background-color: #f8f9fa;
  cursor: pointer;
}
.upload-dropzone:hover {
  background-color: #f1f3f5;
}
.object-fit-cover { object-fit: cover; }
.thumb { height: 120px; }

.image-grid-item {
  height: 110px;
  border: 1px solid rgba(0,0,0,.1);
  background-color: #fff;
}
.image-grid-item:hover {
  box-shadow: 0 .25rem .5rem rgba(0,0,0,.08);
}

/* Simple slider */
.slider { position: relative; }
.slider-viewport { position: relative; height: 220px; overflow: hidden; }
.slide { position: absolute; inset: 0; opacity: 0; transition: opacity .3s ease; }
.slide.active { opacity: 1; }
.slider-btn { position: absolute; top: 50%; transform: translateY(-50%); border: none; background: rgba(255,255,255,.8); border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; }
.slider-btn.prev { left: 6px; }
.slider-btn.next { right: 6px; }
.slider-dots .dot { width: 8px; height: 8px; border-radius: 50%; border: none; margin: 0 3px; background: #ced4da; }
.slider-dots .dot.active { background: #0d6efd; }

.image-scroll-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: .5rem;
  max-height: 260px;
  overflow-y: auto;
}
.image-scroll-item { min-height: 110px; }
</style>
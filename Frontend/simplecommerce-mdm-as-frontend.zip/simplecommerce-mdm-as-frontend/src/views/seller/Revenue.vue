<template>
  <SellerLayout>
    <!-- Revenue Stats -->
    <div class="row mb-4">
      <div class="col-md-3">
        <div class="card bg-success text-white">
          <div class="card-body text-center">
            <h3>{{ formatCurrency(overviewData.totalRevenue || 0) }}</h3>
            <small>Tổng doanh thu</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-primary text-white">
          <div class="card-body text-center">
            <h3>{{ formatCurrency(avgOrderValue || 0) }}</h3>
            <small>Giá trị đơn hàng TB</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-warning text-white">
          <div class="card-body text-center">
            <h3>{{ overviewData.completedOrders || 0 }}</h3>
            <small>Đơn hoàn thành</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-info text-white">
          <div class="card-body text-center">
            <h3>{{ returnsCount || 0 }}</h3>
            <small>Trả hàng</small>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <!-- Revenue Chart -->
      <div class="col-md-8">
        <div class="card mb-4">
          <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
              <h5>{{ chartTitle }}</h5>
              <div class="d-flex gap-2">
                <select v-model="chartFilter.range" @change="loadSalesData" class="form-select form-select-sm" style="width: auto;">
                  <option value="7d">7 ngày</option>
                  <option value="30d">30 ngày</option>
                  <option value="90d">3 tháng</option>
                  <option value="1y">1 năm</option>
                </select>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div v-if="loading.sales" class="text-center">
              <div class="spinner-border" role="status">
                <span class="visually-hidden">Đang tải...</span>
              </div>
            </div>
            <canvas v-else ref="revenueChart" id="sellerRevenueChart" height="340px"></canvas>
          </div>
        </div>
      </div>

      <!-- Quick Stats -->
      <div class="col-md-4">
        <div class="card mb-4">
          <div class="card-header">
            <h5>Thống kê nhanh</h5>
          </div>
          <div class="card-body">
            <div class="mb-3">
              <div class="d-flex justify-content-between">
                <span>Doanh thu hôm nay</span>
                <strong>{{ formatCurrency(overviewData.todayRevenue || 0) }}</strong>
              </div>
            </div>
            <div class="mb-3">
              <div class="d-flex justify-content-between">
                <span>Đơn hàng đang xử lý</span>
                <strong>{{ overviewData.processingOrders || 0 }}</strong>
              </div>
            </div>
            <div class="mb-3">
              <div class="d-flex justify-content-between">
                <span>Đơn hàng chờ duyệt</span>
                <strong>{{ overviewData.pendingOrders || 0 }}</strong>
              </div>
            </div>
          </div>
        </div>

        <!-- Payment Breakdown -->
        <!-- <div class="card">
          <div class="card-header">
            <h5>Phân tích thanh toán</h5>
          </div>
          <div class="card-body">
            <div v-if="loading.payment" class="text-center">
              <div class="spinner-border spinner-border-sm" role="status">
                <span class="visually-hidden">Đang tải...</span>
              </div>
            </div>
            <div v-else>
              <div v-for="item in paymentBreakdown" :key="item.label" class="d-flex justify-content-between align-items-center mb-2">
                <span>{{ item.label }}</span>
                <div class="text-end">
                  <div class="badge bg-primary">{{ item.count }}</div>
                  <div class="small text-muted">{{ formatCurrency(item.amount) }}</div>
                </div>
              </div>
            </div>
          </div>
        </div> -->
      </div>
    </div>

  </SellerLayout>
</template>

<script setup>
import { ref, onMounted, computed, nextTick } from 'vue'
import SellerLayout from '../../components/SellerLayout.vue'
import { Chart, registerables } from 'chart.js'
import Swal from 'sweetalert2'
import statsService from '@/services/seller/statis'


Chart.register(...registerables)

let chartInstance = null

// Data refs
const overviewData = ref({})
const salesData = ref([])
const paymentBreakdown = ref([])
const avgOrderValue = ref(0)
const returnsCount = ref(0)

// Loading states
const loading = ref({
  overview: false,
  sales: false,
  payment: false,
  aov: false,
  returns: false
})

// Chart filter
const chartFilter = ref({
  range: '30d'
})

// Computed properties
const chartTitle = computed(() => {
  const rangeLabels = {
    '7d': 'Doanh thu 7 ngày qua',
    '30d': 'Doanh thu 30 ngày qua', 
    '90d': 'Doanh thu 3 tháng qua',
    '1y': 'Doanh thu 1 năm qua'
  }
  return rangeLabels[chartFilter.value.range] || 'Doanh thu'
})

const revenueChart = ref(null)

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND'
  }).format(amount)
}

// ĐẢM BẢO CÓ ĐỦ TẤT CẢ CÁC HÀM LOAD
const loadPaymentBreakdown = async () => {
  try {
    loading.value.payment = true
    const response = await statsService.getPaymentBreakdown(chartFilter.value.range)
    if (response && response.statusCode === 200) {
      paymentBreakdown.value = response.data
      console.log('Payment breakdown loaded:', paymentBreakdown.value)
    }
  } catch (error) {
    console.error('Error loading payment breakdown:', error)
  } finally {
    loading.value.payment = false
  }
}

const loadAvgOrderValue = async () => {
  try {
    loading.value.aov = true
    const response = await statsService.getAvgOrderValue(chartFilter.value.range)
    // SỬA: Gán trực tiếp response, không cần kiểm tra statusCode
    avgOrderValue.value = response || 0
    console.log('AOV loaded:', avgOrderValue.value)
  } catch (error) {
    console.error('Error loading AOV:', error)
  } finally {
    loading.value.aov = false
  }
}

const loadReturns = async () => {
  try {
    loading.value.returns = true
    const response = await statsService.getReturns(chartFilter.value.range)
    if (response && response.statusCode === 200) {
      returnsCount.value = response.data
      console.log('Returns loaded:', returnsCount.value)
    }
  } catch (error) {
    console.error('Error loading returns:', error)
  } finally {
    loading.value.returns = false
  }
}

const loadSalesData = async () => {
  try {
    loading.value.sales = true
    const response = await statsService.getSalesSeries(chartFilter.value.range)
    if (response && response.statusCode === 200) {
      salesData.value = response.data
      // console.log('Revenue sales data loaded:', salesData.value)
      
      // THÊM TIMEOUT ĐỂ ĐẢM BẢO DOM ĐÃ READY
      setTimeout(() => {
        initChart()
      }, 100)
    }
  } catch (error) {
    console.error('Error loading sales data:', error)
    Swal.fire({
      title: 'Lỗi!',
      text: 'Không thể tải dữ liệu doanh thu',
      icon: 'error'
    })
  } finally {
    loading.value.sales = false
  }
}

const loadOverview = async () => {
  try {
    loading.value.overview = true
    const response = await statsService.getOverview()
    //console.log('Overview response:', response)
    
    if (response && response.statusCode === 200) {
      overviewData.value = response.data
      //console.log('Overview loaded:', overviewData.value)
    } else {
      console.warn('Unexpected response structure:', response)
    }
  } catch (error) {
    console.error('Error loading overview:', error)
    Swal.fire({
      title: 'Lỗi!',
      text: 'Không thể tải dữ liệu tổng quan',
      icon: 'error'
    })
  } finally {
    loading.value.overview = false
  }
}

const initChart = () => {
  console.log('Initializing revenue chart...')
  
  if (chartInstance) {
    chartInstance.destroy()
    chartInstance = null
  }

  // ĐỢI NEXT TICK
  nextTick(() => {
    if (!revenueChart.value) {
      console.error('Revenue chart canvas not found!')
      
      // Thử tìm canvas bằng ID
      const canvas = document.getElementById('sellerRevenueChart')
      if (canvas) {
        console.log('Found canvas by ID:', canvas)
        revenueChart.value = canvas
      } else {
        console.error('No canvas element found with ID sellerRevenueChart')
        return
      }
    }

    if (!salesData.value || salesData.value.length === 0) {
      console.warn('No sales data available for revenue chart')
      return
    }

    const ctx = revenueChart.value.getContext('2d')
    if (!ctx) {
      console.error('Could not get canvas context')
      return
    }

    // Prepare chart data
    const labels = salesData.value.map(item => {
      try {
        const date = new Date(item.date)
        return date.toLocaleDateString('vi-VN', { 
          day: '2-digit', 
          month: '2-digit' 
        })
      } catch (error) {
        console.error('Error parsing date:', item.date, error)
        return item.date
      }
    })
    
    const revenueData = salesData.value.map(item => item.revenue || 0)
    const ordersData = salesData.value.map(item => item.orders || 0)

    // console.log('Chart labels:', labels)
    // console.log('Revenue data:', revenueData)
    // console.log('Orders data:', ordersData)

    try {
      chartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Doanh thu (VNĐ)',
              data: revenueData,
              borderColor: 'rgb(54, 162, 235)',
              backgroundColor: 'rgba(54, 162, 235, 0.2)',
              tension: 0.4,
              fill: true,
              pointBackgroundColor: 'rgb(54, 162, 235)',
              pointBorderColor: '#fff',
              pointBorderWidth: 2,
              pointRadius: 5,
              pointHoverRadius: 7,
              yAxisID: 'y'
            },
            {
              label: 'Số đơn hàng',
              data: ordersData,
              borderColor: 'rgb(255, 99, 132)',
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
              tension: 0.4,
              fill: false,
              pointBackgroundColor: 'rgb(255, 99, 132)',
              pointBorderColor: '#fff',
              pointBorderWidth: 2,
              pointRadius: 4,
              pointHoverRadius: 6,
              yAxisID: 'y1'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: false
            },
            legend: {
              display: true,
              position: 'bottom'
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  if (context.datasetIndex === 0) {
                    return `Doanh thu: ${formatCurrency(context.parsed.y)}`
                  } else {
                    return `Số đơn hàng: ${context.parsed.y}`
                  }
                }
              }
            }
          },
          scales: {
            y: {
              type: 'linear',
              display: true,
              position: 'left',
              beginAtZero: true,
              ticks: {
                callback: function(value) {
                  return new Intl.NumberFormat('vi-VN', {
                    style: 'currency',
                    currency: 'VND',
                    notation: 'compact'
                  }).format(value)
                }
              },
              grid: {
                color: 'rgba(0, 0, 0, 0.1)'
              }
            },
            y1: {
              type: 'linear',
              display: true,
              position: 'right',
              beginAtZero: true,
              grid: {
                drawOnChartArea: false,
              },
              ticks: {
                callback: function(value) {
                  return Math.floor(value)
                }
              }
            },
            x: {
              grid: {
                display: false
              }
            }
          },
          interaction: {
            intersect: false,
            mode: 'index'
          }
        }
      })
      
      console.log('Revenue chart created successfully')
    } catch (error) {
      console.error('Error creating revenue chart:', error)
    }
  })
}

const loadAllData = async () => {
  console.log('Loading all data...')
  try {
    await Promise.all([
      loadOverview(),
      loadSalesData(),
      loadPaymentBreakdown(), // ĐẢM BẢO HÀM NÀY ĐÃ ĐƯỢC ĐỊNH NGHĨA
      loadAvgOrderValue(),
      loadReturns()
    ])
    console.log('All data loaded successfully')
  } catch (error) {
    console.error('Error loading all data:', error)
  }
}

onMounted(() => {
  console.log('Revenue component mounted')
  loadAllData()
})
</script>

<style scoped>
.card-header .d-flex {
  align-items: center;
}

.form-select-sm {
  min-width: 80px;
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

/* Đảm bảo chart container có chiều cao */
.chart-container {
  position: relative;
  height: 350px;
  width: 100%;
}

/* Đảm bảo canvas chiếm toàn bộ container */
canvas {
  width: 100% !important;
  height: 100% !important;
}

@media (max-width: 768px) {
  .card-header .d-flex {
    flex-direction: column;
    gap: 10px;
  }

  .card-header .d-flex > div {
    width: 100%;
  }

  .card-header .d-flex .form-select {
    width: 100% !important;
  }
  
  .chart-container {
    height: 300px;
  }
}
</style>
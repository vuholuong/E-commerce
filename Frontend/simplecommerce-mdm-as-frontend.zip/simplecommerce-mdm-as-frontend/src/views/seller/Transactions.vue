<template>
  <SellerLayout>
    <div class="container-fluid p-4">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
              <h4 class="mb-0">
                <i class="bi bi-clock-history me-2"></i>
                Lịch sử giao dịch
              </h4>
              <div class="d-flex gap-2">
                <button class="btn btn-outline-success" @click="exportTransactions">
                  <i class="bi bi-download me-2"></i>
                  Xuất Excel
                </button>
                <button class="btn btn-primary" @click="refreshTransactions">
                  <i class="bi bi-arrow-clockwise me-2"></i>
                  Làm mới
                </button>
              </div>
            </div>

            <div class="card-body">
              <!-- Bộ lọc -->
              <div class="row mb-4">
                <div class="col-md-2">
                  <label class="form-label">Trạng thái</label>
                  <select class="form-select" v-model="filters.status">
                    <option value="">Tất cả</option>
                    <option value="completed">Hoàn thành</option>
                    <option value="pending">Đang xử lý</option>
                    <option value="failed">Thất bại</option>
                    <option value="refunded">Đã hoàn tiền</option>
                  </select>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Loại giao dịch</label>
                  <select class="form-select" v-model="filters.type">
                    <option value="">Tất cả</option>
                    <option value="order">Bán hàng</option>
                    <option value="withdrawal">Rút tiền</option>
                    <option value="commission">Hoa hồng</option>
                    <option value="refund">Hoàn tiền</option>
                  </select>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Từ ngày</label>
                  <input
                      type="date"
                      class="form-control"
                      v-model="filters.startDate"
                  >
                </div>
                <div class="col-md-2">
                  <label class="form-label">Đến ngày</label>
                  <input
                      type="date"
                      class="form-control"
                      v-model="filters.endDate"
                  >
                </div>
                <div class="col-md-3">
                  <label class="form-label">Tìm kiếm</label>
                  <input
                      type="text"
                      class="form-control"
                      placeholder="Mã giao dịch, mã đơn hàng..."
                      v-model="filters.search"
                  >
                </div>
                <div class="col-md-1 d-flex align-items-end">
                  <button class="btn btn-outline-secondary w-100" @click="resetFilters">
                    <i class="bi bi-arrow-clockwise"></i>
                  </button>
                </div>
              </div>
              
              <!-- Bảng giao dịch -->
              <div class="table-responsive">
                <table class="table table-hover">
                  <thead class="table-dark">
                  <tr>
                    <th>Mã giao dịch</th>
                    <th>Ngày</th>
                    <th>Loại</th>
                    <th>Mô tả</th>
                    <th>Số tiền</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr v-for="transaction in paginatedTransactions" :key="transaction.id">
                    <td>
                      <span class="badge bg-secondary">{{ transaction.code }}</span>
                    </td>
                    <td>
                      <div>{{ formatDate(transaction.createdAt) }}</div>
                      <small class="text-muted">{{ formatTime(transaction.createdAt) }}</small>
                    </td>
                    <td>
                        <span
                            :class="getTypeClass(transaction.type)"
                            class="badge"
                        >
                          {{ getTypeText(transaction.type) }}
                        </span>
                    </td>
                    <td>
                      <div>{{ transaction.description }}</div>
                      <small class="text-muted" v-if="transaction.orderCode">
                        Đơn hàng: {{ transaction.orderCode }}
                      </small>
                    </td>
                    <td>
                      <strong
                          :class="{
                            'text-success': transaction.amount > 0,
                            'text-danger': transaction.amount < 0
                          }"
                      >
                        {{ transaction.amount > 0 ? '+' : '' }}{{ formatCurrency(transaction.amount) }}
                      </strong>
                    </td>
                    <td>
                        <span
                            :class="getStatusClass(transaction.status)"
                            class="badge"
                        >
                          {{ getStatusText(transaction.status) }}
                        </span>
                    </td>
                    <td>
                      <button
                          class="btn btn-sm btn-outline-primary"
                          @click="viewTransactionDetail(transaction)"
                          data-bs-toggle="modal"
                          data-bs-target="#transactionDetailModal"
                      >
                        <i class="bi bi-eye"></i>
                        Chi tiết
                      </button>
                    </td>
                  </tr>
                  </tbody>
                </table>
              </div>

              <!-- Phân trang -->
              <nav aria-label="Phân trang giao dịch" v-if="totalPages > 1">
                <ul class="pagination justify-content-center">
                  <li class="page-item" :class="{ disabled: currentPage === 1 }">
                    <button class="page-link" @click="currentPage = 1" :disabled="currentPage === 1">
                      Đầu
                    </button>
                  </li>
                  <li class="page-item" :class="{ disabled: currentPage === 1 }">
                    <button class="page-link" @click="currentPage--" :disabled="currentPage === 1">
                      <i class="bi bi-chevron-left"></i>
                    </button>
                  </li>
                  <li
                      class="page-item"
                      v-for="page in visiblePages"
                      :key="page"
                      :class="{ active: page === currentPage }"
                  >
                    <button
                        class="page-link"
                        @click="currentPage = page"
                        v-if="typeof page === 'number'"
                    >
                      {{ page }}
                    </button>
                    <span class="page-link" v-else>{{ page }}</span>
                  </li>
                  <li class="page-item" :class="{ disabled: currentPage === totalPages }">
                    <button class="page-link" @click="currentPage++" :disabled="currentPage === totalPages">
                      <i class="bi bi-chevron-right"></i>
                    </button>
                  </li>
                  <li class="page-item" :class="{ disabled: currentPage === totalPages }">
                    <button class="page-link" @click="currentPage = totalPages" :disabled="currentPage === totalPages">
                      Cuối
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal chi tiết giao dịch -->
    <div class="modal fade" id="transactionDetailModal" tabindex="-1" aria-labelledby="transactionDetailModalLabel"
         aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="transactionDetailModalLabel">
              <i class="bi bi-receipt me-2"></i>
              Chi tiết giao dịch
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>

          <div class="modal-body" v-if="selectedTransaction">
            <div class="row">
              <!-- Thông tin cơ bản -->
              <div class="col-md-6">
                <h6 class="text-primary mb-3">
                  <i class="bi bi-info-circle me-2"></i>
                  Thông tin giao dịch
                </h6>
                <div class="mb-3">
                  <label class="form-label fw-bold">Mã giao dịch:</label>
                  <div>{{ selectedTransaction.code }}</div>
                </div>
                <div class="mb-3">
                  <label class="form-label fw-bold">Ngày tạo:</label>
                  <div>{{ formatDateTime(selectedTransaction.createdAt) }}</div>
                </div>
                <div class="mb-3">
                  <label class="form-label fw-bold">Loại giao dịch:</label>
                  <div>
                    <span
                        :class="getTypeClass(selectedTransaction.type)"
                        class="badge"
                    >
                      {{ getTypeText(selectedTransaction.type) }}
                    </span>
                  </div>
                </div>
                <div class="mb-3">
                  <label class="form-label fw-bold">Trạng thái:</label>
                  <div>
                    <span
                        :class="getStatusClass(selectedTransaction.status)"
                        class="badge"
                    >
                      {{ getStatusText(selectedTransaction.status) }}
                    </span>
                  </div>
                </div>
              </div>

              <!-- Thông tin tài chính -->
              <div class="col-md-6">
                <h6 class="text-success mb-3">
                  <i class="bi bi-cash-coin me-2"></i>
                  Thông tin tài chính
                </h6>
                <div class="mb-3">
                  <label class="form-label fw-bold">Số tiền:</label>
                  <div>
                    <h5
                        :class="{
                        'text-success': selectedTransaction.amount > 0,
                        'text-danger': selectedTransaction.amount < 0
                      }"
                    >
                      {{ selectedTransaction.amount > 0 ? '+' : '' }}{{ formatCurrency(selectedTransaction.amount) }}
                    </h5>
                  </div>
                </div>
                <div class="mb-3" v-if="selectedTransaction.fee">
                  <label class="form-label fw-bold">Phí giao dịch:</label>
                  <div class="text-warning">{{ formatCurrency(selectedTransaction.fee) }}</div>
                </div>
                <div class="mb-3" v-if="selectedTransaction.balanceBefore !== undefined">
                  <label class="form-label fw-bold">Số dư trước:</label>
                  <div>{{ formatCurrency(selectedTransaction.balanceBefore) }}</div>
                </div>
                <div class="mb-3" v-if="selectedTransaction.balanceAfter !== undefined">
                  <label class="form-label fw-bold">Số dư sau:</label>
                  <div>{{ formatCurrency(selectedTransaction.balanceAfter) }}</div>
                </div>
              </div>

              <!-- Thông tin đơn hàng (nếu có) -->
              <div class="col-12" v-if="selectedTransaction.orderInfo">
                <hr>
                <h6 class="text-info mb-3">
                  <i class="bi bi-bag me-2"></i>
                  Thông tin đơn hàng
                </h6>
                <div class="row">
                  <div class="col-md-6">
                    <div class="mb-2">
                      <label class="form-label fw-bold">Mã đơn hàng:</label>
                      <span class="ms-2">{{ selectedTransaction.orderInfo.code }}</span>
                    </div>
                    <div class="mb-2">
                      <label class="form-label fw-bold">Khách hàng:</label>
                      <span class="ms-2">{{ selectedTransaction.orderInfo.customerName }}</span>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="mb-2">
                      <label class="form-label fw-bold">Tổng tiền đơn hàng:</label>
                      <span class="ms-2">{{ formatCurrency(selectedTransaction.orderInfo.total) }}</span>
                    </div>
                    <div class="mb-2">
                      <label class="form-label fw-bold">Hoa hồng ({{
                          selectedTransaction.orderInfo.commissionRate
                        }}%):</label>
                      <span class="ms-2 text-success">{{
                          formatCurrency(selectedTransaction.orderInfo.commission)
                        }}</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Mô tả chi tiết -->
              <div class="col-12">
                <hr>
                <h6 class="text-secondary mb-3">
                  <i class="bi bi-card-text me-2"></i>
                  Mô tả chi tiết
                </h6>
                <div class="p-3 bg-light rounded">
                  {{ selectedTransaction.description }}
                </div>
              </div>

              <!-- Thông tin bổ sung -->
              <div class="col-12" v-if="selectedTransaction.notes">
                <hr>
                <h6 class="text-warning mb-3">
                  <i class="bi bi-sticky me-2"></i>
                  Ghi chú
                </h6>
                <div class="p-3 bg-warning bg-opacity-10 rounded">
                  {{ selectedTransaction.notes }}
                </div>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
              <i class="bi bi-x-circle me-1"></i>
              Đóng
            </button>
            <button type="button" class="btn btn-primary" @click="printTransaction" v-if="selectedTransaction">
              <i class="bi bi-printer me-1"></i>
              In biên lai
            </button>
          </div>
        </div>
      </div>
    </div>
  </SellerLayout>
</template>

<script setup>
import SellerLayout from "@/components/SellerLayout.vue";
import Swal from "sweetalert2";
import {ref, computed, onMounted} from 'vue';

// Reactive data
const currentPage = ref(1);
const itemsPerPage = ref(15);
const selectedTransaction = ref(null);

// Filters
const filters = ref({
  status: '',
  type: '',
  startDate: '',
  endDate: '',
  search: ''
});

// Sample transaction data
const transactions = ref([
  {
    id: 1,
    code: 'TXN001234',
    type: 'order',
    amount: 450000,
    fee: 15000,
    balanceBefore: 2000000,
    balanceAfter: 2435000,
    status: 'completed',
    description: 'Hoa hồng bán hàng từ đơn hàng #ORD001',
    createdAt: '2024-06-19T10:30:00',
    orderCode: 'ORD001',
    orderInfo: {
      code: 'ORD001',
      customerName: 'Nguyễn Văn A',
      total: 1500000,
      commission: 450000,
      commissionRate: 30
    },
    notes: 'Đơn hàng được giao thành công'
  },
  {
    id: 2,
    code: 'TXN001235',
    type: 'withdrawal',
    amount: -500000,
    fee: 5000,
    balanceBefore: 2435000,
    balanceAfter: 1930000,
    status: 'completed',
    description: 'Rút tiền về tài khoản ngân hàng Vietcombank ***1234',
    createdAt: '2024-06-18T14:15:00',
    notes: 'Giao dịch thành công trong 2 giờ'
  },
  {
    id: 3,
    code: 'TXN001236',
    type: 'commission',
    amount: 300000,
    balanceBefore: 1930000,
    balanceAfter: 2230000,
    status: 'completed',
    description: 'Hoa hồng khuyến mãi tháng 6',
    createdAt: '2024-06-17T09:00:00'
  },
  {
    id: 4,
    code: 'TXN001237',
    type: 'refund',
    amount: -120000,
    balanceBefore: 2230000,
    balanceAfter: 2110000,
    status: 'completed',
    description: 'Hoàn tiền đơn hàng bị hủy #ORD002',
    createdAt: '2024-06-16T16:45:00',
    orderCode: 'ORD002'
  },
  {
    id: 5,
    code: 'TXN001238',
    type: 'withdrawal',
    amount: -1000000,
    fee: 10000,
    balanceBefore: 2110000,
    balanceAfter: 2110000,
    status: 'pending',
    description: 'Rút tiền về tài khoản ngân hàng ACB ***5678',
    createdAt: '2024-06-15T11:20:00',
    notes: 'Đang xử lý, dự kiến hoàn thành trong 24h'
  },
  {
    id: 6,
    code: 'TXN001239',
    type: 'order',
    amount: 0,
    status: 'failed',
    description: 'Giao dịch thất bại - Lỗi hệ thống thanh toán',
    createdAt: '2024-06-14T13:30:00',
    notes: 'Vui lòng liên hệ support để được hỗ trợ'
  }
]);

// Computed properties
const filteredTransactions = computed(() => {
  let filtered = transactions.value;

  if (filters.value.status) {
    filtered = filtered.filter(t => t.status === filters.value.status);
  }

  if (filters.value.type) {
    filtered = filtered.filter(t => t.type === filters.value.type);
  }

  if (filters.value.startDate) {
    filtered = filtered.filter(t =>
        new Date(t.createdAt) >= new Date(filters.value.startDate)
    );
  }

  if (filters.value.endDate) {
    filtered = filtered.filter(t =>
        new Date(t.createdAt) <= new Date(filters.value.endDate + 'T23:59:59')
    );
  }

  if (filters.value.search) {
    const search = filters.value.search.toLowerCase();
    filtered = filtered.filter(t =>
        t.code.toLowerCase().includes(search) ||
        t.description.toLowerCase().includes(search) ||
        (t.orderCode && t.orderCode.toLowerCase().includes(search))
    );
  }

  return filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
});

const totalPages = computed(() => {
  return Math.ceil(filteredTransactions.value.length / itemsPerPage.value);
});

const paginatedTransactions = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage.value;
  const end = start + itemsPerPage.value;
  return filteredTransactions.value.slice(start, end);
});

const visiblePages = computed(() => {
  const pages = [];
  const total = totalPages.value;
  const current = currentPage.value;

  if (total <= 7) {
    for (let i = 1; i <= total; i++) {
      pages.push(i);
    }
  } else {
    if (current <= 4) {
      for (let i = 1; i <= 5; i++) {
        pages.push(i);
      }
      pages.push('...');
      pages.push(total);
    } else if (current >= total - 3) {
      pages.push(1);
      pages.push('...');
      for (let i = total - 4; i <= total; i++) {
        pages.push(i);
      }
    } else {
      pages.push(1);
      pages.push('...');
      for (let i = current - 1; i <= current + 1; i++) {
        pages.push(i);
      }
      pages.push('...');
      pages.push(total);
    }
  }

  return pages;
});

// Statistics
const totalIncome = computed(() => {
  return transactions.value
      .filter(t => t.status === 'completed' && t.amount > 0)
      .reduce((sum, t) => sum + t.amount, 0);
});

const monthlyIncome = computed(() => {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  return transactions.value
      .filter(t => {
        const date = new Date(t.createdAt);
        return t.status === 'completed' &&
            t.amount > 0 &&
            date.getMonth() === currentMonth &&
            date.getFullYear() === currentYear;
      })
      .reduce((sum, t) => sum + t.amount, 0);
});

const totalTransactions = computed(() => {
  return transactions.value.length;
});

const pendingTransactions = computed(() => {
  return transactions.value.filter(t => t.status === 'pending').length;
});

// Methods
const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND'
  }).format(Math.abs(amount));
};

const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('vi-VN');
};

const formatTime = (dateString) => {
  return new Date(dateString).toLocaleTimeString('vi-VN', {
    hour: '2-digit',
    minute: '2-digit'
  });
};

const formatDateTime = (dateString) => {
  return new Date(dateString).toLocaleString('vi-VN');
};

const getStatusClass = (status) => {
  const classes = {
    'completed': 'bg-success',
    'pending': 'bg-warning',
    'failed': 'bg-danger',
    'refunded': 'bg-info'
  };
  return classes[status] || 'bg-secondary';
};

const getStatusText = (status) => {
  const texts = {
    'completed': 'Hoàn thành',
    'pending': 'Đang xử lý',
    'failed': 'Thất bại',
    'refunded': 'Đã hoàn tiền'
  };
  return texts[status] || 'Không xác định';
};

const getTypeClass = (type) => {
  const classes = {
    'order': 'bg-primary',
    'withdrawal': 'bg-warning',
    'commission': 'bg-success',
    'refund': 'bg-danger'
  };
  return classes[type] || 'bg-secondary';
};

const getTypeText = (type) => {
  const texts = {
    'order': 'Bán hàng',
    'withdrawal': 'Rút tiền',
    'commission': 'Hoa hồng',
    'refund': 'Hoàn tiền'
  };
  return texts[type] || 'Khác';
};

const resetFilters = () => {
  filters.value = {
    status: '',
    type: '',
    startDate: '',
    endDate: '',
    search: ''
  };
  currentPage.value = 1;
};

const viewTransactionDetail = (transaction) => {
  selectedTransaction.value = transaction;
};

const refreshTransactions = async () => {
  Swal.fire({
    title: 'Đang làm mới...',
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    }
  });

  // Simulate API call
  setTimeout(() => {
    Swal.fire({
      title: 'Thành công!',
      text: 'Đã cập nhật dữ liệu mới nhất.',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false
    });
  }, 1000);
};

const exportTransactions = async () => {
  Swal.fire({
    title: 'Đang xuất file...',
    text: 'Vui lòng đợi trong giây lát.',
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    }
  });

  // Simulate export
  setTimeout(() => {
    Swal.fire({
      title: 'Xuất thành công!',
      text: 'File Excel đã được tải xuống.',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false
    });
  }, 2000);
};

const printTransaction = () => {
  window.print();
};

onMounted(() => {
  console.log('Transaction history component mounted');
});
</script>

<style scoped>
.card {
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  border: 1px solid rgba(0, 0, 0, 0.125);
}

.table-hover tbody tr:hover {
  background-color: rgba(0, 0, 0, 0.075);
}

.badge {
  font-size: 0.75em;
}

.pagination .page-link.active {
  background-color: #007bff;
  border-color: #007bff;
  color: white;
}

.modal-lg {
  max-width: 900px;
}

@media print {
  .modal-header,
  .modal-footer {
    display: none;
  }

  .modal-body {
    padding: 0;
  }
}
</style>
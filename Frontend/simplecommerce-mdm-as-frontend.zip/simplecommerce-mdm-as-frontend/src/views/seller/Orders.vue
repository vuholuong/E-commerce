<template>
  <SellerLayout>
    <!-- <div class="d-flex justify-content-between align-items-center mb-4">
      <h4>Quản lý đơn hàng</h4>
      <button class="btn btn-outline-primary" @click="exportReport" :disabled="loading">
        <i class="bi bi-download"></i> Xuất báo cáo
      </button>
    </div> -->

    <!-- Order Stats -->
    <div class="row mb-4">
      <div class="col-md-3">
        <div class="card bg-primary text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.total }}</h3>
            <small>Tổng đơn hàng</small>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card bg-warning text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.pending }}</h3>
            <small>Chờ xử lý</small>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card bg-info text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.shipping }}</h3>
            <small>Đang giao</small>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card bg-success text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.completed }}</h3>
            <small>Hoàn thành</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-danger text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.cancelled }}</h3>
            <small>Đã hủy</small>
          </div>
        </div>
      </div>
      <!-- <div class="col-md-2">
        <div class="card bg-secondary text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.returned }}</h3>
            <small>Trả hàng</small>
          </div>
        </div>
      </div> -->
    </div>

    <!-- Orders Table -->
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
          <h5>Danh sách đơn hàng</h5>
          <div class="d-flex gap-2">
            <input type="text" class="form-control" placeholder="Tìm mã đơn..." style="width: 200px;"
              v-model="searchQuery" @input="debounceSearch">
            <select class="form-select" style="width: 150px;" v-model="selectedStatus" @change="filterByStatus">
              <option value="">Tất cả trạng thái</option>
              <option v-for="(label, status) in ORDER_STATUS_LABELS" :key="status" :value="status">
                {{ label }}
              </option>
            </select>
          </div>
        </div>
      </div>
      <div class="card-body">
        <!-- Loading -->
        <div v-if="loading" class="text-center py-4">
          <div class="spinner-border" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>

        <!-- Error -->
        <div v-else-if="error" class="alert alert-danger">
          <i class="bi bi-exclamation-triangle"></i> {{ error }}
        </div>

        <!-- Orders Table -->
        <div v-else class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Khách hàng</th>
                <th>Sản phẩm</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Ngày đặt</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="order in orders" :key="order.id">
                <td><strong>#{{ order.orderNumber }}</strong></td>
                <td>
                  <div>
                    <strong>{{ order.customerEmail }}</strong><br>
                    Địa chỉ: <small class="text-muted">{{ order.shippingAddress }}</small>
                  </div>
                </td>
                <td>
                  <div>
                    {{ order.totalItems }} sản phẩm<br>
                    <small class="text-muted">SL: {{ order.totalQuantity }}</small>
                  </div>
                </td>
                <td>{{ formatCurrency(order.totalAmount) }}</td>
                <td>
                  <span :class="`badge bg-${getStatusColor(order.orderStatus)}`">
                    {{ getStatusLabel(order.orderStatus) }}
                  </span>
                </td>
                <td>{{ formatDate(order.orderedAt) }}</td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary" @click="viewOrderDetail(order)">
                      <i class="bi bi-eye"></i> Chi tiết
                    </button>
                    <button class="btn btn-outline-secondary" @click="printOrder(order)">
                      <i class="bi bi-printer"></i> In
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          <!-- Empty state -->
          <div v-if="!loading && orders.length === 0" class="text-center py-4">
            <i class="bi bi-inbox display-1 text-muted"></i>
            <p class="text-muted mt-2">Không có đơn hàng nào</p>
          </div>
        </div>

        <!-- Pagination -->
        <nav class="mt-4" v-if="pagination.totalPages > 1">
          <ul class="pagination justify-content-center">
            <li class="page-item" :class="{ disabled: pagination.first }">
              <a class="page-link" href="#" @click.prevent="changePage(pagination.number - 1)">Trước</a>
            </li>

            <li v-for="page in getVisiblePages()" :key="page" class="page-item"
              :class="{ active: page === pagination.number }">
              <a class="page-link" href="#" @click.prevent="changePage(page)">{{ page + 1 }}</a>
            </li>

            <li class="page-item" :class="{ disabled: pagination.last }">
              <a class="page-link" href="#" @click.prevent="changePage(pagination.number + 1)">Sau</a>
            </li>
          </ul>
        </nav>
      </div>
    </div>

    <!-- Order Detail Modal -->
    <div class="modal fade" :class="{ show: showDetailModal, 'd-block': showDetailModal }" tabindex="-1"
      v-if="showDetailModal">
      <div class="modal-dialog modal-lg">
        <div class="modal-content" v-if="selectedOrder">
          <div class="modal-header">
            <h5 class="modal-title">Chi tiết đơn hàng #{{ selectedOrder.orderNumber }}</h5>
            <button type="button" class="btn-close" @click="showDetailModal = false"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-md-6">
                <h6>Thông tin đơn hàng</h6>
                <!-- <p><strong>Mã đơn:</strong> {{ selectedOrder.orderNumber }}</p>
                <p><strong>Mã nhóm đơn:</strong> {{ selectedOrder.orderGroupNumber }}</p> -->
                <p><strong>Shop:</strong> {{ selectedOrder.shopName }}</p>
                <p><strong>Ngày đặt:</strong> {{ formatDate(selectedOrder.orderedAt) }}</p>
                <p><strong>Trạng thái:</strong>
                  <span :class="`badge bg-${getStatusColor(selectedOrder.orderStatus)}`">
                    {{ getStatusLabel(selectedOrder.orderStatus) }}
                  </span>
                </p>
              </div>
              <div class="col-md-6">
                <h6>Thông tin vận chuyển</h6>
                <p><strong>Phương thức vận chuyển:</strong> {{ selectedOrder.shippingMethodNameSnapshot || 'Không có' }}</p>
                <p><strong>Địa chỉ nhận hàng:</strong> {{ selectedOrder.shippingAddress || 'Không có' }}</p>
                <p><strong>Ghi chú cho người bán:</strong> {{ selectedOrder.notesToSeller || 'Không có' }}</p>
              </div>
            </div>

            <hr>

            <h6>Danh sách sản phẩm</h6>
            <div class="table-responsive">
              <table class="table table-sm">
                <thead>
                  <tr>
                    <th>Sản phẩm</th>
                    <th>SKU</th>
                    <th>Biến thể</th>
                    <th>Số lượng</th>
                    <th>Đơn giá</th>
                    <th>Thành tiền</th>
                    <!-- <th>Trạng thái</th> -->
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="item in selectedOrder.orderItems" :key="item.id">
                    <td>
                      <div class="d-flex align-items-center">
                        <img :src="item.variantImageUrl" :alt="item.productNameSnapshot" class="img-thumbnail me-2"
                          style="width: 50px; height: 50px; object-fit: cover;">
                        <div>
                          <strong>{{ item.productNameSnapshot }}</strong>
                        </div>
                      </div>
                    </td>
                    <td>{{ item.variantSkuSnapshot }}</td>
                    <td>{{ item.variantOptionsSnapshot }}</td>
                    <td>{{ item.quantity }}</td>
                    <td>{{ formatCurrency(item.unitPrice) }}</td>
                    <td>{{ formatCurrency(item.subtotal) }}</td>
                    <!-- <td>
                      <span :class="`badge bg-${getItemStatusColor(item.status)}`">
                        {{ getItemStatusLabel(item.status) }}
                      </span>
                    </td> -->
                  </tr>
                </tbody>
              </table>
            </div>

            <hr>

            <h6>Thông tin thanh toán</h6>
            <div class="row">
              <div class="col-md-6">
                <p><strong>Tổng sản phẩm:</strong> {{ selectedOrder.totalItems }}</p>
                <p><strong>Tổng số lượng:</strong> {{ selectedOrder.totalQuantity }}</p>
                <p><strong>Tiền hàng:</strong> {{ formatCurrency(selectedOrder.subtotalAmount) }}</p>
                <!-- <p><strong>Giảm giá sản phẩm:</strong> -{{ formatCurrency(selectedOrder.itemDiscountAmount) }}</p> -->
              </div>
              <div class="col-md-6">
                <p><strong>Phí vận chuyển:</strong> {{ formatCurrency(selectedOrder.shippingFee) }}</p>
                <p><strong>Giảm giá vận chuyển:</strong> -{{ formatCurrency(selectedOrder.shippingDiscountAmount) }}</p>
                <p><strong>Thuế:</strong> {{ formatCurrency(selectedOrder.taxAmount) }}</p>
                <p><strong>Tổng cộng:</strong>
                  <span class="fw-bold text-primary">{{ formatCurrency(selectedOrder.totalAmount) }}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="showDetailModal = false">Đóng</button>
            <div class="dropdown" v-if="hasAvailableTransitions(selectedOrder.orderStatus)">
              <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                Cập nhật trạng thái
              </button>
              <ul class="dropdown-menu">
                <li v-for="(label, status) in getAvailableStatusTransitions(selectedOrder.orderStatus)" :key="status">
                  <a class="dropdown-item" href="#" @click.prevent="updateStatus(selectedOrder, status)">
                    {{ label }}
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop fade show" v-if="showDetailModal"></div>

    <!-- Status Update Modal -->
    <div class="modal fade" :class="{ show: showStatusModal, 'd-block': showStatusModal }" tabindex="-1"
      v-if="showStatusModal">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Cập nhật trạng thái đơn hàng</h5>
            <button type="button" class="btn-close" @click="showStatusModal = false"></button>
          </div>
          <div class="modal-body">
            <p>Đơn hàng: <strong>#{{ statusUpdateData.orderNumber }}</strong></p>
            <p>Trạng thái hiện tại:
              <span :class="`badge bg-${getStatusColor(statusUpdateData.currentStatus)}`">
                {{ getStatusLabel(statusUpdateData.currentStatus) }}
              </span>
            </p>
            <p>Trạng thái mới:
              <span :class="`badge bg-${getStatusColor(statusUpdateData.newStatus)}`">
                {{ getStatusLabel(statusUpdateData.newStatus) }}
              </span>
            </p>

            <div class="mb-3">
              <label for="internalNotes" class="form-label">Ghi chú nội bộ (tùy chọn)</label>
              <textarea id="internalNotes" class="form-control" rows="3" v-model="statusUpdateData.internalNotes"
                placeholder="Nhập ghi chú về việc cập nhật trạng thái...">
              </textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="showStatusModal = false">Hủy</button>
            <button type="button" class="btn btn-primary" @click="confirmStatusUpdate" :disabled="updating">
              <span v-if="updating" class="spinner-border spinner-border-sm me-2"></span>
              Cập nhật
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop fade show" v-if="showStatusModal"></div>
  </SellerLayout>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import SellerLayout from '@/components/SellerLayout.vue'
import { orderService, ORDER_STATUS, ORDER_STATUS_LABELS, ORDER_STATUS_COLORS } from '@/services/seller/order'
import Swal from 'sweetalert2'

// Thêm constants cho item status
const ITEM_STATUS_LABELS = {
  'PENDING': 'Chờ xử lý',
  'PROCESSING': 'Đang xử lý',
  'SHIPPED': 'Đã gửi hàng',
  'DELIVERED': 'Đã giao hàng',
  'CANCELLED': 'Đã hủy',
  'RETURNED': 'Đã trả hàng'
};

const ITEM_STATUS_COLORS = {
  'PENDING': 'warning',
  'PROCESSING': 'info',
  'SHIPPED': 'primary',
  'DELIVERED': 'success',
  'CANCELLED': 'danger',
  'RETURNED': 'secondary'
};

// Reactive data
const loading = ref(false)
const updating = ref(false)
const error = ref('')
const orders = ref([])
const selectedOrder = ref(null)
const showDetailModal = ref(false)
const showStatusModal = ref(false)
const searchQuery = ref('')
const selectedStatus = ref('')

// Pagination
const pagination = ref({
  totalPages: 0,
  totalElements: 0,
  first: true,
  last: true,
  size: 5,
  number: 0,
  numberOfElements: 0
})

// Status update data
const statusUpdateData = ref({
  orderId: null,
  orderNumber: '',
  currentStatus: '',
  newStatus: '',
  internalNotes: ''
})

// Computed
const orderStats = computed(() => {
  const stats = {
    total: pagination.value.totalElements,
    pending: 0,
    shipping: 0,
    completed: 0,
    cancelled: 0,
    returned: 0
  }

  orders.value.forEach(order => {
    switch (order.orderStatus) {
      case ORDER_STATUS.PENDING_PAYMENT:
      case ORDER_STATUS.AWAITING_CONFIRMATION:
        stats.pending++
        break
      case ORDER_STATUS.PROCESSING:
      case ORDER_STATUS.SHIPPED:
        stats.shipping++
        break
      case ORDER_STATUS.DELIVERED:
      case ORDER_STATUS.COMPLETED:
        stats.completed++
        break
      case ORDER_STATUS.CANCELLED_BY_USER:
      case ORDER_STATUS.CANCELLED_BY_SELLER:
      case ORDER_STATUS.CANCELLED_BY_ADMIN:
      case ORDER_STATUS.FAILED:
        stats.cancelled++
        break
      case ORDER_STATUS.RETURN_REQUESTED:
      case ORDER_STATUS.RETURN_APPROVED:
      case ORDER_STATUS.RETURNED:
        stats.returned++
        break
    }
  })

  return stats
})

// Methods
const loadOrders = async (page = 0) => {
  try {
    loading.value = true
    error.value = ''

    const params = {
      page,
      size: pagination.value.size
    }

    if (selectedStatus.value) {
      params.status = selectedStatus.value
    }

    const response = await orderService.getSellerOrders(params)

    // Cập nhật để phù hợp với response mới
    if (response.statusCode === 200) {
      orders.value = response.data.content || response.data.items || [];
      pagination.value = {
        totalPages: response.data.totalPages || 0,
        totalElements: response.data.totalElements || 0,
        first: response.data.first || true,
        last: response.data.last || true,
        size: response.data.size || params.size,
        number: response.data.number || page,
        numberOfElements: response.data.numberOfElements || 0
      }
    } else {
      // Xử lý response không thành công
      error.value = response.message || 'Có lỗi xảy ra khi tải dữ liệu';
    }
  } catch (err) {
    error.value = err.message || 'Có lỗi xảy ra khi tải dữ liệu'
    console.error('Error loading orders:', err)
  } finally {
    loading.value = false
  }
}

const changePage = (page) => {
  if (page >= 0 && page < pagination.value.totalPages) {
    loadOrders(page)
  }
}

const getVisiblePages = () => {
  const current = pagination.value.number
  const total = pagination.value.totalPages
  const delta = 2

  let start = Math.max(0, current - delta)
  let end = Math.min(total - 1, current + delta)

  if (end - start < 4) {
    if (start === 0) {
      end = Math.min(total - 1, start + 4)
    } else if (end === total - 1) {
      start = Math.max(0, end - 4)
    }
  }

  const pages = []
  for (let i = start; i <= end; i++) {
    pages.push(i)
  }
  return pages
}

const filterByStatus = () => {
  loadOrders(0)
}

let searchTimeout = null
const debounceSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    // Implement search logic here if needed
    console.log('Searching for:', searchQuery.value)
  }, 500)
}

const viewOrderDetail = async (order) => {
  try {
    loading.value = true;
    // Gọi API để lấy chi tiết đầy đủ
    const orderDetail = await orderService.getOrderDetail(order.id);
    selectedOrder.value = orderDetail;
    showDetailModal.value = true;
  } catch (err) {
    console.error('Error loading order detail:', err);
    Swal.fire({
      title: 'Lỗi!',
      text: 'Không thể tải chi tiết đơn hàng',
      icon: 'error',
      timer: 2000,
      showConfirmButton: false
    });
  } finally {
    loading.value = false;
  }
}

const updateStatus = (order, newStatus) => {
  statusUpdateData.value = {
    orderId: order.id,
    orderNumber: order.orderNumber,
    currentStatus: order.orderStatus,
    newStatus,
    internalNotes: ''
  }
  showDetailModal.value = false
  showStatusModal.value = true
}

const getAvailableStatusTransitions = (currentStatus) => {
  const SELLER_ALLOWED_TRANSITIONS = {
    [ORDER_STATUS.AWAITING_CONFIRMATION]: {
      [ORDER_STATUS.PROCESSING]: 'Xác nhận đơn hàng',
      [ORDER_STATUS.CANCELLED_BY_SELLER]: 'Hủy đơn'
    },
    [ORDER_STATUS.PROCESSING]: {
      [ORDER_STATUS.SHIPPED]: 'Đã giao cho shipper',
      [ORDER_STATUS.CANCELLED_BY_SELLER]: 'Hủy đơn',
      // [ORDER_STATUS.FAILED]: 'Đánh dấu thất bại'
    },
    [ORDER_STATUS.SHIPPED]: {
      [ORDER_STATUS.DELIVERED]: 'Xác nhận đã giao',
      // [ORDER_STATUS.FAILED]: 'Giao hàng thất bại'
    },
    [ORDER_STATUS.DELIVERED]: {
      [ORDER_STATUS.COMPLETED]: 'Hoàn thành đơn hàng',
      // [ORDER_STATUS.RETURN_REQUESTED]: 'Tiếp nhận yêu cầu trả hàng'
    },
    // [ORDER_STATUS.RETURN_REQUESTED]: {
    //   [ORDER_STATUS.RETURN_APPROVED]: 'Chấp nhận trả hàng',
    //   [ORDER_STATUS.COMPLETED]: 'Từ chối yêu cầu trả hàng'
    // },
    // [ORDER_STATUS.RETURN_APPROVED]: {
    //   [ORDER_STATUS.RETURNED]: 'Xác nhận đã nhận hàng trả'
    // }
  };

  return SELLER_ALLOWED_TRANSITIONS[currentStatus] || {};
};

// Thêm hàm kiểm tra có transition khả dụng không
const hasAvailableTransitions = (currentStatus) => {
  const transitions = getAvailableStatusTransitions(currentStatus);
  return Object.keys(transitions).length > 0;
};

const confirmStatusUpdate = async () => {
  try {
    updating.value = true;

    const allowedTransitions = getAvailableStatusTransitions(statusUpdateData.value.currentStatus);
    if (!allowedTransitions[statusUpdateData.value.newStatus]) {
      throw new Error(`Không thể chuyển từ ${statusUpdateData.value.currentStatus} sang ${statusUpdateData.value.newStatus}`);
    }

    const response = await orderService.updateOrderStatus(
      statusUpdateData.value.orderId,
      {
        orderStatus: statusUpdateData.value.newStatus,
        internalNotes: statusUpdateData.value.internalNotes || ''
      }
    );

    // Cập nhật để phù hợp với response mới
    if (response.statusCode === 200) {
      await loadOrders(pagination.value.number); // Refresh data ở trang hiện tại
      showStatusModal.value = false;
      Swal.fire('Thành công!', 'Cập nhật trạng thái thành công', 'success');
    } else {
      throw new Error(response.message || 'Có lỗi xảy ra khi cập nhật');
    }
  } catch (err) {
    const errorMsg = err.response?.data?.message || err.message;
    Swal.fire('Lỗi!', errorMsg, 'error');
  } finally {
    updating.value = false;
  }
};

const exportReport = async () => {
  try {
    loading.value = true

    const blob = await orderService.exportOrderReport({
      status: selectedStatus.value
    })

    // Tạo link download
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `order_report_${new Date().toISOString().split('T')[0]}.xlsx`)
    document.body.appendChild(link)
    link.click()
    link.remove()
    window.URL.revokeObjectURL(url)

    Swal.fire({
      title: 'Thành công!',
      text: 'Báo cáo đã được xuất',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false
    })
  } catch (err) {
    Swal.fire({
      title: 'Lỗi!',
      text: 'Không thể xuất báo cáo',
      icon: 'error'
    })
  } finally {
    loading.value = false
  }
}

// Thêm hàm helper mới cho trạng thái item
const getItemStatusLabel = (status) => {
  return ITEM_STATUS_LABELS[status] || status;
};

const getItemStatusColor = (status) => {
  return ITEM_STATUS_COLORS[status] || 'secondary';
};

// Helper functions
const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND'
  }).format(amount)
}

const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('vi-VN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const getStatusLabel = (status) => {
  return ORDER_STATUS_LABELS[status] || status
}

const getStatusColor = (status) => {
  return ORDER_STATUS_COLORS[status] || 'secondary'
}

const printOrder = (order) => {
  try {
    // Tạo nội dung in đơn hàng
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Đơn hàng #${order.orderNumber}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px; }
          .order-info { margin-bottom: 20px; }
          .customer-info { margin-bottom: 20px; }
          .products-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          .products-table th, .products-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          .products-table th { background-color: #f2f2f2; }
          .total-section { text-align: right; font-weight: bold; }
          .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; }
          @media print { body { margin: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>ĐƠN HÀNG #${order.orderNumber}</h1>
          <p>Ngày đặt: ${formatDate(order.orderedAt)}</p>
        </div>
        
        <div class="order-info">
          <h3>Thông tin đơn hàng</h3>
          <p><strong>Shop:</strong> ${order.shopName || 'N/A'}</p>
          <p><strong>Trạng thái:</strong> ${getStatusLabel(order.orderStatus)}</p>
        </div>
        
        <div class="customer-info">
          <h3>Thông tin khách hàng</h3>
          <p><strong>Email:</strong> ${order.customerEmail || 'N/A'}</p>
          <p><strong>Địa chỉ:</strong> ${order.shippingAddress || 'N/A'}</p>
          <p><strong>Ghi chú:</strong> ${order.notesToSeller || 'Không có'}</p>
        </div>
        
        <h3>Danh sách sản phẩm</h3>
        <table class="products-table">
          <thead>
            <tr>
              <th>Sản phẩm</th>
              <th>SKU</th>
              <th>Biến thể</th>
              <th>Số lượng</th>
              <th>Đơn giá</th>
              <th>Thành tiền</th>
            </tr>
          </thead>
          <tbody>
            ${(order.orderItems || []).map(item => `
              <tr>
                <td>${item.productNameSnapshot || 'N/A'}</td>
                <td>${item.variantSkuSnapshot || 'N/A'}</td>
                <td>${item.variantOptionsSnapshot || 'N/A'}</td>
                <td>${item.quantity || 0}</td>
                <td>${formatCurrency(item.unitPrice || 0)}</td>
                <td>${formatCurrency(item.subtotal || 0)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div class="total-section">
          <p><strong>Tổng sản phẩm:</strong> ${order.totalItems || 0}</p>
          <p><strong>Tổng số lượng:</strong> ${order.totalQuantity || 0}</p>
          <p><strong>Tiền hàng:</strong> ${formatCurrency(order.subtotalAmount || 0)}</p>
          <p><strong>Phí vận chuyển:</strong> ${formatCurrency(order.shippingFee || 0)}</p>
          <p><strong>Giảm giá vận chuyển:</strong> -${formatCurrency(order.shippingDiscountAmount || 0)}</p>
          <p><strong>Thuế:</strong> ${formatCurrency(order.taxAmount || 0)}</p>
          <p><strong>Tổng cộng:</strong> ${formatCurrency(order.totalAmount || 0)}</p>
        </div>
        
        <div class="footer">
          <p>Đơn hàng được in từ hệ thống quản lý đơn hàng</p>
          <p>Thời gian in: ${new Date().toLocaleString('vi-VN')}</p>
        </div>
      </body>
      </html>
    `;
    
    // Mở cửa sổ in mới
    const printWindow = window.open('', '_blank');
    printWindow.document.write(printContent);
    printWindow.document.close();
    
    // Đợi nội dung load xong rồi in
    printWindow.onload = () => {
      printWindow.print();
      printWindow.close();
    };
    
  } catch (error) {
    console.error('Error printing order:', error);
    Swal.fire({
      title: 'Lỗi!',
      text: 'Không thể in đơn hàng',
      icon: 'error',
      timer: 2000,
      showConfirmButton: false
    });
  }
}

// Lifecycle
onMounted(() => {
  loadOrders()
})
</script>

<style scoped>
.modal {
  background-color: rgba(0, 0, 0, 0.5);
}

.card {
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  border: 1px solid rgba(0, 0, 0, 0.125);
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid rgba(0, 0, 0, 0.125);
}

.table th {
  background-color: #f8f9fa;
  font-weight: 600;
  border-top: none;
}

.btn-group-sm .btn {
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
}

.badge {
  font-size: 0.75em;
}

.pagination .page-link {
  color: #0d6efd;
}

.pagination .page-item.active .page-link {
  background-color: #0d6efd;
  border-color: #0d6efd;
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

.text-primary {
  color: #0d6efd !important;
}

.dropdown-menu {
  border: 1px solid rgba(0, 0, 0, 0.15);
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.dropdown-item:hover {
  background-color: #f8f9fa;
}

/* Thêm style cho hình ảnh sản phẩm */
.img-thumbnail {
  border-radius: 4px;
  border: 1px solid #dee2e6;
}

@media (max-width: 768px) {
  .d-flex.gap-2 {
    flex-direction: column;
    gap: 0.5rem !important;
  }

  .d-flex.gap-2 input,
  .d-flex.gap-2 select {
    width: 100% !important;
  }
}
</style>
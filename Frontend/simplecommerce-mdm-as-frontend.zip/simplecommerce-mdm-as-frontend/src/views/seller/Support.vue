<template>
  <SellerLayout>
    <!-- Review Stats -->
<div class="row mb-4">
  <div class="col-md-4">
    <div class="card bg-primary text-white">
      <div class="card-body text-center">
        <template v-if="statsLoading">
          <div class="spinner-border spinner-border-sm" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </template>
        <template v-else>
          <h3>{{ reviewStats.totalReviews || 0 }}</h3>
          <small>Tổng đánh giá</small>
        </template>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card bg-success text-white">
      <div class="card-body text-center">
        <template v-if="statsLoading">
          <div class="spinner-border spinner-border-sm" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </template>
        <template v-else>
          <h3>{{ (reviewStats.averageRating || 0).toFixed(1) }}/5</h3>
          <small>Đánh giá trung bình</small>
        </template>
      </div>
    </div>
  </div>
  <!-- <div class="col-md-3">
    <div class="card bg-warning text-white">
      <div class="card-body text-center">
        <h3>{{ pendingReviewsCount }}</h3>
        <small>Chờ phản hồi</small>
      </div>
    </div>
  </div> -->
  <div class="col-md-4">
    <div class="card bg-info text-white">
      <div class="card-body text-center">
        <h3>{{ verifiedReviewsCount }}</h3>
        <small>Đã xác thực mua hàng</small>
      </div>
    </div>
  </div>
</div>
    <!-- Reviews List -->
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
          <h5>Quản lý đánh giá sản phẩm</h5>
          <div class="d-flex gap-2">
            <select class="form-select" style="width: 150px;" v-model="filterStatus" @change="loadReviews">
              <option value="">Tất cả</option>
              <option value="approved">Đã duyệt</option>
              <option value="pending">Chờ duyệt</option>
              <option value="reported">Bị báo cáo</option>
            </select>
            <select class="form-select" style="width: 120px;" v-model="sortBy" @change="loadReviews">
              <option value="createdAt">Ngày tạo</option>
              <option value="rating">Đánh giá</option>
            </select>
            <select class="form-select" style="width: 100px;" v-model="sortDir" @change="loadReviews">
              <option value="desc">Giảm dần</option>
              <option value="asc">Tăng dần</option>
            </select>
          </div>
        </div>
      </div>
      
      <div class="card-body">
        <!-- Loading -->
        <div v-if="loading" class="text-center py-4">
          <div class="spinner-border" role="status">
            <span class="visually-hidden">Đang tải...</span>
          </div>
        </div>

        <!-- Reviews List -->
        <div v-else-if="reviews.length > 0">
          <div v-for="review in reviews" :key="review.id" class="border rounded p-3 mb-3">
            <div class="row">
              <div class="col-md-8">
                <div class="d-flex justify-content-between align-items-start mb-2">
                  <div>
                    <h6 class="mb-1">{{ review.userName }}</h6>
                    <small class="text-muted">{{ review.userEmail }}</small>
                  </div>
                  <div class="text-end">
                    <div class="text-warning mb-1">
                      <span v-for="(filled, index) in getStarsArray(review.rating)" :key="index" 
                            :class="filled ? 'bi bi-star-fill' : 'bi bi-star'"></span>
                    </div>
                    <small class="text-muted">{{ formatDate(review.createdAt) }}</small>
                  </div>
                </div>

                <div class="mb-2">
                  <strong>Sản phẩm:</strong> 
                  <span class="text-primary">{{ review.productName }}</span>
                </div>

                <p class="mb-2">{{ review.comment }}</p>

                <div class="d-flex gap-2 mb-2">
                  <span v-if="review.isVerifiedPurchase" class="badge bg-success">
                    <i class="bi bi-check-circle"></i> Đã mua hàng
                  </span>
                  <span v-if="review.isApproved" class="badge bg-primary">Đã duyệt</span>
                  <span v-else class="badge bg-warning">Chờ duyệt</span>
                  <span v-if="review.isReported" class="badge bg-danger">Bị báo cáo</span>
                  <span class="badge bg-info">
                    <i class="bi bi-hand-thumbs-up"></i> {{ review.helpfulCount || 0 }}
                  </span>
                </div>

                <div v-if="review.moderatorNotes" class="alert alert-info">
                  <strong>Ghi chú của moderator:</strong> {{ review.moderatorNotes }}
                </div>
              </div>

              <div class="col-md-4">
                <div class="d-flex flex-column gap-2">
                  <button class="btn btn-outline-primary btn-sm" @click="viewReviewDetail(review)">
                    <i class="bi bi-eye"></i> Xem chi tiết
                  </button>
                  <div class="small text-muted">
                    <div>Đơn hàng: #{{ review.orderId }}</div>
                    <div v-if="review.reportReason">
                      Lý do báo cáo: {{ review.reportReason }}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Pagination -->
          <div class="d-flex justify-content-between align-items-center mt-4">
            <div class="small text-muted">
              Hiển thị {{ ((currentPage) * pageSize) + 1 }} - 
              {{ Math.min((currentPage + 1) * pageSize, totalElements) }} 
              trong tổng số {{ totalElements }} đánh giá
            </div>
            
            <nav>
              <ul class="pagination mb-0">
                <li class="page-item" :class="{ disabled: currentPage === 0 }">
                  <button class="page-link" @click="changePage(currentPage - 1)" :disabled="currentPage === 0">
                    Trước
                  </button>
                </li>
                
                <li v-for="page in visiblePages" :key="page" 
                    class="page-item" :class="{ active: page === currentPage }">
                  <button class="page-link" @click="changePage(page)">{{ page + 1 }}</button>
                </li>
                
                <li class="page-item" :class="{ disabled: currentPage >= totalPages - 1 }">
                  <button class="page-link" @click="changePage(currentPage + 1)" 
                          :disabled="currentPage >= totalPages - 1">
                    Sau
                  </button>
                </li>
              </ul>
            </nav>
          </div>
        </div>

        <!-- Empty State -->
        <div v-else class="text-center py-5">
          <i class="bi bi-star display-1 text-muted"></i>
          <h5 class="mt-3 text-muted">Chưa có đánh giá nào</h5>
          <p class="text-muted">Đánh giá sẽ xuất hiện ở đây khi khách hàng đánh giá sản phẩm của bạn.</p>
        </div>
      </div>
    </div>

    <!-- Review Detail Modal -->
    <div class="modal fade" :class="{ show: showDetailModal, 'd-block': showDetailModal }" 
         tabindex="-1" v-if="showDetailModal">
      <div class="modal-dialog modal-lg">
        <div class="modal-content" v-if="selectedReview">
          <div class="modal-header">
            <h5 class="modal-title">Chi tiết đánh giá</h5>
            <button type="button" class="btn-close" @click="showDetailModal = false"></button>
          </div>
          <div class="modal-body">
            <div class="row mb-3">
              <div class="col-md-6">
                <strong>Khách hàng:</strong><br>
                {{ selectedReview.userName }}<br>
                <small class="text-muted">{{ selectedReview.userEmail }}</small>
              </div>
              <div class="col-md-6 text-end">
                <div class="text-warning mb-1">
                  <span v-for="(filled, index) in getStarsArray(selectedReview.rating)" :key="index" 
                        :class="filled ? 'bi bi-star-fill' : 'bi bi-star'"></span>
                </div>
                <small class="text-muted">{{ formatDate(selectedReview.createdAt) }}</small>
              </div>
            </div>

            <div class="mb-3">
              <strong>Sản phẩm:</strong> {{ selectedReview.productName }}<br>
              <strong>Đơn hàng:</strong> #{{ selectedReview.orderId }}
            </div>

            <div class="mb-3">
              <strong>Nội dung đánh giá:</strong>
              <p class="mt-2 p-3 bg-light rounded">{{ selectedReview.comment }}</p>
            </div>

            <div class="mb-3">
              <div class="d-flex gap-2">
                <span v-if="selectedReview.isVerifiedPurchase" class="badge bg-success">
                  Đã xác thực mua hàng
                </span>
                <span :class="`badge bg-${selectedReview.isApproved ? 'primary' : 'warning'}`">
                  {{ selectedReview.isApproved ? 'Đã duyệt' : 'Chờ duyệt' }}
                </span>
                <span v-if="selectedReview.isReported" class="badge bg-danger">Bị báo cáo</span>
                <span class="badge bg-info">{{ selectedReview.helpfulCount || 0 }} lượt hữu ích</span>
              </div>
            </div>

            <div v-if="selectedReview.reportReason" class="alert alert-warning">
              <strong>Lý do báo cáo:</strong> {{ selectedReview.reportReason }}
            </div>

            <div v-if="selectedReview.moderatorNotes" class="alert alert-info">
              <strong>Ghi chú của moderator:</strong> {{ selectedReview.moderatorNotes }}
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="showDetailModal = false">Đóng</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Backdrop -->
    <div class="modal-backdrop fade show" v-if="showDetailModal"></div>
  </SellerLayout>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick, watch } from 'vue'
import SellerLayout from '../../components/SellerLayout.vue'
import reviewService from '@/services/seller/review'

// Reactive data
const loading = ref(false)
const statsLoading = ref(false)
const reviews = ref([])
const reviewStats = ref({
  totalReviews: 0,
  averageRating: 0
})

// Pagination
const currentPage = ref(0)
const pageSize = ref(20)
const totalElements = ref(0)
const totalPages = ref(0)

// Filters and sorting
const filterStatus = ref('')
const sortBy = ref('createdAt')
const sortDir = ref('desc')

// Modals
const showDetailModal = ref(false)
const selectedReview = ref(null)

// Computed properties
const pendingReviewsCount = computed(() => {
  return reviews.value.filter(review => !review.isApproved).length
})

const verifiedReviewsCount = computed(() => {
  return reviews.value.filter(review => review.isVerifiedPurchase).length
})

const visiblePages = computed(() => {
  const pages = []
  const start = Math.max(0, currentPage.value - 2)
  const end = Math.min(totalPages.value, currentPage.value + 3)
  
  for (let i = start; i < end; i++) {
    pages.push(i)
  }
  return pages
})

// Methods
const loadReviews = async () => {
  try {
    loading.value = true
    const params = {
      page: currentPage.value,
      size: pageSize.value,
      sortBy: sortBy.value,
      sortDir: sortDir.value
    }

    const response = await reviewService.getShopReviews(params)
    
    console.log('Reviews API Response:', response)
    
    if (response.statusCode === 200 && response.data) {
      reviews.value = response.data.reviews || []
      totalElements.value = response.data.totalElements || 0
      totalPages.value = response.data.totalPages || 0
    } else {
      console.error('Unexpected reviews response structure:', response)
    }
  } catch (error) {
    console.error('Error loading reviews:', error)
  } finally {
    loading.value = false
  }
}

const loadStatistics = async () => {
  try {
    statsLoading.value = true
    const response = await reviewService.getShopReviewStatistics()
    
    console.log('Statistics API Response:', response)
    
    // Xử lý cả hai định dạng response
    if (response.statusCode === 200) {
      const data = response.data || response
      reviewStats.value = {
        totalReviews: data.totalReviews || 0,
        averageRating: data.averageRating || 0
      }
    } else if (response.data) {
      // Fallback cho định dạng response cũ
      reviewStats.value = {
        totalReviews: response.data.totalReviews || 0,
        averageRating: response.data.averageRating || 0
      }
    } else {
      useFallbackStatistics()
    }
  } catch (error) {
    console.error('Error loading statistics, using fallback:', error)
    useFallbackStatistics()
  } finally {
    statsLoading.value = false
  }
}

const useFallbackStatistics = () => {
  // Tính toán thống kê từ reviews hiện tại
  if (reviews.value.length > 0) {
    const total = reviews.value.length
    const avgRating = reviews.value.reduce((sum, review) => sum + review.rating, 0) / total
    
    reviewStats.value = {
      totalReviews: total,
      averageRating: avgRating
    }
  } else {
    // Giá trị mặc định nếu không có reviews
    reviewStats.value = {
      totalReviews: 0,
      averageRating: 0
    }
  }
}

const changePage = (page) => {
  if (page >= 0 && page < totalPages.value) {
    currentPage.value = page
    loadReviews()
  }
}

const viewReviewDetail = (review) => {
  selectedReview.value = review
  showDetailModal.value = true
}

const formatDate = (dateString) => {
  return reviewService.formatDate(dateString)
}

const getStarsArray = (rating) => {
  return reviewService.getStarsArray(rating)
}

// Lifecycle
onMounted(() => {
  console.log('Component mounted, loading data...')
  
  // Tải song song cả reviews và statistics
  Promise.all([loadReviews(), loadStatistics()])
    .then(() => {
      console.log('All data loaded successfully')
    })
    .catch(error => {
      console.error('Error loading data:', error)
    })
})

// Watch for changes in reviews to update statistics as fallback
watch(reviews, (newReviews) => {
  if (newReviews.length > 0 && reviewStats.value.totalReviews === 0) {
    console.log('Updating statistics from reviews data')
    useFallbackStatistics()
  }
}, { deep: true })

onUnmounted(() => {
  console.log('Component unmounted, cleaning up...')
})

nextTick(() => {
  console.log('Next tick after component mounted')
})
</script>

<style scoped>
/* Giữ nguyên styles từ component cũ */
.bi {
  font-size: 0.9rem;
}

.pagination .page-link {
  border-radius: 0.25rem;
  margin: 0 0.125rem;
}

.modal {
  background-color: rgba(0, 0, 0, 0.5);
}

.spinner-border {
  width: 3rem;
  height: 3rem;
}

.badge {
  font-size: 0.75em;
}

.alert {
  padding: 0.75rem;
  margin-bottom: 0.5rem;
}

.card-header h5 {
  margin-bottom: 0;
}

.form-select {
  font-size: 0.875rem;
}

/* Thêm style mới để xử lý skeleton loading */
.skeleton-loader {
  background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
  background-size: 200% 100%;
  animation: loading 1.5s infinite;
  border-radius: 4px;
  height: 20px;
  margin-bottom: 8px;
}

@keyframes loading {
  0% {
    background-position: 200% 0;
  }
  100% {
    background-position: -200% 0;
  }
}

/* Đảm bảo statistics card có chiều cao cố định */
.card {
  min-height: 120px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
</style>
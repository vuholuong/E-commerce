<template>
  <SellerLayout>
    <div class="container-fluid py-4">
      <!-- Shop Profile Header Section -->
      <div class="shop-profile-header mb-5">
        <div class="shop-profile-container">
          <!-- Cover Image -->
          <div class="cover-image-section">
            <div class="cover-image-wrapper">
              <img 
                :src="shopInfo.coverImagePreview || shopInfo.coverImageUrl || '/placeholder-cover.jpg'" 
                alt="Shop cover" 
                class="cover-image"
              >
              
              <!-- Cover Image Upload Button -->
              <div class="cover-upload-overlay">
                <label for="coverImage" class="cover-upload-btn">
                  <i class="bi bi-camera"></i>
                  <span>Thay đổi ảnh bìa</span>
                  <input 
                    type="file" 
                    id="coverImage" 
                    @change="handleCoverImageUpload" 
                    accept="image/*" 
                    style="display: none;"
                  >
                </label>
              </div>
            </div>
          </div>
          
          <!-- Shop Info Section -->
          <div class="shop-info-section">
            <!-- Logo -->
            <div class="logo-section">
              <div class="logo-wrapper">
                <img 
                  :src="shopInfo.logoPreview || shopInfo.logoUrl || '/placeholder-logo.jpg'" 
                  alt="Shop logo" 
                  class="shop-logo"
                >
                
                <!-- Logo Upload Button -->
                <label for="shopLogo" class="logo-upload-btn">
                  <i class="bi bi-camera"></i>
                  <input 
                    type="file" 
                    id="shopLogo" 
                    @change="handleLogoUpload" 
                    accept="image/*" 
                    style="display: none;"
                  >
                </label>
              </div>
            </div>
            
            <!-- Shop Basic Info -->
            <div class="shop-basic-info">
              <h1 class="shop-name">{{ shopInfo.name || 'Tên Shop' }}</h1>
              <div class="shop-meta">
                <div class="d-flex align-items-center gap-3 flex-wrap">
                  <span :class="shopInfo.isActive ? 'badge bg-success' : 'badge bg-danger'">
                    {{ shopInfo.isActive ? 'Đang hoạt động' : 'Tạm ngừng' }}
                  </span>
                  <div class="rating-info">
                    <span class="badge bg-warning">{{ shopInfo.rating }}/5 ⭐</span>
                    <small class="text-muted ms-2">({{ shopInfo.totalProducts }} sản phẩm)</small>
                  </div>
                  <small class="text-muted">Shop ID: #{{ shopInfo.id }}</small>
                </div>
                <p v-if="shopInfo.description" class="shop-description mt-2 mb-0">
                  {{ shopInfo.description }}
                </p>
              </div>
            </div>
          </div>
          
          <!-- Image Upload Actions -->
          <div v-if="shopInfo.coverImage || shopInfo.logo" class="upload-actions">
            <div class="row">
              <!-- Cover Image Actions -->
              <div v-if="shopInfo.coverImage" class="col-md-6 mb-2">
                <div class="d-flex gap-2">
                  <button 
                    v-if="!isUploadingCover" 
                    type="button" 
                    @click="uploadCoverImage" 
                    class="btn btn-sm btn-success"
                  >
                    <i class="bi bi-check"></i> Lưu ảnh bìa
                  </button>
                  <button 
                    v-if="isUploadingCover" 
                    type="button" 
                    class="btn btn-sm btn-success" 
                    disabled
                  >
                    <span class="spinner-border spinner-border-sm me-1"></span>
                    Đang lưu...
                  </button>
                  <button 
                    type="button" 
                    @click="cancelCoverUpload" 
                    class="btn btn-sm btn-secondary"
                  >
                    <i class="bi bi-x"></i> Hủy
                  </button>
                </div>
              </div>
              
              <!-- Logo Actions -->
              <div v-if="shopInfo.logo" class="col-md-6 mb-2">
                <div class="d-flex gap-2">
                  <button 
                    v-if="!isUploadingLogo" 
                    type="button" 
                    @click="uploadLogo" 
                    class="btn btn-sm btn-primary"
                  >
                    <i class="bi bi-check"></i> Lưu logo
                  </button>
                  <button 
                    v-if="isUploadingLogo" 
                    type="button" 
                    class="btn btn-sm btn-primary" 
                    disabled
                  >
                    <span class="spinner-border spinner-border-sm me-1"></span>
                    Đang lưu...
                  </button>
                  <button 
                    type="button" 
                    @click="cancelLogoUpload" 
                    class="btn btn-sm btn-secondary"
                  >
                    <i class="bi bi-x"></i> Hủy
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
     </div>

      <!-- Main Settings Section -->

      <!-- Navigation Tabs -->
      <div class="row mb-4">
        <div class="col-12">
          <ul class="nav nav-tabs" id="settingsTabs" role="tablist">
            <li class="nav-item" role="presentation">
              <button class="nav-link active" id="shop-info-tab" data-bs-toggle="tab" data-bs-target="#shop-info"
                type="button" role="tab">
                Thông tin shop
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link" id="stats-info-tab" data-bs-toggle="tab" data-bs-target="#stats-info"
                type="button" role="tab">
                Thống kê shop
              </button>
            </li>
          </ul>
        </div>
      </div>

      <!-- Tab Content -->
      <div class="tab-content" id="settingsTabContent">

        <!-- Shop Information Tab -->
        <div class="tab-pane fade show active" id="shop-info" role="tabpanel" aria-labelledby="shop-info-tab">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">Thông tin shop</h5>
            </div>
            <div class="card-body">
              <div v-if="isLoading" class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Đang tải thông tin shop...</p>
              </div>

              <template v-else>
                
                  <div class="row">
                    <div class="col-md-6 mb-3">
                      <label for="shopName" class="form-label">Tên shop *</label>
                      <input type="text" class="form-control" id="shopName" v-model="shopInfo.name"
                        :class="{ 'is-invalid': errors.name }" required>
                      <div v-if="errors.name" class="invalid-feedback">
                        {{ errors.name }}
                      </div>
                    </div>

                    <div class="col-md-6 mb-3">
                      <label for="shopEmail" class="form-label">Email shop *</label>
                      <input type="email" class="form-control" id="shopEmail" v-model="shopInfo.contactEmail"
                        :class="{ 'is-invalid': errors.contactEmail }" required>
                      <div v-if="errors.contactEmail" class="invalid-feedback">
                        {{ errors.contactEmail }}
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6 mb-3">
                      <label for="shopPhone" class="form-label">Số điện thoại *</label>
                      <input type="tel" class="form-control" id="shopPhone" v-model="shopInfo.contactPhone"
                        :class="{ 'is-invalid': errors.contactPhone }" required>
                      <div v-if="errors.contactPhone" class="invalid-feedback">
                        {{ errors.contactPhone }}
                      </div>
                    </div>

                    <div class="col-md-6 mb-3">
                      <label for="shopSlug" class="form-label">Slug shop</label>
                      <input type="text" class="form-control" id="shopSlug" v-model="shopInfo.slug" readonly disabled>
                      <div class="form-text">Slug tự động được tạo từ tên shop</div>
                    </div>
                  </div>

                  <div class="mb-3">
                    <label for="shopDescription" class="form-label">Mô tả shop</label>
                    <textarea class="form-control" id="shopDescription" rows="4" v-model="shopInfo.description"
                      placeholder="Mô tả về shop của bạn..."></textarea>
                  </div>
                  
                  <!-- Address Section -->
                  <hr>
                  <h6 class="mt-4 mb-3">Địa chỉ shop</h6>
                  
                  <!-- Loading addresses -->
                  <div v-if="isLoadingAddresses" class="text-center py-3">
                    <div class="spinner-border spinner-border-sm text-primary" role="status">
                      <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2 small">Đang tải danh sách địa chỉ...</p>
                  </div>
                  
                  <!-- Address selection -->
                  <div v-else-if="userAddresses.length > 0" class="mb-4">
                    <label class="form-label">Chọn địa chỉ từ danh sách:</label>
                    <div class="address-list">
                      <div v-for="address in userAddresses" :key="address.id" class="card mb-2">
                        <div class="card-body">
                          <div class="form-check">
                            <input 
                              class="form-check-input" 
                              type="radio" 
                              :id="'address-' + address.id" 
                              :value="address.id" 
                              v-model="selectedAddressId"
                            >
                            <label class="form-check-label" :for="'address-' + address.id">
                              <strong>{{ address.contactFullName }} - {{ address.contactPhoneNumber }}</strong><br>
                              {{ address.fullAddress }}
                              <span v-if="address.isDefaultShipping" class="badge bg-primary ms-2">Mặc định</span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div v-else class="alert alert-info">
                    Bạn chưa có địa chỉ nào. Vui lòng thêm địa chỉ trong phần quản lý địa chỉ cá nhân.
                  </div>

                  <div class="d-flex justify-content-end">
                    <button 
                      type="button" 
                      @click="updateShopAddress" 
                      class="btn btn-primary" 
                      :disabled="isUpdatingAddress || !selectedAddressId"
                    >
                      <span v-if="isUpdatingAddress" class="spinner-border spinner-border-sm me-2"></span>
                      {{ isUpdatingAddress ? 'Đang cập nhật...' : 'Cập nhật địa chỉ shop' }}
                    </button>
                  </div>
              </template>
            </div>
          </div>
        </div>

        <!-- Shop Stats Tab -->
        <div class="tab-pane fade" id="stats-info" role="tabpanel" aria-labelledby="stats-info-tab">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">Thống kê shop</h5>
            </div>
            <div class="card-body">
              <div v-if="isLoadingStats" class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Đang tải thống kê...</p>
              </div>

              <template v-else>
                <div class="row">
                  <!-- Shop Info Card -->
                  <div class="col-md-6 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                      <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                          <h5 class="card-title mb-0">Thông tin cơ bản</h5>
                          <span class="badge bg-primary">Shop ID: {{ shopStats.shopId }}</span>
                        </div>

                        <div class="mb-3">
                          <h6 class="text-muted mb-2">Tên shop</h6>
                          <h4>{{ shopStats.shopName }}</h4>
                        </div>

                        <div class="mb-3">
                          <h6 class="text-muted mb-2">Trạng thái</h6>
                          <span :class="shopStats.isActive ? 'badge bg-success' : 'badge bg-danger'">
                            {{ shopStats.isActive ? 'Hoạt động' : 'Không hoạt động' }}
                          </span>
                          <small v-if="shopStats.approvedAt" class="text-muted ms-2">
                            (Đã duyệt: {{ formatDate(shopStats.approvedAt) }})
                          </small>
                        </div>

                        <div class="mb-3">
                          <h6 class="text-muted mb-2">Đánh giá</h6>
                          <div class="d-flex align-items-center">
                            <div class="rating-display">
                              <span class="badge bg-warning">{{ shopStats.rating }}/5</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- Products Stats Card -->
                  <div class="col-md-6 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                      <div class="card-body">
                        <h5 class="card-title mb-4">Thống kê sản phẩm</h5>
                        <div class="row">
                          <div class="col-6 mb-3">
                            <div class="stat-card bg-light-primary p-3 rounded">
                              <div class="text-primary mb-1">
                                <i class="bi bi-box-seam fs-4"></i>
                              </div>
                              <h3 class="mb-0">{{ shopStats.totalProducts }}</h3>
                              <p class="mb-0 text-muted small">Tổng sản phẩm</p>
                            </div>
                          </div>
                          <div class="col-6 mb-3">
                            <div class="stat-card bg-light-success p-3 rounded">
                              <div class="text-success mb-1">
                                <i class="bi bi-check-circle fs-4"></i>
                              </div>
                              <h3 class="mb-0">{{ shopStats.approvedProducts }}</h3>
                              <p class="mb-0 text-muted small">Sản phẩm đã duyệt</p>
                            </div>
                          </div>

                          <div class="col-6">
                            <div class="stat-card bg-light-warning p-3 rounded">
                              <div class="text-warning mb-1">
                                <i class="bi bi-hourglass-split fs-4"></i>
                              </div>
                              <h3 class="mb-0">{{ shopStats.pendingProducts }}</h3>
                              <p class="mb-0 text-muted small">Sản phẩm chờ duyệt</p>
                            </div>
                          </div>
                          <!-- sản bị hủy sẽ bằng tổng sp - sp đã duyệt - sp chờ duyệt -->
                          <div class="col-6">
                            <div class="stat-card bg-light-danger p-3 rounded">
                              <div class="text-danger mb-1">
                                <i class="bi bi-x-circle fs-4"></i>
                              </div>
                              <h3 class="mb-0">
                                {{
                                  shopStats.totalProducts - shopStats.approvedProducts - shopStats.pendingProducts
                                }}
                              </h3>
                              <p class="mb-0 text-muted small">Sản phẩm bị hủy</p>
                            </div>  
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </SellerLayout>
</template>

<script setup>
import SellerLayout from '@/components/SellerLayout.vue'
import Swal from 'sweetalert2'
import { ref, reactive, onMounted } from 'vue'
import shopService from '@/services/seller/shops'

// Reactive data
const shopInfo = reactive({
  id: null,
  name: '',
  slug: '',
  description: '',
  logoUrl: null,
  coverImageUrl: null,
  contactEmail: '',
  contactPhone: '',
  rating: 0,
  isActive: false,
  approvedAt: null,
  createdAt: null,
  rejectionReason: null,
  totalProducts: 0,
  // For file uploads
  logo: null,
  logoPreview: null,
  coverImage: null,
  coverImagePreview: null
})

const shopStats = reactive({
  pendingProducts: 0,
  totalProducts: 0,
  rating: 0,
  shopName: '',
  shopId: null,
  approvedProducts: 0,
  isActive: false,
  approvedAt: null
})

const userAddresses = ref([])
const selectedAddressId = ref(null)
const errors = reactive({})
const isUpdatingAddress = ref(false)
const isLoading = ref(true)
const isLoadingStats = ref(true)
const isLoadingAddresses = ref(false)
const isUploadingLogo = ref(false)
const isUploadingCover = ref(false)

// API methods
const updateShopAddress = async () => {
  if (!selectedAddressId.value) {
    Swal.fire({
      title: 'Lỗi!',
      text: 'Vui lòng chọn một địa chỉ',
      icon: 'error',
      confirmButtonText: 'OK'
    })
    return
  }

  isUpdatingAddress.value = true

  try {
    const response = await shopService.updateShopAddress(selectedAddressId.value)
    
    if (response.data) {
      Swal.fire({
        title: 'Thành công!',
        text: 'Địa chỉ shop đã được cập nhật',
        icon: 'success',
        confirmButtonText: 'OK'
      })
      
      // Reload shop data to get updated address
      await loadShopData()
    }
  } catch (error) {
    console.error('Update shop address error:', error)

    let errorMessage = 'Có lỗi xảy ra khi cập nhật địa chỉ shop'
    if (error.response?.data?.message) {
      errorMessage = error.response.data.message
    }

    Swal.fire({
      title: 'Lỗi!',
      text: errorMessage,
      icon: 'error',
      confirmButtonText: 'OK'
    })
  } finally {
    isUpdatingAddress.value = false
  }
}

// Load user addresses
const loadUserAddresses = async () => {
  try {
    isLoadingAddresses.value = true
    const response = await shopService.getShopAddress()
    
    if (response.data) {
      userAddresses.value = response.data
    }
  } catch (error) {
    console.error('Error loading user addresses:', error)
    
    let errorMessage = 'Có lỗi xảy ra khi tải danh sách địa chỉ'
    if (error.response?.data?.message) {
      errorMessage = error.response.data.message
    }

    Swal.fire({
      title: 'Lỗi!',
      text: errorMessage,
      icon: 'error',
      confirmButtonText: 'OK'
    })
  } finally {
    isLoadingAddresses.value = false
  }
}

// Upload logo separately
const uploadLogo = async () => {
  if (!shopInfo.logo) {
    Swal.fire({
      title: 'Lỗi!',
      text: 'Vui lòng chọn file logo trước khi tải lên',
      icon: 'error',
      confirmButtonText: 'OK'
    });
    return;
  }

  isUploadingLogo.value = true;

  try {
    const response = await shopService.updateShopLogo(shopInfo.logo);
    
    if (response.data) {
      // Cập nhật logoUrl mới
      shopInfo.logoUrl = response.data.logoUrl;
      
      // Reset preview và file sau khi upload thành công
      shopInfo.logoPreview = null;
      shopInfo.logo = null;
      
      // Reset file input
      const logoInput = document.getElementById('shopLogo');
      if (logoInput) {
        logoInput.value = '';
      }

      Swal.fire({
        title: 'Thành công!',
        text: 'Logo shop đã được cập nhật',
        icon: 'success',
        confirmButtonText: 'OK'
      });
    }
  } catch (error) {
    console.error('Upload logo error:', error);

    let errorMessage = 'Có lỗi xảy ra khi cập nhật logo';
    if (error.response?.data?.message) {
      errorMessage = error.response.data.message;
    }

    Swal.fire({
      title: 'Lỗi!',
      text: errorMessage,
      icon: 'error',
      confirmButtonText: 'OK'
    });
  } finally {
    isUploadingLogo.value = false;
  }
};

// Upload cover image separately
const uploadCoverImage = async () => {
  if (!shopInfo.coverImage) {
    Swal.fire({
      title: 'Lỗi!',
      text: 'Vui lòng chọn file ảnh bìa trước khi tải lên',
      icon: 'error',
      confirmButtonText: 'OK'
    });
    return;
  }

  isUploadingCover.value = true;

  try {
    const response = await shopService.updateShopCover(shopInfo.coverImage);
    
    if (response.data) {
      // Cập nhật coverImageUrl mới
      shopInfo.coverImageUrl = response.data.coverImageUrl;
      
      // Reset preview và file sau khi upload thành công
      shopInfo.coverImagePreview = null;
      shopInfo.coverImage = null;
      
      // Reset file input
      const coverInput = document.getElementById('coverImage');
      if (coverInput) {
        coverInput.value = '';
      }

      Swal.fire({
        title: 'Thành công!',
        text: 'Ảnh bìa shop đã được cập nhật',
        icon: 'success',
        confirmButtonText: 'OK'
      });
    }
  } catch (error) {
    console.error('Upload cover error:', error);

    let errorMessage = 'Có lỗi xảy ra khi cập nhật ảnh bìa';
    if (error.response?.data?.message) {
      errorMessage = error.response.data.message;
    }

    Swal.fire({
      title: 'Lỗi!',
      text: errorMessage,
      icon: 'error',
      confirmButtonText: 'OK'
    });
  } finally {
    isUploadingCover.value = false;
  }
};

// Cancel logo upload
const cancelLogoUpload = () => {
  shopInfo.logo = null;
  shopInfo.logoPreview = null;
  
  const logoInput = document.getElementById('shopLogo');
  if (logoInput) {
    logoInput.value = '';
  }
};

// Cancel cover upload
const cancelCoverUpload = () => {
  shopInfo.coverImage = null;
  shopInfo.coverImagePreview = null;
  
  const coverInput = document.getElementById('coverImage');
  if (coverInput) {
    coverInput.value = '';
  }
};

// File upload methods
const handleLogoUpload = (event) => {
  const file = event.target.files[0]
  if (file) {
    if (file.size > 2 * 1024 * 1024) {
      Swal.fire({
        title: 'Lỗi!',
        text: 'Kích thước file không được vượt quá 2MB',
        icon: 'error',
        confirmButtonText: 'OK'
      })
      event.target.value = '' // Reset input
      return
    }

    if (!file.type.startsWith('image/')) {
      Swal.fire({
        title: 'Lỗi!',
        text: 'Vui lòng chọn file hình ảnh (JPG, PNG)',
        icon: 'error',
        confirmButtonText: 'OK'
      })
      event.target.value = '' // Reset input
      return
    }

    shopInfo.logo = file

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => {
      shopInfo.logoPreview = e.target.result
    }
    reader.readAsDataURL(file)
  }
}

const handleCoverImageUpload = (event) => {
  const file = event.target.files[0]
  if (file) {
    if (file.size > 5 * 1024 * 1024) {
      Swal.fire({
        title: 'Lỗi!',
        text: 'Kích thước file không được vượt quá 5MB',
        icon: 'error',
        confirmButtonText: 'OK'
      })
      event.target.value = '' // Reset input
      return
    }

    if (!file.type.startsWith('image/')) {
      Swal.fire({
        title: 'Lỗi!',
        text: 'Vui lòng chọn file hình ảnh (JPG, PNG)',
        icon: 'error',
        confirmButtonText: 'OK'
      })
      event.target.value = '' // Reset input
      return
    }

    shopInfo.coverImage = file

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => {
      shopInfo.coverImagePreview = e.target.result
    }
    reader.readAsDataURL(file)
  }
}

// Data loading methods
const loadShopData = async () => {
  try {
    isLoading.value = true
    const response = await shopService.getCurrentShop()

    if (response.data) {
      // Map API data to shopInfo
      Object.assign(shopInfo, {
        id: response.data.id,
        name: response.data.name || '',
        slug: response.data.slug || '',
        description: response.data.description || '',
        logoUrl: response.data.logoUrl,
        coverImageUrl: response.data.coverImageUrl,
        contactEmail: response.data.contactEmail || '',
        contactPhone: response.data.contactPhone || '',
        rating: response.data.rating || 0,
        isActive: response.data.isActive || false,
        approvedAt: response.data.approvedAt,
        createdAt: response.data.createdAt,
        rejectionReason: response.data.rejectionReason,
        totalProducts: response.data.totalProducts || 0
      })
    }
  } catch (error) {
    console.error('Error loading shop data:', error)

    let errorMessage = 'Có lỗi xảy ra khi tải thông tin shop'
    if (error.response?.status === 404) {
      errorMessage = 'Không tìm thấy thông tin shop'
    } else if (error.response?.data?.message) {
      errorMessage = error.response.data.message
    }

    Swal.fire({
      title: 'Lỗi!',
      text: errorMessage,
      icon: 'error',
      confirmButtonText: 'OK'
    })
  } finally {
    isLoading.value = false
  }
}

const loadShopStats = async () => {
  try {
    isLoadingStats.value = true
    const response = await shopService.getShopStats()

    if (response.data) {
      Object.assign(shopStats, {
        pendingProducts: response.data.pendingProducts || 0,
        totalProducts: response.data.totalProducts || 0,
        rating: response.data.rating || 0,
        shopName: response.data.shopName || '',
        shopId: response.data.shopId || null,
        approvedProducts: response.data.approvedProducts || 0,
        isActive: response.data.isActive || false,
        approvedAt: response.data.approvedAt || null
      })
    }
  } catch (error) {
    console.error('Error loading shop stats:', error)

    let errorMessage = 'Có lỗi xảy ra khi tải thống kê shop'
    if (error.response?.status === 404) {
      errorMessage = 'Không tìm thấy thông tin thống kê'
    } else if (error.response?.data?.message) {
      errorMessage = error.response.data.message
    }

    Swal.fire({
      title: 'Lỗi!',
      text: errorMessage,
      icon: 'error',
      confirmButtonText: 'OK'
    })
  } finally {
    isLoadingStats.value = false
  }
}

const loadCurrentData = async () => {
  await Promise.all([
    loadShopData(),
    loadShopStats(),
    loadUserAddresses()
  ])
}

// Format date for display
const formatDate = (dateString) => {
  if (!dateString) return 'N/A'
  return new Date(dateString).toLocaleDateString('vi-VN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// Lifecycle
onMounted(async () => {
  await loadCurrentData()
})
</script>

<style scoped>
/* Giữ nguyên tất cả các style từ file gốc */
/* ... (tất cả các style cũ) ... */

/* Additional styles for address list */
.address-list {
  max-height: 300px;
  overflow-y: auto;
}

.form-check-input:checked {
  background-color: #0d6efd;
  border-color: #0d6efd;
}

.address-list .card {
  border: 1px solid #dee2e6;
  border-radius: 0.5rem;
  transition: all 0.2s ease;
}

.address-list .card:hover {
  border-color: #0d6efd;
  box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
}

.address-list .card-body {
  padding: 1rem;
}

.form-check-label {
  cursor: pointer;
  width: 100%;
}

.nav-tabs .nav-link {
  border-bottom: 2px solid transparent;
  color: #6c757d;
}

.nav-tabs .nav-link.active {
  border-bottom-color: #0d6efd;
  color: #0d6efd;
  background-color: transparent;
  border-top: none;
  border-left: none;
  border-right: none;
}

.card {
  border: none;
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
}

.form-label {
  font-weight: 600;
  color: #495057;
}

.btn-primary {
  background-color: #0d6efd;
  border-color: #0d6efd;
}

.btn-success {
  background-color: #198754;
  border-color: #198754;
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

.bi {
  font-family: 'Bootstrap Icons';
}

/* Bootstrap Icons fallback */
.bi-box-seam::before {
  content: "📦";
}

.bi-check-circle::before {
  content: "✅";
}

.bi-hourglass-split::before {
  content: "⏳";
}

.bi-x-circle::before {
  content: "❌";
}

.bi-camera::before {
  content: "📷";
}

.bi-check::before {
  content: "✓";
}

.bi-x::before {
  content: "×";
}

.badge {
  font-size: 0.875em;
}

.badge.bg-success {
  background-color: #198754 !important;
}

.badge.bg-danger {
  background-color: #dc3545 !important;
}

.badge.bg-warning {
  background-color: #ffc107 !important;
  color: #000;
}

.badge.bg-primary {
  background-color: #0d6efd !important;
}

/* Stats cards */
.stat-card {
  transition: all 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.bg-light-primary {
  background-color: rgba(13, 110, 253, 0.1);
}

.bg-light-success {
  background-color: rgba(25, 135, 84, 0.1);
}

.bg-light-warning {
  background-color: rgba(255, 193, 7, 0.1);
}

.bg-light-danger {
  background-color: rgba(220, 53, 69, 0.1);
}

/* Shop Profile Header - Facebook Style */
.shop-profile-header {
  margin-bottom: 2rem;
}

.shop-profile-container {
  position: relative;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.12);
  background: #fff;
}

.cover-image-section {
  position: relative;
}

.cover-image-wrapper {
  position: relative;
  width: 100%;
  height: 280px;
  overflow: hidden;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.cover-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.cover-image-wrapper:hover .cover-image {
  transform: scale(1.02);
}

.cover-upload-overlay {
  position: absolute;
  bottom: 20px;
  right: 20px;
}

.cover-upload-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  background: rgba(0, 0, 0, 0.75);
  color: white;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

.cover-upload-btn:hover {
  background: rgba(0, 0, 0, 0.85);
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
}

.shop-info-section {
  position: relative;
  padding: 100px 32px 32px;
  background: linear-gradient(to bottom, transparent, rgba(255, 255, 255, 0.95) 50%);
}

.logo-section {
  position: absolute;
  top: -80px;
  left: 32px;
  z-index: 10;
}

.logo-wrapper {
  position: relative;
  width: 160px;
  height: 160px;
}

.shop-logo {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 6px solid white;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  transition: transform 0.3s ease;
  background: #f8f9fa;
}

.logo-wrapper:hover .shop-logo {
  transform: scale(1.05);
}

.logo-upload-btn {
  position: absolute;
  bottom: 12px;
  right: 12px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #007bff, #0056b3);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border: 3px solid white;
  font-size: 16px;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(0, 123, 255, 0.4);
}

.logo-upload-btn:hover {
  background: linear-gradient(135deg, #0056b3, #004085);
  transform: scale(1.1);
  box-shadow: 0 6px 16px rgba(0, 123, 255, 0.5);
}

.shop-basic-info {
  margin-top: 20px;
}

.shop-name {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 16px;
  color: #1a1a1a;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.shop-meta {
  color: #666;
}

.shop-description {
  font-size: 1.1rem;
  line-height: 1.6;
  color: #555;
  max-width: 600px;
}

.rating-info {
  display: flex;
  align-items: center;
}

.upload-actions {
  padding: 20px 32px;
  background: #f8f9fa;
  border-top: 1px solid #e9ecef;
}

.upload-guidelines {
  padding: 16px;
  background: #f8f9fa;
  border-radius: 12px;
  border: 1px solid #e9ecef;
  margin-top: 16px;
}

/* Action buttons styling */
.btn-sm {
  padding: 8px 16px;
  font-size: 13px;
  border-radius: 8px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.btn-success {
  background: linear-gradient(135deg, #28a745, #20c997);
  border: none;
  box-shadow: 0 3px 6px rgba(40, 167, 69, 0.3);
}

.btn-success:hover {
  transform: translateY(-2px);
  box-shadow: 0 5px 12px rgba(40, 167, 69, 0.4);
}

.btn-primary {
  background: linear-gradient(135deg, #007bff, #6610f2);
  border: none;
  box-shadow: 0 3px 6px rgba(0, 123, 255, 0.3);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 5px 12px rgba(0, 123, 255, 0.4);
}

.btn-secondary {
  background: #6c757d;
  border: none;
}

.btn-secondary:hover {
  background: #5a6268;
  transform: translateY(-1px);
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .nav-tabs {
    flex-direction: column;
  }

  .nav-tabs .nav-item {
    width: 100%;
  }

  .nav-tabs .nav-link {
    text-align: center;
    margin-bottom: 0.25rem;
  }

  /* Mobile adjustments for shop profile */
  .cover-image-wrapper {
    height: 200px;
  }

  .shop-info-section {
    padding: 80px 20px 20px;
  }

  .logo-section {
    left: 20px;
    top: -60px;
  }

  .logo-wrapper {
    width: 120px;
    height: 120px;
  }

  .shop-name {
    font-size: 1.8rem;
  }

  .cover-upload-btn {
    padding: 8px 12px;
    font-size: 12px;
    bottom: 12px;
    right: 12px;
  }

  .logo-upload-btn {
    width: 32px;
    height: 32px;
    font-size: 14px;
  }

  .upload-actions {
    padding: 16px 20px;
  }
}

/* Form validation styles */
.is-invalid {
  border-color: #dc3545;
}

.invalid-feedback {
  display: block;
  width: 100%;
  margin-top: 0.25rem;
  font-size: 0.875em;
  color: #dc3545;
}

/* Disabled input styling */
.form-control:disabled {
  background-color: #e9ecef;
  opacity: 1;
}

/* Text area resize */
textarea.form-control {
  resize: vertical;
  min-height: calc(1.5em + 0.75rem + 2px);
}

/* Loading states */
.spinner-border {
  width: 1.5rem;
  height: 1.5rem;
}

/* Hover effects for cards */
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

/* Badge improvements */
.badge {
  padding: 0.5em 0.75em;
  font-size: 0.75em;
  border-radius: 0.5rem;
}

/* Enhanced visual hierarchy */
h2, h3, h4, h5 {
  color: #2c3e50;
}

.text-muted {
  color: #6c757d !important;
}

/* Smooth transitions */
* {
  transition: all 0.2s ease;
}

/* Custom scrollbar for webkit browsers */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}
</style>
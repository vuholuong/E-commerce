<template>
  <SellerLayout>
    <!-- Stats Cards -->
    <div class="row mb-4">
      <div class="col-md-3">
        <div class="card text-white bg-success">
          <div class="card-body">
            <h5 class="card-title">Doanh thu</h5>
            <h3>{{ formatCurrency(overviewData.totalRevenue || 0) }}</h3>
            <small>Tổng doanh thu</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-primary">
          <div class="card-body">
            <h5 class="card-title">Đơn hàng</h5>
            <h3>{{ overviewData.totalOrders || 0 }}</h3>
            <small>{{ overviewData.pendingOrders || 0 }} chờ xử lý</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-info">
          <div class="card-body">
            <h5 class="card-title">Đơn hoàn thành</h5>
            <h3>{{ overviewData.completedOrders || 0 }}</h3>
            <small>{{ overviewData.deliveredOrders || 0 }} đã giao</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-warning">
          <div class="card-body">
            <h5 class="card-title">Đơn hủy</h5>
            <h3>{{ returnsCount || 0 }}</h3>
            <small>{{ overviewData.cancelledOrders || 0 }} bị hủy</small>
          </div>
        </div>
      </div>
    </div>

    <!-- Charts Section -->
    <div class="row">
      <!-- Biểu đồ -->
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-start align-items-lg-center">
              <h5 class="mb-2 mb-lg-0">Thống kê bán hàng</h5>

              <!-- Filter controls với responsive design -->
              <div class="filter-controls w-100 w-lg-auto">
                <div class="row g-2">
                  <div class="col-12 col-sm-6 col-lg-auto">
                    <select v-model="selectedRange" @change="updateCharts" class="form-select form-select-sm">
                      <option value="7d">7 ngày</option>
                      <option value="30d">30 ngày</option>
                      <option value="90d">3 tháng</option>
                      <option value="1y">1 năm</option>
                    </select>
                  </div>
                  <div class="col-12 col-sm-6 col-lg-auto">
                    <select v-model="selectedMetric" @change="updateCharts" class="form-select form-select-sm">
                      <option value="revenue">Doanh thu</option>
                      <option value="orders">Đơn hàng</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card-body">
            <!-- Main Chart -->
            <div class="chart-container mb-4">
              <div v-if="loading.sales" class="text-center">
                <div class="spinner-border" role="status">
                  <span class="visually-hidden">Đang tải...</span>
                </div>
              </div>
              <canvas v-else ref="mainChart" style="height: auto;"></canvas>
            </div>
          </div>
        </div>
      </div>

      <!-- Hiệu suất bán hàng -->
      <div class="col-md-4">
        <!-- Sản phẩm bán chạy -->
        <div class="card">
          <div class="card-header">
            <h5>Sản phẩm bán chạy</h5>
          </div>
          <div class="card-body">
            <div v-if="loading.topProducts" class="text-center">
              <div class="spinner-border spinner-border-sm" role="status">
                <span class="visually-hidden">Đang tải...</span>
              </div>
            </div>
            <div v-else>
              <div v-for="(product, index) in topProducts" :key="product.productId" class="d-flex justify-content-between align-items-center mb-2">
                <div>
                  <span class="badge bg-secondary me-2">#{{ index + 1 }}</span>
                  <span class="fw-medium">{{ product.productName }}</span>
                </div>
                <div class="text-end">
                  <span class="badge bg-success">{{ product.totalQuantity }}</span>
                  <div class="small text-muted">{{ formatCurrency(product.totalRevenue) }}</div>
                </div>
              </div>
              <div v-if="topProducts.length === 0" class="text-center text-muted">
                <small>Chưa có dữ liệu</small>
              </div>
            </div>
          </div>
        </div>

        <!-- Cảnh báo hàng sắp hết -->
        <div class="card mt-3">
          <div class="card-header">
            <h6>Sản phẩm sắp hết hàng</h6>
          </div>
          <div class="card-body">
            <div v-if="loading.lowStock" class="text-center">
              <div class="spinner-border spinner-border-sm" role="status">
                <span class="visually-hidden">Đang tải...</span>
              </div>
            </div>
            <div v-else>
              <div v-for="item in lowStockItems" :key="item.variantId" class="d-flex justify-content-between align-items-center mb-2">
                <div>
                  <div class="fw-medium">{{ item.productName }}</div>
                  <small class="text-muted">SKU: {{ item.sku }}</small>
                </div>
                <div class="text-end">
                  <span class="badge" :class="getStockBadgeClass(item.stockQuantity)">
                    {{ item.stockQuantity }}
                  </span>
                </div>
              </div>
              <div v-if="lowStockItems.length === 0" class="text-center text-muted">
                <small>Tất cả sản phẩm đều còn đủ hàng</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </SellerLayout>
</template>

<script setup>
import { ref, onMounted, nextTick, computed } from 'vue'
import SellerLayout from '../../components/SellerLayout.vue'
import Swal from 'sweetalert2'
import statsService from '@/services/seller/statis'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  LineController,
  BarController,
  Filler
} from 'chart.js'

// Register Chart.js components
ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend,
    LineController,
    BarController,
    Filler
)


// Data refs
const overviewData = ref({})
const salesData = ref([])
const topProducts = ref([])
const lowStockItems = ref([])
const returnsCount = ref(0)

// Chart references
const mainChart = ref(null)
let mainChartInstance = null

// Loading states
const loading = ref({
  overview: false,
  sales: false,
  topProducts: false,
  lowStock: false,
  returns: false
})

// Filter states
const selectedRange = ref('30d')
const selectedMetric = ref('revenue')

// Computed properties
const chartTitle = computed(() => {
  const metricLabel = selectedMetric.value === 'revenue' ? 'Doanh thu' : 'Đơn hàng'
  const rangeLabel = {
    '7d': '7 ngày',
    '30d': '30 ngày', 
    '90d': '3 tháng',
    '1y': '1 năm'
  }[selectedRange.value]
  
  return `${metricLabel} ${rangeLabel} qua`
})

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND'
  }).format(amount)
}

const getStockBadgeClass = (quantity) => {
  if (quantity <= 0) return 'bg-danger'
  if (quantity <= 5) return 'bg-warning'
  if (quantity <= 10) return 'bg-info'
  return 'bg-success'
}

// API calls
const loadOverview = async () => {
  try {
    loading.value.overview = true
    const response = await statsService.getOverview()
    // SỬA Ở ĐÂY
    if (response && response.statusCode === 200) {
      overviewData.value = response.data
    }
  } catch (error) {
    console.error('Error loading overview:', error)
    showError('Không thể tải dữ liệu tổng quan')
  } finally {
    loading.value.overview = false
  }
}

const loadTopProducts = async () => {
  try {
    loading.value.topProducts = true
    const response = await statsService.getTopProducts('quantity', 5)
    // SỬA: Gán trực tiếp response
    topProducts.value = response || []
  } catch (error) {
    console.error('Error loading top products:', error)
    showError('Không thể tải dữ liệu sản phẩm bán chạy')
  } finally {
    loading.value.topProducts = false
  }
}

const loadLowStock = async () => {
  try {
    loading.value.lowStock = true
    const response = await statsService.getLowStock(10)
    // SỬA: Gán trực tiếp response
    lowStockItems.value = response || []
  } catch (error) {
    console.error('Error loading low stock:', error)
    showError('Không thể tải dữ liệu hàng tồn kho')
  } finally {
    loading.value.lowStock = false
  }
}

const loadReturns = async () => {
  try {
    loading.value.returns = true
    const response = await statsService.getReturns(selectedRange.value)
    // SỬA Ở ĐÂY
    if (response && response.statusCode === 200) {
      returnsCount.value = response.data
    }
  } catch (error) {
    console.error('Error loading returns:', error)
  } finally {
    loading.value.returns = false
  }
}

const showError = (message) => {
  Swal.fire({
    title: 'Lỗi!',
    text: message,
    icon: 'error',
    timer: 3000,
    showConfirmButton: false
  })
}

const getLabels = () => {
  return salesData.value.map(item => {
    const date = new Date(item.date)
    return date.toLocaleDateString('vi-VN', { 
      day: '2-digit', 
      month: '2-digit' 
    })
  })
}

const getData = () => {
  return salesData.value.map(item => 
    selectedMetric.value === 'revenue' ? item.revenue : item.orders
  )
}

const getMetricLabel = () => {
  const labels = {
    revenue: 'Doanh thu (VNĐ)',
    orders: 'Số đơn hàng'
  }
  return labels[selectedMetric.value]
}

const createMainChart = () => {
  // console.log('Creating main chart...')
  // console.log('mainChart ref:', mainChart.value)
  // console.log('salesData:', salesData.value)

  if (mainChartInstance) {
    mainChartInstance.destroy()
    mainChartInstance = null
  }

  // ĐỢI NEXT TICK ĐỂ ĐẢM BẢO DOM ĐÃ RENDER
  nextTick(() => {
    if (!mainChart.value) {
      console.error('Main chart canvas not found!')
      // Thử tìm canvas bằng cách khác
      const canvas = document.querySelector('canvas')
      if (canvas) {
        console.log('Found canvas element:', canvas)
        mainChart.value = canvas
      } else {
        console.error('No canvas element found in DOM')
        return
      }
    }

    if (!salesData.value || salesData.value.length === 0) {
      console.warn('No sales data available for chart')
      return
    }

    const ctx = mainChart.value.getContext('2d')
    if (!ctx) {
      console.error('Could not get canvas context')
      return
    }

    const labels = getLabels()
    const data = getData()

    // console.log('Main chart labels:', labels)
    // console.log('Main chart data:', data)

    try {
      mainChartInstance = new ChartJS(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: getMetricLabel(),
            data: data,
            borderColor: '#36A2EB',
            backgroundColor: 'rgba(54, 162, 235, 0.1)',
            tension: 0.4,
            fill: true,
            pointBackgroundColor: '#36A2EB',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 7
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: chartTitle.value
            },
            legend: {
              display: false
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  if (selectedMetric.value === 'revenue') {
                    return `Doanh thu: ${formatCurrency(context.parsed.y)}`
                  } else {
                    return `Số đơn hàng: ${context.parsed.y}`
                  }
                }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                callback: function(value) {
                  if (selectedMetric.value === 'revenue') {
                    return new Intl.NumberFormat('vi-VN', {
                      notation: 'compact',
                      style: 'currency',
                      currency: 'VND'
                    }).format(value)
                  }
                  return value
                }
              },
              grid: {
                color: 'rgba(0, 0, 0, 0.1)'
              }
            },
            x: {
              grid: {
                display: false
              }
            }
          },
          interaction: {
            intersect: false,
            mode: 'index'
          }
        }
      })
      
      console.log('Main chart created successfully')
    } catch (error) {
      console.error('Error creating main chart:', error)
    }
  })
}

// Sửa hàm loadSalesData
const loadSalesData = async () => {
  try {
    loading.value.sales = true
    const response = await statsService.getSalesSeries(selectedRange.value)
    if (response && response.statusCode === 200) {
      salesData.value = response.data
     // console.log('Sales data loaded:', salesData.value)
      
      // THÊM TIMEOUT ĐỂ ĐẢM BẢO DOM ĐÃ READY
      setTimeout(() => {
        createMainChart()
      }, 100)
    }
  } catch (error) {
    console.error('Error loading sales data:', error)
    showError('Không thể tải dữ liệu bán hàng')
  } finally {
    loading.value.sales = false
  }
}

const updateCharts = async () => {
  await Promise.all([
    loadSalesData(),
    loadReturns()
  ])
}

const loadAllData = async () => {
  await Promise.all([
    loadOverview(),
    loadSalesData(),
    loadTopProducts(),
    loadLowStock(),
    loadReturns()
  ])
}

onMounted(() => {
  loadAllData()
})
</script>

<style scoped>
.chart-container {
  position: relative;
  height: 400px;
  width: 100%;
}

canvas {
  width: 100% !important;
  height: 100% !important;
}

.filter-controls {
  min-width: 200px;
}

@media (max-width: 768px) {
  .chart-container {
    height: 300px;
  }
  
  .filter-controls {
    width: 100%;
  }
}
</style>
<script setup>
import { ref, onMounted } from 'vue'
import SellerLayout from '../../components/SellerLayout.vue'
import Swal from 'sweetalert2'

// Reactive data
const vouchers = ref([])
const showModal = ref(false)
const editingVoucher = ref(null)
const isLoading = ref(false)

// Form data
const voucherForm = ref({
  id: null,
  code: '',
  title: '',
  description: '',
  discountType: 'percentage', // percentage, fixed
  discountValue: 0,
  minOrderValue: 0,
  maxDiscountAmount: 0,
  usageLimit: 0,
  usedCount: 0,
  startDate: '',
  endDate: '',
  isActive: true,
  applicableProducts: [], // array of product IDs
  applicationType: 'all' // all, specific_products, specific_categories
})

// Sample data (thay thế bằng API call thực tế)
const sampleVouchers = [
  {
    id: 1,
    code: 'SUMMER2024',
    title: 'Giảm giá mùa hè',
    description: 'Giảm 20% cho tất cả sản phẩm',
    discountType: 'percentage',
    discountValue: 20,
    minOrderValue: 100000,
    maxDiscountAmount: 50000,
    usageLimit: 100,
    usedCount: 25,
    startDate: '2024-06-01',
    endDate: '2024-08-31',
    isActive: true,
    applicationType: 'all'
  },
  {
    id: 2,
    code: 'NEWCUSTOMER',
    title: 'Khách hàng mới',
    description: 'Giảm 50,000đ cho đơn hàng đầu tiên',
    discountType: 'fixed',
    discountValue: 50000,
    minOrderValue: 200000,
    maxDiscountAmount: 50000,
    usageLimit: 50,
    usedCount: 12,
    startDate: '2024-01-01',
    endDate: '2024-12-31',
    isActive: true,
    applicationType: 'all'
  }
]

// Methods
const loadVouchers = async () => {
  isLoading.value = true
  try {
    // Thay thế bằng API call thực tế
    await new Promise(resolve => setTimeout(resolve, 500))
    vouchers.value = [...sampleVouchers]
  } catch (error) {
    console.error('Error loading vouchers:', error)
    Swal.fire('Lỗi!', 'Không thể tải danh sách voucher', 'error')
  } finally {
    isLoading.value = false
  }
}

const openCreateModal = () => {
  editingVoucher.value = null
  resetForm()
  showModal.value = true
}

const openEditModal = (voucher) => {
  editingVoucher.value = voucher
  Object.assign(voucherForm.value, { ...voucher })
  showModal.value = true
}

const resetForm = () => {
  voucherForm.value = {
    id: null,
    code: '',
    title: '',
    description: '',
    discountType: 'percentage',
    discountValue: 0,
    minOrderValue: 0,
    maxDiscountAmount: 0,
    usageLimit: 0,
    usedCount: 0,
    startDate: '',
    endDate: '',
    isActive: true,
    applicableProducts: [],
    applicationType: 'all'
  }
}

const generateVoucherCode = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let result = ''
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  voucherForm.value.code = result
}

const validateForm = () => {
  if (!voucherForm.value.code.trim()) {
    Swal.fire('Lỗi!', 'Vui lòng nhập mã voucher', 'error')
    return false
  }
  if (!voucherForm.value.title.trim()) {
    Swal.fire('Lỗi!', 'Vui lòng nhập tiêu đề voucher', 'error')
    return false
  }
  if (voucherForm.value.discountValue <= 0) {
    Swal.fire('Lỗi!', 'Giá trị giảm giá phải lớn hơn 0', 'error')
    return false
  }
  if (voucherForm.value.discountType === 'percentage' && voucherForm.value.discountValue > 100) {
    Swal.fire('Lỗi!', 'Phần trăm giảm giá không được vượt quá 100%', 'error')
    return false
  }
  if (new Date(voucherForm.value.startDate) >= new Date(voucherForm.value.endDate)) {
    Swal.fire('Lỗi!', 'Ngày kết thúc phải sau ngày bắt đầu', 'error')
    return false
  }
  return true
}

const saveVoucher = async () => {
  if (!validateForm()) return

  try {
    isLoading.value = true

    // Thay thế bằng API call thực tế
    await new Promise(resolve => setTimeout(resolve, 1000))

    if (editingVoucher.value) {
      // Update existing voucher
      const index = vouchers.value.findIndex(v => v.id === editingVoucher.value.id)
      if (index !== -1) {
        vouchers.value[index] = { ...voucherForm.value }
      }
      Swal.fire('Thành công!', 'Cập nhật voucher thành công', 'success')
    } else {
      // Create new voucher
      const newVoucher = {
        ...voucherForm.value,
        id: Date.now(),
        usedCount: 0
      }
      vouchers.value.unshift(newVoucher)
      Swal.fire('Thành công!', 'Tạo voucher mới thành công', 'success')
    }

    showModal.value = false
    resetForm()
  } catch (error) {
    console.error('Error saving voucher:', error)
    Swal.fire('Lỗi!', 'Không thể lưu voucher', 'error')
  } finally {
    isLoading.value = false
  }
}

const deleteVoucher = async (voucher) => {
  const result = await Swal.fire({
    title: 'Xác nhận xóa',
    text: `Bạn có chắc chắn muốn xóa voucher "${voucher.title}"?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy',
    confirmButtonColor: '#dc3545'
  })

  if (result.isConfirmed) {
    try {
      isLoading.value = true

      // Thay thế bằng API call thực tế
      await new Promise(resolve => setTimeout(resolve, 500))

      vouchers.value = vouchers.value.filter(v => v.id !== voucher.id)
      Swal.fire('Đã xóa!', 'Voucher đã được xóa thành công', 'success')
    } catch (error) {
      console.error('Error deleting voucher:', error)
      Swal.fire('Lỗi!', 'Không thể xóa voucher', 'error')
    } finally {
      isLoading.value = false
    }
  }
}

const toggleVoucherStatus = async (voucher) => {
  try {
    isLoading.value = true

    // Thay thế bằng API call thực tế
    await new Promise(resolve => setTimeout(resolve, 500))

    voucher.isActive = !voucher.isActive

    const status = voucher.isActive ? 'kích hoạt' : 'vô hiệu hóa'
    Swal.fire('Thành công!', `Đã ${status} voucher`, 'success')
  } catch (error) {
    console.error('Error toggling voucher status:', error)
    Swal.fire('Lỗi!', 'Không thể thay đổi trạng thái voucher', 'error')
  } finally {
    isLoading.value = false
  }
}

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND'
  }).format(amount)
}

const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('vi-VN')
}

const getDiscountText = (voucher) => {
  if (voucher.discountType === 'percentage') {
    return `${voucher.discountValue}%`
  } else {
    return formatCurrency(voucher.discountValue)
  }
}

const getStatusBadgeClass = (voucher) => {
  if (!voucher.isActive) return 'bg-secondary'

  const now = new Date()
  const endDate = new Date(voucher.endDate)

  if (endDate < now) return 'bg-danger'
  if (voucher.usedCount >= voucher.usageLimit) return 'bg-warning'

  return 'bg-success'
}

const getStatusText = (voucher) => {
  if (!voucher.isActive) return 'Vô hiệu hóa'

  const now = new Date()
  const endDate = new Date(voucher.endDate)

  if (endDate < now) return 'Hết hạn'
  if (voucher.usedCount >= voucher.usageLimit) return 'Đã hết lượt'

  return 'Hoạt động'
}

// Lifecycle
onMounted(() => {
  loadVouchers()
})
</script>

<template>
  <SellerLayout>
    <div class="container-fluid py-4">
      <!-- Header -->
      <div class="row mb-4">
        <div class="col-12">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h2 class="mb-0"></h2>
            </div>
            <button
                class="btn btn-primary"
                @click="openCreateModal"
                :disabled="isLoading"
            >
              <i class="bi bi-plus-lg me-2"></i>
              Tạo Voucher Mới
            </button>
          </div>
        </div>
      </div>

      <!-- Voucher List -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">Danh sách Voucher</h5>
            </div>
            <div class="card-body">
              <div v-if="isLoading && vouchers.length === 0" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                  <span class="visually-hidden">Đang tải...</span>
                </div>
              </div>

              <div v-else-if="vouchers.length === 0" class="text-center py-5">
                <i class="bi bi-ticket-perforated display-4 text-muted mb-3"></i>
                <h5 class="text-muted">Chưa có voucher nào</h5>
                <p class="text-muted">Tạo voucher đầu tiên để bắt đầu</p>
              </div>

              <div v-else class="table-responsive">
                <table class="table table-hover">
                  <thead>
                  <tr>
                    <th>Mã Voucher</th>
                    <th>Tiêu đề</th>
                    <th>Giảm giá</th>
                    <th>Đơn tối thiểu</th>
                    <th>Sử dụng</th>
                    <th>Thời hạn</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr v-for="voucher in vouchers" :key="voucher.id">
                    <td>
                      <code class="bg-light px-2 py-1 rounded">{{ voucher.code }}</code>
                    </td>
                    <td>
                      <div>
                        <div class="fw-bold">{{ voucher.title }}</div>
                        <small class="text-muted">{{ voucher.description }}</small>
                      </div>
                    </td>
                    <td>
                      <span class="fw-bold text-success">{{ getDiscountText(voucher) }}</span>
                      <div v-if="voucher.maxDiscountAmount > 0 && voucher.discountType === 'percentage'" class="small text-muted">
                        Tối đa: {{ formatCurrency(voucher.maxDiscountAmount) }}
                      </div>
                    </td>
                    <td>{{ formatCurrency(voucher.minOrderValue) }}</td>
                    <td>
                      <div class="text-center">
                        <div>{{ voucher.usedCount }}/{{ voucher.usageLimit }}</div>
                        <div class="progress" style="height: 4px;">
                          <div
                              class="progress-bar"
                              :style="{ width: (voucher.usedCount / voucher.usageLimit * 100) + '%' }"
                          ></div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div class="small">
                        <div>{{ formatDate(voucher.startDate) }}</div>
                        <div>{{ formatDate(voucher.endDate) }}</div>
                      </div>
                    </td>
                    <td>
                        <span
                            class="badge"
                            :class="getStatusBadgeClass(voucher)"
                        >
                          {{ getStatusText(voucher) }}
                        </span>
                    </td>
                    <td>
                      <div class="btn-group" role="group">
                        <button
                            class="btn btn-sm btn-outline-primary"
                            @click="openEditModal(voucher)"
                            :disabled="isLoading"
                            title="Chỉnh sửa"
                        >
                          <i class="bi bi-pencil-square"></i>
                        </button>
                        <button
                            class="btn btn-sm"
                            :class="voucher.isActive ? 'btn-outline-warning' : 'btn-outline-success'"
                            @click="toggleVoucherStatus(voucher)"
                            :disabled="isLoading"
                            :title="voucher.isActive ? 'Tạm dừng' : 'Kích hoạt'"
                        >
                          <i :class="voucher.isActive ? 'bi bi-pause-fill' : 'bi bi-play-fill'"></i>
                        </button>
                        <button
                            class="btn btn-sm btn-outline-danger"
                            @click="deleteVoucher(voucher)"
                            :disabled="isLoading"
                            title="Xóa"
                        >
                          <i class="bi bi-trash3"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- Pagination -->
              <nav class="mt-4">
                <ul class="pagination justify-content-center">
                  <li class="page-item"><a class="page-link" href="#">Trước</a></li>
                  <li class="page-item active"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">Sau</a></li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal -->
      <div
          class="modal fade"
          :class="{ show: showModal, 'd-block': showModal }"
          tabindex="-1"
          v-if="showModal"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                <i class="bi bi-ticket-perforated me-2"></i>
                {{ editingVoucher ? 'Chỉnh sửa Voucher' : 'Tạo Voucher Mới' }}
              </h5>
              <button
                  type="button"
                  class="btn-close"
                  @click="showModal = false"
                  :disabled="isLoading"
              ></button>
            </div>
            <div class="modal-body">
              <form @submit.prevent="saveVoucher">
                <div class="row">
                  <!-- Mã voucher -->
                  <div class="col-md-8 mb-3">
                    <label class="form-label">
                      <i class="bi bi-tag me-1"></i>
                      Mã Voucher <span class="text-danger">*</span>
                    </label>
                    <input
                        type="text"
                        class="form-control"
                        v-model="voucherForm.code"
                        placeholder="Ví dụ: SUMMER2024"
                        :disabled="isLoading"
                        required
                    >
                  </div>
                  <div class="col-md-4 mb-3">
                    <label class="form-label">&nbsp;</label>
                    <button
                        type="button"
                        class="btn btn-outline-secondary d-block w-100"
                        @click="generateVoucherCode"
                        :disabled="isLoading"
                    >
                      <i class="bi bi-arrow-clockwise me-1"></i>
                      Tạo mã tự động
                    </button>
                  </div>

                  <!-- Tiêu đề -->
                  <div class="col-12 mb-3">
                    <label class="form-label">
                      <i class="bi bi-card-text me-1"></i>
                      Tiêu đề <span class="text-danger">*</span>
                    </label>
                    <input
                        type="text"
                        class="form-control"
                        v-model="voucherForm.title"
                        placeholder="Ví dụ: Giảm giá mùa hè"
                        :disabled="isLoading"
                        required
                    >
                  </div>

                  <!-- Mô tả -->
                  <div class="col-12 mb-3">
                    <label class="form-label">
                      <i class="bi bi-chat-left-text me-1"></i>
                      Mô tả
                    </label>
                    <textarea
                        class="form-control"
                        v-model="voucherForm.description"
                        rows="2"
                        placeholder="Mô tả chi tiết về voucher"
                        :disabled="isLoading"
                    ></textarea>
                  </div>

                  <!-- Loại giảm giá -->
                  <div class="col-md-6 mb-3">
                    <label class="form-label">
                      <i class="bi bi-percent me-1"></i>
                      Loại giảm giá
                    </label>
                    <select class="form-select" v-model="voucherForm.discountType" :disabled="isLoading">
                      <option value="percentage">Phần trăm (%)</option>
                      <option value="fixed">Số tiền cố định (VNĐ)</option>
                    </select>
                  </div>

                  <!-- Giá trị giảm giá -->
                  <div class="col-md-6 mb-3">
                    <label class="form-label">
                      <i class="bi bi-currency-dollar me-1"></i>
                      Giá trị giảm giá <span class="text-danger">*</span>
                      <small class="text-muted">
                        ({{ voucherForm.discountType === 'percentage' ? '%' : 'VNĐ' }})
                      </small>
                    </label>
                    <input
                        type="number"
                        class="form-control"
                        v-model.number="voucherForm.discountValue"
                        :min="1"
                        :max="voucherForm.discountType === 'percentage' ? 100 : undefined"
                        :disabled="isLoading"
                        required
                    >
                  </div>

                  <!-- Đơn hàng tối thiểu -->
                  <div class="col-md-6 mb-3">
                    <label class="form-label">
                      <i class="bi bi-cart-check me-1"></i>
                      Giá trị đơn hàng tối thiểu (VNĐ)
                    </label>
                    <input
                        type="number"
                        class="form-control"
                        v-model.number="voucherForm.minOrderValue"
                        min="0"
                        :disabled="isLoading"
                    >
                  </div>

                  <!-- Giảm giá tối đa -->
                  <div class="col-md-6 mb-3" v-if="voucherForm.discountType === 'percentage'">
                    <label class="form-label">
                      <i class="bi bi-arrow-up-circle me-1"></i>
                      Giảm giá tối đa (VNĐ)
                    </label>
                    <input
                        type="number"
                        class="form-control"
                        v-model.number="voucherForm.maxDiscountAmount"
                        min="0"
                        :disabled="isLoading"
                    >
                    <div class="form-text">Để trống nếu không giới hạn</div>
                  </div>

                  <!-- Giới hạn sử dụng -->
                  <div class="col-md-6 mb-3">
                    <label class="form-label">
                      <i class="bi bi-123 me-1"></i>
                      Giới hạn số lượt sử dụng
                    </label>
                    <input
                        type="number"
                        class="form-control"
                        v-model.number="voucherForm.usageLimit"
                        min="1"
                        :disabled="isLoading"
                    >
                  </div>

                  <!-- Ngày bắt đầu -->
                  <div class="col-md-6 mb-3">
                    <label class="form-label">
                      <i class="bi bi-calendar-event me-1"></i>
                      Ngày bắt đầu <span class="text-danger">*</span>
                    </label>
                    <input
                        type="date"
                        class="form-control"
                        v-model="voucherForm.startDate"
                        :disabled="isLoading"
                        required
                    >
                  </div>

                  <!-- Ngày kết thúc -->
                  <div class="col-md-6 mb-3">
                    <label class="form-label">
                      <i class="bi bi-calendar-x me-1"></i>
                      Ngày kết thúc <span class="text-danger">*</span>
                    </label>
                    <input
                        type="date"
                        class="form-control"
                        v-model="voucherForm.endDate"
                        :disabled="isLoading"
                        required
                    >
                  </div>

                  <!-- Áp dụng cho -->
                  <div class="col-12 mb-3">
                    <label class="form-label">
                      <i class="bi bi-target me-1"></i>
                      Áp dụng cho
                    </label>
                    <select class="form-select" v-model="voucherForm.applicationType" :disabled="isLoading">
                      <option value="all">Tất cả sản phẩm</option>
                      <option value="specific_products">Sản phẩm cụ thể</option>
                      <option value="specific_categories">Danh mục cụ thể</option>
                    </select>
                  </div>

                  <!-- Trạng thái -->
                  <div class="col-12 mb-3">
                    <div class="form-check">
                      <input
                          class="form-check-input"
                          type="checkbox"
                          v-model="voucherForm.isActive"
                          :disabled="isLoading"
                      >
                      <label class="form-check-label">
                        <i class="bi bi-toggle-on me-1"></i>
                        Kích hoạt voucher ngay sau khi tạo
                      </label>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button
                  type="button"
                  class="btn btn-secondary"
                  @click="showModal = false"
                  :disabled="isLoading"
              >
                <i class="bi bi-x-lg me-1"></i>
                Hủy
              </button>
              <button
                  type="button"
                  class="btn btn-primary"
                  @click="saveVoucher"
                  :disabled="isLoading"
              >
                <span v-if="isLoading" class="spinner-border spinner-border-sm me-2"></span>
                <i v-else class="bi bi-check-lg me-1"></i>
                {{ editingVoucher ? 'Cập nhật' : 'Tạo Voucher' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal backdrop -->
      <div v-if="showModal" class="modal-backdrop fade show"></div>
    </div>
  </SellerLayout>
</template>

<style scoped>
.modal {
  background-color: rgba(0, 0, 0, 0.5);
}

.progress {
  background-color: #e9ecef;
}

.table th {
  border-top: none;
  font-weight: 600;
  color: #495057;
  background-color: #f8f9fa;
}

.badge {
  font-size: 0.75rem;
}

code {
  font-size: 0.85rem;
  font-weight: 600;
}

.btn-group .btn {
  border-radius: 0.25rem;
  margin-right: 2px;
}

.card {
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  border: 1px solid rgba(0, 0, 0, 0.125);
}

.form-text {
  font-size: 0.875rem;
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

.display-4 {
  font-size: 3rem;
}
</style>
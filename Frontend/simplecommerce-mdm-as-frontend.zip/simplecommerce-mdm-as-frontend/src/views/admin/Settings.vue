
<template>
  <AdminLayout>
    <div class="mb-4">
      <h4></h4>
    </div>

    <!-- Container căn giữa -->
    <div class="row justify-content-center">
      <!-- System Configuration -->
      <div class="col-md-8 col-lg-6">
        <div class="card mb-4">
          <div class="card-header">
            <h5 class="text-center mb-0">Cấu hình chung</h5>
          </div>
          <div class="card-body">
            <form @submit.prevent="saveSettings">
              <div class="mb-3">
                <label class="form-label">Tên hệ thống</label>
                <input
                    type="text"
                    class="form-control"
                    v-model="systemConfig.systemName"
                    required
                >
              </div>
              <div class="mb-3">
                <label class="form-label">Email hỗ trợ</label>
                <input
                    type="email"
                    class="form-control"
                    v-model="systemConfig.supportEmail"
                    required
                >
              </div>
              <div class="mb-3">
                <label class="form-label">Số điện thoại hỗ trợ</label>
                <input
                    type="text"
                    class="form-control"
                    v-model="systemConfig.supportPhone"
                    required
                >
              </div>
              <div class="mb-3">
                <label class="form-label">Địa chỉ công ty</label>
                <textarea
                    class="form-control"
                    rows="3"
                    v-model="systemConfig.companyAddress"
                    required
                ></textarea>
              </div>

              <!-- Save Button inside form -->
              <div class="d-flex justify-content-center gap-2 mt-4">
                <button
                    type="button"
                    class="btn btn-secondary"
                    @click="resetSettings"
                >
                  Hủy thay đổi
                </button>
                <button
                    type="submit"
                    class="btn btn-primary"
                    :disabled="isLoading"
                >
                  <span v-if="isLoading" class="spinner-border spinner-border-sm me-2"></span>
                  Lưu cấu hình
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

  </AdminLayout>
</template>

<script setup>
import { ref } from 'vue'
import AdminLayout from '../../components/AdminLayout.vue'
import Swal from "sweetalert2"

const isLoading = ref(false)

const originalConfig = {
  systemName: 'E-commerce Platform',
  supportEmail: 'support@example.com',
  supportPhone: '1900-123-456',
  companyAddress: '123 Nguyễn Văn Linh, Quận 7, TP.HCM'
}

const systemConfig = ref({...originalConfig})

const saveSettings = async () => {
  try {
    isLoading.value = true

    // Hiển thị loading
    Swal.fire({
      title: 'Đang lưu...',
      text: 'Vui lòng chờ trong giây lát',
      allowOutsideClick: false,
      didOpen: () => {
        Swal.showLoading()
      }
    })

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))

    // Đóng loading và hiển thị thành công
    await Swal.fire({
      icon: 'success',
      title: 'Thành công!',
      text: 'Cấu hình đã được lưu thành công!',
      confirmButtonText: 'OK',
      confirmButtonColor: '#28a745'
    })

  } catch (error) {
    // Hiển thị lỗi nếu có
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Có lỗi xảy ra khi lưu cấu hình. Vui lòng thử lại!',
      confirmButtonText: 'OK',
      confirmButtonColor: '#dc3545'
    })
  } finally {
    isLoading.value = false
  }
}

const resetSettings = async () => {
  const result = await Swal.fire({
    title: 'Xác nhận',
    text: 'Bạn có chắc chắn muốn hủy tất cả thay đổi?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Có, hủy thay đổi',
    cancelButtonText: 'Không',
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d'
  })

  if (result.isConfirmed) {
    systemConfig.value = {...originalConfig}

    Swal.fire({
      icon: 'info',
      title: 'Đã hủy',
      text: 'Tất cả thay đổi đã được hủy',
      timer: 1500,
      showConfirmButton: false
    })
  }
}
</script>

<style scoped>
.card {
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  border: 1px solid rgba(0, 0, 0, 0.125);
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid rgba(0, 0, 0, 0.125);
}

.form-control:focus {
  border-color: #80bdff;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.btn {
  min-width: 120px;
}
</style>
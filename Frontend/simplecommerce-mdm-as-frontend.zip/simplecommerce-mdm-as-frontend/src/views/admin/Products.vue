<template>
  <AdminLayout>
    <!-- tổng sản phẩm -->
     <div class="row mb-4 g-3">
      <div class="col-md-3">
        <div class="card text-bg-primary">
          <div class="card-body text-center">
            <h5 class="card-title">Tổng sản phẩm</h5>
            <p class="card-text">{{ pagination.totalElements }}</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-bg-warning">
          <div class="card-body text-center">
            <h5 class="card-title">Sản phẩm chờ duyệt</h5>
            <p class="card-text">{{ products.filter(p => p.statusKey === 'PENDING_APPROVAL').length }}</p>
          </div>  
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-bg-success">
          <div class="card-body text-center">
            <h5 class="card-title">Sản phẩm đã duyệt</h5>
            <p class="card-text">{{ products.filter(p => p.statusKey === 'APPROVED').length }}</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-bg-danger">
          <div class="card-body text-center">
            <h5 class="card-title">Sản phẩm bị từ chối</h5>
            <p class="card-text">{{ products.filter(p => p.statusKey === 'REJECTED').length }}</p>
          </div>
        </div>
      </div>
    </div>
      <!-- Filters -->
    <div class="card mb-4">
      <div class="card-body">
        <div class="row">
          <div class="col-md-3">
            <select class="form-select" v-model="filters.status" @change="loadProducts">
              <option v-for="option in statusOptions" :key="option.value" :value="option.value">
                {{ option.label }}
              </option>
            </select>
          </div>
      
          <div class="col-md-6">
            <input type="text" class="form-control" placeholder="Tìm kiếm sản phẩm..." v-model="filters.searchTerm"
              @keyup.enter="loadProducts">
          </div>
          <div class="col-md-2">
            <button class="btn btn-success w-100" @click="loadProducts" :disabled="loading">
              <span v-if="loading" class="spinner-border spinner-border-sm me-1"></span>
              Tìm kiếm
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Products Table -->
    <div class="card">
      <div class="card-body">
        <div v-if="loading && products.length === 0" class="text-center py-4">
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
          <p class="mt-2">Đang tải danh sách sản phẩm...</p>
        </div>

        <div v-else-if="products.length === 0" class="text-center py-4">
          <i class="bi bi-inbox h1 text-muted"></i>
          <p class="text-muted">Không tìm thấy sản phẩm nào</p>
        </div>

        <div v-else>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>Sản phẩm</th>
                  <th>Seller</th>
                  <th>Giá</th>
                  <th>Tồn kho</th>
                  <th>Trạng thái</th>
                  <th>Ngày tạo</th>
                  <th>Thao tác</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="product in products" :key="product.id">
                  <td>
                    <div class="d-flex align-items-center">
                      <img :src="product.image" alt="" class="rounded me-2"
                        style="width: 60px; height: 60px; object-fit: cover;">
                      <div>
                        <strong>{{ product.name }}</strong><br>
                        <small class="text-muted">{{ product.sku || 'N/A' }}</small>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div>
                      {{ product.seller }}
                      <br>
                      <small class="text-muted">{{ product.sellerEmail }}</small>
                    </div>
                  </td>
                  <td>
                    <div v-if="product.priceRange && product.hasVariants">
                      {{ product.priceRange.display }}
                    </div>
                    <div v-else>
                      {{ formatCurrency(product.price) }}
                    </div>
                  </td>
                  <td>{{ product.stock }}</td>
                  <td>
                    <span :class="`badge bg-${product.statusColor}`">{{ product.status }}</span>
                  </td>
                  <td>{{ product.createdAt }}</td>
                  <td>
                    <div class="btn-group btn-group-sm ">
                      <button class="btn btn-outline-primary" @click="viewProduct(product)">
                        <i class="bi bi-eye"></i> Xem
                      </button>
                      <button v-if="product.statusKey === 'PENDING_APPROVAL'" class="btn btn-outline-success ms-1"
                        @click="showApprovalModal(product)" :disabled="actionLoading">
                        <i class="bi bi-check-circle"></i> Duyệt
                      </button>
                      <button v-if="product.statusKey === 'PENDING_APPROVAL'" class="btn btn-outline-danger ms-1"
                        @click="showRejectModal(product)" :disabled="actionLoading">
                        <i class="bi bi-x-circle"></i> Từ chối
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Pagination -->
          <nav class="mt-4" v-if="pagination.totalPages > 1">
            <ul class="pagination justify-content-center">
              <li class="page-item" :class="{ disabled: pagination.currentPage === 0 }">
                <button class="page-link" @click="changePage(pagination.currentPage - 1)">Trước</button>
              </li>
              <li v-for="page in visiblePages" :key="page" class="page-item"
                :class="{ active: page === pagination.currentPage }">
                <button class="page-link" @click="changePage(page)">{{ page + 1 }}</button>
              </li>
              <li class="page-item" :class="{ disabled: pagination.currentPage >= pagination.totalPages - 1 }">
                <button class="page-link" @click="changePage(pagination.currentPage + 1)">Sau</button>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>

    <!-- Product Detail Modal -->
    <ProductDetailModal v-if="selectedProduct" :show="showDetail" :product="selectedProduct" @close="showDetail = false"
      @approve="showApprovalModal" @reject="showRejectModal" @block="showBlockModal" @unblock="unblockProduct" />

    <!-- Approval Modal -->
    <ActionModal v-if="selectedProduct" :show="showApproval" title="Duyệt sản phẩm"
      :message="`Bạn có chắc chắn muốn duyệt sản phẩm '${selectedProduct.name}'?`" confirm-text="Xác nhận duyệt"
      confirm-class="btn-success" :show-note="true" note-label="Ghi chú duyệt (tùy chọn)"
      note-placeholder="Nhập ghi chú duyệt..." v-model:note="actionNote" @close="closeApprovalModal"
      @confirm="approveProduct" :loading="actionLoading" />

    <!-- Reject Modal -->
    <ActionModal v-if="selectedProduct" :show="showReject" title="Từ chối sản phẩm"
      :message="`Bạn có chắc chắn muốn từ chối sản phẩm '${selectedProduct.name}'?`" confirm-text="Xác nhận từ chối"
      confirm-class="btn-danger" :show-reason="true" reason-label="Lý do từ chối"
      reason-placeholder="Chọn lý do từ chối" :reason-options="rejectReasons" v-model:reason="actionReason"
      :show-note="true" note-label="Ghi chú thêm" note-placeholder="Nhập ghi chú thêm..." v-model:note="actionNote"
      @close="closeRejectModal" @confirm="rejectProduct" :loading="actionLoading" />

    <!-- Block Modal -->
    <ActionModal v-if="selectedProduct" :show="showBlock" title="Khóa sản phẩm"
      :message="`Bạn có chắc chắn muốn khóa sản phẩm '${selectedProduct.name}'?`" confirm-text="Xác nhận khóa"
      confirm-class="btn-warning" :show-reason="true" reason-label="Lý do khóa" reason-placeholder="Chọn lý do khóa"
      :reason-options="blockReasons" v-model:reason="actionReason" :show-note="true" note-label="Ghi chú thêm"
      note-placeholder="Nhập ghi chú thêm..." v-model:note="actionNote" @close="closeBlockModal" @confirm="blockProduct"
      :loading="actionLoading" />
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import AdminLayout from '@/components/AdminLayout.vue'
import ProductDetailModal from '@/components/admin/ProductDetailModal.vue'
import ActionModal from '@/components/admin/ActionModal.vue'
import productAdminService from '@/services/admin/product'
import Swal from 'sweetalert2'

// Reactive data
const products = ref([])
const selectedProduct = ref(null)
const loading = ref(false)
const actionLoading = ref(false)

// Modal states
const showDetail = ref(false)
const showApproval = ref(false)
const showReject = ref(false)
const showBlock = ref(false)

// Action data
const actionNote = ref('')
const actionReason = ref('')

// Filters
const filters = ref({
  searchTerm: '',
  status: '',
  sellerEmail: '',
  page: 0,
  size: 4,
  sortBy: 'createdAt',
  sortDirection: 'desc'
})

// Pagination - Updated to match new API response structure
const pagination = ref({
  currentPage: 0,
  totalPages: 0,
  totalElements: 0,
  size: 4
})

// Options
const statusOptions = ref(productAdminService.getStatusOptions())

const rejectReasons = [
  { value: 'Không đúng danh mục', label: 'Không đúng danh mục' },
  { value: 'Thông tin không đầy đủ', label: 'Thông tin không đầy đủ' },
  { value: 'Hình ảnh kém chất lượng', label: 'Hình ảnh kém chất lượng' },
  { value: 'Giá không hợp lý', label: 'Giá không hợp lý' },
  { value: 'Vi phạm chính sách', label: 'Vi phạm chính sách' },
  { value: 'Sản phẩm cấm', label: 'Sản phẩm cấm' },
  { value: 'Khác', label: 'Khác' }
]

const blockReasons = [
  { value: 'Chất lượng kém', label: 'Chất lượng kém' },
  { value: 'Không đúng mô tả', label: 'Không đúng mô tả' },
  { value: 'Hàng giả', label: 'Hàng giả' },
  { value: 'Vi phạm chính sách', label: 'Vi phạm chính sách' },
  { value: 'Khác', label: 'Khác' }
]

// Computed
const visiblePages = computed(() => {
  const current = pagination.value.currentPage
  const total = pagination.value.totalPages
  const delta = 2

  let start = Math.max(0, current - delta)
  let end = Math.min(total - 1, current + delta)

  const pages = []
  for (let i = start; i <= end; i++) {
    pages.push(i)
  }
  return pages
})

// Methods
const loadProducts = async () => {
  try {
    loading.value = true
    const response = await productAdminService.getAllProducts(filters.value)

    if (response.success && response.data) {
      products.value = response.data.content || []

      // Updated pagination mapping for new API structure
      pagination.value = {
        currentPage: response.data.number || 0,
        totalPages: response.data.totalPages || 0,
        totalElements: response.data.totalElements || 0,
        size: response.data.size || 20
      }
    } else {
      throw new Error(response.message || 'Không thể tải danh sách sản phẩm')
    }
  } catch (error) {
    showError('Không thể tải danh sách sản phẩm', error.message)
    products.value = []
  } finally {
    loading.value = false
  }
}

const changePage = (page) => {
  if (page >= 0 && page < pagination.value.totalPages) {
    filters.value.page = page
    loadProducts()
  }
}

const viewProduct = (product) => {
  selectedProduct.value = product
  showDetail.value = true
}

const showApprovalModal = (product) => {
  selectedProduct.value = product
  actionNote.value = ''
  showApproval.value = true
}

const showRejectModal = (product) => {
  selectedProduct.value = product
  actionReason.value = ''
  actionNote.value = ''
  showReject.value = true
}

const closeApprovalModal = () => {
  showApproval.value = false
  actionNote.value = ''
}

const closeRejectModal = () => {
  showReject.value = false
  actionReason.value = ''
  actionNote.value = ''
}

const approveProduct = async () => {
  try {
    actionLoading.value = true
    const response = await productAdminService.approveProduct(selectedProduct.value.id, actionNote.value)

    if (response.success) {
      closeApprovalModal()
      showSuccess('Sản phẩm đã được duyệt thành công')
      await loadProducts()
    } else {
      throw new Error(response.message || 'Không thể duyệt sản phẩm')
    }
  } catch (error) {
    showError('Không thể duyệt sản phẩm', error.message)
  } finally {
    actionLoading.value = false
  }
}

const rejectProduct = async () => {
  try {
    actionLoading.value = true
    const response = await productAdminService.rejectProduct(
      selectedProduct.value.id,
      actionReason.value,
      actionNote.value
    )

    if (response.success) {
      closeRejectModal()
      showSuccess('Sản phẩm đã được từ chối')
      await loadProducts()
    } else {
      throw new Error(response.message || 'Không thể từ chối sản phẩm')
    }
  } catch (error) {
    showError('Không thể từ chối sản phẩm', error.message)
  } finally {
    actionLoading.value = false
  }
}

const formatCurrency = (amount) => {
  return productAdminService.formatCurrency(amount)
}

const showSuccess = (message) => {
  Swal.fire({
    title: 'Thành công!',
    text: message,
    icon: 'success',
    timer: 2000,
    showConfirmButton: false
  })
}

const showError = (title, text = '') => {
  Swal.fire({
    title: title,
    text: text,
    icon: 'error'
  })
}

// Lifecycle
onMounted(() => {
  loadProducts()
})
</script>
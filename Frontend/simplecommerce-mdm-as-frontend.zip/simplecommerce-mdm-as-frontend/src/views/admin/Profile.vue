<template>
  <AdminLayout>
    <div class="container-fluid">
      <!-- Header -->
      <div class="row mb-2 mt-3">
        <div class="col-12">
          <h2 class="text-center mb-0">Thông tin cá nhân</h2>
          <p class="text-center text-muted">Quản lý thông tin tài khoản của bạn</p>
        </div>
      </div>

      <!-- Loading State -->
      <div v-if="isLoadingProfile" class="text-center py-5">
        <div class="spinner-border text-primary mb-3" role="status">
          <span class="visually-hidden">Đang tải...</span>
        </div>
        <p class="text-muted">Đang tải thông tin cá nhân...</p>
      </div>

      <!-- Error State -->
      <div v-else-if="loadError" class="row justify-content-center">
        <div class="col-md-6">
          <div class="alert alert-danger text-center">
            <i class="fas fa-exclamation-triangle mb-2 fs-2"></i>
            <h5>Không thể tải thông tin cá nhân</h5>
            <p class="mb-3">{{ loadError }}</p>
            <button class="btn btn-outline-danger" @click="loadUserProfile">
              <i class="fas fa-redo me-1"></i>
              Thử lại
            </button>
          </div>
        </div>
      </div>

      <!-- Profile Content -->
      <div v-else class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
          <!-- Avatar Section -->
          <div class="card mb-4">
            <div class="card-body text-center">
              <div class="position-relative d-inline-block mb-3">
                <div class="avatar-container" @click="triggerFileInput">
                  <img 
                    :src="displayAvatar" 
                    :alt="`Avatar của ${userProfile.fullName}`" 
                    class="rounded-circle avatar-img"
                    @error="handleImageError">
                  <div class="avatar-overlay">
                    <i class="fas fa-camera"></i>
                    <small>Thay đổi</small>
                  </div>
                </div>
                <input
                    ref="fileInput"
                    type="file"
                    accept="image/*"
                    @change="handleAvatarChange"
                    style="display: none"
                >
              </div>
              <h4 class="mb-1">{{ userProfile.lastName || 'Chưa có tên' }}</h4>
              <p class="text-muted mb-2">{{ userProfile.email }}</p>
              <div v-if="userProfile.phoneNumber" class="text-muted small">
                <i class="fas fa-phone me-1"></i>
                {{ formatPhoneDisplay(userProfile.phoneNumber) }}
              </div>
            </div>
          </div>

          <!-- Profile Form -->
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-user me-2"></i>
                Thông tin cá nhân
                <small class="text-muted ms-2" v-if="hasUnsavedChanges">
                  (có thay đổi chưa lưu)
                </small>
              </h5>
            </div>
            <div class="card-body">
              <form @submit.prevent="updateProfile">
                <!-- Basic Information -->
                <div class="row">
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">
                        <i class="fas fa-user me-1"></i>
                        Họ <span class="text-danger">*</span>
                      </label>
                      <input type="text" class="form-control" v-model="profileForm.firstName"
                          @input="markAsChanged"
                          :class="{ 'is-invalid': errors.firstName }"
                          :disabled="isUpdating"
                          required
                          maxlength="50"
                          placeholder="Nhập họ của bạn"
                      >
                      <div v-if="errors.firstName" class="invalid-feedback">
                        {{ errors.firstName }}
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">
                        <i class="fas fa-user me-1"></i>
                        Tên <span class="text-danger">*</span>
                      </label>
                      <input
                          type="text"
                          class="form-control"
                          v-model="profileForm.lastName"
                          @input="markAsChanged"
                          :class="{ 'is-invalid': errors.lastName }"
                          :disabled="isUpdating"
                          required
                          maxlength="50"
                          placeholder="Nhập tên của bạn"
                      >
                      <div v-if="errors.lastName" class="invalid-feedback">
                        {{ errors.lastName }}
                      </div>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">
                        <i class="fas fa-envelope me-1"></i>
                        Email
                      </label>
                      <input
                          type="email"
                          class="form-control"
                          :value="userProfile.email"
                          disabled
                          readonly
                      >
                      <small class="form-text text-muted">
                        Email không thể thay đổi
                      </small>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">
                        <i class="fas fa-phone me-1"></i>
                        Số điện thoại
                      </label>
                      <input
                          type="text"
                          class="form-control"
                          :value="formatPhoneDisplay(userProfile.phoneNumber)"
                          disabled
                          readonly
                      >
                      <div v-if="errors.phoneNumber" class="invalid-feedback">
                        {{ errors.phoneNumber }}
                      </div>
                      <small class="form-text text-muted">
                        Số điện thoại không thể thay đổi
                      </small>
                    </div>
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label">
                    <i class="fas fa-info-circle me-1"></i>
                    Thông tin bổ sung
                  </label>
                  <textarea
                      class="form-control"
                      rows="3"
                      v-model="profileForm.metadata"
                      @input="markAsChanged"
                      :disabled="isUpdating"
                      maxlength="500"
                      placeholder="Nhập thông tin bổ sung về bản thân..."
                  ></textarea>
                  <small class="form-text text-muted">
                    Tối đa 500 ký tự
                  </small>
                </div>

                <!-- Action Buttons -->
                <div class="d-flex justify-content-center gap-3 mt-4">
                  <button
                      type="button"
                      class="btn btn-outline-secondary"
                      @click="resetForm"
                      :disabled="isUpdating || !hasUnsavedChanges"
                  >
                    <i class="fas fa-undo me-1"></i>
                    Hủy thay đổi
                  </button>
                  <button
                      type="submit"
                      class="btn btn-primary"
                      :disabled="isUpdating || !hasUnsavedChanges"
                  >
                    <span v-if="isUpdating" class="spinner-border spinner-border-sm me-2"></span>
                    <i v-else class="fas fa-save me-1"></i>
                    {{ isUpdating ? 'Đang cập nhật...' : 'Cập nhật thông tin' }}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import AdminLayout from "@/components/AdminLayout.vue"
import { profileService, profileUtils } from '@/services/auth/profile.js'
import { useAuthStore } from '@/stores/auth.js'
import Swal from "sweetalert2"

// Store
const authStore = useAuthStore()

// Component state
const isLoadingProfile = ref(false)
const isUpdating = ref(false)
const loadError = ref(null)
const fileInput = ref(null)
const selectedAvatarFile = ref(null)
const hasChanged = ref(false)

// User profile data
const userProfile = ref({
  uuid: null,
  fullName: '',
  firstName: '',
  lastName: '',
  email: '',
  phoneNumber: '',
  avatarUrl: null,
  metadata: null
})

// Original data for comparison
const originalProfile = ref({})

// Form data
const profileForm = reactive({
  firstName: '',
  lastName: '',
  phoneNumber: '',
  metadata: ''
})

// Form validation errors
const errors = reactive({})

// Computed properties
const displayAvatar = computed(() => {
  if (selectedAvatarFile.value) {
    return URL.createObjectURL(selectedAvatarFile.value)
  }
  return userProfile.value.avatarUrl || '/src/assets/logoMuadima2.png'
})

const hasUnsavedChanges = computed(() => {
  return hasChanged.value || selectedAvatarFile.value !== null
})

// Methods
const loadUserProfile = async () => {
  isLoadingProfile.value = true
  loadError.value = null

  try {
    const result = await profileService.getCurrentUserProfile()

    if (result.success) {
      const formattedData = profileService.formatUserData(result.data)
      userProfile.value = formattedData
      
      // Store original data
      originalProfile.value = { ...formattedData }
      
      // Initialize form
      initializeForm(formattedData)
      
      //console.log('User profile loaded successfully:', formattedData)
    } else {
      loadError.value = result.message
      console.error('Failed to load user profile:', result.message)
    }
  } catch (error) {
    loadError.value = 'Lỗi kết nối. Vui lòng thử lại sau.'
    console.error('Error loading user profile:', error)
  } finally {
    isLoadingProfile.value = false
  }
}

const initializeForm = (profileData) => {
  profileForm.firstName = profileData.firstName || ''
  profileForm.lastName = profileData.lastName || ''
  profileForm.phoneNumber = profileData.phoneNumber || ''
  profileForm.metadata = profileData.metadata || ''
  
  hasChanged.value = false
  selectedAvatarFile.value = null
}

const markAsChanged = () => {
  hasChanged.value = true
  clearErrors()
}

const clearErrors = () => {
  Object.keys(errors).forEach(key => delete errors[key])
}

const validateForm = () => {
  clearErrors()
  
  const validation = profileService.validateProfileData(profileForm)
  
  if (!validation.isValid) {
    Object.assign(errors, validation.errors)
  }
  
  return validation.isValid
}

const updateProfile = async () => {
  if (!validateForm()) {
    return
  }

  isUpdating.value = true

  try {
    Swal.fire({
      title: 'Đang cập nhật...',
      text: 'Vui lòng chờ trong giây lát',
      allowOutsideClick: false,
      didOpen: () => {
        Swal.showLoading()
      }
    })

    const updateData = profileService.prepareUpdateData(profileForm)
    
    let result
    if (selectedAvatarFile.value) {
      // Update với avatar
      result = await profileService.updateProfileWithAvatar(updateData, selectedAvatarFile.value)
    } else {
      // Update chỉ thông tin
      result = await profileService.updateProfile(updateData)
    }

    if (result.success) {
      // Cập nhật dữ liệu local
      const updatedData = profileService.formatUserData(result.data)
      userProfile.value = updatedData
      originalProfile.value = { ...updatedData }
      
      // Reset form state
      initializeForm(updatedData)
      
      await Swal.fire({
        icon: 'success',
        title: 'Thành công!',
        text: result.message,
        confirmButtonText: 'OK',
        confirmButtonColor: '#28a745'
      })
    } else {
      await Swal.fire({
        icon: 'error',
        title: 'Lỗi!',
        text: result.message,
        confirmButtonText: 'OK',
        confirmButtonColor: '#dc3545'
      })
    }
  } catch (error) {
    console.error('Error updating profile:', error)
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Có lỗi xảy ra khi cập nhật thông tin!',
      confirmButtonText: 'OK',
      confirmButtonColor: '#dc3545'
    })
  } finally {
    isUpdating.value = false
  }
}

const resetForm = async () => {
  if (!hasUnsavedChanges.value) return

  const result = await Swal.fire({
    title: 'Xác nhận',
    text: 'Bạn có chắc chắn muốn hủy tất cả thay đổi?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Có, hủy thay đổi',
    cancelButtonText: 'Không',
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d'
  })

  if (result.isConfirmed) {
    initializeForm(originalProfile.value)
    
    Swal.fire({
      icon: 'info',
      title: 'Đã hủy',
      text: 'Tất cả thay đổi đã được hủy',
      timer: 1500,
      showConfirmButton: false
    })
  }
}

const triggerFileInput = () => {
  if (!isUpdating.value) {
    fileInput.value.click()
  }
}

const handleAvatarChange = async (event) => {
  const file = event.target.files[0]
  if (!file) return

  // Validate file
  const validation = await profileUtils.validateAvatarFile(file)
  
  if (!validation.isValid) {
    Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: validation.errors.join('\n'),
      confirmButtonColor: '#dc3545'
    })
    return
  }

  selectedAvatarFile.value = file
  markAsChanged()

  Swal.fire({
    icon: 'success',
    title: 'Avatar đã chọn!',
    text: 'Nhấn "Cập nhật thông tin" để lưu thay đổi',
    timer: 2000,
    showConfirmButton: false
  })
}

const handleImageError = (event) => {
  event.target.src = '/src/assets/logoMuadima2.png'
}

const formatPhoneDisplay = (phone) => {
  return profileUtils.formatPhoneNumber(phone)
}

// Watch for route changes to reload profile
watch(() => authStore.user, (newUser) => {
  if (newUser) {
    loadUserProfile()
  }
}, { immediate: false })

// Lifecycle
onMounted(() => {
  if (authStore.isAuthenticated) {
    loadUserProfile()
  } else {
    loadError.value = 'Bạn cần đăng nhập để xem thông tin cá nhân'
  }
})
</script>

<style scoped>
.avatar-container {
  position: relative;
  cursor: pointer;
  display: inline-block;
}

.avatar-img {
  width: 120px;
  height: 120px;
  object-fit: cover;
  border: 4px solid #fff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  transition: opacity 0.3s ease;
}

.avatar-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.avatar-container:hover .avatar-overlay {
  opacity: 1;
}

.avatar-container:hover .avatar-img {
  opacity: 0.8;
}

.card {
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  border: 1px solid rgba(0, 0, 0, 0.125);
  transition: box-shadow 0.15s ease-in-out;
}

.card:hover {
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid rgba(0, 0, 0, 0.125);
}

.form-control:focus {
  border-color: #80bdff;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.form-control:disabled {
  background-color: #f8f9fa;
  border-color: #dee2e6;
  opacity: 0.8;
}

.btn {
  min-width: 140px;
}

.text-danger {
  color: #dc3545 !important;
}

.is-invalid {
  border-color: #dc3545;
}

.invalid-feedback {
  display: block;
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

.form-text {
  font-size: 0.875em;
  margin-top: 0.25rem;
}

@media (max-width: 768px) {
  .avatar-img {
    width: 100px;
    height: 100px;
  }
  
  .btn {
    min-width: 120px;
    margin-bottom: 0.5rem;
  }
}
</style>
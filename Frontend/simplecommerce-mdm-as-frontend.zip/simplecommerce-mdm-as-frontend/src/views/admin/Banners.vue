<template>
  <AdminLayout>
    <div class="container-fluid py-4">
      <!-- Header với thống kê tổng quan -->
      <!-- <div class="row mb-4">
        <div class="col-12">
          <div class="card border-0 shadow-sm">
            <div class="card-body">
              <h4 class="card-title mb-3">
                <i class="bi bi-star-fill text-warning me-2"></i>
                Quản lý Đánh giá
              </h4>
              
              <div class="row text-center" v-if="statistics">
                <div class="col-md-3">
                  <div class="bg-light p-3 rounded">
                    <h5 class="mb-1">{{ statistics.totalReviews || 0 }}</h5>
                    <small class="text-muted">Tổng đánh giá</small>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="bg-light p-3 rounded">
                    <h5 class="mb-1">{{ statistics.averageRating?.toFixed(1) || '0.0' }}</h5>
                    <small class="text-muted">Điểm trung bình</small>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="bg-light p-3 rounded">
                    <h5 class="mb-1">{{ pendingCount }}</h5>
                    <small class="text-muted">Chờ duyệt</small>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="bg-light p-3 rounded">
                    <h5 class="mb-1">{{ reportedCount }}</h5>
                    <small class="text-muted">Bị báo cáo</small>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> -->

      <!-- Filter Tabs -->
      <div class="row mb-4">
        <div class="col-12">
          <ul class="nav nav-pills mb-3">
            <li class="nav-item">
              <button class="nav-link" :class="{ active: currentTab === 'all' }" @click="changeTab('all')">
                Tất cả
              </button>
            </li>
            <li class="nav-item">
              <button class="nav-link position-relative" :class="{ active: currentTab === 'pending' }"
                @click="changeTab('pending')">
                Chờ duyệt
                <span v-if="pendingCount > 0"
                  class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  {{ pendingCount }}
                </span>
              </button>
            </li>
            <li class="nav-item">
              <button class="nav-link position-relative" :class="{ active: currentTab === 'reported' }"
                @click="changeTab('reported')">
                Bị báo cáo
                <span v-if="reportedCount > 0"
                  class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  {{ reportedCount }}
                </span>
              </button>
            </li>
          </ul>
        </div>
      </div>

      <!-- Reviews Table -->
      <div class="row">
        <div class="col-12">
          <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
              <h6 class="mb-0">Danh sách đánh giá</h6>

              <!-- Sort options -->
              <div class="d-flex align-items-center gap-2">
                <select v-model="sortBy" @change="fetchReviews" class="form-select form-select-sm">
                  <option value="createdAt">Ngày tạo</option>
                  <option value="rating">Điểm đánh giá</option>
                  <!-- <option value="userName">Tên người dùng</option>
                  <option value="productName">Tên sản phẩm</option> -->
                </select>

                <select v-model="sortDir" @change="fetchReviews" class="form-select form-select-sm">
                  <option value="desc">Giảm dần</option>
                  <option value="asc">Tăng dần</option>
                </select>
              </div>
            </div>

            <div class="card-body">
              <!-- Loading -->
              <div v-if="loading" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div>
              </div>

              <!-- Reviews List -->
              <div v-else-if="reviews.length > 0">
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="table-light">
                      <tr>
                        <th>ID</th>
                        <th>Người dùng</th>
                        <th>Sản phẩm</th>
                        <th>Đánh giá</th>
                        <th>Bình luận</th>
                        <th>Trạng thái</th>
                        <th>Ngày tạo</th>
                        <th>Thao tác</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="review in reviews" :key="review.id">
                        <td>{{ review.id }}</td>
                        <td>
                          <div>
                            <strong>{{ review.userName }}</strong>
                            <br>
                            <small class="text-muted">{{ review.userEmail }}</small>
                            <br>
                            <span v-if="review.isVerifiedPurchase" class="badge bg-success">
                              <i class="bi bi-check-circle me-1"></i>Đã mua
                            </span>
                          </div>
                        </td>
                        <td>
                          <span class="fw-medium">{{ review.productName }}</span>
                          <br>
                          <small class="text-muted">ID: {{ review.productId }}</small>
                        </td>
                        <td>
                          <div class="d-flex align-items-center">
                            <span class="me-2">{{ review.rating }}</span>
                            <div>
                              <i v-for="i in 5" :key="i" class="bi"
                                :class="i <= review.rating ? 'bi-star-fill text-warning' : 'bi-star text-muted'"></i>
                            </div>
                          </div>
                        </td>
                        <td>
                          <div class="text-truncate" style="max-width: 200px;" :title="review.comment">
                            {{ review.comment }}
                          </div>
                        </td>
                        <td>
                          <div class="d-flex flex-column gap-1">
                            <span v-if="review.isApproved === true" class="badge bg-success">
                              Đã duyệt
                            </span>
                            <span v-else-if="review.isApproved === false" class="badge bg-danger">
                              Từ chối
                            </span>
                            <span v-else class="badge bg-warning">
                              Chờ duyệt
                            </span>

                            <span v-if="review.isReported" class="badge bg-warning">
                              <i class="bi bi-exclamation-triangle me-1"></i>Báo cáo
                            </span>
                          </div>
                        </td>
                        <td>
                          {{ formatDate(review.createdAt) }}
                        </td>
                        <td>
                          <div class="btn-group-sm">
                            <button @click="viewReviewDetails(review)" class="btn btn-outline-info btn-sm">
                              <i class="bi bi-eye"></i> Xem
                            </button>

                            <button v-if="review.isApproved !== true" @click="approveReview(review.id)"
                              class="btn btn-outline-success btn-sm m-1" :disabled="moderating === review.id">
                              <i class="bi bi-check"></i> Duyệt
                            </button>

                            <button v-if="review.isApproved !== false" @click="rejectReview(review.id)"
                              class="btn btn-outline-warning btn-sm m-1" :disabled="moderating === review.id">
                              <i class="bi bi-x"></i> Từ chối
                            </button>

                            <button @click="deleteReview(review.id)" class="btn btn-outline-danger btn-sm"
                              :disabled="deleting === review.id">
                              <i class="bi bi-trash"></i> Xóa
                            </button>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <!-- Pagination -->
                <nav v-if="totalPages > 1" class="mt-4">
                  <ul class="pagination justify-content-center">
                    <li class="page-item" :class="{ disabled: currentPage === 0 }">
                      <button class="page-link" @click="changePage(currentPage - 1)" :disabled="currentPage === 0">
                        Trước
                      </button>
                    </li>

                    <li v-for="page in visiblePages" :key="page" class="page-item"
                      :class="{ active: page === currentPage }">
                      <button class="page-link" @click="changePage(page)">
                        {{ page + 1 }}
                      </button>
                    </li>

                    <li class="page-item" :class="{ disabled: currentPage === totalPages - 1 }">
                      <button class="page-link" @click="changePage(currentPage + 1)"
                        :disabled="currentPage === totalPages - 1">
                        Sau
                      </button>
                    </li>
                  </ul>
                </nav>
              </div>

              <!-- Empty State -->
              <div v-else class="text-center py-5">
                <i class="bi bi-inbox display-1 text-muted"></i>
                <h5 class="mt-3 text-muted">Không có đánh giá nào</h5>
                <p class="text-muted">Chưa có đánh giá nào trong danh mục này</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Review Details Modal -->
    <div v-if="selectedReview" class="modal fade show d-block" tabindex="-1" role="dialog"
      style="background-color: rgba(0,0,0,0.5);">
      <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
          <!-- Modal Header với gradient -->
          <div class="modal-header bg-gradient-warning text-white">
            <h5 class="modal-title">
              <i class="bi bi-star-fill me-2"></i>
              Chi tiết đánh giá #{{ selectedReview.id }}
            </h5>
            <button type="button" class="btn-close btn-close-white" @click="selectedReview = null"></button>
          </div>

          <!-- Modal Body được thiết kế lại -->
          <div class="modal-body">
            <!-- Card thông tin chung -->
            <div class="card mb-4 shadow-sm">
              <div class="card-header bg-light">
                <h6 class="mb-0">
                  <i class="bi bi-info-circle me-2"></i>
                  Thông tin chung
                </h6>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label text-muted small mb-1">Trạng thái</label>
                    <div>
                      <span v-if="selectedReview.isApproved === true" class="badge bg-success">
                        <i class="bi bi-check-circle me-1"></i>Đã duyệt
                      </span>
                      <span v-else-if="selectedReview.isApproved === false" class="badge bg-danger">
                        <i class="bi bi-x-circle me-1"></i>Từ chối
                      </span>
                      <span v-else class="badge bg-warning">
                        <i class="bi bi-clock me-1"></i>Chờ duyệt
                      </span>

                      <span v-if="selectedReview.isReported" class="badge bg-warning ms-2">
                        <i class="bi bi-exclamation-triangle me-1"></i>Bị báo cáo
                      </span>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label class="form-label text-muted small mb-1">Xác minh mua hàng</label>
                    <p class="mb-0">
                      <span :class="selectedReview.isVerifiedPurchase ? 'text-success' : 'text-danger'">
                        <i class="bi"
                          :class="selectedReview.isVerifiedPurchase ? 'bi-check-circle-fill' : 'bi-x-circle-fill'"></i>
                        {{ selectedReview.isVerifiedPurchase ? 'Đã xác minh' : 'Chưa xác minh' }}
                      </span>
                    </p>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label text-muted small mb-1">Ngày tạo</label>
                    <p class="mb-0">
                      <i class="bi bi-calendar-plus me-1 text-muted"></i>
                      {{ formatDate(selectedReview.createdAt) }}
                    </p>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label text-muted small mb-1">Cập nhật lần cuối</label>
                    <p class="mb-0">
                      <i class="bi bi-calendar-check me-1 text-muted"></i>
                      {{ formatDate(selectedReview.updatedAt) }}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Card đánh giá chi tiết -->
            <div class="card mb-4 shadow-sm">
              <div class="card-header bg-light">
                <h6 class="mb-0">
                  <i class="bi bi-chat-square-text me-2"></i>
                  Nội dung đánh giá
                </h6>
              </div>
              <div class="card-body">
                <div class="d-flex align-items-start mb-4">
                  <div class="flex-shrink-0">
                    <div class="bg-warning rounded-circle p-3 text-white">
                      <i class="bi bi-star-fill" style="font-size: 1.5rem;"></i>
                    </div>
                  </div>
                  <div class="flex-grow-1 ms-3">
                    <h4 class="fw-bold mb-1">{{ selectedReview.rating }}/5</h4>
                    <div class="mb-3">
                      <i v-for="i in 5" :key="i" class="bi me-1" style="font-size: 1.2rem;"
                        :class="i <= selectedReview.rating ? 'bi-star-fill text-warning' : 'bi-star text-muted'"></i>
                    </div>
                    <div class="bg-light p-3 rounded">
                      <p class="mb-0 fst-italic">"{{ selectedReview.comment }}"</p>
                    </div>
                  </div>
                </div>

                <div v-if="selectedReview.moderatorNotes" class="mt-3">
                  <label class="form-label text-muted small mb-1">Ghi chú của quản trị viên</label>
                  <div class="alert alert-info py-2">
                    <i class="bi bi-info-circle me-1"></i>
                    {{ selectedReview.moderatorNotes }}
                  </div>
                </div>
              </div>
            </div>

            <!-- Card thông tin người dùng -->
            <div class="card mb-4 shadow-sm">
              <div class="card-header bg-light">
                <h6 class="mb-0">
                  <i class="bi bi-person-circle me-2"></i>
                  Thông tin người dùng
                </h6>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label text-muted small mb-1">Họ tên</label>
                    <p class="fw-semibold mb-0">{{ selectedReview.userName }}</p>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label class="form-label text-muted small mb-1">Email</label>
                    <p class="mb-0">
                      <a :href="`mailto:${selectedReview.userEmail}`" class="text-decoration-none">
                        <i class="bi bi-envelope me-1"></i>
                        {{ selectedReview.userEmail }}
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Card thông tin sản phẩm -->
            <div class="card mb-4 shadow-sm">
              <div class="card-header bg-light">
                <h6 class="mb-0">
                  <i class="bi bi-box me-2"></i>
                  Thông tin sản phẩm
                </h6>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-8 mb-3">
                    <label class="form-label text-muted small mb-1">Tên sản phẩm</label>
                    <p class="fw-semibold mb-0">{{ selectedReview.productName }}</p>
                  </div>
                  <div class="col-md-4 mb-3">
                    <label class="form-label text-muted small mb-1">Mã sản phẩm</label>
                    <p class="mb-0">
                      <span class="badge bg-secondary">{{ selectedReview.productId }}</span>
                    </p>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label text-muted small mb-1">Mã đơn hàng</label>
                    <p class="mb-0">
                      <span class="badge bg-info text-dark">{{ selectedReview.orderId || 'Không có' }}</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Modal Footer với các nút hành động -->
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" @click="selectedReview = null">
              <i class="bi bi-x-circle me-1"></i> Đóng
            </button>

            <div class="btn-group" v-if="!selectedReview.isApproved">
              <button v-if="selectedReview.isApproved !== true" @click="approveReview(selectedReview.id)"
                class="btn btn-success" :disabled="moderating === selectedReview.id">
                <i class="bi bi-check-circle me-1"></i> Duyệt
              </button>

              <button v-if="selectedReview.isApproved !== false" @click="rejectReview(selectedReview.id)"
                class="btn btn-warning" :disabled="moderating === selectedReview.id">
                <i class="bi bi-x-circle me-1"></i> Từ chối
              </button>
            </div>

            <button @click="deleteReview(selectedReview.id)" class="btn btn-danger"
              :disabled="deleting === selectedReview.id">
              <i class="bi bi-trash me-1"></i> Xóa
            </button>
          </div>
        </div>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import AdminLayout from '../../components/AdminLayout.vue'
import Swal from 'sweetalert2'
import { Modal } from 'bootstrap'
import { reviewAdminService } from '@/services/admin/review'

// Reactive data
const reviews = ref([])
const statistics = ref(null)
const loading = ref(false)
const currentTab = ref('all')
const currentPage = ref(0)
const totalPages = ref(0)
const totalElements = ref(0)
const pageSize = ref(5)
const sortBy = ref('createdAt')
const sortDir = ref('desc')
const selectedReview = ref(null)
const moderating = ref(null)
const deleting = ref(null)

// Computed properties
const visiblePages = computed(() => {
  const pages = []
  const start = Math.max(0, currentPage.value - 2)
  const end = Math.min(totalPages.value - 1, currentPage.value + 2)

  for (let i = start; i <= end; i++) {
    pages.push(i)
  }
  return pages
})

const pendingCount = ref(0)
const reportedCount = ref(0)

// Methods
const fetchReviews = async () => {
  loading.value = true
  try {
    let response
    switch (currentTab.value) {
      case 'pending':
        response = await reviewAdminService.getPendingReviews(
          currentPage.value, pageSize.value, sortBy.value, sortDir.value
        )
        break
      case 'reported':
        response = await reviewAdminService.getReportedReviews(
          currentPage.value, pageSize.value, sortBy.value, sortDir.value
        )
        break
      default:
        response = await reviewAdminService.getAllReviews(
          currentPage.value, pageSize.value, sortBy.value, sortDir.value
        )
    }

    // Check if response and response.data exist before accessing properties
    if (response && response.data) {
      reviews.value = response.data.reviews || []
      totalElements.value = response.data.totalElements || 0
      totalPages.value = response.data.totalPages || 0
      currentPage.value = response.data.currentPage || 0
    } else {
      console.warn('Unexpected response structure:', response)
      reviews.value = []
      totalElements.value = 0
      totalPages.value = 0
      currentPage.value = 0
    }
  } catch (error) {
    console.error('Error fetching reviews:', error)
    Swal.fire('Lỗi!', 'Không thể tải danh sách đánh giá', 'error')
    // Set default values on error
    reviews.value = []
    totalElements.value = 0
    totalPages.value = 0
    currentPage.value = 0
  } finally {
    loading.value = false
  }
}

const fetchStatistics = async () => {
  try {
    const response = await reviewAdminService.getStatisticsOverview()
    if (response && response.data) {
      statistics.value = response.data
    } else {
      console.warn('Unexpected statistics response structure:', response)
      statistics.value = {}
    }
  } catch (error) {
    console.error('Error fetching statistics:', error)
    statistics.value = {}
  }
}

const fetchCounts = async () => {
  try {
    // Get pending count
    const pendingResponse = await reviewAdminService.getPendingReviews(0, 1)
    if (pendingResponse && pendingResponse.data) {
      pendingCount.value = pendingResponse.data.totalElements || 0
    } else {
      pendingCount.value = 0
    }

    // Get reported count
    const reportedResponse = await reviewAdminService.getReportedReviews(0, 1)
    if (reportedResponse && reportedResponse.data) {
      reportedCount.value = reportedResponse.data.totalElements || 0
    } else {
      reportedCount.value = 0
    }
  } catch (error) {
    console.error('Error fetching counts:', error)
    // Set default values on error
    pendingCount.value = 0
    reportedCount.value = 0
  }
}

const changeTab = (tab) => {
  currentTab.value = tab
  currentPage.value = 0
  fetchReviews()
}

const changePage = (page) => {
  currentPage.value = page
  fetchReviews()
}

const viewReviewDetails = async (review) => {
  try {
    const response = await reviewAdminService.getReviewDetails(review.id)
    if (response && response.data) {
      selectedReview.value = response.data
    } else {
      console.warn('Unexpected review details response structure:', response)
      selectedReview.value = null
    }
  } catch (error) {
    console.error('Error fetching review details:', error)
    Swal.fire('Lỗi!', 'Không thể tải chi tiết đánh giá', 'error')
    selectedReview.value = null
  }
}

const approveReview = async (reviewId) => {
  const result = await Swal.fire({
    title: 'Xác nhận duyệt',
    text: 'Bạn có chắc chắn muốn duyệt đánh giá này?',
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#198754',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Duyệt',
    cancelButtonText: 'Hủy'
  })

  if (result.isConfirmed) {
    moderating.value = reviewId
    try {
      await reviewAdminService.moderateReview(reviewId, true)
      Swal.fire('Thành công!', 'Đánh giá đã được duyệt', 'success')
      fetchReviews()
      fetchCounts()
    } catch (error) {
      console.error('Error approving review:', error)
      Swal.fire('Lỗi!', 'Không thể duyệt đánh giá', 'error')
    } finally {
      moderating.value = null
    }
  }
}

const rejectReview = async (reviewId) => {
  const { value: reason } = await Swal.fire({
    title: 'Từ chối đánh giá',
    text: 'Vui lòng nhập lý do từ chối:',
    input: 'textarea',
    inputPlaceholder: 'Nhập lý do từ chối...',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Từ chối',
    cancelButtonText: 'Hủy',
    inputValidator: (value) => {
      if (!value) {
        return 'Vui lòng nhập lý do từ chối!'
      }
    }
  })

  if (reason) {
    moderating.value = reviewId
    try {
      await reviewAdminService.moderateReview(reviewId, false, reason)
      Swal.fire('Thành công!', 'Đánh giá đã được từ chối', 'success')
      fetchReviews()
      fetchCounts()
    } catch (error) {
      console.error('Error rejecting review:', error)
      Swal.fire('Lỗi!', 'Không thể từ chối đánh giá', 'error')
    } finally {
      moderating.value = null
    }
  }
}

const deleteReview = async (reviewId) => {
  const result = await Swal.fire({
    title: 'Xác nhận xóa',
    text: 'Bạn có chắc chắn muốn xóa đánh giá này? Hành động này không thể hoàn tác!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy'
  })

  if (result.isConfirmed) {
    deleting.value = reviewId
    try {
      await reviewAdminService.deleteReview(reviewId)
      Swal.fire('Thành công!', 'Đánh giá đã được xóa', 'success')
      fetchReviews()
      fetchCounts()
      fetchStatistics()
    } catch (error) {
      console.error('Error deleting review:', error)
      Swal.fire('Lỗi!', 'Không thể xóa đánh giá', 'error')
    } finally {
      deleting.value = null
    }
  }
}

const formatDate = (dateString) => {
  if (!dateString) return ''
  const date = new Date(dateString)
  return date.toLocaleDateString('vi-VN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// Initialize data
onMounted(() => {
  fetchReviews()
  fetchStatistics()
  fetchCounts()
})
</script>

<style scoped>
.table th {
  background-color: #f8f9fa;
  font-weight: 600;
}

.badge {
  font-size: 0.75rem;
}

.text-truncate {
  max-width: 200px;
}

.nav-pills .nav-link.active {
  background-color: #0d6efd;
}

.modal-lg {
  max-width: 900px;
}

@media (max-width: 768px) {
  .table-responsive {
    font-size: 0.875rem;
  }

  .btn-group-vertical {
    flex-direction: row;
  }

  .btn-group-vertical .btn {
    margin-right: 0.25rem;
    margin-bottom: 0;
  }
}

/* Custom styles for the review modal */
.bg-gradient-warning {
  background: linear-gradient(135deg, #f6c23e 0%, #e0a800 100%) !important;
}

.modal-content {
  border: none;
  border-radius: 0.5rem;
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.modal-header {
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}

.card {
  border: none;
  border-radius: 0.5rem;
}

.card-header {
  border-bottom: 1px solid #e3e6f0;
  font-weight: 600;
}

.badge {
  font-size: 0.75em;
  padding: 0.5em 0.75em;
}

.bg-light {
  background-color: #f8f9fc !important;
}

.text-muted {
  color: #858796 !important;
}

.fw-semibold {
  font-weight: 600;
}

.btn {
  border-radius: 0.35rem;
  font-weight: 500;
}

/* Star rating styles */
.bi-star-fill.text-warning {
  color: #ffc107 !important;
}

/* Hover effects */
.card:hover {
  transform: translateY(-2px);
  transition: transform 0.2s ease-in-out;
}

.btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.1);
}

/* Comment box styling */
.bg-light p {
  line-height: 1.6;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .modal-dialog {
    margin: 0.5rem;
  }

  .card-body {
    padding: 1rem;
  }

  .btn-group {
    flex-direction: column;
    width: 100%;
  }

  .btn-group .btn {
    margin-bottom: 0.5rem;
    width: 100%;
  }
}
</style>
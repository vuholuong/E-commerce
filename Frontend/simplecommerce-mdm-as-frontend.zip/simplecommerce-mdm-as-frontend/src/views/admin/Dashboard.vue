<template>
  <AdminLayout>
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h6></h6>
      <div class="d-flex gap-2">
        <!-- Filter Controls -->
        <div class="dropdown">
          <button class="btn btn-outline-secondary dropdown-toggle" type="button" @click="toggleYearDropdown">
            <i class="bi bi-calendar-year"></i> {{ selectedYear }}
          </button>
          <div class="dropdown-menu" :class="{ 'show': showYearDropdown }">
            <h6 class="dropdown-header">Chọn năm</h6>
            <button v-for="year in availableYears" :key="year" class="dropdown-item"
              :class="{ 'active': selectedYear === year }" @click="selectYear(year)">
              {{ year }}
            </button>
          </div>
        </div>

        <div class="dropdown">
          <button class="btn btn-outline-secondary dropdown-toggle" type="button" @click="toggleRangeDropdown">
            <i class="bi bi-calendar-range"></i> {{ getRangeLabel() }}
          </button>
          <div class="dropdown-menu" :class="{ 'show': showRangeDropdown }">
            <h6 class="dropdown-header">Chọn khoảng thời gian</h6>
            <button v-for="range in timeRanges" :key="range.value" class="dropdown-item"
              :class="{ 'active': selectedRange === range.value }" @click="selectRange(range.value)">
              <i class="bi" :class="range.icon"></i> {{ range.label }}
            </button>
          </div>
        </div>

        <!-- <button class="btn btn-primary" @click="exportExcel" :disabled="isExporting">
          <i class="bi bi-download"></i> 
          {{ isExporting ? 'Đang xuất...' : 'Xuất Excel' }}
        </button> -->
      </div>
    </div>

    <!-- Advanced Filter Bar -->
    <div class="filter-bar card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="mb-0">
          <i class="bi bi-funnel me-2"></i>Bộ lọc nâng cao
        </h6>
        <div class="filter-actions">
          <button class="btn btn-sm btn-outline-secondary me-2" @click="resetFilters">
            <i class="bi bi-arrow-clockwise me-1"></i>Đặt lại
          </button>
          <button class="btn btn-sm btn-outline-primary" @click="toggleFilterBar">
            <i class="bi" :class="showFilterBar ? 'bi-chevron-up' : 'bi-chevron-down'"></i>
          </button>
        </div>
      </div>

      <div class="card-body" v-show="showFilterBar">
        <div class="row g-3">
          <!-- Metric Type Filter -->
          <div class="col-md-3">
            <label class="form-label">Chỉ số:</label>
            <select v-model="selectedMetric" class="form-select form-select-sm" @change="updateChart">
              <option value="revenue">Doanh thu</option>
              <option value="orders">Số đơn hàng</option>
            </select>
          </div>

          <!-- Shops Filter -->
          <div class="col-md-3">
            <label class="form-label">Top Shops:</label>
            <select v-model="topShopsLimit" class="form-select form-select-sm" @change="updateTopShops">
              <option value="5">Top 5</option>
              <option value="10">Top 10</option>
              <option value="20">Top 20</option>
            </select>
          </div>

          <!-- Payment Filter -->
          <div class="col-md-3">
            <label class="form-label">Phương thức thanh toán:</label>
            <select v-model="paymentRange" class="form-select form-select-sm" @change="updatePaymentBreakdown">
              <option value="7d">7 ngày qua</option>
              <option value="30d">30 ngày qua</option>
              <option value="90d">90 ngày qua</option>
            </select>
          </div>

          <!-- Quick Filters -->
      <div class="col-md-3">
            <label class="form-label">Lọc nhanh:</label>
            <div class="btn-group-sm d-flex gap-1" role="group">
              <button type="button" class="btn flex-fill"
                :class="quickFilter === 'growth' ? 'btn-success' : 'btn-outline-success'"
                @click="setQuickFilter('growth')">
                <i class="bi bi-graph-up-arrow me-1"></i>Tăng trưởng
              </button>
              <button type="button" class="btn flex-fill"
                :class="quickFilter === 'today' ? 'btn-primary' : 'btn-outline-primary'"
                @click="setQuickFilter('today')">
                <i class="bi bi-calendar-day me-1"></i>Hôm nay
              </button>
            </div>
          </div>
        </div>

        <!-- Active Filters Display -->
        <div class="active-filters mt-3" v-if="hasActiveFilters">
          <small class="text-muted">Bộ lọc đang áp dụng:</small>
          <div class="mt-1">
            <span v-if="selectedMetric !== 'revenue'" class="badge bg-primary me-1">
              {{ getMetricLabel(selectedMetric) }}
              <button type="button" class="btn-close btn-close-white ms-1"
                @click="selectedMetric = 'revenue'; updateChart()"></button>
            </span>
            <span v-if="topShopsLimit !== 10" class="badge bg-success me-1">
              Top {{ topShopsLimit }} shops
              <button type="button" class="btn-close btn-close-white ms-1"
                @click="topShopsLimit = 10; updateTopShops()"></button>
            </span>
            <span v-if="paymentRange !== '30d'" class="badge bg-info me-1">
              Thanh toán {{ getRangeLabel(paymentRange) }}
              <button type="button" class="btn-close btn-close-white ms-1"
                @click="paymentRange = '30d'; updatePaymentBreakdown()"></button>
            </span>
            <span v-if="quickFilter !== 'none'" class="badge bg-dark me-1">
              {{ getQuickFilterLabel(quickFilter) }}
              <button type="button" class="btn-close btn-close-white ms-1" @click="quickFilter = 'none'"></button>
            </span>
          </div>
        </div>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="isLoading" class="text-center py-4">
      <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Đang tải...</span>
      </div>
      <p class="mt-2 text-muted">Đang tải dữ liệu thống kê...</p>
    </div>

    <!-- Error State -->
    <div v-if="error" class="alert alert-danger" role="alert">
      <i class="bi bi-exclamation-triangle me-2"></i>
      <strong>Lỗi:</strong> {{ error }}
      <button class="btn btn-sm btn-outline-danger ms-2" @click="loadAllData">
        <i class="bi bi-arrow-clockwise me-1"></i>Thử lại
      </button>
    </div>

    <!-- Overview Stats -->
    <div v-if="!isLoading && !error" class="row mb-4">
      <div class="col-md-3 mb-3">
        <div class="card bg-primary text-white">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <div>
                <h6 class="card-title">Tổng đơn hàng</h6>
                <h4>{{ formatNumber(overview.totalOrders) }}</h4>
              </div>
              <i class="bi bi-bag-check display-4"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-3">
        <div class="card bg-success text-white">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <div>
                <h6 class="card-title">Tổng doanh thu</h6>
                <h4>{{ formatCurrency(overview.totalRevenue) }}</h4>
              </div>
              <i class="bi bi-currency-dollar display-4"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-3">
        <div class="card bg-info text-white">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <div>
                <h6 class="card-title">Tổng người dùng</h6>
                <h4>{{ formatNumber(overview.totalUsers) }}</h4>
              </div>
              <i class="bi bi-people display-4"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3 mb-3">
        <div class="card bg-warning text-white">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <div>
                <h6 class="card-title">Tổng shops</h6>
                <h4>{{ formatNumber(overview.totalShops) }}</h4>
              </div>
              <i class="bi bi-shop display-4"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Charts and Data -->
    <div v-if="!isLoading && !error" class="row mb-4">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5>{{ getChartTitle() }}</h5>
            <div class="chart-controls d-flex gap-2">
              <!-- Chart Type Controls -->
              <div class="btn-group btn-group-sm" role="group">
                <button type="button" class="btn" :class="chartType === 'line' ? 'btn-primary' : 'btn-outline-primary'"
                  @click="changeChartType('line')" title="Biểu đồ đường">
                  <i class="bi bi-graph-up"></i>
                </button>
                <button type="button" class="btn" :class="chartType === 'bar' ? 'btn-primary' : 'btn-outline-primary'"
                  @click="changeChartType('bar')" title="Biểu đồ cột">
                  <i class="bi bi-bar-chart"></i>
                </button>
                <button type="button" class="btn" :class="chartType === 'area' ? 'btn-primary' : 'btn-outline-primary'"
                  @click="changeChartType('area')" title="Biểu đồ vùng">
                  <i class="bi bi-area-chart"></i>
                </button>
              </div>

              <!-- Chart Options -->
              <div class="btn-group btn-group-sm" role="group">
                <button type="button" class="btn btn-outline-secondary" :class="{ 'active': showDataLabels }"
                  @click="toggleDataLabels" title="Hiển thị giá trị">
                  <i class="bi bi-123"></i>
                </button>
                <button type="button" class="btn btn-outline-secondary" :class="{ 'active': showGridLines }"
                  @click="toggleGridLines" title="Hiển thị lưới">
                  <i class="bi bi-grid"></i>
                </button>
              </div>
            </div>
          </div>
          <div class="card-body">
            <canvas ref="revenueChart" id="revenueChart" height="350"></canvas>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div v-if="!isLoading && !error" class="card">
          <div class="card-header">
            <h5>Top {{ topShopsLimit }} Shops theo doanh thu</h5>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Hạng</th>
                    <th>Shop</th>
                    <th>Doanh thu</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(shop, index) in topShops" :key="shop.shopId">
                    <td>
                      <span class="badge"
                        :class="`bg-${index === 0 ? 'warning' : index === 1 ? 'secondary' : index === 2 ? 'dark' : 'light text-dark'}`">
                        #{{ index + 1 }}
                      </span>
                    </td>
                    <td>
                      <div class="d-flex align-items-center">
                        <div
                          class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                          style="width: 40px; height: 40px;">
                          {{ shop.shopName.charAt(0) }}
                        </div>
                        <div>
                          <strong>{{ shop.shopName }}</strong><br>
                          <small class="text-muted">ID: {{ shop.shopId }}</small>
                        </div>
                      </div>
                    </td>
                    <td>{{ formatCurrency(shop.revenue) }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>



  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, computed, watch } from 'vue'
import AdminLayout from '../../components/AdminLayout.vue'
import { Chart, registerables } from 'chart.js'
import Swal from 'sweetalert2'
import AdminStatsService from '@/services/admin/statis'

Chart.register(...registerables)

const revenueChart = ref(null)
const paymentChart = ref(null)
let revenueChartInstance = null
let paymentChartInstance = null

// Loading states
const isLoading = ref(true)
const isExporting = ref(false)
const error = ref(null)

// Filter states
const selectedYear = ref(new Date().getFullYear())
const selectedRange = ref('30d')
const showYearDropdown = ref(false)
const showRangeDropdown = ref(false)
const chartType = ref('line')

// Advanced filter states
const showFilterBar = ref(true)
const selectedMetric = ref('revenue')
const topShopsLimit = ref(10)
const paymentRange = ref('30d')
const quickFilter = ref('none')

// Chart display options
const showDataLabels = ref(false)
const showGridLines = ref(true)

// Data
const overview = ref({
  totalOrders: 0,
  totalRevenue: 0,
  totalUsers: 0,
  totalShops: 0,
  pendingOrders: 0,
  processingOrders: 0,
  shippedOrders: 0,
  deliveredOrders: 0,
  completedOrders: 0,
  cancelledOrders: 0,
  todayRevenue: 0,
  newUsers7d: 0,
  totalProducts: 0,
  pendingProducts: 0
})

const salesSeries = ref([])
const paymentBreakdown = ref([])
const topShops = ref([])

// Available options
const availableYears = ref([2021, 2022, 2023, 2024, 2025])
const timeRanges = ref([
  { value: '7d', label: '7 ngày qua', icon: 'bi-calendar-week' },
  { value: '30d', label: '30 ngày qua', icon: 'bi-calendar-month' },
  { value: '90d', label: '90 ngày qua', icon: 'bi-calendar-range' },
  { value: '1y', label: '1 năm qua', icon: 'bi-calendar-year' }
])

// Computed properties
const hasActiveFilters = computed(() => {
  return selectedMetric.value !== 'revenue' ||
    topShopsLimit.value !== 10 ||
    paymentRange.value !== '30d' ||
    quickFilter.value !== 'none'
})

const activeFiltersCount = computed(() => {
  let count = 0
  if (selectedMetric.value !== 'revenue') count++
  if (topShopsLimit.value !== 10) count++
  if (paymentRange.value !== '30d') count++
  if (quickFilter.value !== 'none') count++
  return count
})

const chartLabels = computed(() => {
  return salesSeries.value.map(point => {
    const date = new Date(point.date)
    return date.toLocaleDateString('vi-VN', {
      month: 'short',
      day: 'numeric'
    })
  })
})

const chartData = computed(() => {
  if (selectedMetric.value === 'orders') {
    return salesSeries.value.map(point => point.orders)
  }
  return salesSeries.value.map(point => point.revenue)
})

// Methods
const loadAllData = async () => {
  try {
    isLoading.value = true
    error.value = null

    // Load all data concurrently
    const [overviewResult, salesResult, paymentResult, shopsResult] = await Promise.all([
      AdminStatsService.getOverview(),
      AdminStatsService.getSalesSeries(selectedRange.value),
      AdminStatsService.getPaymentBreakdown(paymentRange.value),
      AdminStatsService.getTopShops(topShopsLimit.value)
    ])

    // Update data
    overview.value = overviewResult.data
    salesSeries.value = salesResult.data
    paymentBreakdown.value = paymentResult.data
    topShops.value = shopsResult.data

    // Update charts
    updateChart()
    updatePaymentChart()

  } catch (err) {
    error.value = err.response?.data?.message || 'Không thể tải dữ liệu'
    console.error('Error loading admin stats:', err)
  } finally {
    isLoading.value = false
  }
}

const updateChart = async () => {
  try {
    const result = await AdminStatsService.getSalesSeries(selectedRange.value)
    salesSeries.value = result.data
    initChart()
  } catch (err) {
    console.error('Error updating chart:', err)
  }
}

const updatePaymentBreakdown = async () => {
  try {
    const result = await AdminStatsService.getPaymentBreakdown(paymentRange.value)
    paymentBreakdown.value = result.data
    updatePaymentChart()
  } catch (err) {
    console.error('Error updating payment breakdown:', err)
  }
}

const updateTopShops = async () => {
  try {
    const result = await AdminStatsService.getTopShops(topShopsLimit.value)
    topShops.value = result.data
  } catch (err) {
    console.error('Error updating top shops:', err)
  }
}

const initChart = () => {
  if (revenueChartInstance) {
    revenueChartInstance.destroy()
  }

  if (revenueChart.value) {
    const ctx = revenueChart.value.getContext('2d')

    const chartConfig = {
      type: chartType.value === 'area' ? 'line' : chartType.value,
      data: {
        labels: chartLabels.value,
        datasets: [{
          label: getMetricLabel(selectedMetric.value),
          data: chartData.value,
          borderColor: 'rgb(75, 192, 192)',
          backgroundColor: chartType.value === 'bar' || chartType.value === 'area'
            ? 'rgba(75, 192, 192, 0.5)'
            : 'rgba(75, 192, 192, 0.2)',
          tension: chartType.value === 'line' || chartType.value === 'area' ? 0.1 : 0,
          fill: chartType.value === 'area'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: getChartTitle()
          },
          legend: {
            display: true,
            position: 'top'
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: {
              display: showGridLines.value
            },
            ticks: {
              callback: function (value) {
                if (selectedMetric.value === 'revenue') {
                return new Intl.NumberFormat('vi-VN', {
                  style: 'currency',
                  currency: 'VND',
                    notation: 'compact'
                }).format(value)
                }
                return value.toLocaleString()
              }
            }
          },
          x: {
            grid: {
              display: showGridLines.value
            }
          }
        },
        animation: {
          duration: 1000,
          easing: 'easeInOutQuart'
        }
      }
    }

    revenueChartInstance = new Chart(ctx, chartConfig)
  }
}

const updatePaymentChart = () => {
  if (paymentChartInstance) {
    paymentChartInstance.destroy()
  }

  if (paymentChart.value && paymentBreakdown.value.length > 0) {
    const ctx = paymentChart.value.getContext('2d')

    const colors = [
      'rgba(255, 99, 132, 0.8)',
      'rgba(54, 162, 235, 0.8)',
      'rgba(255, 205, 86, 0.8)',
      'rgba(75, 192, 192, 0.8)',
      'rgba(153, 102, 255, 0.8)'
    ]

    paymentChartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: paymentBreakdown.value.map(item => item.label),
        datasets: [{
          data: paymentBreakdown.value.map(item => item.amount),
          backgroundColor: colors.slice(0, paymentBreakdown.value.length),
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    })
  }
}

const getMetricLabel = (metric) => {
  const labels = {
    revenue: 'Doanh thu',
    orders: 'Đơn hàng'
  }
  return labels[metric] || 'Doanh thu'
}

const getRangeLabel = (range = selectedRange.value) => {
  const range_obj = timeRanges.value.find(r => r.value === range)
  return range_obj?.label || range
}

const getQuickFilterLabel = (filter) => {
  const labels = {
    none: 'Không',
    growth: 'Tăng trưởng',
    today: 'Hôm nay'
  }
  return labels[filter] || filter
}

const getChartTitle = () => {
  const metricLabel = getMetricLabel(selectedMetric.value)
  return `Biểu đồ ${metricLabel.toLowerCase()} - ${getRangeLabel()}`
}

const toggleYearDropdown = () => {
  showYearDropdown.value = !showYearDropdown.value
  showRangeDropdown.value = false
}

const toggleRangeDropdown = () => {
  showRangeDropdown.value = !showRangeDropdown.value
  showYearDropdown.value = false
}

const selectYear = (year) => {
  selectedYear.value = year
  showYearDropdown.value = false
  updateChart()
}

const selectRange = (range) => {
  selectedRange.value = range
  showRangeDropdown.value = false
  updateChart()
}

const changeChartType = (type) => {
  chartType.value = type
  initChart()
}

const toggleFilterBar = () => {
  showFilterBar.value = !showFilterBar.value
}

const resetFilters = () => {
  selectedMetric.value = 'revenue'
  topShopsLimit.value = 10
  paymentRange.value = '30d'
  quickFilter.value = 'none'
  updateChart()
  updatePaymentBreakdown()
  updateTopShops()
}

const setQuickFilter = (filter) => {
  quickFilter.value = quickFilter.value === filter ? 'none' : filter
  if (filter === 'today') {
    selectedRange.value = '7d'
    updateChart()
  } else if (filter === 'growth') {
    selectedRange.value = '90d'
    updateChart()
  }
}

const toggleDataLabels = () => {
  showDataLabels.value = !showDataLabels.value
  initChart()
}

const toggleGridLines = () => {
  showGridLines.value = !showGridLines.value
  initChart()
}

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    notation: 'compact'
  }).format(amount)
}

const formatNumber = (number) => {
  return new Intl.NumberFormat('vi-VN').format(number)
}

const exportExcel = async () => {
  try {
    isExporting.value = true

    const filters = {
      range: selectedRange.value,
      metric: selectedMetric.value,
      topShopsLimit: topShopsLimit.value,
      paymentRange: paymentRange.value,
      quickFilter: quickFilter.value
    }

    await AdminStatsService.exportToExcel(filters)

    await Swal.fire({
      icon: 'success',
      title: 'Xuất Excel thành công!',
      text: `Đã xuất báo cáo thống kê thành công!`,
      confirmButtonText: 'OK'
    })
  } catch (error) {
    await Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: error.response?.data?.message || 'Có lỗi xảy ra khi xuất file Excel!',
      confirmButtonText: 'OK'
    })
  } finally {
    isExporting.value = false
  }
}

// Click outside handler
const handleClickOutside = (event) => {
  if (!event.target.closest('.dropdown')) {
    showYearDropdown.value = false
    showRangeDropdown.value = false
  }
}

// Watch for changes
watch([selectedRange, selectedMetric], () => {
  updateChart()
})

watch(topShopsLimit, () => {
  updateTopShops()
})

watch(paymentRange, () => {
  updatePaymentBreakdown()
})

onMounted(() => {
  loadAllData()
  document.addEventListener('click', handleClickOutside)
})
</script>

<style scoped>
.filter-bar {
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
  border: 1px solid #dee2e6;
}

.filter-bar .card-header {
  background: rgba(255, 255, 255, 0.8);
  border-bottom: 1px solid #dee2e6;
}

.active-filters .badge {
  font-size: 0.75rem;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.btn-close {
  width: 12px;
  height: 12px;
  font-size: 10px;
}

.dropdown {
  position: relative;
}

.dropdown-menu {
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 1000;
  display: none;
  min-width: 200px;
  padding: 0.5rem 0;
  margin: 0.125rem 0 0;
  font-size: 0.875rem;
  color: #212529;
  text-align: left;
  list-style: none;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid rgba(0, 0, 0, 0.15);
  border-radius: 0.375rem;
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.dropdown-menu.show {
  display: block;
}

.dropdown-item {
  display: block;
  width: 100%;
  padding: 0.375rem 1rem;
  clear: both;
  font-weight: 400;
  color: #212529;
  text-align: inherit;
  text-decoration: none;
  white-space: nowrap;
  background-color: transparent;
  border: 0;
  cursor: pointer;
  transition: all 0.15s ease-in-out;
}

.dropdown-item:hover,
.dropdown-item:focus {
  color: #1e2125;
  background-color: #e9ecef;
}

.dropdown-item.active {
  color: #fff;
  background-color: #0d6efd;
}

.dropdown-header {
  display: block;
  padding: 0.5rem 1rem;
  margin-bottom: 0;
  font-size: 0.75rem;
  color: #6c757d;
  white-space: nowrap;
}

.chart-controls .btn-group .btn {
  min-width: 40px;
}

.alert {
  border-radius: 0.5rem;
  border: none;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid #e9ecef;
  border-radius: 0.5rem 0.5rem 0 0 !important;
}

.btn {
  border-radius: 0.375rem;
}

.badge {
  font-size: 0.75rem;
}

.progress {
  background-color: #e9ecef;
  border-radius: 0.375rem;
}

.form-select-sm {
  font-size: 0.875rem;
}

.btn-group-sm .btn {
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
}

.spinner-border {
  width: 3rem;
  height: 3rem;
}

.bg-primary {
  background-color: #0d6efd !important;
}

.bg-success {
  background-color: #198754 !important;
}

.bg-info {
  background-color: #0dcaf0 !important;
}

.bg-warning {
  background-color: #ffc107 !important;
}

.bg-secondary {
  background-color: #6c757d !important;
}

.bg-dark {
  background-color: #212529 !important;
}

.display-4 {
  font-size: 2.5rem;
  opacity: 0.7;
}

.rounded-circle {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.text-white {
  color: #fff !important;
}

.text-muted {
  color: #6c757d !important;
}
</style>
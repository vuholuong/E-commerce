<template>
  <AdminLayout>
    <div class="container-fluid">
      <!-- Header with refresh button -->
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center">
          <button
              class="btn btn-outline-secondary btn-sm"
              @click="refreshData"
              :disabled="categoriesStore.refreshing"
              title="Làm mới dữ liệu">
            <span v-if="categoriesStore.refreshing" class="spinner-border spinner-border-sm me-1"></span>
            <i v-else class="bi bi-arrow-clockwise"></i>
            {{ categoriesStore.refreshing ? 'Đang tải...' : 'Làm mới' }}
          </button>
        </div>
        <button class="btn btn-primary" @click="openCreateModal">
          <i class="bi bi-plus-lg"></i> Thêm danh mục
        </button>
      </div>

      <!-- Search and Filter -->
      <div class="card mb-4">
        <div class="card-body">
          <div class="row">
            <div class="col-md-4">
              <div class="input-group">
                <span class="input-group-text">
                  <i class="bi bi-search"></i>
                </span>
                <input
                    type="text"
                    class="form-control"
                    placeholder="Tìm kiếm danh mục..."
                    :value="categoriesStore.searchTerm"
                    @input="handleSearch"
                >
                <button
                    v-if="categoriesStore.searchTerm"
                    class="btn btn-outline-secondary"
                    @click="clearSearch"
                    type="button">
                  <i class="bi bi-x-lg"></i>
                </button>
              </div>
            </div>
            <div class="col-md-3">
              <select
                  class="form-select"
                  :value="categoriesStore.parentFilter"
                  @change="handleParentFilter">
                <option value="">Tất cả loại</option>
                <option value="root">Danh mục gốc</option>
                <option value="child">Danh mục con</option>
              </select>
            </div>
            <div class="col-md-3">
              <select
                  class="form-select"
                  :value="categoriesStore.pageSize"
                  @change="handlePageSizeChange">
                <option value="5">5 mục/trang</option>
                <option value="10">10 mục/trang</option>
                <option value="20">20 mục/trang</option>
                <option value="50">50 mục/trang</option>
              </select>
            </div>
            <div class="col-md-2">
              <button
                  class="btn btn-outline-danger w-100"
                  @click="clearAllFilters"
                  :disabled="!hasActiveFilters">
                <i class="bi bi-funnel"></i> Xóa bộ lọc
              </button>
            </div>
          </div>

          <!-- Active filters display -->
          <div v-if="hasActiveFilters" class="mt-3">
            <small class="text-muted">Bộ lọc đang áp dụng:</small>
            <div class="d-flex flex-wrap gap-2 mt-1">
              <span v-if="categoriesStore.searchTerm" class="badge bg-primary">
                Tìm kiếm: "{{ categoriesStore.searchTerm }}"
                <button type="button" class="btn-close btn-close-white ms-1" @click="clearSearch"></button>
              </span>
              <span v-if="categoriesStore.parentFilter" class="badge bg-info">
                Loại: {{ getFilterLabel(categoriesStore.parentFilter) }}
                <button type="button" class="btn-close btn-close-white ms-1" @click="clearParentFilter"></button>
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Results Summary -->
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="text-muted">
          <i class="bi bi-info-circle me-1"></i>
          Hiển thị {{ categoriesStore.paginatedCategories.length }} trên {{ categoriesStore.totalItems }} danh mục
          <span v-if="categoriesStore.lastFetch" class="ms-2">
            (Cập nhật lần cuối: {{ formatLastUpdate(categoriesStore.lastFetch) }})
          </span>
        </div>
        <div class="d-flex align-items-center gap-2">
          <small class="text-muted">Sắp xếp:</small>
          <select
              class="form-select form-select-sm"
              style="width: auto;"
              :value="`${categoriesStore.sortBy}-${categoriesStore.sortOrder}`"
              @change="handleSortChange">
            <option value="name-asc">Tên A-Z</option>
            <option value="name-desc">Tên Z-A</option>
            <option value="id-asc">ID tăng dần</option>
            <option value="id-desc">ID giảm dần</option>
          </select>
        </div>
      </div>

      <!-- Loading State -->
      <div v-if="categoriesStore.loading && !categoriesStore.refreshing" class="text-center py-5">
        <div class="spinner-border text-primary mb-3" role="status">
          <span class="visually-hidden">Đang tải...</span>
        </div>
        <p class="text-muted">Đang tải danh sách danh mục...</p>
      </div>

      <!-- Error State -->
      <div v-else-if="categoriesStore.error" class="alert alert-danger">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <i class="bi bi-exclamation-triangle me-2"></i>
            {{ categoriesStore.error }}
          </div>
          <button class="btn btn-outline-danger btn-sm" @click="retryLoad">
            <i class="bi bi-arrow-clockwise"></i> Thử lại
          </button>
        </div>
      </div>

      <!-- Categories Table -->
      <div v-else class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead class="table-light">
              <tr>
                <th style="width: 80px">
                  <button class="btn btn-sm btn-ghost" @click="handleSort('id')">
                    ID
                    <i class="bi bi-chevron-expand ms-1"></i>
                  </button>
                </th>
                <th>
                  <button class="btn btn-sm btn-ghost" @click="handleSort('name')">
                    Tên danh mục
                    <i class="bi bi-chevron-expand ms-1"></i>
                  </button>
                </th>
                <th style="width: 200px">Slug</th>
                <th>Mô tả</th>
                <th style="width: 150px">Danh mục cha</th>
                <th style="width: 100px">Số con</th>
                <th style="width: 120px">Hành động</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="category in categoriesStore.paginatedCategories" :key="`category-${category.id}`">
                <td>
                  <span class="badge bg-light text-dark">{{ category.id }}</span>
                </td>
                <td>
                  <div class="d-flex align-items-center">
                    <strong>{{ category.name }}</strong>
                  </div>
                </td>
                <td>
                  <code class="text-primary small">{{ category.slug }}</code>
                </td>
                <td>
                  <span v-if="category.description" class="text-muted">
                    {{ truncateText(category.description, 60) }}
                  </span>
                  <span v-else class="text-muted fst-italic">Không có mô tả</span>
                </td>
                <td>
                  <span v-if="categoriesStore.getParentName(category.parentId)" class="badge bg-secondary">
                    {{ categoriesStore.getParentName(category.parentId) }}
                  </span>
                  <span v-else class="text-muted">Danh mục gốc</span>
                </td>
                <td>
                  <span class="badge bg-info">
                    {{ categoriesStore.getChildrenCount(category.id) }}
                  </span>
                </td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary me-2"
                        @click="openEditModal(category)"
                        title="Chỉnh sửa"
                        :disabled="submitting"> Sửa
                      <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-outline-danger"
                        @click="confirmDelete(category)"
                        title="Xóa"
                        :disabled="submitting || categoriesStore.hasChildren(category.id)"> Xóa
                      <i class="bi bi-trash"></i>
                    </button>
                  </div>
                </td>
              </tr>
              <tr v-if="categoriesStore.paginatedCategories.length === 0">
                <td colspan="7" class="text-center text-muted py-5">
                  <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                  <p class="mb-0">
                    {{ hasActiveFilters ? 'Không tìm thấy danh mục nào với bộ lọc hiện tại' : 'Chưa có danh mục nào' }}
                  </p>
                  <button v-if="hasActiveFilters" class="btn btn-outline-primary btn-sm mt-2" @click="clearAllFilters">
                    Xóa bộ lọc
                  </button>
                </td>
              </tr>
              </tbody>
            </table>
          </div>

          <!-- Enhanced Pagination -->
          <nav v-if="categoriesStore.totalPages > 1" class="mt-4">
            <div class="d-flex justify-content-between align-items-center">
              <div class="text-muted small">
                Trang {{ categoriesStore.currentPage }} / {{ categoriesStore.totalPages }}
              </div>
              <ul class="pagination pagination-sm mb-0">
                <li class="page-item" :class="{ disabled: !categoriesStore.hasPreviousPage }">
                  <button class="page-link" @click="categoriesStore.previousPage()">
                    <i class="bi bi-chevron-left"></i>
                  </button>
                </li>
                <li
                    v-for="page in categoriesStore.visiblePages"
                    :key="`page-${page}`"
                    class="page-item"
                    :class="{ active: page === categoriesStore.currentPage }"
                >
                  <button class="page-link" @click="categoriesStore.setPage(page)">{{ page }}</button>
                </li>
                <li class="page-item" :class="{ disabled: !categoriesStore.hasNextPage }">
                  <button class="page-link" @click="categoriesStore.nextPage()">
                    <i class="bi bi-chevron-right"></i>
                  </button>
                </li>
              </ul>
            </div>
          </nav>
        </div>
      </div>

      <!-- Create/Edit Modal -->
      <div class="modal fade" id="categoryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                {{ isEditing ? 'Cập nhật danh mục' : 'Thêm danh mục mới' }}
              </h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form @submit.prevent="saveCategory">
              <div class="modal-body">
                <div class="row">
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">Tên danh mục <span class="text-danger">*</span></label>
                      <input
                          type="text"
                          class="form-control"
                          v-model="categoryForm.name"
                          @input="onNameChange"
                          required
                          :class="{ 'is-invalid': formErrors.name }"
                          :disabled="submitting"
                      >
                      <div v-if="formErrors.name" class="invalid-feedback">
                        {{ formErrors.name }}
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">Slug <span class="text-danger">*</span></label>
                      <input
                          type="text"
                          class="form-control"
                          v-model="categoryForm.slug"
                          required
                          :class="{ 'is-invalid': formErrors.slug }"
                          :disabled="submitting"
                      >
                      <div v-if="formErrors.slug" class="invalid-feedback">
                        {{ formErrors.slug }}
                      </div>
                    </div>
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label">Danh mục cha</label>
                  <select
                      class="form-select"
                      v-model="categoryForm.parentId"
                      :disabled="submitting"
                  >
                    <option value="">Không có (Danh mục gốc)</option>
                    <option
                        v-for="parent in categoriesStore.getAvailableParents(categoryForm.id)"
                        :key="parent.id"
                        :value="parent.id"
                    >
                      {{ parent.name }}
                    </option>
                  </select>
                </div>

                <div class="mb-3">
                  <label class="form-label">Mô tả</label>
                  <textarea
                      class="form-control"
                      rows="4"
                      v-model="categoryForm.description"
                      placeholder="Nhập mô tả cho danh mục..."
                      :class="{ 'is-invalid': formErrors.description }"
                      :disabled="submitting"
                  ></textarea>
                  <div v-if="formErrors.description" class="invalid-feedback">
                    {{ formErrors.description }}
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" :disabled="submitting">
                  Hủy
                </button>
                <button type="submit" class="btn btn-primary" :disabled="submitting">
                  <span v-if="submitting" class="spinner-border spinner-border-sm me-2"></span>
                  {{ isEditing ? 'Cập nhật' : 'Thêm mới' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import AdminLayout from '@/components/AdminLayout.vue'
import { useCategoriesStore } from '@/stores/admin/categories.js'
import { categoryUtils } from '@/services/admin/categories.js'
import Swal from 'sweetalert2'
import { Modal } from 'bootstrap'

// Store
const categoriesStore = useCategoriesStore()

// Component state
const submitting = ref(false)
const isEditing = ref(false)

// Form data
const categoryForm = reactive({
  id: null,
  name: '',
  slug: '',
  description: '',
  parentId: ''
})

// Form validation errors
const formErrors = reactive({
  name: '',
  slug: '',
  description: ''
})

// Computed properties
const hasActiveFilters = computed(() => {
  return categoriesStore.searchTerm || categoriesStore.parentFilter
})

// Methods
const refreshData = async () => {
  const result = await categoriesStore.refreshCategories()
  if (!result.success) {
    Swal.fire('Lỗi!', result.error, 'error')
  }
}

const retryLoad = async () => {
  categoriesStore.clearError()
  await loadData()
}

const loadData = async () => {
  const result = await categoriesStore.loadCategories()
  if (!result.success && !result.fromCache) {
    Swal.fire('Lỗi!', result.error, 'error')
  }
}

// Search and filter handlers
const handleSearch = (event) => {
  categoriesStore.setSearchTerm(event.target.value)
}

const clearSearch = () => {
  categoriesStore.setSearchTerm('')
}

const handleParentFilter = (event) => {
  categoriesStore.setParentFilter(event.target.value)
}

const clearParentFilter = () => {
  categoriesStore.setParentFilter('')
}

const handlePageSizeChange = (event) => {
  categoriesStore.setPageSize(parseInt(event.target.value))
}

const handleSort = (field) => {
  const currentOrder = categoriesStore.sortBy === field && categoriesStore.sortOrder === 'asc' ? 'desc' : 'asc'
  categoriesStore.setSorting(field, currentOrder)
}

const handleSortChange = (event) => {
  const [sortBy, sortOrder] = event.target.value.split('-')
  categoriesStore.setSorting(sortBy, sortOrder)
}

const clearAllFilters = () => {
  categoriesStore.clearFilters()
}

const getFilterLabel = (filter) => {
  switch (filter) {
    case 'root': return 'Danh mục gốc'
    case 'child': return 'Danh mục con'
    default: return 'Tất cả'
  }
}

// Utility functions
const truncateText = (text, maxLength) => {
  if (!text) return ''
  return text.length > maxLength ? text.substring(0, maxLength) + '...' : text
}

const formatLastUpdate = (timestamp) => {
  const now = Date.now()
  const diff = now - timestamp
  const minutes = Math.floor(diff / 60000)

  if (minutes < 1) return 'vừa xong'
  if (minutes < 60) return `${minutes} phút trước`

  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours} giờ trước`

  return new Date(timestamp).toLocaleString('vi-VN')
}

// Form handling
const onNameChange = () => {
  if (!isEditing.value) {
    categoryForm.slug = categoryUtils.generateSlug(categoryForm.name)
  }
  clearFieldError('name')
}

const clearFormErrors = () => {
  formErrors.name = ''
  formErrors.slug = ''
  formErrors.description = ''
}

const clearFieldError = (field) => {
  if (formErrors[field]) {
    formErrors[field] = ''
  }
}

const validateForm = () => {
  clearFormErrors()
  const validation = categoryUtils.validateCategory(categoryForm)

  if (!validation.isValid) {
    Object.assign(formErrors, validation.errors)
  }

  return validation.isValid
}

const resetForm = () => {
  categoryForm.id = null
  categoryForm.name = ''
  categoryForm.slug = ''
  categoryForm.description = ''
  categoryForm.parentId = ''
}

// Modal actions
const openCreateModal = () => {
  isEditing.value = false
  resetForm()
  clearFormErrors()
  const modal = new Modal(document.getElementById('categoryModal'))
  modal.show()
}

const openEditModal = async (category) => {
  isEditing.value = true

  // Get fresh data from store
  const result = await categoriesStore.getCategoryDetails(category.id)

  if (result.success) {
    const categoryData = result.data
    categoryForm.id = categoryData.id
    categoryForm.name = categoryData.name
    categoryForm.slug = categoryData.slug
    categoryForm.description = categoryData.description || ''
    categoryForm.parentId = categoryData.parentId || ''
    clearFormErrors()

    const modal = new Modal(document.getElementById('categoryModal'))
    modal.show()
  } else {
    Swal.fire('Lỗi!', result.error, 'error')
  }
}

const saveCategory = async () => {
  if (!validateForm()) {
    return
  }

  submitting.value = true

  const requestData = {
    name: categoryForm.name.trim(),
    slug: categoryForm.slug.trim(),
    description: categoryForm.description.trim() || null,
    parentId: categoryForm.parentId || null
  }

  let result
  if (isEditing.value) {
    result = await categoriesStore.updateCategory(categoryForm.id, requestData)
  } else {
    result = await categoriesStore.createCategory(requestData)
  }

  if (result.success) {
    Swal.fire('Thành công!', result.message, 'success')

    const modal = Modal.getInstance(document.getElementById('categoryModal'))
    modal.hide()
  } else {
    Swal.fire('Lỗi!', result.error, 'error')
  }

  submitting.value = false
}

const confirmDelete = async (category) => {
  // Check if category has children
  if (categoriesStore.hasChildren(category.id)) {
    Swal.fire({
      title: 'Không thể xóa',
      text: 'Danh mục này có danh mục con. Vui lòng xóa các danh mục con trước.',
      icon: 'warning'
    })
    return
  }

  const result = await Swal.fire({
    title: 'Xác nhận xóa',
    text: `Bạn có chắc chắn muốn xóa danh mục "${category.name}"?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy'
  })

  if (result.isConfirmed) {
    await deleteCategory(category.id)
  }
}

const deleteCategory = async (categoryId) => {
  submitting.value = true

  const result = await categoriesStore.deleteCategory(categoryId)

  if (result.success) {
    Swal.fire('Đã xóa!', result.message, 'success')
  } else {
    Swal.fire('Lỗi!', result.error, 'error')
  }

  submitting.value = false
}

// Lifecycle
onMounted(() => {
  loadData()
})

// Watch for store errors
watch(() => categoriesStore.error, (newError) => {
  if (newError) {
    console.error('Categories store error:', newError)
  }
})
</script>

<style scoped>
.btn-ghost {
  background: transparent;
  border: none;
  color: inherit;
  text-align: left;
  width: 100%;
  padding: 0.25rem 0.5rem;
}

.btn-ghost:hover {
  background-color: rgba(0,0,0,0.05);
}

.btn-close-white {
  filter: invert(1) grayscale(100%) brightness(200%);
}

.badge .btn-close {
  font-size: 0.7em;
  padding: 0;
  margin-left: 0.25rem;
}

.pagination-sm .page-link {
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
}

.table th button {
  font-weight: 600;
  color: #495057;
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

.text-truncate {
  max-width: 200px;
}

@media (max-width: 768px) {
  .btn-group-sm {
    flex-direction: column;
  }

  .btn-group-sm .btn {
    border-radius: 0.375rem !important;
    margin-bottom: 0.25rem;
  }
}
</style>
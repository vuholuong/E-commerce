<template>
  <AdminLayout>
    <!-- Shop Stats -->
    <div class="row mb-4 g-2">
      <div class="col-6 col-md-3">
        <div class="card bg-primary text-white">
          <div class="card-body text-center p-2">
            <h5 class="mb-0">{{ shopStats.total }}</h5>
            <small>Tổng Shops</small>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="card bg-success text-white">
          <div class="card-body text-center p-2">
            <h5 class="mb-0">{{ shopStats.active }}</h5>
            <small>Đang hoạt động</small>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="card bg-warning text-white">
          <div class="card-body text-center p-2">
            <h5 class="mb-0">{{ shopStats.pending }}</h5>
            <small>Chờ duyệt</small>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="card bg-danger text-white">
          <div class="card-body text-center p-2">
            <h5 class="mb-0">{{ shopStats.suspended }}</h5>
            <small>Bị tạm ngưng</small>
          </div>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
      <div class="card-body">
        <div class="row g-2 ">
          <div class="col-12 col-md-4">
            <select class="form-select form-select-sm" v-model="filters.status">
              <option value="">Tất cả trạng thái</option>
              <option value="active">Hoạt động</option>
              <option value="pending">Chờ duyệt</option>
              <option value="suspended">Bị tạm ngưng</option>
            </select>
          </div>
          <!-- <div class="col-12 col-md-3">
            <input type="text" class="form-control form-control-sm" placeholder="Email seller..."
              v-model="filters.sellerEmail">
          </div> -->
          <div class="col-12 col-md-6">
            <input type="text" class="form-control form-control-sm" placeholder="Tìm kiếm shop..."
              v-model="filters.searchTerm" @keyup.enter="searchShops">
          </div>
          <div class="col-12 col-md-2">
            <button class="btn btn-outline-success w-100 btn-sm" @click="searchShops" :disabled="loading">
              <span v-if="loading" class="spinner-border spinner-border-sm me-1"></span>
              Tìm kiếm
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Loading -->
    <div v-if="loading && shops.length === 0" class="text-center py-5">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>

    <!-- Shops Table -->
    <div class="card" v-if="!loading || shops.length > 0">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-sm mb-0">
            <thead class=" d-md-table-header-group">
              <tr>
                <th>Shop</th>
                <th>Seller</th>
                <th>Email</th>
                <!-- <th>Ngày duyệt</th> -->
                <th>Sản phẩm</th>
                <th>Đánh giá</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="shop in shops" :key="shop.id">
                <!-- Mobile view -->
                <td class="d-md-none">
                  <div class="d-flex flex-column">
                    <div class="d-flex align-items-center mb-2">
                      <div
                        class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                        style="width: 40px; height: 40px;">
                        {{ shop.name.charAt(0).toUpperCase() }}
                      </div>
                      <div>
                        <strong>{{ shop.name }}</strong><br>
                        <small class="text-muted">ID: {{ shop.id }}</small>
                      </div>
                    </div>

                    <div class="mb-2">
                      <strong>Seller:</strong> {{ shop.sellerFullName }}<br>
                      <small class="text-muted">{{ shop.sellerPhone }}</small>
                    </div>

                    <div class="mb-2">
                      <strong>Email:</strong> {{ shop.sellerEmail }}
                    </div>

                    <!-- <div class="mb-2">
                      <strong>Ngày duyệt:</strong> {{ formatDate(shop.approvedAt) }}
                    </div> -->

                    <div class="mb-2">
                      <strong>Sản phẩm:</strong>
                      <span class="badge bg-info me-1">{{ shop.totalProducts }}</span> Tổng
                      <span class="badge bg-warning">{{ shop.pendingProducts }}</span> Chờ
                      <span class="badge bg-success me-1">{{ shop.approvedProducts }}</span> Đã duyệt
                      
                    </div>

                    <div class="mb-2">
                      <strong>Đánh giá:</strong>
                      <span class="me-1">{{ shop.rating.toFixed(1) }}</span>
                      <i class="bi bi-star-fill text-warning"></i>
                    </div>

                    <div class="mb-2">
                      <strong>Trạng thái:</strong>
                      <span :class="`badge bg-${shop.statusColor}`">{{ shop.status }}</span>
                    </div>

                    <div class="btn-group btn-group-sm d-flex">
                      <button class="btn btn-outline-primary flex-grow-1" @click="viewShop(shop)">
                        <i class="bi bi-eye"></i>
                      </button>
                      <button class="btn btn-outline-success flex-grow-1" v-if="shop.status === 'Chờ duyệt'"
                        @click="approveShop(shop)">
                        <i class="bi bi-check-circle"></i>
                      </button>
                      <button class="btn btn-outline-warning flex-grow-1 " v-if="shop.status === 'Hoạt động'"
                        @click="suspendShop(shop)">
                        <i class="bi bi-pause-circle"></i>
                      </button>
                      <button class="btn btn-outline-success flex-grow-1" v-if="shop.status === 'Bị tạm ngưng'"
                        @click="reactivateShop(shop)">
                        <i class="bi bi-play-circle"></i>
                      </button>
                      <button class="btn btn-outline-danger flex-grow-1" v-if="shop.status === 'Chờ duyệt'"
                        @click="rejectShop(shop)">
                        <i class="bi bi-x-circle"></i>
                      </button>
                    </div>
                  </div>
                </td>

                <!-- Desktop view -->
                <td class="d-none d-md-table-cell">
                  <div class="d-flex align-items-center">
                    <div
                      class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                      style="width: 40px; height: 40px;">
                      {{ shop.name.charAt(0).toUpperCase() }}
                    </div>
                    <div>
                      <strong>{{ shop.name }}</strong><br>
                      <small class="text-muted">ID: {{ shop.id }}</small>
                    </div>
                  </div>
                </td>
                <td class="d-none d-md-table-cell">
                  <div>
                    <strong>{{ shop.sellerFullName }}</strong><br>
                    <small class="text-muted">{{ shop.sellerPhone }}</small>
                  </div>
                </td>
                <td class="d-none d-md-table-cell">{{ shop.sellerEmail }}</td>
                <!-- <td class="d-none d-md-table-cell">{{ formatDate(shop.approvedAt) }}</td> -->
                <td class="d-none d-md-table-cell">
                  <div>
                    <span class="badge bg-info me-1">{{ shop.totalProducts }}</span> Tổng<br>
                    <span class="badge bg-success me-1">{{ shop.approvedProducts }}</span> Đã duyệt <br>
                    <span class="badge bg-warning">{{ shop.pendingProducts }}</span> Chờ
                  </div>
                </td>
                <td class="d-none d-md-table-cell">
                  <div class="d-flex align-items-center">
                    <span class="me-1">{{ shop.rating.toFixed(1) }}</span>
                    <i class="bi bi-star-fill text-warning"></i>
                  </div>
                </td>
                <td class="d-none d-md-table-cell">
                  <span :class="`badge bg-${shop.statusColor}`">{{ shop.status }}</span>
                </td>
                <td class="d-none d-md-table-cell">
                  <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary me-1" @click="viewShop(shop)">
                      <i class="bi bi-eye"></i> Xem
                    </button>
                    <button class="btn btn-outline-success ms-1" v-if="shop.status === 'Chờ duyệt'"
                      @click="approveShop(shop)">
                      <i class="bi bi-check-circle"></i> Duyệt
                    </button>
                    <button class="btn btn-outline-warning ms-1" v-if="shop.status === 'Hoạt động'"
                      @click="suspendShop(shop)">
                      <i class="bi bi-pause-circle"></i> Tạm ngưng
                    </button>
                    <button class="btn btn-outline-success ms-1" v-if="shop.status === 'Bị tạm ngưng'"
                      @click="reactivateShop(shop)">
                      <i class="bi bi-play-circle"></i> Kích hoạt
                    </button>
                    <button class="btn btn-outline-danger ms-1" v-if="shop.status === 'Chờ duyệt'" @click="rejectShop(shop)">
                      <i class="bi bi-x-circle"></i> Từ chối
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <nav class="mt-4 px-3" v-if="pagination.totalPages > 1">
          <ul class="pagination pagination-sm justify-content-center flex-wrap">
            <li class="page-item" :class="{ disabled: !pagination.hasPrevious }">
              <a class="page-link" href="#" @click.prevent="changePage(pagination.currentPage - 1)">
                Trước
              </a>
            </li>
            <li v-for="page in visiblePages" :key="page" class="page-item"
              :class="{ active: page === pagination.currentPage }">
              <a class="page-link" href="#" @click.prevent="changePage(page)">
                {{ page + 1 }}
              </a>
            </li>
            <li class="page-item" :class="{ disabled: !pagination.hasNext }">
              <a class="page-link" href="#" @click.prevent="changePage(pagination.currentPage + 1)">
                Sau
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>

    <!-- Shop Detail Modal -->
    <div class="modal fade" :class="{ show: showDetailModal, 'd-block': showDetailModal }" tabindex="-1"
      v-if="showDetailModal && selectedShop">
      <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Chi tiết Shop - {{ selectedShop.name }}</h5>
            <button type="button" class="btn-close" @click="closeDetailModal"></button>
          </div>
          <div class="modal-dialog">
            <div class="row">
              <div class="col-12 col-md-4 mb-3 mb-md-0">
                <div class="card">
                  <div class="card-body text-center">
                    <div
                      class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3"
                      style="width: 80px; height: 80px; font-size: 1.5rem;">
                      {{ selectedShop.name.charAt(0).toUpperCase() }}
                    </div>
                    <h5>{{ selectedShop.name }}</h5>
                    <p class="text-muted">{{ selectedShop.slug }}</p>
                    <span :class="`badge bg-${selectedShop.statusColor} mb-3`">{{ selectedShop.status }}</span>
                    <div class="d-flex justify-content-center align-items-center">
                      <span class="me-1">{{ selectedShop.rating.toFixed(1) }}</span>
                      <i class="bi bi-star-fill text-warning"></i>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-md-8">
                <div class="row">
                  <div class="col-12 col-md-6 mb-3 mb-md-0">
                    <h6>Thông tin shop</h6>
                    <table class="table table-sm table-borderless">
                      <tbody>
                        <tr>
                          <td><strong>Email liên hệ:</strong></td>
                          <td>{{ selectedShop.contactEmail }}</td>
                        </tr>
                        <tr>
                          <td><strong>Điện thoại:</strong></td>
                          <td>{{ selectedShop.contactPhone }}</td>
                        </tr>
                        <tr>
                          <td><strong>Mô tả:</strong></td>
                          <td>{{ selectedShop.description }}</td>
                        </tr>
                        <tr>
                          <td><strong>Ngày duyệt:</strong></td>
                          <td>{{ formatDate(selectedShop.approvedAt) }}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="col-12 col-md-6">
                    <h6>Thông tin seller</h6>
                    <table class="table table-sm table-borderless">
                      <tbody>
                        <tr>
                          <td><strong>Tên:</strong></td>
                          <td>{{ selectedShop.sellerFullName }}</td>
                        </tr>
                        <tr>
                          <td><strong>Email:</strong></td>
                          <td>{{ selectedShop.sellerEmail }}</td>
                        </tr>
                        <tr>
                          <td><strong>Điện thoại:</strong></td>
                          <td>{{ selectedShop.sellerPhone }}</td>
                        </tr>
                        <tr>
                          <td><strong>Địa chỉ:</strong></td>
                          <td>{{ selectedShop.sellerAddress }}</td>
                        </tr>
                      </tbody>
                    </table>

                    <h6 class="mt-3">Thống kê sản phẩm</h6>
                    <table class="table table-sm table-borderless">
                      <tbody>
                        <tr>
                          <td><strong>Tổng sản phẩm:</strong></td>
                          <td><span class="badge bg-info">{{ selectedShop.totalProducts }}</span></td>
                        </tr>
                        <tr>
                          <td><strong>Đã duyệt:</strong></td>
                          <td><span class="badge bg-success">{{ selectedShop.approvedProducts }}</span></td>
                        </tr>
                        <tr>
                          <td><strong>Chờ duyệt:</strong></td>
                          <td><span class="badge bg-warning">{{ selectedShop.pendingProducts }}</span></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeDetailModal">Đóng</button>
            <button type="button" class="btn btn-success" v-if="selectedShop.status === 'Chờ duyệt'"
              @click="handleApproveShop">
              Duyệt Shop
            </button>
            <button type="button" class="btn btn-warning" v-if="selectedShop.status === 'Hoạt động'"
              @click="handleSuspendShop">
              Tạm ngưng
            </button>
            <button type="button" class="btn btn-success" v-if="selectedShop.status === 'Bị tạm ngưng'"
              @click="handleReactivateShop">
              Kích hoạt lại
            </button>
            <button type="button" class="btn btn-danger" v-if="selectedShop.status === 'Chờ duyệt'"
              @click="handleRejectShop">
              Từ chối
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop fade show" v-if="showDetailModal"></div>

  </AdminLayout>
</template>

<script setup>
import { ref, computed, onMounted, reactive, watch } from 'vue'
import AdminLayout from '@/components/AdminLayout.vue'
import Swal from 'sweetalert2'
import shopAdminService from '@/services/admin/shops'

// State
const loading = ref(false)
const showDetailModal = ref(false)
const selectedShop = ref(null)
const shops = ref([])

// Stats
const shopStats = ref({
  total: 0,
  active: 0,
  pending: 0,
  suspended: 0
})

// Filters
const filters = reactive({
  searchTerm: '',
  status: '',
  sellerEmail: '',
  city: '',
  country: '',
  sortBy: 'createdAt',
  sortDirection: 'desc'
})

// Pagination
const pagination = reactive({
  currentPage: 0,
  totalPages: 0,
  totalElements: 0,
  pageSize: 5,
  hasNext: false,
  hasPrevious: false
})

// Computed properties
const visiblePages = computed(() => {
  const pages = []
  const start = Math.max(0, pagination.currentPage - 2)
  const end = Math.min(pagination.totalPages - 1, pagination.currentPage + 2)

  for (let i = start; i <= end; i++) {
    pages.push(i)
  }

  return pages
})

// Methods
const formatDate = (dateString) => {
  if (!dateString) return 'Chưa duyệt'
  return new Date(dateString).toLocaleDateString('vi-VN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const loadShops = async (page = 0) => {
  loading.value = true
  try {
    const params = { ...filters, page, size: pagination.pageSize }

    // Remove empty filters
    Object.keys(params).forEach(key => {
      if (params[key] === '') delete params[key]
    })

    const response = await shopAdminService.getShops(params)

    if (response.statusCode === 200) {
      const data = response.data

      // Map shops with status
      shops.value = data.shops.map(shop => {
        const { status, statusColor } = shopAdminService.mapShopStatus(shop)
        return { ...shop, status, statusColor }
      })

      // Update pagination
      Object.assign(pagination, {
        currentPage: data.currentPage,
        totalPages: data.totalPages,
        totalElements: data.totalElements,
        pageSize: data.pageSize,
        hasNext: data.hasNext,
        hasPrevious: data.hasPrevious
      })

      // Update stats
      shopStats.value = shopAdminService.calculateShopStats(shops.value)
    }
  } catch (error) {
    console.error('Error loading shops:', error)
    showErrorMessage('Không thể tải danh sách shop', error.message)
  } finally {
    loading.value = false
  }
}

const searchShops = () => {
  pagination.currentPage = 0
  loadShops(0)
}

const changePage = (page) => {
  if (page >= 0 && page < pagination.totalPages) {
    loadShops(page)
  }
}

// Modal methods
const viewShop = (shop) => {
  selectedShop.value = { ...shop }
  showDetailModal.value = true
}

const closeDetailModal = () => {
  showDetailModal.value = false
  selectedShop.value = null
}

// Action methods
const approveShop = (shop) => {
  selectedShop.value = shop
  handleApproveShop()
}

const handleApproveShop = async () => {
 // closeDetailModal()

  const result = await showConfirmDialog(
    'Duyệt Shop?',
    `Bạn có chắc chắn muốn duyệt shop "${selectedShop.value.name}"?`,
    'Duyệt',
    '#28a745'
  )

  if (result.isConfirmed) {
    await executeAction(
      () => shopAdminService.approveShop(selectedShop.value.id),
      'Đã duyệt!',
      'Shop đã được duyệt thành công và seller đã được cấp quyền bán hàng',
      'Không thể duyệt shop'
    )
  }
}

const rejectShop = (shop) => {
  selectedShop.value = shop
  handleRejectShop()
}

const handleRejectShop = async () => {
  //closeDetailModal()

  const { value: rejectionReason } = await Swal.fire({
    title: 'Từ chối Shop',
    text: `Nhập lý do từ chối shop "${selectedShop.value.name}":`,
    input: 'textarea',
    inputPlaceholder: 'Lý do từ chối...',
    inputValidator: (value) => {
      if (!value) return 'Bạn cần nhập lý do từ chối!'
    },
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Từ chối',
    cancelButtonText: 'Hủy'
  })

  if (rejectionReason) {
    await executeAction(
      () => shopAdminService.rejectShop(selectedShop.value.id, { rejectionReason }),
      'Đã từ chối!',
      'Shop đã được từ chối',
      'Không thể từ chối shop'
    )
  }
}

const suspendShop = (shop) => {
  selectedShop.value = shop
  handleSuspendShop()
}

const handleSuspendShop = async () => {
  //closeDetailModal()

  const { value: suspensionReason } = await Swal.fire({
    title: 'Tạm ngưng Shop',
    text: `Nhập lý do tạm ngưng shop "${selectedShop.value.name}":`,
    input: 'textarea',
    inputPlaceholder: 'Lý do tạm ngưng...',
    inputValidator: (value) => {
      if (!value) return 'Bạn cần nhập lý do tạm ngưng!'
    },
    showCancelButton: true,
    confirmButtonColor: '#ffc107',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Tạm ngưng',
    cancelButtonText: 'Hủy'
  })

  if (suspensionReason) {
    await executeAction(
      () => shopAdminService.suspendShop(selectedShop.value.id, { rejectionReason: suspensionReason }),
      'Đã tạm ngưng!',
      'Shop đã được tạm ngưng',
      'Không thể tạm ngưng shop'
    )
  }
}

const reactivateShop = (shop) => {
  selectedShop.value = shop
  handleReactivateShop()
}

const handleReactivateShop = async () => {
//  closeDetailModal()

  const result = await showConfirmDialog(
    'Kích hoạt lại Shop?',
    `Bạn có chắc chắn muốn kích hoạt lại shop "${selectedShop.value.name}"?`,
    'Kích hoạt',
    '#28a745'
  )

  if (result.isConfirmed) {
    await executeAction(
      () => shopAdminService.reactivateShop(selectedShop.value.id),
      'Đã kích hoạt!',
      'Shop đã được kích hoạt lại',
      'Không thể kích hoạt lại shop'
    )
  }
}

// Utility methods
const showConfirmDialog = (title, text, confirmButtonText, confirmButtonColor) => {
  return Swal.fire({
    title,
    text,
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor,
    cancelButtonColor: '#6c757d',
    confirmButtonText,
    cancelButtonText: 'Hủy'
  })
}

const showErrorMessage = (title, text) => {
  Swal.fire({
    title: 'Lỗi!',
    text: text || title,
    icon: 'error'
  })
}

const showSuccessMessage = (title, text) => {
  return Swal.fire({
    title,
    text,
    icon: 'success',
    timer: 2000,
    showConfirmButton: false
  })
}

const executeAction = async (actionFn, successTitle, successText, errorText) => {
  try {
    const response = await actionFn()

    if (response.statusCode === 200) {
      await showSuccessMessage(successTitle, successText)
      await loadShops(pagination.currentPage)
    }
  } catch (error) {
    showErrorMessage(errorText, error.message)
  }
}

// Watchers
watch(() => filters.status, searchShops, { deep: true })

// Lifecycle
onMounted(() => {
  loadShops()
})
</script>

<style scoped>
.table th {
  border-top: none;
  font-weight: 600;
  background-color: #f8f9fa;
}

.badge {
  font-size: 0.75em;
}

.btn-group-sm>.btn {
  padding: 0.25rem 0.5rem;
  font-size: 0.75rem;
}

.spinner-border-sm {
  width: 1rem;
  height: 1rem;
}

.modal.show {
  background-color: rgba(0, 0, 0, 0.5);
}

.card {
  border: none;
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}

/* Mobile styles */
@media (max-width: 767.98px) {
  .btn-group-sm>.btn {
    margin-bottom: 0.25rem;
  }

  .table-responsive {
    font-size: 0.875rem;
  }

  .modal-dialog {
    margin: 0.5rem;
  }

  .modal-content {
    border-radius: 0.5rem;
  }

  .modal-body {
    padding: 1.5rem;
  }

  .modal-footer {
    flex-wrap: wrap;
  }

  .modal-footer .btn {
    margin-bottom: 0.5rem;
    flex: 1 0 45%;
  }

  /* Stack cards vertically on mobile */
  .row>[class*="col-"] {
    margin-bottom: 0.5rem;
  }

  /* Smaller font size for shop stats on mobile */
  .card h3 {
    font-size: 1.25rem;
  }
}

/* Tablet styles */
@media (min-width: 768px) and (max-width: 991.98px) {
  .modal-dialog {
    max-width: 90%;
  }

  /* Adjust table columns */
  .table td,
  .table th {
    padding: 0.5rem;
  }

  /* Make buttons smaller */
  .btn-group-sm>.btn {
    padding: 0.2rem 0.4rem;
    font-size: 0.7rem;
  }
}

/* Hide some table columns on smaller screens */
@media (max-width: 991.98px) {
  .d-md-table-cell {
    display: table-cell !important;
  }

  .d-md-none {
    display: none !important;
  }
}

@media (max-width: 767.98px) {
  .d-md-none {
    display: block !important;
  }

  .d-md-table-cell {
    display: none !important;
  }

  /* Make pagination fit better */
  .pagination {
    flex-wrap: wrap;
  }

  .page-item {
    margin-bottom: 0.25rem;
  }
}
</style>
<template>
  <AdminLayout>
    <div class="container-fluid py-4">
      <!-- Search and Filter -->
      <div class="card mb-4">
        <div class="card-body">
          <div class="row g-3">
            <!-- <div class="col-md-3">
              <label for="userId" class="form-label">Tìm theo User ID</label>
              <input
                id="userId"
                v-model="searchParams.userId"
                type="number"
                class="form-control"
                placeholder="Nhập User ID"
                @input="debouncedSearch"
              />
            </div> -->
            <div class="col-md-3">
              <label for="userEmail" class="form-label">Email</label>
              <input id="userEmail" v-model="searchParams.userEmail" type="text" class="form-control"
                placeholder="Nhập email" @input="debouncedSearch" />
            </div>
            <div class="col-md-3">
              <label for="city" class="form-label">Thành phố</label>
              <input id="city" v-model="searchParams.city" type="text" class="form-control" placeholder="Nhập thành phố"
                @input="debouncedSearch" />
            </div>
            <div class="col-md-3 d-flex align-items-end">
              <button @click="clearSearch" class="btn btn-outline-secondary">
                Xóa bộ lọc
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Loading State -->
      <div v-if="loading" class="text-center py-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>
      </div>

      <!-- Address List -->
      <div v-else-if="addresses.length > 0" class="card">
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Người dùng</th>
                <th scope="col">Địa chỉ</th>
                <th scope="col">Liên hệ</th>
                <th scope="col">Trạng thái</th>
                <th scope="col">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="address in addresses" :key="address.userAddressId">
                <td>
                  <strong>{{ address.userAddressId }}</strong>
                </td>
                <td>
                  <div>
                    <div class="fw-medium">{{ address.userFullName }}</div>
                    <div class="text-muted small">{{ address.userEmail }}</div>
                    <div class="text-muted" style="font-size: 0.8rem;">ID: {{ address.userId }}</div>
                  </div>
                </td>
                <td>
                  <div>
                    <div class="text-truncate" style="max-width: 300px;">
                      {{ address.fullAddress }}
                    </div>
                    <div class="text-muted small">
                      {{ address.ward }}, {{ address.district }}
                    </div>
                  </div>
                </td>
                <td>
                  <div>
                    <div class="fw-medium">{{ address.contactFullName }}</div>
                    <div class="text-muted small">{{ address.contactPhoneNumber }}</div>
                  </div>
                </td>
                <td>
                  <div class="d-flex flex-column gap-1">
                    <span v-if="address.isDefaultShipping" class="badge bg-success">
                      Giao hàng mặc định
                    </span>
                    <span v-if="address.isDefaultBilling" class="badge bg-primary">
                      Thanh toán mặc định
                    </span>
                  </div>
                </td>
                <td>
                  <div class="d-flex gap-2">
                    <button @click="viewAddress(address.userAddressId)" class="btn btn-outline-primary btn-sm"
                      title="Xem chi tiết">
                      <i class="bi bi-eye"></i> Xem
                    </button>
                    <!-- <button @click="confirmDeleteAddress(address)" class="btn btn-outline-danger btn-sm"
                      title="Xóa địa chỉ">
                      <i class="bi bi-trash"></i> Xóa
                    </button> -->
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <div class="card-footer bg-white border-top">
          <div class="row align-items-center">
            <div class="col-md-6">
              <small class="text-muted">
                Hiển thị từ
                <strong>{{ (currentPage * pageSize) + 1 }}</strong>
                đến
                <strong>{{ Math.min((currentPage + 1) * pageSize, totalElements) }}</strong>
                trong tổng số
                <strong>{{ totalElements }}</strong>
                kết quả
              </small>
            </div>
            <div class="col-md-6">
              <nav aria-label="Pagination">
                <ul class="pagination pagination-sm justify-content-end mb-0">
                  <li class="page-item" :class="{ disabled: currentPage <= 0 }">
                    <button class="page-link" @click="changePage(currentPage - 1)" :disabled="currentPage <= 0">
                      ‹ Trước
                    </button>
                  </li>
                  <template v-for="page in visiblePages" :key="page">
                    <li class="page-item" :class="{ active: page === currentPage }">
                      <button class="page-link" @click="changePage(page)">
                        {{ page + 1 }}
                      </button>
                    </li>
                  </template>
                  <li class="page-item" :class="{ disabled: currentPage >= totalPages - 1 }">
                    <button class="page-link" @click="changePage(currentPage + 1)"
                      :disabled="currentPage >= totalPages - 1">
                      Sau ›
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>

      <!-- Empty State -->
      <div v-else class="card text-center py-5">
        <div class="card-body">
          <div class="display-1 text-muted mb-3">📍</div>
          <h4 class="card-title">Không tìm thấy địa chỉ</h4>
          <p class="card-text text-muted">Không có địa chỉ nào phù hợp với tiêu chí tìm kiếm.</p>
        </div>
      </div>

      <!-- Address Detail Modal -->
      <div v-if="showDetailModal" class="modal fade show d-block" tabindex="-1" role="dialog"
        style="background-color: rgba(0,0,0,0.5);">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="document">
          <div class="modal-content" v-if="selectedAddress">
            <!-- Modal Header với gradient -->
            <div class="modal-header bg-gradient-primary text-white">
              <h5 class="modal-title">
                <i class="bi bi-geo-alt-fill me-2"></i>
                Chi tiết địa chỉ #{{ selectedAddress.id }}
              </h5>
              <button type="button" class="btn-close btn-close-white" @click="closeDetailModal"></button>
            </div>

            <!-- Modal Body được thiết kế lại -->
            <div class="modal-body">
              <!-- Card thông tin người dùng -->
              <div class="card mb-4 shadow-sm">
                <div class="card-header bg-light">
                  <h6 class="mb-0">
                    <i class="bi bi-person-circle me-2"></i>
                    Thông tin người dùng
                  </h6>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Họ tên</label>
                      <p class="fw-semibold mb-0">{{ selectedAddress.userFullName }}</p>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Email</label>
                      <p class="mb-0">
                        <a :href="`mailto:${selectedAddress.userEmail}`" class="text-decoration-none">
                          <i class="bi bi-envelope me-1"></i>
                          {{ selectedAddress.userEmail }}
                        </a>
                      </p>
                    </div>
                    <!-- <div class="col-md-6">
                      <label class="form-label text-muted small mb-1">User ID</label>
                      <p class="mb-0">
                        <span class="badge bg-secondary">{{ selectedAddress.userId }}</span>
                      </p>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label text-muted small mb-1">Address ID</label>
                      <p class="mb-0">
                        <span class="badge bg-info text-dark">{{ selectedAddress.id }}</span>
                      </p>
                    </div> -->
                  </div>
                </div>
              </div>

              <!-- Card địa chỉ chi tiết -->
              <div class="card mb-4 shadow-sm">
                <div class="card-header bg-light">
                  <h6 class="mb-0">
                    <i class="bi bi-house-door me-2"></i>
                    Địa chỉ chi tiết
                  </h6>
                </div>
                <div class="card-body">
                  <div class="d-flex mb-3">
                    <div class="flex-shrink-0">
                      <div class="bg-primary rounded-circle p-3 text-white">
                        <i class="bi bi-geo-fill" style="font-size: 1.5rem;"></i>
                      </div>
                    </div>
                    <div class="flex-grow-1 ms-3">
                      <h6 class="fw-bold mb-1">Địa chỉ đầy đủ</h6>
                      <p class="mb-0">{{ selectedAddress.fullAddress }}</p>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Địa chỉ dòng 1</label>
                      <p class="mb-0">{{ selectedAddress.streetAddress1 || 'Không có' }}</p>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Địa chỉ dòng 2</label>
                      <p class="mb-0">{{ selectedAddress.streetAddress2 || 'Không có' }}</p>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label class="form-label text-muted small mb-1">Phường/Xã</label>
                      <p class="mb-0">{{ selectedAddress.ward }}</p>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label class="form-label text-muted small mb-1">Quận/Huyện</label>
                      <p class="mb-0">{{ selectedAddress.district }}</p>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label class="form-label text-muted small mb-1">Thành phố</label>
                      <p class="mb-0">{{ selectedAddress.city }}</p>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Mã bưu điện</label>
                      <p class="mb-0">{{ selectedAddress.postalCode }}</p>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Mã quốc gia</label>
                      <p class="mb-0">
                        <span class="badge bg-light text-dark border">
                          {{ selectedAddress.countryCode }}
                        </span>
                      </p>
                    </div>
                    <div class="col-12" v-if="selectedAddress.latitude && selectedAddress.longitude">
                      <label class="form-label text-muted small mb-1">Tọa độ</label>
                      <p class="mb-0">
                        <span class="badge bg-light text-dark border me-2">
                          <i class="bi bi-geo-alt me-1"></i>
                          {{ selectedAddress.latitude }}, {{ selectedAddress.longitude }}
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Card thông tin liên hệ -->
              <div class="card mb-4 shadow-sm">
                <div class="card-header bg-light">
                  <h6 class="mb-0">
                    <i class="bi bi-telephone me-2"></i>
                    Thông tin liên hệ
                  </h6>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Người liên hệ</label>
                      <p class="fw-semibold mb-0">{{ selectedAddress.contactFullName }}</p>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Số điện thoại</label>
                      <p class="mb-0">
                        <a :href="`tel:${selectedAddress.contactPhoneNumber}`" class="text-decoration-none">
                          <i class="bi bi-phone me-1"></i>
                          {{ selectedAddress.contactPhoneNumber }}
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Card trạng thái -->
              <div class="card mb-4 shadow-sm">
                <div class="card-header bg-light">
                  <h6 class="mb-0">
                    <i class="bi bi-info-circle me-2"></i>
                    Trạng thái & Thời gian
                  </h6>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Trạng thái</label>
                      <div>
                        <span v-if="selectedAddress.isDefaultShipping" class="badge bg-success me-2 mb-2">
                          <i class="bi bi-truck me-1"></i> Giao hàng mặc định
                        </span>
                        <span v-if="selectedAddress.isDefaultBilling" class="badge bg-primary me-2 mb-2">
                          <i class="bi bi-credit-card me-1"></i> Thanh toán mặc định
                        </span>
                        <span v-if="!selectedAddress.isDefaultShipping && !selectedAddress.isDefaultBilling"
                          class="badge bg-secondary">
                          Địa chỉ thông thường
                        </span>
                      </div>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Ngày tạo</label>
                      <p class="mb-0">
                        <i class="bi bi-calendar-plus me-1 text-muted"></i>
                        {{ formatDateTime(selectedAddress.createdAt) }}
                      </p>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label text-muted small mb-1">Cập nhật lần cuối</label>
                      <p class="mb-0">
                        <i class="bi bi-calendar-check me-1 text-muted"></i>
                        {{ formatDateTime(selectedAddress.updatedAt) }}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-secondary" @click="closeDetailModal">
                <i class="bi bi-x-circle me-1"></i> Đóng
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, computed, watch } from 'vue'
import AdminLayout from '../../components/AdminLayout.vue'
import { addressService } from '../../services/admin/address'
import Swal from 'sweetalert2'

// Reactive data
const loading = ref(false)
const addresses = ref([])
const searchParams = ref({
  userId: '',
  userAddressId: '',
  addressId: '',
  userEmail: '',
  city: '',
  page: 0,
  size: 10,
  sort: 'createdAt,desc'
})

// Pagination
const currentPage = ref(0)
const pageSize = ref(10)
const totalElements = ref(0)
const totalPages = ref(0)

// Modal
const showDetailModal = ref(false)
const selectedAddress = ref(null)

// Debounce search
let searchTimeout = null
const debouncedSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    currentPage.value = 0
    searchParams.value.page = 0
    fetchAddresses()
  }, 500)
}

// Computed
const visiblePages = computed(() => {
  const delta = 2
  const range = []
  const rangeWithDots = []

  for (let i = Math.max(0, currentPage.value - delta);
    i <= Math.min(totalPages.value - 1, currentPage.value + delta);
    i++) {
    range.push(i)
  }

  if (range[0] > 0) {
    rangeWithDots.push(0)
    if (range[0] > 1) {
      rangeWithDots.push('...')
    }
  }

  rangeWithDots.push(...range)

  if (range[range.length - 1] < totalPages.value - 1) {
    if (range[range.length - 1] < totalPages.value - 2) {
      rangeWithDots.push('...')
    }
    rangeWithDots.push(totalPages.value - 1)
  }

  return rangeWithDots.filter(page => page !== '...')
})

// Methods
const fetchAddresses = async () => {
  loading.value = true
  try {
    // Clean up empty search params
    const cleanParams = Object.keys(searchParams.value).reduce((acc, key) => {
      if (searchParams.value[key] !== '' && searchParams.value[key] !== null) {
        acc[key] = searchParams.value[key]
      }
      return acc
    }, {})

    const response = await addressService.getAllAddresses(cleanParams)

    if (response.statusCode === 200) {
      addresses.value = response.data.content
      currentPage.value = response.data.number
      pageSize.value = response.data.size
      totalElements.value = response.data.totalElements
      totalPages.value = response.data.totalPages
    }
  } catch (error) {
    console.error('Lỗi khi tải danh sách địa chỉ:', error)
    Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Không thể tải danh sách địa chỉ. Vui lòng thử lại.',
      confirmButtonText: 'OK'
    })
  } finally {
    loading.value = false
  }
}

const changePage = (page) => {
  if (page >= 0 && page < totalPages.value) {
    currentPage.value = page
    searchParams.value.page = page
    fetchAddresses()
  }
}

const clearSearch = () => {
  searchParams.value = {
    userId: '',
    userEmail: '',
    city: '',
    page: 0,
    size: 20,
    sort: 'createdAt,desc'
  }
  currentPage.value = 0
  fetchAddresses()
}

const viewAddress = async (userAddressId) => {
  try {
    loading.value = true
    const response = await addressService.getAddressById(userAddressId)

    if (response.statusCode === 200) {
      selectedAddress.value = response.data
      showDetailModal.value = true
    }
  } catch (error) {
    console.error('Lỗi khi tải chi tiết địa chỉ:', error)
    Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Không thể tải chi tiết địa chỉ. Vui lòng thử lại.',
      confirmButtonText: 'OK'
    })
  } finally {
    loading.value = false
  }
}

const closeDetailModal = () => {
  showDetailModal.value = false
  selectedAddress.value = null
}

const confirmDeleteAddress = async (address) => {
  const result = await Swal.fire({
    title: 'Xác nhận xóa địa chỉ',
    html: `
      <div class="text-start" style="font-size: 0.9rem; font-weight: 500;">
        <p>Bạn có chắc chắn muốn xóa địa chỉ này?</p>
        <div class="mt-3 p-3 bg-light rounded">
          <strong>ID:</strong> ${address.userAddressId}<br>
          <strong>Người dùng:</strong> ${address.userFullName}<br>
          <strong>Địa chỉ:</strong> ${address.fullAddress}
        </div>
      </div>
    `,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: '<i class="bi bi-trash"></i> Xóa',
    cancelButtonText: '<i class="bi bi-x"></i> Hủy',
    input: 'textarea',
    inputPlaceholder: 'Nhập lý do xóa (không bắt buộc)...',
    inputAttributes: {
      'aria-label': 'Lý do xóa',
      'style': 'width: 450px; height: 70px; resize: none; font-size: 0.85rem;'
    },
    customClass: {
      input: 'form-control'
    }
  })

  if (result.isConfirmed) {
    await deleteAddress(address.userAddressId, result.value)
  }
}


const deleteAddress = async (userAddressId, reason) => {
  try {
    loading.value = true
    const deleteData = {
      reason: reason || 'Admin deletion',
      adminId: null // Có thể lấy từ auth store nếu cần
    }

    const response = await addressService.deleteAddress(userAddressId, deleteData)

    if (response.statusCode === 200) {
      await Swal.fire({
        icon: 'success',
        title: 'Thành công!',
        text: 'Địa chỉ đã được xóa thành công.',
        confirmButtonText: 'OK',
        timer: 2000,
        timerProgressBar: true
      })

      // Refresh list
      await fetchAddresses()
    }
  } catch (error) {
    console.error('Lỗi khi xóa địa chỉ:', error)
    Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Không thể xóa địa chỉ. Vui lòng thử lại.',
      confirmButtonText: 'OK'
    })
  } finally {
    loading.value = false
  }
}

const formatDateTime = (dateTimeString) => {
  if (!dateTimeString) return 'N/A'
  const date = new Date(dateTimeString)
  return date.toLocaleString('vi-VN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
}

// Lifecycle
onMounted(() => {
  fetchAddresses()
})
</script>

<style scoped>
/* Custom styles for Bootstrap components */
.table th {
  font-weight: 600;
  background-color: #f8f9fa;
  border-bottom: 2px solid #dee2e6;
}

.table td {
  vertical-align: middle;
}

.badge {
  font-size: 0.75rem;
}

.modal {
  backdrop-filter: blur(3px);
}

.btn-outline-primary:hover,
.btn-outline-danger:hover {
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.card {
  border: none;
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
}

.pagination .page-link {
  border-color: #dee2e6;
  color: #6c757d;
}

.pagination .page-item.active .page-link {
  background-color: #0d6efd;
  border-color: #0d6efd;
}

.form-control:focus {
  border-color: #86b7fe;
  box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

.text-truncate {
  max-width: 300px;
}

@media (max-width: 768px) {
  .text-truncate {
    max-width: 200px;
  }

  .table-responsive {
    font-size: 0.875rem;
  }
}
/* Custom styles for the modal */
.bg-gradient-primary {
  background: linear-gradient(135deg, #4e73df 0%, #224abe 100%) !important;
}

.modal-content {
  border: none;
  border-radius: 0.5rem;
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.modal-header {
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}

.card {
  border: none;
  border-radius: 0.5rem;
}

.card-header {
  border-bottom: 1px solid #e3e6f0;
  font-weight: 600;
}

.badge {
  font-size: 0.75em;
  padding: 0.5em 0.75em;
}

.bg-light {
  background-color: #f8f9fc !important;
}

.text-muted {
  color: #858796 !important;
}

.fw-semibold {
  font-weight: 600;
}

.btn {
  border-radius: 0.35rem;
  font-weight: 500;
}

/* Hover effects */
.card:hover {
  transform: translateY(-2px);
  transition: transform 0.2s ease-in-out;
}

.btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.1);
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .modal-dialog {
    margin: 0.5rem;
  }
  
  .card-body {
    padding: 1rem;
  }
}
</style>
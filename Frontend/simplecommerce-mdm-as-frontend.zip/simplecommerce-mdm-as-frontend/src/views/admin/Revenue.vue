<template>
  <AdminLayout>
    <!-- Quản lý lệnh rút tiền -->
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
          <h5 class="mb-0">
            <i class="bi bi-cash-coin me-2"></i>
            Quản lý lệnh rút tiền ({{ pendingWithdrawals.length }})
          </h5>
          <div class="d-flex gap-2">
            <select v-model="withdrawalFilter" class="form-select" style="width: auto;">
              <option value="all">Tất cả</option>
              <option value="pending">Chờ duyệt</option>
              <option value="approved">Đã duyệt</option>
              <option value="rejected">Đã từ chối</option>
            </select>
            <button class="btn btn-outline-primary" @click="loadWithdrawals">
              <i class="bi bi-arrow-clockwise"></i> Làm mới
            </button>
          </div>
        </div>
      </div>

      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-hover">
            <thead class="table-light">
            <tr>
              <th>ID</th>
              <th>Seller</th>
              <th>Số tiền</th>
              <th>Ngân hàng</th>
              <th>Ngày yêu cầu</th>
              <th>Trạng thái</th>
              <th>Thao tác</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="withdrawal in filteredWithdrawals" :key="withdrawal.id">
              <td><span class="badge bg-secondary">#{{ withdrawal.id }}</span></td>
              <td>
                <div class="d-flex align-items-center">
                  <img :src="withdrawal.seller.avatar" class="rounded-circle me-2" width="32" height="32">
                  <div>
                    <div class="fw-semibold">{{ withdrawal.seller.name }}</div>
                    <small class="text-muted">{{ withdrawal.seller.email }}</small>
                  </div>
                </div>
              </td>
              <td class="fw-bold text-success">{{ formatCurrency(withdrawal.amount) }}</td>
              <td>
                <div>{{ withdrawal.bankInfo.bankName }}</div>
                <small class="text-muted">{{ withdrawal.bankInfo.accountNumber }}</small>
              </td>
              <td>{{ formatDate(withdrawal.requestDate) }}</td>
              <td>
                  <span class="badge" :class="getStatusBadgeClass(withdrawal.status)">
                    {{ getStatusText(withdrawal.status) }}
                  </span>
              </td>
              <td>
                <div class="btn-group" role="group" v-if="withdrawal.status === 'pending'">
                  <button
                      class="btn btn-sm btn-success"
                      @click="approveWithdrawal(withdrawal)"
                      title="Duyệt"
                  >
                    <i class="bi bi-check-lg"></i>
                  </button>
                  <button
                      class="btn btn-sm btn-danger"
                      @click="rejectWithdrawal(withdrawal)"
                      title="Từ chối"
                  >
                    <i class="bi bi-x-lg"></i>
                  </button>
                  <button
                      class="btn btn-sm btn-info"
                      @click="viewWithdrawalDetails(withdrawal)"
                      title="Chi tiết"
                  >
                    <i class="bi bi-eye"></i>
                  </button>
                </div>
                <button
                    v-else
                    class="btn btn-sm btn-outline-info"
                    @click="viewWithdrawalDetails(withdrawal)"
                >
                  <i class="bi bi-eye"></i> Chi tiết
                </button>
              </td>
            </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <nav class="mt-4">
          <ul class="pagination justify-content-center">
            <li class="page-item"><a class="page-link" href="#">Trước</a></li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">Sau</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import AdminLayout from '../../components/AdminLayout.vue'
import Swal from 'sweetalert2'

// Reactive data
const currentPage = ref(1)
const itemsPerPage = 10
const withdrawalFilter = ref('all')

// Stats data
const revenueStats = ref({
  totalRevenue: 2450000000,
  totalCommission: 122500000,
  monthlyGrowth: 15.5,
  commissionRate: 5,
  activeSellers: 156,
  newSellers: 12
})

// Sample withdrawal data
const withdrawals = ref([
  {
    id: 'WD001',
    seller: {
      name: 'Shop Điện tử ABC',
      email: 'abc@email.com',
      avatar: 'https://via.placeholder.com/32'
    },
    amount: 15000000,
    bankInfo: {
      bankName: 'Vietcombank',
      accountNumber: '1234567890'
    },
    requestDate: '2024-06-01',
    status: 'pending'
  },
  {
    id: 'WD002',
    seller: {
      name: 'Fashion Store XYZ',
      email: 'xyz@email.com',
      avatar: 'https://via.placeholder.com/32'
    },
    amount: 8500000,
    bankInfo: {
      bankName: 'Techcombank',
      accountNumber: '0987654321'
    },
    requestDate: '2024-06-02',
    status: 'approved'
  },
  {
    id: 'WD003',
    seller: {
      name: 'Books & More',
      email: 'books@email.com',
      avatar: 'https://via.placeholder.com/32'
    },
    amount: 3200000,
    bankInfo: {
      bankName: 'BIDV',
      accountNumber: '5555666677'
    },
    requestDate: '2024-06-03',
    status: 'pending'
  },
  {
    id: 'WD004',
    seller: {
      name: 'Home & Garden',
      email: 'home@email.com',
      avatar: 'https://via.placeholder.com/32'
    },
    amount: 12000000,
    bankInfo: {
      bankName: 'VPBank',
      accountNumber: '9999888877'
    },
    requestDate: '2024-06-04',
    status: 'rejected'
  },
  {
    id: 'WD005',
    seller: {
      name: 'Sports Equipment',
      email: 'sports@email.com',
      avatar: 'https://via.placeholder.com/32'
    },
    amount: 6800000,
    bankInfo: {
      bankName: 'ACB',
      accountNumber: '1111222233'
    },
    requestDate: '2024-06-05',
    status: 'pending'
  }
])

// Computed properties
const pendingWithdrawals = computed(() =>
    withdrawals.value.filter(w => w.status === 'pending')
)

const pendingAmount = computed(() =>
    pendingWithdrawals.value.reduce((sum, w) => sum + w.amount, 0)
)

const filteredWithdrawals = computed(() => {
  let filtered = withdrawals.value
  if (withdrawalFilter.value !== 'all') {
    filtered = filtered.filter(w => w.status === withdrawalFilter.value)
  }

  const start = (currentPage.value - 1) * itemsPerPage
  const end = start + itemsPerPage
  return filtered.slice(start, end)
})

const totalPages = computed(() => {
  let filtered = withdrawals.value
  if (withdrawalFilter.value !== 'all') {
    filtered = filtered.filter(w => w.status === withdrawalFilter.value)
  }
  return Math.ceil(filtered.length / itemsPerPage)
})

const visiblePages = computed(() => {
  const pages = []
  const maxVisible = 5
  let start = Math.max(1, currentPage.value - Math.floor(maxVisible / 2))
  let end = Math.min(totalPages.value, start + maxVisible - 1)

  if (end - start < maxVisible - 1) {
    start = Math.max(1, end - maxVisible + 1)
  }

  for (let i = start; i <= end; i++) {
    pages.push(i)
  }
  return pages
})

// Methods
const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND'
  }).format(amount)
}

const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('vi-VN')
}

const getStatusBadgeClass = (status) => {
  const classes = {
    pending: 'bg-warning',
    approved: 'bg-success',
    rejected: 'bg-danger'
  }
  return classes[status] || 'bg-secondary'
}

const getStatusText = (status) => {
  const texts = {
    pending: 'Chờ duyệt',
    approved: 'Đã duyệt',
    rejected: 'Đã từ chối'
  }
  return texts[status] || status
}

const changePage = (page) => {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page
  }
}

const loadWithdrawals = () => {
  // Reload withdrawals from API
  Swal.fire({
    title: 'Đã làm mới!',
    text: 'Dữ liệu đã được cập nhật',
    icon: 'success',
    timer: 1500,
    showConfirmButton: false
  })
}

const approveWithdrawal = async (withdrawal) => {
  const result = await Swal.fire({
    title: 'Xác nhận duyệt rút tiền?',
    html: `
      <div class="text-start">
        <p><strong>Seller:</strong> ${withdrawal.seller.name}</p>
        <p><strong>Số tiền:</strong> ${formatCurrency(withdrawal.amount)}</p>
        <p><strong>Ngân hàng:</strong> ${withdrawal.bankInfo.bankName} - ${withdrawal.bankInfo.accountNumber}</p>
      </div>
    `,
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: '<i class="bi bi-check-lg"></i> Duyệt',
    cancelButtonText: '<i class="bi bi-x-lg"></i> Hủy',
    confirmButtonColor: '#28a745',
    cancelButtonColor: '#6c757d'
  })

  if (result.isConfirmed) {
    withdrawal.status = 'approved'
    withdrawal.approvedDate = new Date().toISOString().split('T')[0]

    Swal.fire({
      title: 'Đã duyệt!',
      text: 'Lệnh rút tiền đã được duyệt thành công',
      icon: 'success',
      confirmButtonText: 'OK'
    })
  }
}

const rejectWithdrawal = async (withdrawal) => {
  const { value: reason } = await Swal.fire({
    title: 'Lý do từ chối',
    input: 'textarea',
    inputPlaceholder: 'Nhập lý do từ chối lệnh rút tiền...',
    inputAttributes: {
      'aria-label': 'Lý do từ chối'
    },
    showCancelButton: true,
    confirmButtonText: '<i class="bi bi-x-lg"></i> Từ chối',
    cancelButtonText: '<i class="bi bi-arrow-left"></i> Hủy',
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    inputValidator: (value) => {
      if (!value) {
        return 'Vui lòng nhập lý do từ chối!'
      }
    }
  })

  if (reason) {
    withdrawal.status = 'rejected'
    withdrawal.rejectReason = reason
    withdrawal.rejectedDate = new Date().toISOString().split('T')[0]

    Swal.fire({
      title: 'Đã từ chối!',
      text: 'Lệnh rút tiền đã bị từ chối',
      icon: 'success',
      confirmButtonText: 'OK'
    })
  }
}

const viewWithdrawalDetails = (withdrawal) => {
  Swal.fire({
    title: 'Chi tiết lệnh rút tiền',
    html: `
      <div class="text-start">
        <div class="row mb-2">
          <div class="col-4"><strong>ID:</strong></div>
          <div class="col-8">${withdrawal.id}</div>
        </div>
        <div class="row mb-2">
          <div class="col-4"><strong>Seller:</strong></div>
          <div class="col-8">${withdrawal.seller.name}</div>
        </div>
        <div class="row mb-2">
          <div class="col-4"><strong>Email:</strong></div>
          <div class="col-8">${withdrawal.seller.email}</div>
        </div>
        <div class="row mb-2">
          <div class="col-4"><strong>Số tiền:</strong></div>
          <div class="col-8 text-success fw-bold">${formatCurrency(withdrawal.amount)}</div>
        </div>
        <div class="row mb-2">
          <div class="col-4"><strong>Ngân hàng:</strong></div>
          <div class="col-8">${withdrawal.bankInfo.bankName}</div>
        </div>
        <div class="row mb-2">
          <div class="col-4"><strong>Số tài khoản:</strong></div>
          <div class="col-8">${withdrawal.bankInfo.accountNumber}</div>
        </div>
        <div class="row mb-2">
          <div class="col-4"><strong>Ngày yêu cầu:</strong></div>
          <div class="col-8">${formatDate(withdrawal.requestDate)}</div>
        </div>
        <div class="row mb-2">
          <div class="col-4"><strong>Trạng thái:</strong></div>
          <div class="col-8">
            <span class="badge ${getStatusBadgeClass(withdrawal.status)}">${getStatusText(withdrawal.status)}</span>
          </div>
        </div>
        ${withdrawal.rejectReason ? `
          <div class="row mb-2">
            <div class="col-4"><strong>Lý do từ chối:</strong></div>
            <div class="col-8 text-danger">${withdrawal.rejectReason}</div>
          </div>
        ` : ''}
        ${withdrawal.approvedDate ? `
          <div class="row mb-2">
            <div class="col-4"><strong>Ngày duyệt:</strong></div>
            <div class="col-8">${formatDate(withdrawal.approvedDate)}</div>
          </div>
        ` : ''}
        ${withdrawal.rejectedDate ? `
          <div class="row mb-2">
            <div class="col-4"><strong>Ngày từ chối:</strong></div>
            <div class="col-8">${formatDate(withdrawal.rejectedDate)}</div>
          </div>
        ` : ''}
      </div>
    `,
    width: 600,
    confirmButtonText: '<i class="bi bi-x-lg"></i> Đóng',
    customClass: {
      htmlContainer: 'text-start'
    }
  })
}

onMounted(() => {
  // Load initial data
  console.log('Revenue management page loaded')
})
</script>

<style scoped>
.card {
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  border: 1px solid rgba(0, 0, 0, 0.125);
}

.table th {
  font-weight: 600;
  border-top: none;
}

.btn-group .btn {
  margin-right: 2px;
}

@media (max-width: 768px) {
  .d-flex.gap-2 {
    flex-direction: column;
    gap: 0.5rem !important;
  }

  .d-flex.gap-2 > * {
    width: 100% !important;
  }

  .btn-group {
    flex-direction: column;
  }

  .btn-group .btn {
    margin-bottom: 2px;
    margin-right: 0;
  }
}

.table-responsive {
  min-height: 400px;
}

.pagination .page-link {
  color: #495057;
}

.pagination .page-item.active .page-link {
  background-color: #007bff;
  border-color: #007bff;
}
</style>
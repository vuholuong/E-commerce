<template>
  <AdminLayout>
    <!-- Order Stats -->
    <div class="row mb-4" v-if="orderStats && orderStats.total !== undefined">
      <div class="col-md-2">
        <div class="card bg-primary text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.total || 0 }}</h3>
            <small>Tổng đơn hàng</small>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card bg-info text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.awaitingConfirmation || 0 }}</h3>
            <small>Chờ xác nhận</small>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card bg-warning text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.processing || 0 }}</h3>
            <small>Đang xử lý</small>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card bg-secondary text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.shipping || 0 }}</h3>
            <small>Đang giao</small>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card bg-success text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.completed || 0 }}</h3>
            <small>Hoàn thành</small>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card bg-danger text-white">
          <div class="card-body text-center">
            <h3>{{ orderStats.cancelled || 0 }}</h3>
            <small>Đã hủy</small>
          </div>
        </div>
      </div>
    </div>

    <!-- Orders Table -->
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
          <h5>Danh sách đơn hàng</h5>
          <div class="d-flex gap-2">
            <input type="text" class="form-control" placeholder="Tìm kiếm..." style="width: 250px;"
              v-model="searchKeyword" @keyup.enter="searchOrders">
            <button class="btn btn-primary" @click="searchOrders" :disabled="isLoading">
              <i class="bi bi-search"></i>
            </button>
          </div>
        </div>
      </div>
      <div class="card-body">
        <!-- Loading state -->
        <div v-if="isLoading" class="text-center py-4">
          <div class="spinner-border" role="status">
            <span class="visually-hidden">Đang tải...</span>
          </div>
        </div>

        <!-- Orders table -->
        <div class="table-responsive" v-else>
          <table class="table">
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Khách hàng</th>
                <th>Shop</th>
                <th>Sản phẩm</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Ngày đặt</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="orders.length === 0">
                <td colspan="8" class="text-center py-4">
                  {{ isSearching ? 'Không tìm thấy đơn hàng nào' : 'Không có đơn hàng nào' }}
                </td>
              </tr>
              <tr v-for="order in orders" :key="order.id">
                <td>
                  <strong>#{{ order.id }}</strong>
                  <!-- <strong class="text-muted">{{ order.orderGroupNumber }}</strong> -->
                </td>
                <td>
                  <div>
                    <strong>{{ order.customerEmail }}</strong>
                    <!-- thêm địa chỉ kh --> <br>
                  Địa chỉ: <small class="text-dark">{{ order.customerAddress }}</small>
                  </div>
                </td>
                <td>{{ order.sellerName }}</td>
                <td>
                  <div>
                    {{ order.productCount }} sản phẩm<br>
                    <small class="text-muted">SL: {{ order.quantity }}</small>
                  </div>
                </td>
                <td>
                  <div>
                    <strong>{{ formatCurrency(order.total) }}</strong>
                    <br>
                    <small class="text-muted">
                      SP: {{ formatCurrency(order.subtotal) }}<br>
                      Ship: {{ formatCurrency(order.shippingFee) }}
                    </small>
                  </div>
                </td>
                <td>
                  <span :class="`badge bg-${order.statusColor}`">{{ order.status }}</span>
                </td>
                <td>{{ order.createdAt }}</td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary" @click="viewOrderDetail(order)">
                      <i class="bi bi-eye"></i> Chi tiết
                    </button>
                    <button class="btn btn-outline-warning" v-if="canUpdateStatus(order.rawStatus)"
                      @click="showUpdateStatusModal(order)">
                      <i class="bi bi-pencil"></i> Cập nhật
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <nav class="mt-4" v-if="pagination && pagination.totalPages > 1">
          <ul class="pagination justify-content-center">
            <li class="page-item" :class="{ disabled: pagination.first }">
              <a class="page-link" href="#" @click.prevent="goToPage(pagination.number - 1)">Trước</a>
            </li>

            <li v-for="page in getVisiblePages()" :key="page" class="page-item"
              :class="{ active: page === pagination.number }">
              <a class="page-link" href="#" @click.prevent="goToPage(page)">{{ page + 1 }}</a>
            </li>

            <li class="page-item" :class="{ disabled: pagination.last }">
              <a class="page-link" href="#" @click.prevent="goToPage(pagination.number + 1)">Sau</a>
            </li>
          </ul>

          <div class="text-center mt-2">
            <small class="text-muted">
              Hiển thị {{ pagination.numberOfElements }} / {{ pagination.totalElements }} đơn hàng
              (Trang {{ pagination.number + 1 }} / {{ pagination.totalPages }})
            </small>
          </div>
        </nav>
      </div>
    </div>

    <!-- Order Detail Modal -->
    <transition name="modal-fade">
      <div v-if="showDetailModal" class="modal fade show d-block" tabindex="-1" role="dialog"
        style="background-color: rgba(0,0,0,0.5);">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content" v-if="selectedOrderDetail">
            <div class="modal-header">
              <h5 class="modal-title">Chi tiết đơn hàng #{{ selectedOrderDetail.id }}</h5>
              <button type="button" class="btn-close" @click="showDetailModal = false"></button>
            </div>
            <div class="modal-body">
              <div class="row mb-4">
                <div class="col-md-6">
                  <div class="card">
                    <div class="card-header">
                      <h6>Thông tin đơn hàng</h6>
                    </div>
                    <div class="card-body">
                      <table class="table table-sm">
                        <tbody>
                          <tr>
                            <th>Mã đơn hàng:</th>
                            <td>#{{ selectedOrderDetail.id }}</td>
                          </tr>
                          <!-- <tr>
                            <th>Master Order ID:</th>
                            <td>{{ selectedOrderDetail.masterOrderId }}</td>
                          </tr>
                          <tr>
                            <th>Nhóm đơn hàng:</th>
                            <td>{{ selectedOrderDetail.orderGroupNumber }}</td>
                          </tr> -->
                          <tr>
                            <th>Shop:</th>
                            <td>{{ selectedOrderDetail.shopName }}</td>
                          </tr>
                          <tr>
                            <th>Trạng thái:</th>
                            <td>
                              <span
                                :class="`badge bg-${orderService.getStatusBadgeColor(selectedOrderDetail.orderStatus)}`">
                                {{ orderService.formatStatusText(selectedOrderDetail.orderStatus) }}
                              </span>
                            </td>
                          </tr>
                          <tr>
                            <th>Ngày đặt:</th>
                            <td>{{ formatDateTime(selectedOrderDetail.orderedAt) }}</td>
                          </tr>
                          <tr>
                            <th>Ghi chú cho người bán:</th>
                            <td>{{ selectedOrderDetail.notesToSeller || 'Không có' }}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="card">
                    <div class="card-header">
                      <h6>Thông tin thanh toán</h6>
                    </div>
                    <div class="card-body">
                      <table class="table table-sm">
                        <tbody>
                          <tr>
                            <th>Tổng tiền hàng:</th>
                            <td class="text-end">{{ formatCurrency(selectedOrderDetail.subtotalAmount) }}</td>
                          </tr>
                          <tr>
                            <th>Địa chỉ giao hàng:</th>
                            <td class="text-end">{{ (selectedOrderDetail.shippingAddress) }}</td>
                          </tr>
                          <tr>
                            <th>Địa chỉ thanh toán:</th>
                            <td class="text-end">{{ selectedOrderDetail.billingAddress }}</td>
                          </tr>
                          <tr>
                            <th>Phí vận chuyển:</th>
                            <td class="text-end">{{ formatCurrency(selectedOrderDetail.shippingFee) }}</td>
                          </tr>
                          <tr>
                            <th>Giảm giá vận chuyển:</th>
                            <td class="text-end text-danger">-{{
                              formatCurrency(selectedOrderDetail.shippingDiscountAmount) }}</td>
                          </tr>
                          <!-- <tr>
                            <th>Thuế:</th>
                            <td class="text-end">{{ formatCurrency(selectedOrderDetail.taxAmount) }}</td>
                          </tr> -->
                          <tr class="table-primary">
                            <th><strong>Tổng cộng:</strong></th>
                            <th class="text-end">{{ formatCurrency(selectedOrderDetail.totalAmount) }}</th>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Order Items -->
              <div class="card">
                <div class="card-header">
                  <h6>Chi tiết sản phẩm</h6>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Hình ảnh</th>
                          <th>Sản phẩm</th>
                          <th>SKU</th>
                          <th>Tùy chọn</th>
                          <th>Số lượng</th>
                          <th>Đơn giá</th>
                          <th>Thành tiền</th>
                          <!-- <th>Trạng thái</th> -->
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="item in selectedOrderDetail.orderItems" :key="item.id">
                          <td>
                            <img v-if="item.variantImageUrl" :src="item.variantImageUrl" class="img-thumbnail"
                              style="width: 50px; height: 50px; object-fit: cover;">
                            <div v-else class="bg-light d-flex align-items-center justify-content-center"
                              style="width: 50px; height: 50px;">
                              <i class="bi bi-image text-muted"></i>
                            </div>
                          </td>
                          <td>{{ item.productNameSnapshot }}</td>
                          <td><code>{{ item.variantSkuSnapshot }}</code></td>
                          <td>{{ formatVariantOptions(item.variantOptionsSnapshot) }}</td>
                          <td>{{ item.quantity }}</td>
                          <td>{{ formatCurrency(item.unitPrice) }}</td>
                          <td>{{ formatCurrency(item.subtotal) }}</td>
                          <!-- <td>
                            <span :class="`badge bg-${getItemStatusColor(item.status)}`">
                              {{ formatItemStatus(item.status) }}
                            </span>
                          </td> -->
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" @click="showDetailModal = false">Đóng</button>
              <button type="button" class="btn btn-warning" v-if="canUpdateStatus(selectedOrderDetail.orderStatus)"
                @click="showUpdateStatusModalFromDetail(selectedOrderDetail)">
                Cập nhật trạng thái
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>

    <!-- Update Status Modal -->
    <transition name="modal-fade">
      <div v-if="showStatusModal" class="modal fade show d-block" tabindex="-1" role="dialog"
        style="background-color: rgba(0,0,0,0.5);">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Cập nhật trạng thái đơn hàng</h5>
              <button type="button" class="btn-close" @click="showStatusModal = false"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label">Đơn hàng:</label>
                <p><strong>#{{ orderToUpdate?.id }}</strong></p>
              </div>
              <div class="mb-3">
                <label class="form-label">Trạng thái hiện tại:</label>
                <p><span :class="`badge bg-${orderToUpdate?.statusColor}`">{{ orderToUpdate?.status }}</span></p>
              </div>
              <div class="mb-3">
                <label for="newStatus" class="form-label">Trạng thái mới:</label>
                <select id="newStatus" class="form-select" v-model="newStatus">
                  <option value="">Chọn trạng thái...</option>
                  <option v-for="option in getAvailableStatuses(orderToUpdate?.rawStatus)" :key="option.value"
                    :value="option.value">
                    {{ option.label }}
                  </option>
                </select>
              </div>
              <div class="mb-3">
                <label for="statusNote" class="form-label">Ghi chú (tùy chọn):</label>
                <textarea id="statusNote" class="form-control" rows="3" v-model="statusNote"
                  placeholder="Nhập ghi chú về việc thay đổi trạng thái..."></textarea>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" @click="showStatusModal = false">Hủy</button>
              <button type="button" class="btn btn-primary" @click="updateStatus"
                :disabled="!newStatus || isUpdatingStatus">
                {{ isUpdatingStatus ? 'Đang cập nhật...' : 'Cập nhật' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>

    <!-- Modal Backdrop -->
    <transition name="backdrop-fade">
      <div v-if="showDetailModal || showStatusModal" class="modal-backdrop fade show"></div>
    </transition>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import AdminLayout from '../../components/AdminLayout.vue'
import orderService from '@/services/admin/order'
import Swal from 'sweetalert2'

// Reactive data
const showDetailModal = ref(false)
const showStatusModal = ref(false)
const selectedOrder = ref(null)
const selectedOrderDetail = ref(null)
const orderToUpdate = ref(null)
const newStatus = ref('')
const statusNote = ref('')

const orderStats = ref(null)
const orders = ref([])
const pagination = ref(null)
const isLoading = ref(false)
const isExporting = ref(false)
const isUpdatingStatus = ref(false)
const isLoadingDetail = ref(false)

// Search & filter
const searchKeyword = ref('')
const selectedStatus = ref('')
const isSearching = ref(false)

// Pagination
const currentPage = ref(0)
const pageSize = ref(10)

// Status options
const statusOptions = computed(() => orderService.getOrderStatusOptions())

// Methods
const loadOrders = async (page = 0) => {
  isLoading.value = true
  currentPage.value = page

  try {
    let result
    if (searchKeyword.value.trim()) {
      result = await orderService.searchOrders(searchKeyword.value.trim(), page, pageSize.value)
    } else {
      result = await orderService.getAllOrders(page, pageSize.value)
    }

    if (result.success) {
      // Filter by status locally if needed since API doesn't support status filter
      let ordersData = result.data.content.map(order => orderService.formatOrderForDisplay(order))

      if (selectedStatus.value) {
        ordersData = ordersData.filter(order => order.rawStatus === selectedStatus.value)
      }

      orders.value = ordersData
      pagination.value = {
        totalPages: result.data.totalPages,
        totalElements: result.data.totalElements,
        number: result.data.number,
        size: result.data.size,
        numberOfElements: result.data.numberOfElements,
        first: result.data.first,
        last: result.data.last,
        empty: result.data.empty
      }
    } else {
      showError(result.message)
      orders.value = []
      pagination.value = null
    }
  } catch (error) {
    showError('Có lỗi xảy ra khi tải danh sách đơn hàng')
    orders.value = []
    pagination.value = null
  } finally {
    isLoading.value = false
  }
}

// Trong method viewOrderDetail, thêm fallback để test
const viewOrderDetail = async (order) => {
  console.log('Viewing order detail for order:', order)
  selectedOrder.value = order
  isLoadingDetail.value = true
  
  try {
    // Thử cả id và orderNumber vì có thể API dùng orderNumber
    let orderIdentifier = order.id
    console.log('Trying with order ID:', orderIdentifier)
    
    let result = await orderService.getOrderDetail(orderIdentifier)
    console.log('API response with ID:', result)
    
    // Nếu không thành công, thử với orderNumber
    if (!result.success || !result.data) {
      console.log('Trying with order number:', order.orderNumber)
      orderIdentifier = order.orderNumber
      result = await orderService.getOrderDetail(orderIdentifier)
      console.log('API response with order number:', result)
    }
    
    if (result.success && result.data) {
      selectedOrderDetail.value = result.data
      showDetailModal.value = true
      console.log('Order detail loaded successfully:', result.data)
    } else {
      console.error('Failed to load order detail after all attempts:', result.message)
      
      // Hiển thị thông báo chi tiết hơn
      showError(`Không tìm thấy đơn hàng: ${result.message || 'Vui lòng kiểm tra lại mã đơn hàng'}`)
    }
  } catch (error) {
    console.error('Error loading order detail:', error)
    showError('Có lỗi xảy ra khi tải chi tiết đơn hàng: ' + error.message)
  } finally {
    isLoadingDetail.value = false
  }
}
// Tìm kiếm đơn hàng theo từ khóa (mã đơn, email khách hàng)
const searchOrders = async () => {
  isSearching.value = !!searchKeyword.value.trim()
  await loadOrders(0)
}

const loadStatistics = async () => {
  try {
    const result = await orderService.getOrderStatistics()

    if (result.success) {
      orderStats.value = result.data
    }
  } catch (error) {
    console.error('Failed to load order statistics:', error)
    orderStats.value = {
      total: 0,
      pending: 0,
      shipping: 0,
      completed: 0,
      awaitingConfirmation: 0,
      processing: 0,
      delivered: 0,
      cancelled: 0
    }
  }
}

const goToPage = (page) => {
  if (page >= 0 && page < pagination.value.totalPages) {
    loadOrders(page)
  }
}

const getVisiblePages = () => {
  if (!pagination.value) return []

  const current = pagination.value.number
  const total = pagination.value.totalPages
  const delta = 2
  const pages = []

  const start = Math.max(0, current - delta)
  const end = Math.min(total - 1, current + delta)

  for (let i = start; i <= end; i++) {
    pages.push(i)
  }

  return pages
}

const showUpdateStatusModal = (order) => {
  orderToUpdate.value = order
  newStatus.value = ''
  statusNote.value = ''
  showDetailModal.value = false
  showStatusModal.value = true
}

const showUpdateStatusModalFromDetail = (orderDetail) => {
  orderToUpdate.value = orderService.formatOrderForDisplay(orderDetail)
  newStatus.value = ''
  statusNote.value = ''
  showDetailModal.value = false
  showStatusModal.value = true
}

const canUpdateStatus = (status) => {
  const nonUpdatableStatuses = ['COMPLETED', 'CANCELLED_BY_USER', 'CANCELLED_BY_SELLER', 'CANCELLED_BY_ADMIN', 'RETURNED', 'FAILED']
  return !nonUpdatableStatuses.includes(status)
}

const getAvailableStatuses = (currentStatus) => {
  const allStatuses = statusOptions.value.filter(option => option.value !== '')

  const statusFlow = {
    'PENDING_PAYMENT': ['AWAITING_CONFIRMATION', 'CANCELLED_BY_ADMIN'],
    'AWAITING_CONFIRMATION': ['PROCESSING', 'CANCELLED_BY_USER', 'CANCELLED_BY_SELLER', 'CANCELLED_BY_ADMIN'],
    'PROCESSING': ['SHIPPED', 'CANCELLED_BY_USER', 'CANCELLED_BY_SELLER', 'CANCELLED_BY_ADMIN'],
    'SHIPPED': ['DELIVERED', 'RETURN_REQUESTED'],
    'DELIVERED': ['COMPLETED', 'RETURN_REQUESTED'],
    'RETURN_REQUESTED': ['RETURN_APPROVED', 'CANCELLED_BY_ADMIN'],
    'RETURN_APPROVED': ['RETURNED']
  }

  const availableStatuses = statusFlow[currentStatus] || []
  return allStatuses.filter(status => availableStatuses.includes(status.value))
}

const updateStatus = async () => {
  if (!newStatus.value || !orderToUpdate.value) return

  isUpdatingStatus.value = true

  try {
    const orderId = orderToUpdate.value.id
    console.log('Updating order:', orderId, 'to status:', newStatus.value)

    const result = await orderService.updateOrderStatus(
      orderId,
      newStatus.value,
      statusNote.value
    )

    if (result.success) {
      showSuccess('Cập nhật trạng thái thành công')
      showStatusModal.value = false

      const orderIndex = orders.value.findIndex(o => o.id === orderToUpdate.value.id)
      if (orderIndex >= 0) {
        orders.value[orderIndex] = {
          ...orders.value[orderIndex],
          status: orderService.formatStatusText(newStatus.value),
          statusColor: orderService.getStatusBadgeColor(newStatus.value),
          rawStatus: newStatus.value
        }
      }

      await loadStatistics()
      await loadOrders(currentPage.value)
    } else {
      showError(result.message || 'Cập nhật trạng thái thất bại')
    }
  } catch (error) {
    console.error('Update status error:', error)
    showError('Có lỗi xảy ra khi cập nhật trạng thái: ' + (error.response?.data?.message || error.message))
  } finally {
    isUpdatingStatus.value = false
  }
}

const formatCurrency = (amount) => {
  return orderService.formatCurrency(amount)
}

const formatDateTime = (dateString) => {
  if (!dateString) return ''
  const date = new Date(dateString)
  return date.toLocaleString('vi-VN')
}

const formatVariantOptions = (options) => {
  try {
    if (!options || options === '{}') return 'Không có'
    const parsed = JSON.parse(options)
    return Object.values(parsed).join(', ') || 'Không có'
  } catch {
    return options || 'Không có'
  }
}

const formatItemStatus = (status) => {
  const statusMap = {
    'PENDING': 'Chờ xử lý',
    'PROCESSING': 'Đang xử lý',
    'SHIPPED': 'Đã gửi',
    'DELIVERED': 'Đã giao',
    'COMPLETED': 'Hoàn thành',
    'CANCELLED': 'Đã hủy'
  }
  return statusMap[status] || status
}

const getItemStatusColor = (status) => {
  const colorMap = {
    'PENDING': 'warning',
    'PROCESSING': 'info',
    'SHIPPED': 'primary',
    'DELIVERED': 'success',
    'COMPLETED': 'success',
    'CANCELLED': 'danger'
  }
  return colorMap[status] || 'secondary'
}

const showSuccess = (message) => {
  Swal.fire({
    title: 'Thành công!',
    text: message,
    icon: 'success',
    timer: 2000,
    showConfirmButton: false
  })
}

const showError = (message) => {
  Swal.fire({
    title: 'Lỗi!',
    text: message,
    icon: 'error'
  })
}

// Lifecycle hooks
onMounted(async () => {
  await Promise.all([
    loadOrders(),
    loadStatistics()
  ])
})
</script>

<style scoped>
.table th {
  background-color: #f8f9fa;
  font-weight: 600;
  border-bottom: 2px solid #dee2e6;
}

.table td {
  vertical-align: middle;
}

.badge {
  font-size: 0.75em;
}

.btn-group-sm>.btn {
  padding: 0.25rem 0.5rem;
  font-size: 0.75rem;
}

.pagination .page-link {
  color: #6c757d;
}

.pagination .page-item.active .page-link {
  background-color: #0d6efd;
  border-color: #0d6efd;
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
}

.modal-backdrop {
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 1040;
}

.spinner-border {
  color: #0d6efd;
}

.img-thumbnail {
  padding: 0.25rem;
  background-color: #fff;
  border: 1px solid #dee2e6;
  border-radius: 0.375rem;
  max-width: 100%;
  height: auto;
}

/* Modal transitions */
.modal-fade-enter-active,
.modal-fade-leave-active {
  transition: opacity 0.3s ease;
}

.modal-fade-enter-from,
.modal-fade-leave-to {
  opacity: 0;
}

.backdrop-fade-enter-active,
.backdrop-fade-leave-active {
  transition: opacity 0.3s ease;
}

.backdrop-fade-enter-from,
.backdrop-fade-leave-to {
  opacity: 0;
}

/* Ensure modal displays correctly */
.modal {
  z-index: 1050;
}

.modal-dialog {
  z-index: 1055;
}

.modal-content {
  z-index: 1060;
}
</style>
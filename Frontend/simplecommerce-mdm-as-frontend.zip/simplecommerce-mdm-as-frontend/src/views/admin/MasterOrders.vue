<template>
  <AdminLayout>
    <div class="container-fluid">
      <!-- Page Header -->
      
      <!-- Filters -->
      <!-- <div class="row mb-4">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="card-title mb-0">Bộ lọc</h5>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-3">
                  <label class="form-label">Trạng thái</label>
                  <select v-model="filters.status" class="form-select" @change="applyFilters">
                    <option value="">Tất cả trạng thái</option>
                    <option value="PENDING">Chờ xử lý</option>
                    <option value="PROCESSING">Đang xử lý</option>
                    <option value="SHIPPED">Đã gửi hàng</option>
                    <option value="DELIVERED">Đã giao hàng</option>
                    <option value="COMPLETED">Hoàn thành</option>
                    <option value="CANCELLED">Đã hủy</option>
                  </select>
                </div>
                <div class="col-md-3">
                  <label class="form-label">Email khách hàng</label>
                  <input 
                    v-model="filters.customerEmail" 
                    type="email" 
                    class="form-control" 
                    placeholder="Nhập email khách hàng"
                    @input="debounceSearch"
                  >
                </div>
                <div class="col-md-3">
                  <label class="form-label">Số điện thoại</label>
                  <input 
                    v-model="filters.customerPhone" 
                    type="text" 
                    class="form-control" 
                    placeholder="Nhập số điện thoại"
                    @input="debounceSearch"
                  >
                </div>
                <div class="col-md-3">
                  <label class="form-label">Từ ngày</label>
                  <input 
                    v-model="filters.fromDate" 
                    type="date" 
                    class="form-control"
                    @change="applyFilters"
                  >
                </div>
              </div>
              <div class="row mt-3">
                <div class="col-md-3">
                  <label class="form-label">Đến ngày</label>
                  <input 
                    v-model="filters.toDate" 
                    type="date" 
                    class="form-control"
                    @change="applyFilters"
                  >
                </div>
                <div class="col-md-3">
                  <label class="form-label">Số lượng hiển thị</label>
                  <select v-model="pagination.size" class="form-select" @change="applyFilters">
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                  </select>
                </div>
                <div class="col-md-6 d-flex align-items-end">
                  <button class="btn btn-outline-secondary me-2" @click="resetFilters">
                    <i class="fas fa-undo"></i> Đặt lại
                  </button>
                  <button class="btn btn-primary" @click="exportOrders" :disabled="loading">
                    <i class="fas fa-download"></i> Xuất Excel
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> -->

      <!-- Statistics Cards -->
      <!-- <div class="row mb-4">
        <div class="col-md-3">
          <div class="card bg-primary text-white">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5 class="card-title">Tổng đơn hàng</h5>
                  <h3 class="mb-0">{{ statistics.totalOrders }}</h3>
                </div>
                <div class="align-self-center">
                  <i class="fas fa-shopping-cart fa-2x"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card bg-success text-white">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5 class="card-title">Hoàn thành</h5>
                  <h3 class="mb-0">{{ statistics.completedOrders }}</h3>
                </div>
                <div class="align-self-center">
                  <i class="fas fa-check-circle fa-2x"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card bg-warning text-white">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5 class="card-title">Chờ xử lý</h5>
                  <h3 class="mb-0">{{ statistics.pendingOrders }}</h3>
                </div>
                <div class="align-self-center">
                  <i class="fas fa-clock fa-2x"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card bg-info text-white">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h5 class="card-title">Doanh thu</h5>
                  <h3 class="mb-0">{{ masterOrderService.formatCurrency(statistics.totalRevenue) }}</h3>
                </div>
                <div class="align-self-center">
                  <i class="fas fa-dollar-sign fa-2x"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> -->

      <!-- Orders Table -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
              <h5 class="card-title mb-0">Danh sách đơn hàng chính</h5>
              <button class="btn btn-outline-primary" @click="refreshData" :disabled="loading">
                <i class="fas fa-sync-alt" :class="{'fa-spin': loading}"></i> Làm mới
              </button>
            </div>
            <div class="card-body">
              <div v-if="loading" class="text-center py-4">
                <div class="spinner-border" role="status">
                  <span class="visually-hidden">Đang tải...</span>
                </div>
              </div>
              
              <div v-else-if="masterOrders.length === 0" class="text-center py-4">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <p class="text-muted">Không có đơn hàng nào</p>
              </div>

              <div v-else class="table-responsive">
                <table class="table table-hover">
                  <thead class="table-light">
                    <tr>
                      <th>Mã đơn hàng</th>
                      <th>Khách hàng</th>
                      <th>Địa chỉ giao hàng</th>
                      <th>Trạng thái</th>
                      <!-- <th>Tổng thanh toán</th> -->
                      <th>Số đơn con</th>
                      <th>Số sản phẩm</th>
                      <th>Ngày tạo</th>
                      <th>Thao tác</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="order in masterOrders" :key="order.id">
                      <td>
                        <strong class="text-primary">#{{ order.orderGroupNumber }}</strong>
                      </td>
                      <td>
                        <div>
                          <div class="fw-bold">{{ order.customerEmail }}</div>
                          <small class="text-muted">{{ order.customerPhone }}</small>
                        </div>
                      </td>
                      <td>
                        <span class="text-truncate" style="max-width: 200px; display: inline-block;" 
                              :title="order.shippingAddressSnapshot">
                          {{ order.shippingAddressSnapshot }}
                        </span>
                      </td>
                      <td>
                        <span class="badge" :class="masterOrderService.getStatusBadgeClass(order.overallStatus)">
                          {{ getStatusText(order.overallStatus) }}
                        </span>
                      </td>
                      <!-- <td>
                        <div class="fw-bold text-success">
                          {{ masterOrderService.formatCurrency(order.totalAmountPaid) }}
                        </div>
                        <small class="text-muted" v-if="order.totalDiscountAmount > 0">
                          Giảm: {{ masterOrderService.formatCurrency(order.totalDiscountAmount) }}
                        </small>
                      </td> -->
                      <td>
                        <span class="badge bg-secondary">{{ order.totalOrders }}</span>
                      </td>
                      <td>
                        <span class="badge bg-info">{{ order.totalQuantity }}</span>
                      </td>
                      <td>
                        {{ masterOrderService.formatDate(order.createdAt) }}
                      </td>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <button class="btn btn-outline-primary" @click="viewOrderDetails(order.id)"title="Xem chi tiết">
                            <i class="bi bi-eye"></i>
                            Xem
                          </button>
                          <!-- <button class="btn btn-outline-secondary" @click="printOrder(order.id)" title="In đơn hàng">
                            
                            <i class="fas fa-print"></i>
                            In
                          </button> -->
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <!-- Pagination -->
              <nav v-if="pagination.totalPages > 1" class="mt-4">
                <ul class="pagination justify-content-center">
                  <li class="page-item" :class="{ disabled: pagination.currentPage === 0 }">
                    <button class="page-link" @click="changePage(0)" :disabled="pagination.currentPage === 0">
                      <i class="fas fa-angle-double-left"></i>
                    </button>
                  </li>
                  <li class="page-item" :class="{ disabled: pagination.currentPage === 0 }">
                    <button class="page-link" @click="changePage(pagination.currentPage - 1)" :disabled="pagination.currentPage === 0">
                      <i class="fas fa-angle-left"></i>
                    </button>
                  </li>
                  
                  <li 
                    v-for="page in visiblePages" 
                    :key="page" 
                    class="page-item" 
                    :class="{ active: page === pagination.currentPage }"
                  >
                    <button class="page-link" @click="changePage(page)">{{ page + 1 }}</button>
                  </li>
                  
                  <li class="page-item" :class="{ disabled: pagination.currentPage >= pagination.totalPages - 1 }">
                    <button class="page-link" @click="changePage(pagination.currentPage + 1)" :disabled="pagination.currentPage >= pagination.totalPages - 1">
                      <i class="fas fa-angle-right"></i>
                    </button>
                  </li>
                  <li class="page-item" :class="{ disabled: pagination.currentPage >= pagination.totalPages - 1 }">
                    <button class="page-link" @click="changePage(pagination.totalPages - 1)" :disabled="pagination.currentPage >= pagination.totalPages - 1">
                      <i class="fas fa-angle-double-right"></i>
                    </button>
                  </li>
                </ul>
              </nav>

              <!-- Pagination Info -->
              <div class="d-flex justify-content-between align-items-center mt-3">
                <div class="text-muted">
                  Hiển thị {{ pagination.currentPage * pagination.size + 1 }} - 
                  {{ Math.min((pagination.currentPage + 1) * pagination.size, pagination.totalElements) }} 
                  trong tổng số {{ pagination.totalElements }} đơn hàng
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Order Detail Modal -->
      <div v-if="showDetailModal" class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5)">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Chi tiết đơn hàng #{{ selectedOrder?.orderGroupNumber }}</h5>
              <button type="button" class="btn-close" @click="closeDetailModal" aria-label="Close"></button>
            </div>
            <div class="modal-body" v-if="selectedOrder">
              <!-- Customer Information -->
              <div class="row mb-4">
                <div class="col-md-6">
                  <div class="card">
                    <div class="card-header">
                      <h6 class="mb-0">Thông tin khách hàng</h6>
                    </div>
                    <div class="card-body">
                      <p><strong>Email:</strong> {{ selectedOrder.customerEmail }}</p>
                      <p><strong>Số điện thoại:</strong> {{ selectedOrder.customerPhone }}</p>
                      <p><strong>Địa chỉ giao hàng:</strong> {{ selectedOrder.shippingAddressSnapshot }}</p>
                      <p><strong>Địa chỉ thanh toán:</strong> {{ selectedOrder.billingAddressSnapshot }}</p>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="card">
                    <div class="card-header">
                      <h6 class="mb-0">Thông tin đơn hàng</h6>
                    </div>
                    <div class="card-body">
                      <p><strong>Trạng thái:</strong> 
                        <span class="badge" :class="masterOrderService.getStatusBadgeClass(selectedOrder.overallStatus)">
                          {{ getStatusText(selectedOrder.overallStatus) }}
                        </span>
                      </p>
                      <!-- <p><strong>Tổng tiền đã thanh toán:</strong> 
                        <span class="text-success fw-bold">{{ masterOrderService.formatCurrency(selectedOrder.totalAmountPaid) }}</span>
                      </p> -->
                      <p><strong>Tổng giảm giá:</strong> {{ masterOrderService.formatCurrency(selectedOrder.totalDiscountAmount) }}</p>
                      <p><strong>Ngày tạo:</strong> {{ masterOrderService.formatDate(selectedOrder.createdAt) }}</p>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Sub Orders -->
              <div class="card">
                <div class="card-header">
                  <h6 class="mb-0">Đơn hàng con ({{ selectedOrder.orders?.length }})</h6>
                </div>
                <div class="card-body">
                  <div v-for="subOrder in selectedOrder.orders" :key="subOrder.id" class="border rounded p-3 mb-3">
                    <div class="row">
                      <div class="col-md-6">
                        <h6 class="text-primary">Đơn hàng #{{ subOrder.orderNumber }}</h6>
                        <p><strong>Cửa hàng:</strong> {{ subOrder.shopName }}</p>
                        <p><strong>Trạng thái:</strong> 
                          <span class="badge" :class="masterOrderService.getStatusBadgeClass(subOrder.orderStatus)">
                            {{ getStatusText(subOrder.orderStatus) }}
                          </span>
                        </p>
                        <p><strong>Phương thức vận chuyển:</strong> {{ subOrder.shippingMethodNameSnapshot }}</p>
                      </div>
                      <div class="col-md-6">
                        <p><strong>Tổng phụ:</strong> {{ masterOrderService.formatCurrency(subOrder.subtotalAmount) }}</p>
                        <p><strong>Phí vận chuyển:</strong> {{ masterOrderService.formatCurrency(subOrder.shippingFee) }}</p>
                        <!-- <p><strong>Giảm giá sản phẩm:</strong> {{ masterOrderService.formatCurrency(subOrder.itemDiscountAmount) }}</p> -->
                        <p><strong>Tổng cộng:</strong> 
                          <span class="text-success fw-bold">{{ masterOrderService.formatCurrency(subOrder.totalAmount) }}</span>
                        </p>
                      </div>
                    </div>

                    <!-- Order Items -->
                    <div class="mt-3">
                      <h6>Sản phẩm ({{ subOrder.orderItems?.length }})</h6>
                      <div class="table-responsive">
                        <table class="table table-sm">
                          <thead>
                            <tr>
                              <th>Hình ảnh</th>
                              <th>Sản phẩm</th>
                              <th>SKU</th>
                              <th>Tùy chọn</th>
                              <th>Số lượng</th>
                              <th>Đơn giá</th>
                              <th>Tổng</th>
                              <!-- <th>Trạng thái</th> -->
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="item in subOrder.orderItems" :key="item.id">
                              <td>
                                <img 
                                  :src="item.variantImageUrl" 
                                  :alt="item.productNameSnapshot" 
                                  class="img-thumbnail" 
                                  style="width: 50px; height: 50px; object-fit: cover;"
                                  @error="$event.target.src = '/placeholder-image.png'"
                                >
                              </td>
                              <td>{{ item.productNameSnapshot }}</td>
                              <td><code>{{ item.variantSkuSnapshot }}</code></td>
                              <td>{{ item.variantOptionsSnapshot }}</td>
                              <td>{{ item.quantity }}</td>
                              <td>{{ masterOrderService.formatCurrency(item.unitPrice) }}</td>
                              <td>{{ masterOrderService.formatCurrency(item.subtotal) }}</td>
                              <!-- <td>
                                <span class="badge" :class="masterOrderService.getStatusBadgeClass(item.status)">
                                  {{ getStatusText(item.status) }}
                                </span>
                              </td> -->
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" @click="closeDetailModal">Đóng</button>
              <button type="button" class="btn btn-primary" @click="printOrder(selectedOrder?.id)" v-if="selectedOrder">
                <i class="fas fa-print"></i> In đơn hàng
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup>
import { ref, onMounted, computed, nextTick } from 'vue'
import AdminLayout from '../../components/AdminLayout.vue'
import { masterOrderService } from '../../services/admin/masterorders'
import Swal from 'sweetalert2'

// Reactive data
const loading = ref(false)
const masterOrders = ref([])
const selectedOrder = ref(null)
const showDetailModal = ref(false)

// Filters
const filters = ref({
  status: '',
  customerEmail: '',
  customerPhone: '',
  fromDate: '',
  toDate: ''
})

// Pagination
const pagination = ref({
  currentPage: 0,
  size: 5,
  totalPages: 0,
  totalElements: 0
})

// Statistics
const statistics = ref({
  totalOrders: 0,
  completedOrders: 0,
  pendingOrders: 0,
  totalRevenue: 0
})

// Computed properties
const visiblePages = computed(() => {
  const current = pagination.value.currentPage
  const total = pagination.value.totalPages
  const delta = 2
  const range = []
  const start = Math.max(0, current - delta)
  const end = Math.min(total - 1, current + delta)
  
  for (let i = start; i <= end; i++) {
    range.push(i)
  }
  
  return range
})

// Methods
const fetchMasterOrders = async () => {
  loading.value = true
  try {
    const params = {
      page: pagination.value.currentPage,
      size: pagination.value.size,
      ...filters.value
    }

    const response = await masterOrderService.getAllMasterOrders(params)
    
    if (response.statusCode === 200 && response.data) {
      masterOrders.value = response.data.content || []
      
      // Update pagination info
      pagination.value.totalPages = response.data.totalPages || 0
      pagination.value.totalElements = response.data.totalElements || 0
      
      // Calculate statistics
      calculateStatistics()
    } else {
      console.warn('Unexpected master orders response structure:', response)
      masterOrders.value = []
      pagination.value.totalPages = 0
      pagination.value.totalElements = 0
    }
  } catch (error) {
    console.error('Error fetching master orders:', error)
    Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Không thể tải danh sách đơn hàng. Vui lòng thử lại.'
    })
  } finally {
    loading.value = false
  }
}

const calculateStatistics = () => {
  statistics.value.totalOrders = masterOrders.value.length
  statistics.value.completedOrders = masterOrders.value.filter(order => order.overallStatus === 'COMPLETED').length
  statistics.value.pendingOrders = masterOrders.value.filter(order => order.overallStatus === 'PENDING').length
  statistics.value.totalRevenue = masterOrders.value.reduce((sum, order) => sum + order.totalAmountPaid, 0)
}

const viewOrderDetails = async (masterOrderId) => {
  try {
    const response = await masterOrderService.getMasterOrderById(masterOrderId)
    
    if (response.statusCode === 200 && response.data) {
      selectedOrder.value = response.data
      showDetailModal.value = true
    } else {
      console.warn('Unexpected order details response structure:', response)
      Swal.fire({
        icon: 'warning',
        title: 'Cảnh báo!',
        text: 'Không thể tải chi tiết đơn hàng. Vui lòng thử lại.'
      })
    }
  } catch (error) {
    console.error('Error fetching order details:', error)
    Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Không thể tải chi tiết đơn hàng. Vui lòng thử lại.'
    })
  }
}

const closeDetailModal = () => {
  showDetailModal.value = false
  selectedOrder.value = null
}

const printOrder = (masterOrderId) => {
  // Implement print functionality
  window.print()
}

const changePage = (page) => {
  if (page >= 0 && page < pagination.value.totalPages) {
    pagination.value.currentPage = page
    fetchMasterOrders()
  }
}

const applyFilters = () => {
  pagination.value.currentPage = 0
  fetchMasterOrders()
}

const resetFilters = () => {
  filters.value = {
    status: '',
    customerEmail: '',
    customerPhone: '',
    fromDate: '',
    toDate: ''
  }
  pagination.value.currentPage = 0
  fetchMasterOrders()
}

const refreshData = () => {
  fetchMasterOrders()
}

// Debounce search for email and phone
let searchTimeout = null
const debounceSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    applyFilters()
  }, 500)
}

const exportOrders = async () => {
  try {
    // Implement export functionality
    Swal.fire({
      icon: 'info',
      title: 'Tính năng đang phát triển',
      text: 'Tính năng xuất Excel đang được phát triển.'
    })
  } catch (error) {
    Swal.fire({
      icon: 'error',
      title: 'Lỗi!',
      text: 'Không thể xuất file. Vui lòng thử lại.'
    })
  }
}

const getStatusText = (status) => {
  const statusTexts = {
    'PENDING': 'Chờ xử lý',
    'PROCESSING': 'Đang xử lý',
    'SHIPPED': 'Đã gửi hàng',
    'DELIVERED': 'Đã giao hàng',
    'COMPLETED': 'Hoàn thành',
    'CANCELLED': 'Đã hủy',
    'REFUNDED': 'Đã hoàn tiền'
  }
  return statusTexts[status] || status
}

// Lifecycle hooks
onMounted(() => {
  fetchMasterOrders()
})
</script>

<style scoped>
.table-responsive {
  border-radius: 0.5rem;
}

.badge {
  font-size: 0.75rem;
}

.badge-warning {
  background-color: #f39c12 !important;
}

.badge-info {
  background-color: #3498db !important;
}

.badge-success {
  background-color: #2ecc71 !important;
}

.badge-danger {
  background-color: #e74c3c !important;
}

.badge-secondary {
  background-color: #95a5a6 !important;
}

.badge-primary {
  background-color: #3490dc !important;
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
}

.btn-group-sm .btn {
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
}

.table th {
  border-top: none;
  font-weight: 600;
  color: #495057;
}

.table-hover tbody tr:hover {
  background-color: #f8f9fa;
}

.spinner-border {
  width: 2rem;
  height: 2rem;
}

.text-truncate {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.pagination .page-link {
  color: #495057;
}

.pagination .page-item.active .page-link {
  background-color: #007bff;
  border-color: #007bff;
}

.btn-close:hover {
  opacity: 0.75;
}

.modal-xl {
  max-width: 60%;
}

@media (max-width: 768px) {
  .modal-xl {
    max-width: 95%;
  }
  
  .table-responsive {
    font-size: 0.875rem;
  }
  
  .btn-group-sm .btn {
    padding: 0.125rem 0.25rem;
    font-size: 0.75rem;
  }
}
</style>
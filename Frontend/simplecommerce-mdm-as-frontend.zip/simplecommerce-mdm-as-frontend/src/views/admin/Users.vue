<template>
  <AdminLayout>
    <!-- User Stats - Responsive Grid -->
    <div class="row mb-4 g-3">
      <div class="col-12 col-sm-6 col-md-4">
        <div class="card bg-primary text-white h-100">
          <div class="card-body text-center py-3">
            <h3 class="mb-1">{{ userStats.totalUsers || 0 }}</h3>
            <small>Tổng người dùng</small>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-4">
        <div class="card bg-success text-white h-100">
          <div class="card-body text-center py-3">
            <h3 class="mb-1">{{ userStats.activeUsers || 0 }}</h3>
            <small>Đang hoạt động</small>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-4">
        <div class="card bg-danger text-white h-100">
          <div class="card-body text-center py-3">
            <h3 class="mb-1">{{ userStats.blockedUsers || 0 }}</h3>
            <small>Đã khóa</small>
          </div>
        </div>
      </div>
    </div>

    <!-- Users Table -->
    <div class="card">
      <div class="card-header">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
          <h5 class="mb-0">Danh sách người dùng</h5>
          <div class="d-flex flex-column flex-sm-row gap-2 w-100 w-md-auto">
            <input type="text" class="form-control flex-grow-1" placeholder="Tìm kiếm..." v-model="searchTerm"
              @input="searchUsers">
            <select class="form-select flex-grow-1" v-model="statusFilter" @change="loadUsers">
              <option value="">Tất cả</option>
              <option value="true">Hoạt động</option>
              <option value="false">Đã khóa</option>
            </select>
            <select class="form-select flex-grow-1" v-model="roleFilter" @change="loadUsers">
              <option value="">Tất cả vai trò</option>
              <option value="USER">USER</option>
              <option value="SELLER">SELLER</option>
              <option value="ADMIN">ADMIN</option>
            </select>
          </div>
        </div>
      </div>

      <div class="card-body">
        <!-- Loading State -->
        <div v-if="loading" class="text-center p-4">
          <div class="spinner-border" role="status">
            <span class="visually-hidden">Đang tải...</span>
          </div>
        </div>

        <!-- Error State -->
        <div v-else-if="error" class="alert alert-danger">
          {{ error }}
        </div>

        <!-- Users Table -->
        <div v-else class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th class="min-width-200">Người dùng</th>
                <th>Email</th>
                <th class="d-none d-md-table-cell">Vai trò</th>
                <th class="d-none d-lg-table-cell">Ngày đăng ký</th>
                <th>Trạng thái</th>
                <th class="text-end">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="user in users" :key="user.id">
                <td>
                  <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                      <img v-if="user.avatarUrl" :src="user.avatarUrl" :alt="user.fullName" class="rounded-circle me-2"
                        style="width: 40px; height: 40px; object-fit: cover;">
                      <div v-else
                        class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                        style="width: 40px; height: 40px;">
                        {{ getInitials(user.fullName) }}
                      </div>
                    </div>
                    <div class="flex-grow-1 ms-2">
                      <div class="fw-bold">{{ user.fullName }}</div>
                      <div class="text-muted small" v-if="user.phoneNumber">{{ user.phoneNumber }}</div>
                    </div>
                  </div>
                </td>
                <td>
                  <div>{{ user.email }}</div>
                  <!-- <div class="text-muted small">
                    <i class="bi bi-envelope" :class="user.emailVerifiedAt ? 'text-success' : 'text-warning'"></i>
                    {{ user.emailVerifiedAt ? 'Đã xác thực' : 'Chưa xác thực' }}
                  </div> -->
                </td>
                <td class="d-none d-md-table-cell">
                  <div class="d-flex flex-wrap gap-1">
                    <span v-for="role in user.roles" :key="role.roleId" class="badge"
                      :class="getRoleBadgeClass(role.roleName)">
                      {{ role.roleName }}
                    </span>
                  </div>
                </td>
                <td class="d-none d-lg-table-cell">{{ formatDate(user.createdAt) }}</td>
                <td>
                  <span :class="`badge bg-${user.isActive ? 'success' : 'danger'}`">
                    {{ user.isActive ? 'Hoạt động' : 'Bị khóa' }}
                  </span>
                  <div class="text-muted small" v-if="user.deletedAt">
                    <i class="bi bi-trash text-danger"></i> Đã xóa
                  </div>
                </td>
                <td>
                  <div class="d-flex justify-content-end gap-1">
                    <button class="btn btn-sm btn-outline-primary" @click="viewUser(user)" title="Xem chi tiết">
                      <i class="bi bi-eye d-md-none"></i>
                      <span class="d-none d-md-inline">Xem</span>
                    </button>
                    <div class="dropdown">
                      <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-three-dots"></i>
                      </button>
                      <ul class="dropdown-menu dropdown-menu-end">
                        <li v-if="user.isActive">
                          <a class="dropdown-item" href="#" @click.prevent="toggleUserStatus(user)">
                            <i class="bi bi-lock"></i> Khóa tài khoản
                          </a>
                        </li>
                        <li v-else>
                          <a class="dropdown-item" href="#" @click.prevent="toggleUserStatus(user)">
                            <i class="bi bi-unlock"></i> Mở khóa
                          </a>
                        </li>
                        <li>
                          <hr class="dropdown-divider">
                        </li>
                        <li>
                          <a class="dropdown-item" href="#" @click.prevent="editUserRoles(user)">
                            <i class="bi bi-person-gear"></i> Sửa vai trò
                          </a>
                        </li>
                        <!-- <li v-if="!user.emailVerifiedAt">
                          <a class="dropdown-item" href="#" @click.prevent="verifyEmail(user)">
                            <i class="bi bi-envelope-check"></i> Xác thực email
                          </a>
                        </li>
                        <li v-if="!user.phoneVerifiedAt && user.phoneNumber">
                          <a class="dropdown-item" href="#" @click.prevent="verifyPhone(user)">
                            <i class="bi bi-phone-vibrate"></i> Xác thực SĐT
                          </a>
                        </li> -->
                        <li v-if="user.deletedAt">
                          <a class="dropdown-item text-success" href="#" @click.prevent="restoreUser(user)">
                            <i class="bi bi-arrow-clockwise"></i> Khôi phục
                          </a>
                        </li>
                        <li v-else>
                          <a class="dropdown-item text-danger" href="#" @click.prevent="deleteUser(user)">
                            <i class="bi bi-trash"></i> Xóa
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </td>
              </tr>
              <tr v-if="users.length === 0">
                <td colspan="6" class="text-center text-muted py-4">
                  Không tìm thấy người dùng nào
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <nav class="mt-4" v-if="pagination.totalElements > 0">
          <ul class="pagination justify-content-center flex-wrap">
            <li class="page-item" :class="{ disabled: pagination.first }">
              <a class="page-link" href="#" @click.prevent="goToPage(pagination.number - 1)">Trước</a>
            </li>
            <li v-for="page in pageNumbers" :key="page" class="page-item"
              :class="{ active: page === pagination.number }">
              <a class="page-link" href="#" @click.prevent="goToPage(page)">{{ page + 1 }}</a>
            </li>
            <li class="page-item" :class="{ disabled: pagination.last }">
              <a class="page-link" href="#" @click.prevent="goToPage(pagination.number + 1)">Sau</a>
            </li>
          </ul>
          <div class="text-center text-muted">
            Hiển thị {{ pagination.numberOfElements }} / {{ pagination.totalElements }} người dùng
          </div>
        </nav>
      </div>
    </div>

    <!-- User Detail Modal -->
    <div class="modal fade" :class="{ show: showDetailModal, 'd-block': showDetailModal }" tabindex="-1"
      v-if="showDetailModal">
      <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content" v-if="selectedUser">
          <div class="modal-header">
            <h5 class="modal-title">Chi tiết người dùng</h5>
            <button type="button" class="btn-close" @click="showDetailModal = false"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-12 col-md-4 mb-3 mb-md-0">
                <div class="text-center">
                  <img v-if="selectedUser.avatarUrl" :src="selectedUser.avatarUrl" :alt="selectedUser.fullName"
                    class="rounded-circle mb-3 img-fluid" style="max-width: 150px; height: auto; aspect-ratio: 1/1; object-fit: cover;">
                  <div v-else
                    class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3"
                    style="width: 100px; height: 100px; font-size: 2rem;">
                    {{ getInitials(selectedUser.fullName) }}
                  </div>
                  <h5>{{ selectedUser.fullName }}</h5>
                  <div class="text-muted">{{ selectedUser.email }}</div>
                </div>
              </div>
              <div class="col-12 col-md-8">
                <div class="table-responsive">
                  <table class="table table-borderless">
                    <tbody>
                      <tr>
                        <td class="text-nowrap"><strong>UUID:</strong></td>
                        <td><code class="text-break">{{ selectedUser.uuid }}</code></td>
                      </tr>
                      <tr>
                        <td><strong>Vai trò:</strong></td>
                        <td>
                          <div class="d-flex flex-wrap gap-1">
                            <span v-for="role in selectedUser.roles" :key="role.roleId" class="badge"
                              :class="getRoleBadgeClass(role.roleName)">
                              {{ role.roleName }}
                            </span>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td><strong>Ngày đăng ký:</strong></td>
                        <td>{{ formatDateTime(selectedUser.createdAt) }}</td>
                      </tr>
                      <tr>
                        <td><strong>Cập nhật cuối:</strong></td>
                        <td>{{ formatDateTime(selectedUser.updatedAt) }}</td>
                      </tr>
                      <tr>
                        <td><strong>Đăng nhập cuối:</strong></td>
                        <td>{{ selectedUser.lastLoginAt ? formatDateTime(selectedUser.lastLoginAt) : 'Chưa đăng nhập' }}
                        </td>
                      </tr>
                      <tr>
                        <td><strong>Trạng thái:</strong></td>
                        <td>
                          <span :class="`badge bg-${selectedUser.isActive ? 'success' : 'danger'}`">
                            {{ selectedUser.isActive ? 'Hoạt động' : 'Bị khóa' }}
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><strong>Số điện thoại:</strong></td>
                        <td>
                          {{ selectedUser.phoneNumber || 'Chưa cập nhật' }}
                          <span v-if="selectedUser.phoneNumber" class="ms-2">
                            <i class="bi bi-phone"
                              :class="selectedUser.phoneVerifiedAt ? 'text-success' : 'text-warning'"></i>
                            {{ selectedUser.phoneVerifiedAt ? 'Đã xác thực' : 'Chưa xác thực' }}
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><strong>Email:</strong></td>
                        <td>
                          {{ selectedUser.email }}
                          <span class="ms-2">
                            <i class="bi bi-envelope"
                              :class="selectedUser.emailVerifiedAt ? 'text-success' : 'text-warning'"></i>
                            {{ selectedUser.emailVerifiedAt ? 'Đã xác thực' : 'Chưa xác thực' }}
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <!-- Statistics -->
                <!-- <div class="mt-4" v-if="selectedUser.statistics">
                  <h6>Thống kê:</h6>
                  <div class="row g-2">
                    <div class="col-6 col-sm-4">
                      <small class="text-muted">Tổng đơn hàng:</small>
                      <strong class="d-block">{{ selectedUser.statistics.totalOrders }}</strong>
                    </div>
                    <div class="col-6 col-sm-4">
                      <small class="text-muted">Tổng cửa hàng:</small>
                      <strong class="d-block">{{ selectedUser.statistics.totalShops }}</strong>
                    </div>
                    <div class="col-6 col-sm-4">
                      <small class="text-muted">Giỏ hàng:</small>
                      <strong class="d-block">{{ selectedUser.statistics.hasActiveCart ? 'Có' : 'Không' }}</strong>
                    </div>
                  </div>
                </div> -->
              </div>
            </div>
          </div>
          <div class="modal-footer d-flex flex-wrap justify-content-between">
            <button type="button" class="btn btn-secondary order-2 order-md-1" @click="showDetailModal = false">Đóng</button>
            <div class="d-flex gap-2 order-1 order-md-2 mb-2 mb-md-0">
              <button type="button" class="btn btn-warning" @click="editUserRoles(selectedUser)">
                <i class="bi bi-person-gear"></i> Sửa vai trò
              </button>
              <button type="button" :class="`btn btn-${selectedUser.isActive ? 'danger' : 'success'}`"
                @click="toggleUserStatus(selectedUser)">
                <i :class="`bi bi-${selectedUser.isActive ? 'lock' : 'unlock'}`"></i>
                {{ selectedUser.isActive ? 'Khóa tài khoản' : 'Mở khóa' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Role Edit Modal -->
    <div class="modal fade" :class="{ show: showRoleModal, 'd-block': showRoleModal }" tabindex="-1"
      v-if="showRoleModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Chỉnh sửa vai trò</h5>
            <button type="button" class="btn-close" @click="showRoleModal = false"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">Người dùng:</label>
              <div><strong>{{ editingUser?.fullName }}</strong> ({{ editingUser?.email }})</div>
            </div>
            <div class="mb-3">
              <label class="form-label">Vai trò hiện tại:</label>
              <div class="d-flex flex-wrap gap-1">
                <span v-for="role in editingUser?.roles" :key="role.roleId" class="badge"
                  :class="getRoleBadgeClass(role.roleName)">
                  {{ role.roleName }}
                </span>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label">Chọn vai trò mới:</label>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" value="USER" id="role-user" v-model="newRoles">
                <label class="form-check-label" for="role-user">USER</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" value="SELLER" id="role-seller" v-model="newRoles">
                <label class="form-check-label" for="role-seller">SELLER</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" value="ADMIN" id="role-admin" v-model="newRoles">
                <label class="form-check-label" for="role-admin">ADMIN</label>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="showRoleModal = false">Hủy</button>
            <button type="button" class="btn btn-primary" @click="saveUserRoles" :disabled="newRoles.length === 0">
              <i class="bi bi-check-lg"></i> Lưu thay đổi
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Backdrop -->
    <div class="modal-backdrop fade show" v-if="showDetailModal || showRoleModal"></div>
  </AdminLayout>
</template>

<script setup>
import { adminUserService } from '@/services/admin/user'
import AdminLayout from '@/components/AdminLayout.vue'
import { ref, onMounted, computed } from 'vue'
import { useUserStore } from '@/stores/admin/user'
import Swal from 'sweetalert2'


const userStore = useUserStore()

// Reactive states
const loading = ref(false)
const error = ref('')
const showDetailModal = ref(false)
const showRoleModal = ref(false)
const selectedUser = ref(null)
const editingUser = ref(null)
const newRoles = ref([])

// Search and filter
const searchTerm = ref('')
const statusFilter = ref('')
const roleFilter = ref('')
const searchTimeout = ref(null)

// Pagination
const currentPage = ref(0)
const pageSize = ref(5)

// Computed properties
const users = computed(() => userStore.users)
const userStats = computed(() => userStore.userStats)
const pagination = computed(() => userStore.pagination)
const pageNumbers = computed(() => userStore.getPageNumbers)

// Utility functions
const getInitials = (fullName) => {
    if (!fullName) return ''
    return fullName.split(' ').map(n => n.charAt(0)).join('').substring(0, 2).toUpperCase()
}

const getRoleBadgeClass = (roleName) => {
    const roleColors = {
        'USER': 'bg-primary',
        'SELLER': 'bg-warning',
        'ADMIN': 'bg-danger'
    }
    return roleColors[roleName] || 'bg-secondary'
}

const formatDate = (dateString) => {
    if (!dateString) return ''
    return new Date(dateString).toLocaleDateString('vi-VN')
}

const formatDateTime = (dateString) => {
    if (!dateString) return ''
    return new Date(dateString).toLocaleString('vi-VN')
}

// API methods
const loadUsers = async () => {
    try {
        loading.value = true
        error.value = ''
        
        const params = {
            searchTerm: searchTerm.value,
            page: currentPage.value,
            size: pageSize.value,
            sortBy: 'createdAt',
            sortDirection: 'desc'
        }
        
        if (statusFilter.value !== '') {
            params.isActive = statusFilter.value === 'true'
        }
        
        if (roleFilter.value) {
            params.roleName = roleFilter.value
        }
        
        await userStore.fetchUsers(params)
    } catch (err) {
        error.value = err.message || 'Không thể tải danh sách người dùng'
        console.error('Error loading users:', err)
        showErrorAlert(err.message || 'Có lỗi xảy ra khi tải dữ liệu')
    } finally {
        loading.value = false
    }
}

const loadUserStats = async () => {
    try {
        await userStore.fetchUserStats()
    } catch (err) {
        console.error('Error loading user stats:', err)
    }
}

const searchUsers = () => {
    if (searchTimeout.value) {
        clearTimeout(searchTimeout.value)
    }
    
    searchTimeout.value = setTimeout(() => {
        currentPage.value = 0
        loadUsers()
    }, 500)
}

const goToPage = (page) => {
    if (page >= 0 && page < pagination.value.totalPages) {
        currentPage.value = page
        loadUsers()
    }
}

const viewUser = async (user) => {
    try {
        const response = await adminUserService.getUserById(user.id)
        if (response?.data) {
            selectedUser.value = response.data
            showDetailModal.value = true
        }
    } catch (err) {
        showErrorAlert(err.message || 'Không thể tải thông tin người dùng')
    }
}

const toggleUserStatus = async (user) => {
    const newStatus = !user.isActive
    const action = newStatus ? 'mở khóa' : 'khóa'
    
    const result = await showConfirmationDialog(
        `${newStatus ? 'Mở khóa' : 'Khóa'} tài khoản?`,
        `Bạn có chắc chắn muốn ${action} tài khoản của ${user.fullName}?`,
        newStatus ? 'success' : 'warning',
        newStatus ? 'Mở khóa' : 'Khóa'
    )

    if (result.isConfirmed) {
        try {
            await userStore.updateUserStatus(user.id, newStatus)
            showSuccessAlert(`Tài khoản đã được ${action}`)
            
            if (selectedUser.value?.id === user.id) {
                selectedUser.value.isActive = newStatus
            }
        } catch (err) {
            showErrorAlert(err.message || `Không thể ${action} tài khoản`)
        }
    }
}

const editUserRoles = (user) => {
    editingUser.value = user
    newRoles.value = user.roles.map(role => role.roleName)
    showDetailModal.value = false
    showRoleModal.value = true
}

const saveUserRoles = async () => {
    if (newRoles.value.length === 0) {
        showErrorAlert('Vui lòng chọn ít nhất một vai trò')
        return
    }

    try {
        await userStore.updateUserRoles(editingUser.value.id, newRoles.value)
        showSuccessAlert('Vai trò đã được cập nhật')
        showRoleModal.value = false
    } catch (err) {
        showErrorAlert(err.message || 'Không thể cập nhật vai trò')
    }
}

const verifyEmail = async (user) => {
    try {
        await adminUserService.verifyUserEmail(user.id)
        userStore.invalidateCache()
        await loadUsers()
        showSuccessAlert('Email đã được xác thực')
    } catch (err) {
        showErrorAlert(err.message || 'Không thể xác thực email')
    }
}

const verifyPhone = async (user) => {
    try {
        await adminUserService.verifyUserPhone(user.id)
        userStore.invalidateCache()
        await loadUsers()
        showSuccessAlert('Số điện thoại đã được xác thực')
    } catch (err) {
        showErrorAlert(err.message || 'Không thể xác thực số điện thoại')
    }
}

const deleteUser = async (user) => {
    const result = await showConfirmationDialog(
        'Xóa người dùng?',
        `Bạn có chắc chắn muốn xóa tài khoản của ${user.fullName}?`,
        'warning',
        'Xóa'
    )

    if (result.isConfirmed) {
        try {
            await userStore.deleteUser(user.id)
            showSuccessAlert('Tài khoản đã được xóa')
        } catch (err) {
            showErrorAlert(err.message || 'Không thể xóa tài khoản')
        }
    }
}

const restoreUser = async (user) => {
    const result = await showConfirmationDialog(
        'Khôi phục người dùng?',
        `Bạn có chắc chắn muốn khôi phục tài khoản của ${user.fullName}?`,
        'warning',
        'Khôi phục'
    )

    if (result.isConfirmed) {
        try {
            await userStore.restoreUser(user.id)
            userStore.invalidateCache()
            await loadUsers()
            showSuccessAlert('Tài khoản đã được khôi phục')
        } catch (err) {
            showErrorAlert(err.message || 'Không thể khôi phục tài khoản')
        }
    }
}

// Helper functions for alerts
const showSuccessAlert = (message) => {
    Swal.fire({
        title: 'Thành công!',
        text: message,
        icon: 'success',
        timer: 2000,
        showConfirmButton: false
    })
}

const showErrorAlert = (message) => {
    Swal.fire({
        title: 'Lỗi!',
        text: message,
        icon: 'error'
    })
}

const showConfirmationDialog = (title, text, icon, confirmText) => {
    return Swal.fire({
        title,
        text,
        icon,
        showCancelButton: true,
        confirmButtonColor: icon === 'success' ? '#28a745' : '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: confirmText,
        cancelButtonText: 'Hủy'
    })
}

// Lifecycle hooks
onMounted(() => {
    loadUsers()
    loadUserStats()
    
})
</script>

<style scoped>
.min-width-200 {
  min-width: 200px;
}

@media (max-width: 767.98px) {
  .card-header h5 {
    font-size: 1.25rem;
  }
  
  .table-responsive {
    border: 0;
  }
  
  .table thead {
    display: none;
  }
  
  .table tr {
    display: block;
    margin-bottom: 1rem;
    border: 1px solid #dee2e6;
    border-radius: 0.25rem;
  }
  
  .table td {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem;
    border-bottom: 1px solid #dee2e6;
  }
  
  .table td:before {
    content: attr(data-label);
    font-weight: bold;
    margin-right: 1rem;
  }
  
  .table td:last-child {
    border-bottom: 0;
  }
  
  .badge {
    font-size: 0.75rem;
  }
}
</style>

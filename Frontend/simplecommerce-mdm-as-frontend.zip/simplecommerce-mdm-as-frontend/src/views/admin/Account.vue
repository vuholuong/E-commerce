<template>
  <AdminLayout>
    <div class="container-fluid">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1 class="h3 mb-0 text-gray-800">Quản lý tài khoản Admin</h1>
          <p class="mb-0 text-muted">Quản lý danh sách các tài khoản quản trị viên</p>
        </div>
        <button class="btn btn-primary" @click="openAddModal">
          <i class="bi bi-plus-circle me-2"></i>
          Thêm Admin mới
        </button>
      </div>

      <!-- Bảng danh sách admin -->
      <div class="card shadow">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Danh sách Admin</h6>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Tên đăng nhập</th>
                <th>Họ tên</th>
                <th>Email</th>
                <th>Vai trò</th>
                <th>Trạng thái</th>
                <th>Đăng nhập cuối</th>
                <th>Thao tác</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(admin, index) in admins" :key="admin.id">
                <td>{{ index + 1 }}</td>
                <td>
                  <strong>{{ admin.username }}</strong>
                </td>
                <td>{{ admin.fullName }}</td>
                <td>{{ admin.email }}</td>
                <td>
                  <span class="badge bg-info">{{ admin.role }}</span>
                </td>
                <td>
                    <span
                        class="badge"
                        :class="getStatusClass(admin.status)"
                    >
                      {{ getStatusText(admin.status) }}
                    </span>
                </td>
                <td>{{ admin.lastLogin }}</td>
                <td>
                  <div class="btn-group" role="group">
                    <!-- Nút chỉnh sửa -->
                    <button
                        class="btn btn-sm btn-outline-primary"
                        @click="openEditModal(admin)"
                        title="Chỉnh sửa"
                    >
                      <i class="bi bi-pencil"></i>
                    </button>

                    <!-- Nút khóa/mở khóa -->
                    <button
                        class="btn btn-sm"
                        :class="admin.status === 'active' ? 'btn-outline-warning' : 'btn-outline-success'"
                        @click="toggleStatus(admin)"
                        :title="admin.status === 'active' ? 'Khóa tài khoản' : 'Mở khóa tài khoản'"
                    >
                      <i :class="admin.status === 'active' ? 'bi bi-lock' : 'bi bi-unlock'"></i>
                    </button>

                    <!-- Nút xóa -->
                    <button
                        class="btn btn-sm btn-outline-danger"
                        @click="deleteAdmin(admin)"
                        title="Xóa tài khoản"
                    >
                      <i class="bi bi-trash"></i>
                    </button>
                  </div>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
          <!-- Pagination -->
          <nav class="mt-4">
            <ul class="pagination justify-content-center">
              <li class="page-item"><a class="page-link" href="#">Trước</a></li>
              <li class="page-item active"><a class="page-link" href="#">1</a></li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item"><a class="page-link" href="#">Sau</a></li>
            </ul>
          </nav>
        </div>
      </div>

      <!-- Modal thêm/chỉnh sửa admin -->
      <div
          class="modal fade"
          :class="{ show: showModal }"
          :style="{ display: showModal ? 'block' : 'none' }"
          tabindex="-1"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">{{ modalTitle }}</h5>
              <button
                  type="button"
                  class="btn-close"
                  @click="closeModal"
              ></button>
            </div>
            <div class="modal-body">
              <form @submit.prevent="saveChanges">
                <!-- Form cho thêm admin mới -->
                <div v-if="!isEditMode">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="newUsername" class="form-label">
                          Tên đăng nhập <span class="text-danger">*</span>
                        </label>
                        <input
                            type="text"
                            class="form-control"
                            :class="{ 'is-invalid': errors.username }"
                            id="newUsername"
                            v-model="newAdmin.username"
                            placeholder="Nhập tên đăng nhập"
                        >
                        <div v-if="errors.username" class="invalid-feedback">
                          {{ errors.username }}
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="newEmail" class="form-label">
                          Email <span class="text-danger">*</span>
                        </label>
                        <input
                            type="email"
                            class="form-control"
                            :class="{ 'is-invalid': errors.email }"
                            id="newEmail"
                            v-model="newAdmin.email"
                            placeholder="Nhập email"
                        >
                        <div v-if="errors.email" class="invalid-feedback">
                          {{ errors.email }}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="newFullName" class="form-label">
                          Họ tên <span class="text-danger">*</span>
                        </label>
                        <input
                            type="text"
                            class="form-control"
                            :class="{ 'is-invalid': errors.fullName }"
                            id="newFullName"
                            v-model="newAdmin.fullName"
                            placeholder="Nhập họ tên"
                        >
                        <div v-if="errors.fullName" class="invalid-feedback">
                          {{ errors.fullName }}
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="newRole" class="form-label">Vai trò</label>
                        <select
                            class="form-select"
                            id="newRole"
                            v-model="newAdmin.role"
                        >
                          <option value="Super Admin">Super Admin</option>
                          <option value="Admin">Admin</option>
                          <option value="Moderator">Moderator</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="newPassword" class="form-label">
                          Mật khẩu <span class="text-danger">*</span>
                        </label>
                        <input
                            type="password"
                            class="form-control"
                            :class="{ 'is-invalid': errors.password }"
                            id="newPassword"
                            v-model="newAdmin.password"
                            placeholder="Nhập mật khẩu"
                        >
                        <div v-if="errors.password" class="invalid-feedback">
                          {{ errors.password }}
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="confirmPassword" class="form-label">
                          Xác nhận mật khẩu <span class="text-danger">*</span>
                        </label>
                        <input
                            type="password"
                            class="form-control"
                            :class="{ 'is-invalid': errors.confirmPassword }"
                            id="confirmPassword"
                            v-model="newAdmin.confirmPassword"
                            placeholder="Nhập lại mật khẩu"
                        >
                        <div v-if="errors.confirmPassword" class="invalid-feedback">
                          {{ errors.confirmPassword }}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="newStatus" class="form-label">Trạng thái</label>
                        <select
                            class="form-select"
                            id="newStatus"
                            v-model="newAdmin.status"
                        >
                          <option value="active">Đang hoạt động</option>
                          <option value="locked">Bị khóa</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Form cho chỉnh sửa admin -->
                <div v-else>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="username" class="form-label">Tên đăng nhập</label>
                        <input
                            type="text"
                            class="form-control"
                            id="username"
                            v-model="selectedAdmin.username"
                            readonly
                        >
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input
                            type="email"
                            class="form-control"
                            id="email"
                            v-model="selectedAdmin.email"
                        >
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="fullName" class="form-label">Họ tên</label>
                        <input
                            type="text"
                            class="form-control"
                            id="fullName"
                            v-model="selectedAdmin.fullName"
                        >
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="role" class="form-label">Vai trò</label>
                        <select
                            class="form-select"
                            id="role"
                            v-model="selectedAdmin.role"
                        >
                          <option value="Super Admin">Super Admin</option>
                          <option value="Admin">Admin</option>
                          <option value="Moderator">Moderator</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="status" class="form-label">Trạng thái</label>
                        <select
                            class="form-select"
                            id="status"
                            v-model="selectedAdmin.status"
                        >
                          <option value="active">Đang hoạt động</option>
                          <option value="locked">Bị khóa</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label for="lastLogin" class="form-label">Đăng nhập cuối</label>
                        <input
                            type="text"
                            class="form-control"
                            id="lastLogin"
                            v-model="selectedAdmin.lastLogin"
                            readonly
                        >
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" @click="closeModal">
                Hủy
              </button>
              <button
                  type="button"
                  class="btn btn-primary"
                  @click="saveChanges"
              >
                {{ isEditMode ? 'Lưu thay đổi' : 'Thêm Admin' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Backdrop cho modal -->
      <div
          class="modal-backdrop fade"
          :class="{ show: showModal }"
          v-if="showModal"
          @click="closeModal"
      ></div>
    </div>
  </AdminLayout>
</template>

<script setup>
import AdminLayout from "@/components/AdminLayout.vue";
import Swal from "sweetalert2";
import {ref, onMounted} from 'vue';

// Dữ liệu mẫu cho danh sách admin
const admins = ref([
  {
    id: 1,
    username: 'admin1',
    email: 'admin1@example.com',
    fullName: 'Nguyễn Văn Admin',
    role: 'Super Admin',
    status: 'active',
    lastLogin: '2024-01-15 10:30:00',
    createdAt: '2024-01-01 08:00:00'
  },
  {
    id: 2,
    username: 'admin2',
    email: 'admin2@example.com',
    fullName: 'Trần Thị Quản Lý',
    role: 'Admin',
    status: 'locked',
    lastLogin: '2024-01-14 16:45:00',
    createdAt: '2024-01-02 09:15:00'
  },
  {
    id: 3,
    username: 'admin3',
    email: 'admin3@example.com',
    fullName: 'Lê Văn Hỗ Trợ',
    role: 'Moderator',
    status: 'active',
    lastLogin: '2024-01-16 14:20:00',
    createdAt: '2024-01-03 11:30:00'
  }
]);

// Dữ liệu cho modal
const showModal = ref(false);
const selectedAdmin = ref({});
const modalTitle = ref('');
const isEditMode = ref(false);

// Dữ liệu cho form thêm admin mới
const newAdmin = ref({
  username: '',
  email: '',
  fullName: '',
  role: 'Admin',
  status: 'active',
  password: '',
  confirmPassword: ''
});

// Validation errors
const errors = ref({});

// Reset form
const resetForm = () => {
  newAdmin.value = {
    username: '',
    email: '',
    fullName: '',
    role: 'Admin',
    status: 'active',
    password: '',
    confirmPassword: ''
  };
  errors.value = {};
};

// Hiển thị modal thêm admin mới
const openAddModal = () => {
  resetForm();
  modalTitle.value = 'Thêm Admin mới';
  isEditMode.value = false;
  showModal.value = true;
};

// Hiển thị modal chỉnh sửa
const openEditModal = (admin) => {
  selectedAdmin.value = {...admin};
  modalTitle.value = 'Chỉnh sửa thông tin Admin';
  isEditMode.value = true;
  errors.value = {};
  showModal.value = true;
};

// Đóng modal
const closeModal = () => {
  showModal.value = false;
  selectedAdmin.value = {};
  resetForm();
  errors.value = {};
};

// Validation cho form thêm admin
const validateForm = () => {
  errors.value = {};
  let isValid = true;

  // Kiểm tra tên đăng nhập
  if (!newAdmin.value.username.trim()) {
    errors.value.username = 'Tên đăng nhập không được để trống';
    isValid = false;
  } else if (newAdmin.value.username.length < 3) {
    errors.value.username = 'Tên đăng nhập phải có ít nhất 3 ký tự';
    isValid = false;
  } else if (admins.value.some(admin => admin.username === newAdmin.value.username)) {
    errors.value.username = 'Tên đăng nhập đã tồn tại';
    isValid = false;
  }

  // Kiểm tra email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!newAdmin.value.email.trim()) {
    errors.value.email = 'Email không được để trống';
    isValid = false;
  } else if (!emailRegex.test(newAdmin.value.email)) {
    errors.value.email = 'Email không đúng định dạng';
    isValid = false;
  } else if (admins.value.some(admin => admin.email === newAdmin.value.email)) {
    errors.value.email = 'Email đã tồn tại';
    isValid = false;
  }

  // Kiểm tra họ tên
  if (!newAdmin.value.fullName.trim()) {
    errors.value.fullName = 'Họ tên không được để trống';
    isValid = false;
  }

  // Kiểm tra mật khẩu
  if (!newAdmin.value.password) {
    errors.value.password = 'Mật khẩu không được để trống';
    isValid = false;
  } else if (newAdmin.value.password.length < 6) {
    errors.value.password = 'Mật khẩu phải có ít nhất 6 ký tự';
    isValid = false;
  }

  // Kiểm tra xác nhận mật khẩu
  if (newAdmin.value.password !== newAdmin.value.confirmPassword) {
    errors.value.confirmPassword = 'Xác nhận mật khẩu không khớp';
    isValid = false;
  }

  return isValid;
};

// Thêm admin mới
const addNewAdmin = () => {
  if (!validateForm()) {
    return;
  }

  const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
  const maxId = Math.max(...admins.value.map(admin => admin.id));

  const adminToAdd = {
    id: maxId + 1,
    username: newAdmin.value.username,
    email: newAdmin.value.email,
    fullName: newAdmin.value.fullName,
    role: newAdmin.value.role,
    status: newAdmin.value.status,
    lastLogin: 'Chưa đăng nhập',
    createdAt: now
  };

  admins.value.push(adminToAdd);

  Swal.fire({
    title: 'Thành công!',
    text: 'Admin mới đã được thêm thành công',
    icon: 'success',
    timer: 2000,
    showConfirmButton: false
  });

  closeModal();
};

// Lưu thay đổi
const saveChanges = () => {
  if (isEditMode.value) {
    const index = admins.value.findIndex(admin => admin.id === selectedAdmin.value.id);
    if (index !== -1) {
      admins.value[index] = {...selectedAdmin.value};
    }

    Swal.fire({
      title: 'Thành công!',
      text: 'Thông tin admin đã được cập nhật',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false
    });
  } else {
    addNewAdmin();
    return;
  }

  closeModal();
};

// Thay đổi trạng thái admin
const toggleStatus = async (admin) => {
  const newStatus = admin.status === 'active' ? 'locked' : 'active';
  const actionText = newStatus === 'locked' ? 'khóa' : 'mở khóa';

  const result = await Swal.fire({
    title: `Xác nhận ${actionText}`,
    text: `Bạn có chắc chắn muốn ${actionText} tài khoản "${admin.username}"?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: newStatus === 'locked' ? '#dc3545' : '#28a745',
    cancelButtonColor: '#6c757d',
    confirmButtonText: `Có, ${actionText}!`,
    cancelButtonText: 'Hủy'
  });

  if (result.isConfirmed) {
    admin.status = newStatus;

    Swal.fire({
      title: 'Thành công!',
      text: `Tài khoản đã được ${actionText}`,
      icon: 'success',
      timer: 2000,
      showConfirmButton: false
    });
  }
};

// Xóa admin
const deleteAdmin = async (admin) => {
  const result = await Swal.fire({
    title: 'Xác nhận xóa',
    text: `Bạn có chắc chắn muốn xóa tài khoản "${admin.username}"? Hành động này không thể hoàn tác!`,
    icon: 'error',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Có, xóa!',
    cancelButtonText: 'Hủy'
  });

  if (result.isConfirmed) {
    const index = admins.value.findIndex(a => a.id === admin.id);
    if (index !== -1) {
      admins.value.splice(index, 1);
    }

    Swal.fire({
      title: 'Đã xóa!',
      text: 'Tài khoản admin đã được xóa',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false
    });
  }
};

// Lấy class cho badge trạng thái
const getStatusClass = (status) => {
  return status === 'active' ? 'bg-success' : 'bg-danger';
};

// Lấy text trạng thái
const getStatusText = (status) => {
  return status === 'active' ? 'Đang hoạt động' : 'Bị khóa';
};

onMounted(() => {
  // Có thể gọi API để lấy dữ liệu admin ở đây
});
</script>

<style scoped>
.table th {
  border-top: none;
  font-weight: 600;
  color: #5a5c69;
}

.btn-group .btn {
  margin-right: 2px;
}

.btn-group .btn:last-child {
  margin-right: 0;
}

.modal.show {
  background-color: rgba(0, 0, 0, 0.5);
}

.card {
  border: none;
  box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
}

.card-header {
  background-color: #f8f9fc;
  border-bottom: 1px solid #e3e6f0;
}

.badge {
  font-size: 0.75rem;
}

.table-responsive {
  border-radius: 0.35rem;
}

.btn-outline-primary:hover,
.btn-outline-success:hover,
.btn-outline-warning:hover,
.btn-outline-danger:hover {
  transform: translateY(-1px);
  transition: all 0.2s;
}

.text-danger {
  color: #dc3545 !important;
}

.is-invalid {
  border-color: #dc3545;
}

.invalid-feedback {
  display: block;
  width: 100%;
  margin-top: 0.25rem;
  font-size: 0.875em;
  color: #dc3545;
}
</style>
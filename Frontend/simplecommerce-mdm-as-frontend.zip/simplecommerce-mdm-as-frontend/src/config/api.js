import axios from 'axios'

/**
 * CẤU HÌNH API CHO CẢ DEVELOPMENT VÀ PRODUCTION
 * 
 * Vấn đề: 
 * - Development: Cần proxy để tránh CORS
 * - Production: Không có proxy, phải gọi trực tiếp backend
 * 
 * Giải pháp: Tự động detect môi trường và chọn base URL phù hợp
 */

// Detect môi trường hiện tại
const isDevelopment = import.meta.env.DEV
const isVercel = import.meta.env.VITE_VERCEL === 'true' || window.location.hostname.includes('vercel.app')
const isCustomDomain = window.location.hostname.includes('nammai.id.vn') && !window.location.hostname.includes('vercel.app')

/**
 * BASE URL CHO API
 * 
 * Development (npm run dev):
 * - Sử dụng proxy: '/api' → vite proxy forward đến backend
 * - Frontend gọi: /api/v1/auth/login
 * - Proxy forward: https://sc-mdm-api.nammai.id.vn/api/v1/auth/login
 * 
 * Production (Custom Domain):
 * - Gọi trực tiếp backend API
 * - Frontend gọi: https://sc-mdm-api.nammai.id.vn/api/v1/auth/login
 * 
 * Production (Vercel):
 * - Sử dụng Vercel rewrites để map API calls
 * - Frontend gọi: /api/v1/auth/login
 * - Vercel rewrite: https://sc-mdm-api.nammai.id.vn/api/v1/auth/login
 */
export const API_BASE_URL = isDevelopment 
    ? '/api' // Development: sử dụng proxy từ vite.config.js
    : isCustomDomain 
        ? 'https://sc-mdm-api.nammai.id.vn/api' // Custom domain: gọi trực tiếp backend
        : '/api' // Vercel: sử dụng Vercel rewrites

/**
 * TẠO AXIOS CLIENT VỚI CẤU HÌNH TÙY CHỈNH
 * 
 * @param {string} baseURL - Base URL cho API (mặc định: API_BASE_URL)
 * @returns {Object} Axios client instance
 */
export const createApiClient = (baseURL = API_BASE_URL) => {
    // Tạo axios instance với cấu hình cơ bản
    const apiClient = axios.create({
        baseURL, // URL gốc cho tất cả requests
        headers: {
            'Content-Type': 'application/json', // Content type mặc định
        },
        timeout: 10000, // Timeout 10 giây
    })

    /**
     * REQUEST INTERCEPTOR
     * Chạy trước khi gửi request
     * Dùng để: thêm token, log, validate...
     */
    apiClient.interceptors.request.use(
        (config) => {
            // Tự động thêm token vào header nếu có
            // Kiểm tra cả 2 loại key để tương thích với code cũ
            const token = localStorage.getItem('accessToken') || 
                         localStorage.getItem('app_access_token')
            
            if (token) {
                config.headers.Authorization = `Bearer ${token}`
                console.log('✅ Token added to request:', token.substring(0, 20) + '...')
            } else {
                console.log('⚠️ No token found, request will be sent without auth')
            }
            
            return config
        },
        (error) => {
            console.error('❌ Request interceptor error:', error)
            return Promise.reject(error)
        }
    )

    /**
     * RESPONSE INTERCEPTOR
     * Chạy sau khi nhận response
     * Dùng để: xử lý lỗi chung, refresh token, redirect...
     */
    apiClient.interceptors.response.use(
        // Response thành công
        (response) => {
            console.log('✅ API Response success:', response.config.url, response.status)
            return response
        },
        // Response lỗi
        (error) => {
            console.error('❌ API Response error:', error.config?.url, error.response?.status)
            
            // Xử lý lỗi 401 (Unauthorized) - token hết hạn
            if (error.response?.status === 401) {
                console.log('🔄 Token expired, redirecting to login...')
                
                // Clear tất cả token cũ
                localStorage.removeItem('accessToken')
                localStorage.removeItem('app_access_token')
                
                // Redirect về trang login
                window.location.href = '/login'
            }
            
            return Promise.reject(error)
        }
    )

    return apiClient
}

/**
 * EXPORT DEFAULT API CLIENT
 * 
 * Sử dụng: import { apiClient } from '@/config/api'
 * 
 * Ví dụ:
 * - await apiClient.post('/v1/auth/login', data)
 * - await apiClient.get('/v1/users')
 * - await apiClient.put('/v1/profile', data)
 */
export const apiClient = createApiClient()

// Log cấu hình hiện tại để debug
console.log('🔧 API Config loaded:', {
    environment: isDevelopment ? 'Development' : (isCustomDomain ? 'Custom Domain' : (isVercel ? 'Vercel' : 'Production')),
    baseURL: API_BASE_URL,
    hasProxy: isDevelopment,
    platform: isCustomDomain ? 'Custom Domain' : (isVercel ? 'Vercel' : 'Other'),
    hostname: window.location.hostname
})

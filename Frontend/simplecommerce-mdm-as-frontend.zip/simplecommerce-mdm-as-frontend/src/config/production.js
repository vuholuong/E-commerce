/**
 * PRODUCTION CONFIGURATION
 * 
 * File này chứa các cấu hình riêng cho môi trường production
 * Sử dụng khi deploy lên server thật
 */

// Cấu hình cho production
export const PRODUCTION_CONFIG = {
    API_BASE_URL: 'https://sc-mdm-api.nammai.id.vn', // Backend URL production
    TIMEOUT: 15000, // Timeout 15 giây cho production (mạng có thể chậm hơn)
    RETRY_ATTEMPTS: 3, // Số lần retry khi API fail
}

/**
 * UTILITY FUNCTIONS ĐỂ KIỂM TRA MÔI TRƯỜNG
 * 
 * Sử dụng để:
 * - Hiển thị UI khác nhau cho dev/prod
 * - Áp dụng cấu hình khác nhau
 * - Debug/log khác nhau
 */

// Kiểm tra môi trường production
export const isProduction = () => {
    return import.meta.env.PROD
}

// Kiểm tra môi trường development
export const isDevelopment = () => {
    return import.meta.env.DEV
}

// Log cấu hình production
if (isProduction()) {
    console.log('🚀 Production mode detected:', PRODUCTION_CONFIG)
}

/**
 * Redirect Utilities - Hỗ trợ tạo URL redirect với token
 */

/**
 * Tạo URL để redirect user đến trang quản lý shop với token
 * @param {string} token - JWT token của user
 * @param {string} baseUrl - Base URL của trang quản lý shop
 * @returns {string} URL hoàn chỉnh với token
 */
export function createShopManagementUrl(token, baseUrl = 'https://simplecommerce-mdm-as.nammai.id.vn') {
  if (!token) {
    console.error('❌ Token không được cung cấp')
    return null
  }
  
  try {
    const url = new URL('/seller/dashboard', baseUrl)
    url.searchParams.set('token', token)
    
    console.log('🔗 Tạo URL quản lý shop:', url.toString())
    return url.toString()
  } catch (error) {
    console.error('❌ Lỗi khi tạo URL:', error)
    return null
  }
}

/**
 * Tạo URL để redirect user đến trang quản lý admin với token
 * @param {string} token - JWT token của user
 * @param {string} baseUrl - Base URL của trang quản lý admin
 * @returns {string} URL hoàn chỉnh với token
 */
export function createAdminManagementUrl(token, baseUrl = 'https://simplecommerce-mdm-as.nammai.id.vn') {
  if (!token) {
    console.error('❌ Token không được cung cấp')
    return null
  }
  
  try {
    const url = new URL('/admin/dashboard', baseUrl)
    url.searchParams.set('token', token)
    
    console.log('🔗 Tạo URL quản lý admin:', url.toString())
    return url.toString()
  } catch (error) {
    console.error('❌ Lỗi khi tạo URL:', error)
    return null
  }
}

/**
 * Mở tab mới với URL quản lý shop
 * @param {string} token - JWT token của user
 * @param {string} baseUrl - Base URL của trang quản lý shop
 */
export function openShopManagementInNewTab(token, baseUrl = 'https://simplecommerce-mdm-as.nammai.id.vn') {
  const url = createShopManagementUrl(token, baseUrl)
  if (url) {
    window.open(url, '_blank', 'noopener,noreferrer')
    console.log('🔄 Mở tab mới quản lý shop')
  }
}

/**
 * Mở tab mới với URL quản lý admin
 * @param {string} token - JWT token của user
 * @param {string} baseUrl - Base URL của trang quản lý admin
 */
export function openAdminManagementInNewTab(token, baseUrl = 'https://simplecommerce-mdm-as.nammai.id.vn') {
  const url = createAdminManagementUrl(token, baseUrl)
  if (url) {
    window.open(url, '_blank', 'noopener,noreferrer')
    console.log('🔄 Mở tab mới quản lý admin')
  }
}

/**
 * Redirect user đến trang quản lý tương ứng với role
 * @param {string} token - JWT token của user
 * @param {string} role - Role của user (ROLE_SELLER, ROLE_ADMIN)
 * @param {string} baseUrl - Base URL của trang quản lý
 */
export function redirectToManagementByRole(token, role, baseUrl = 'https://simplecommerce-mdm-as.nammai.id.vn') {
  if (!token || !role) {
    console.error('❌ Token hoặc role không được cung cấp')
    return
  }
  
  try {
    let path = '/'
    
    if (role === 'ROLE_SELLER') {
      path = '/seller/dashboard'
    } else if (role === 'ROLE_ADMIN') {
      path = '/admin/dashboard'
    } else {
      console.warn('⚠️ Role không được hỗ trợ:', role)
      return
    }
    
    const url = new URL(path, baseUrl)
    url.searchParams.set('token', token)
    
    console.log(`🔄 Redirect user với role ${role} đến:`, url.toString())
    window.open(url.toString(), '_blank', 'noopener,noreferrer')
    
  } catch (error) {
    console.error('❌ Lỗi khi redirect:', error)
  }
}

/**
 * Tạo button HTML để mở trang quản lý
 * @param {string} token - JWT token của user
 * @param {string} role - Role của user
 * @param {string} buttonText - Text hiển thị trên button
 * @param {string} baseUrl - Base URL của trang quản lý
 * @returns {string} HTML string của button
 */
export function createManagementButton(token, role, buttonText = 'Quản lý', baseUrl = 'https://simplecommerce-mdm-as.nammai.id.vn') {
  if (!token || !role) {
    return ''
  }
  
  const url = role === 'ROLE_SELLER' 
    ? createShopManagementUrl(token, baseUrl)
    : createAdminManagementUrl(token, baseUrl)
  
  if (!url) return ''
  
  return `
    <button 
      class="btn btn-primary" 
      onclick="window.open('${url}', '_blank', 'noopener,noreferrer')"
      title="Mở trang quản lý trong tab mới"
    >
      <i class="bi bi-gear"></i> ${buttonText}
    </button>
  `
}

/**
 * Tạo link HTML để mở trang quản lý
 * @param {string} token - JWT token của user
 * @param {string} role - Role của user
 * @param {string} linkText - Text hiển thị trên link
 * @param {string} baseUrl - Base URL của trang quản lý
 * @returns {string} HTML string của link
 */
export function createManagementLink(token, role, linkText = 'Quản lý', baseUrl = 'https://simplecommerce-mdm-as.nammai.id.vn') {
  if (!token || !role) {
    return ''
  }
  
  const url = role === 'ROLE_SELLER' 
    ? createShopManagementUrl(token, baseUrl)
    : createAdminManagementUrl(token, baseUrl)
  
  if (!url) return ''
  
  return `
    <a 
      href="${url}" 
      target="_blank" 
      rel="noopener noreferrer"
      class="text-decoration-none"
      title="Mở trang quản lý trong tab mới"
    >
      <i class="bi bi-gear"></i> ${linkText}
    </a>
  `
}

export default {
  createShopManagementUrl,
  createAdminManagementUrl,
  openShopManagementInNewTab,
  openAdminManagementInNewTab,
  redirectToManagementByRole,
  createManagementButton,
  createManagementLink
}

import {createRouter, createWebHistory} from 'vue-router'
import {useAuthStore} from '@/stores/auth'

// Import components
import Login from '@/views/Login.vue'
import AdminLogin from '@/views/auth/admin/AdminLogin.vue'
import AdminRegister from '@/views/auth/admin/AdminRegister.vue'
import AdminForgotPassword from '@/views/auth/admin/AdminForgotPass.vue'
import SellerLogin from '@/views/auth/seller/SellerLogin.vue'
import SellerRegister from '@/views/auth/seller/SellerRegister.vue'
import SellerForgotPassword from '@/views/auth/seller/SellerForgotPass.vue'

// Import admin views
import AdminDashboard from '@/views/admin/Dashboard.vue'
import AdminProducts from '@/views/admin/Products.vue'
import AdminCategories from '@/views/admin/Categories.vue'
import AdminUsers from '@/views/admin/Users.vue'
import AdminSellers from '@/views/admin/Sellers.vue'
import AdminOrders from '@/views/admin/Orders.vue'
import AdminReports from '@/views/admin/Reports.vue'
import AdminSettings from '@/views/admin/Settings.vue'
import AdminBanners from '@/views/admin/Banners.vue'
import AdminRevenue from '@/views/admin/Revenue.vue'
import AdminProfile from '@/views/admin/Profile.vue'
import AdminAccount from '@/views/admin/Account.vue'
import AdminVouchers from '@/views/admin/MasterOrders.vue'

// Import seller views
import SellerDashboard from '@/views/seller/Dashboard.vue'
import SellerProducts from '@/views/seller/Products.vue'
import SellerOrders from '@/views/seller/Orders.vue'
import SellerRevenue from '@/views/seller/Revenue.vue'
import SellerSupport from '@/views/seller/Support.vue'
import SellerVouchers from '@/views/seller/Vouchers.vue'
import SellerSettings from '@/views/seller/Settings.vue'
import SellerBanners from '@/views/seller/Banners.vue'
import SellerTransactions from '@/views/seller/Transactions.vue'
import SellerProfile from '@/views/seller/Profile.vue'

// Route guards với logic tách biệt Admin và Seller
const requireAuth = (to, from, next) => {
    const authStore = useAuthStore()
    authStore.initializeAuth()

    console.log('🔍 requireAuth check:', {
        isAuthenticated: authStore.isAuthenticated,
        to: to.path,
        from: from.path
    })

    if (!authStore.isAuthenticated) {
        console.log('❌ Not authenticated - redirect to login')
        next('/login')
    } else {
        console.log('✅ Auth check passed')
        next()
    }
}

const requireSellerAuth = (to, from, next) => {
    const authStore = useAuthStore()
    authStore.initializeAuth()

    // console.log('🔍 Seller auth check:', {
    //     isAuthenticated: authStore.isAuthenticated,
    //     userRole: authStore.userRole,
    //     hasSellerRole: authStore.hasRole('SELLER'),
    //     to: to.path,
    //     from: from.path
    // })

    // Kiểm tra authentication
    if (!authStore.isAuthenticated) {
        console.log('❌ Not authenticated - redirect to seller login')
        next('/seller/login')
        return
    }

    // CHỈ SELLER mới có thể truy cập seller routes (KHÔNG cho phép ADMIN)
    if (!authStore.hasRole('SELLER')) {
        console.log('❌ Not a seller - access denied')
        // Clear auth data và redirect về seller login
        authStore.clearAuthData()
        next('/seller/login')
        return
    }

    console.log('✅ Seller auth passed')
    next()
}

const requireAdminAuth = (to, from, next) => {
    const authStore = useAuthStore()
    authStore.initializeAuth()

    // console.log('🔍 Admin auth check:', {
    //     isAuthenticated: authStore.isAuthenticated,
    //     userRole: authStore.userRole,
    //     hasAdminRole: authStore.hasRole('ADMIN'),
    //     to: to.path,
    //     from: from.path
    // })

    // Kiểm tra authentication
    if (!authStore.isAuthenticated) {
        console.log('❌ Not authenticated - redirect to admin login')
        next('/admin/login')
        return
    }

    // CHỈ ADMIN mới có thể truy cập admin routes (KHÔNG cho phép SELLER)
    if (!authStore.hasRole('ADMIN')) {
        console.log('❌ Not an admin - access denied')
        // Clear auth data và redirect về admin login
        authStore.clearAuthData()
        next('/admin/login')
        return
    }

    console.log('✅ Admin auth passed')
    next()
}

// Redirect logic cho authenticated users
const redirectIfAuthenticated = (to, from, next) => {
    const authStore = useAuthStore()
    authStore.initializeAuth()

    // console.log('🔍 Redirect check:', {
    //     isAuthenticated: authStore.isAuthenticated,
    //     userRole: authStore.userRole,
    //     to: to.path,
    //     from: from.path
    // })

    if (authStore.isAuthenticated) {
        const userRole = authStore.userRole
        
        // Redirect về dashboard tương ứng với role
        if (to.path === '/login') {
            if (userRole === 'SELLER') {
                console.log('✅ Seller logged in - redirect to seller dashboard')
                next('/seller/dashboard')
            } else if (userRole === 'ADMIN') {
                console.log('✅ Admin logged in - redirect to admin dashboard')
                next('/admin/dashboard')
            } else {
                console.log('⚠️ Unknown role - stay on login')
                next()
            }
            return
        }
        
        // Ngăn ADMIN truy cập seller login/register/forgot-password
        if ((to.path === '/seller/login' || to.path === '/seller/register' || to.path === '/seller/forgot-password') && userRole === 'ADMIN') {
            console.log('⚠️ Admin trying to access seller auth pages - redirect to admin dashboard')
            next('/admin/dashboard')
            return
        }
        
        // Ngăn SELLER truy cập admin login/register/forgot-password
        if ((to.path === '/admin/login' || to.path === '/admin/register' || to.path === '/admin/forgot-password') && userRole === 'SELLER') {
            console.log('⚠️ Seller trying to access admin auth pages - redirect to seller dashboard')
            next('/seller/dashboard')
            return
        }
        
        // Nếu đã đúng role và truy cập trang auth tương ứng, redirect về dashboard
        if ((to.path === '/admin/login' || to.path === '/admin/register' || to.path === '/admin/forgot-password') && userRole === 'ADMIN') {
            console.log('✅ Admin already logged in - redirect to dashboard')
            next('/admin/dashboard')
            return
        }
        
        if ((to.path === '/seller/login' || to.path === '/seller/register' || to.path === '/seller/forgot-password') && userRole === 'SELLER') {
            console.log('✅ Seller already logged in - redirect to dashboard')
            next('/seller/dashboard')
            return
        }
    }
    
    //console.log('✅ Not authenticated or accessing allowed page')
    next()
}

// Thêm guard mới để ngăn cross-platform access
const preventCrossPlatformAccess = (requiredRole) => {
    return (to, from, next) => {
        const authStore = useAuthStore()
        authStore.initializeAuth()

        console.log(`🔍 Cross-platform check for ${requiredRole}:`, {
            isAuthenticated: authStore.isAuthenticated,
            userRole: authStore.userRole,
            requiredRole: requiredRole,
            to: to.path
        })

        // Nếu chưa đăng nhập, cho phép truy cập trang auth
        if (!authStore.isAuthenticated) {
            next()
            return
        }

        const userRole = authStore.userRole

        // Nếu đã đăng nhập nhưng không đúng role, redirect về dashboard của họ
        if (userRole !== requiredRole) {
            console.log(`❌ Wrong role: ${userRole} trying to access ${requiredRole} area`)
            
            if (userRole === 'ADMIN') {
                next('/admin/dashboard')
            } else if (userRole === 'SELLER') {
                next('/seller/dashboard')
            } else {
                // Clear invalid auth data
                authStore.clearAuthData()
                next('/login')
            }
            return
        }

        // Nếu đúng role nhưng đã đăng nhập, redirect về dashboard
        if (userRole === requiredRole) {
            if (userRole === 'ADMIN') {
                next('/admin/dashboard')
            } else if (userRole === 'SELLER') {
                next('/seller/dashboard')
            }
            return
        }

        next()
    }
}


const routes = [
    {
        path: '/',
        redirect: '/login'
    },
    {
        path: '/login',
        name: 'Login',
        component: Login,
        beforeEnter: redirectIfAuthenticated,
        meta: {
            title: 'Đăng nhập',
            requiresAuth: false
        }
    },

    // Admin routes
    {
        path: '/admin',
        redirect: '/admin/dashboard',
        meta: {
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/login',
        name: 'AdminLogin',
        component: AdminLogin,
        beforeEnter: redirectIfAuthenticated,
        meta: {
            title: 'Đăng nhập Admin',
            requiresAuth: false
        }
    },
    {
        path: '/admin/register',
        name: 'AdminRegister',
        component: AdminRegister,
        beforeEnter: redirectIfAuthenticated,
        meta: {
            title: 'Đăng ký Admin',
            requiresAuth: false
        }
    },
    {
        path: '/admin/forgot-password',
        name: 'AdminForgotPassword',
        component: AdminForgotPassword,
        beforeEnter: redirectIfAuthenticated,
        meta: {
            title: 'Quên mật khẩu Admin',
            requiresAuth: false
        }
    },
    {
        path: '/admin/dashboard',
        name: 'AdminDashboard',
        component: AdminDashboard,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Dashboard Admin',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/products',
        name: 'AdminProducts',
        component: AdminProducts,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Quản lý sản phẩm',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/categories',
        name: 'AdminCategories',
        component: AdminCategories,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Quản lý danh mục',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/users',
        name: 'AdminUsers',
        component: AdminUsers,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Quản lý người dùng',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/sellers',
        name: 'AdminSellers',
        component: AdminSellers,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Quản lý Sellers',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/orders',
        name: 'AdminOrders',
        component: AdminOrders,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Quản lý đơn hàng',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/banners',
        name: 'AdminBanners',
        component: AdminBanners,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Quản lý bài đánh giá',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/reports',
        name: 'AdminReports',
        component: AdminReports,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Báo cáo thống kê',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/settings',
        name: 'AdminSettings',
        component: AdminSettings,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Cấu hình hệ thống',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/revenue',
        name: 'AdminRevenue',
        component: AdminRevenue,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Quản lý rút tiền',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/profile',
        name: 'AdminProfile',
        component: AdminProfile,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Thông tin cá nhân',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/account',
        name: 'AdminAccount',
        component: AdminAccount,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Tài khoản admin',
            requiresAuth: true,
            role: 'admin'
        }
    },
    {
        path: '/admin/vouchers',
        name: 'AdminVouchers',
        component: AdminVouchers,
        beforeEnter: requireAdminAuth,
        meta: {
            title: 'Quản lý đơn hàng tổng',
            requiresAuth: true,
            role: 'admin'
        }
    },

    // Seller routes
    {
        path: '/seller',
        redirect: '/seller/dashboard',
        meta: {
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/login',
        name: 'SellerLogin',
        component: SellerLogin,
        beforeEnter: redirectIfAuthenticated,
        meta: {
            title: 'Đăng nhập Seller',
            requiresAuth: false
        }
    },
    {
        path: '/seller/register',
        name: 'SellerRegister',
        component: SellerRegister,
        beforeEnter: redirectIfAuthenticated,
        meta: {
            title: 'Đăng ký Seller',
            requiresAuth: false
        }
    },
    {
        path: '/seller/profile',
        name: 'SellerProfile',
        component: SellerProfile,
        beforeEnter: redirectIfAuthenticated,
        meta: {
            title: 'Thông tin cá nhân Seller',
            requiresAuth: false
        }
    },
    {
        path: '/seller/forgot-password',
        name: 'SellerForgotPassword',
        component: SellerForgotPassword,
        beforeEnter: redirectIfAuthenticated,
        meta: {
            title: 'Quên mật khẩu Seller',
            requiresAuth: false
        }
    },
    {
        path: '/seller/dashboard',
        name: 'SellerDashboard',
        component: SellerDashboard,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Dashboard',
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/products',
        name: 'SellerProducts',
        component: SellerProducts,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Quản lý sản phẩm',
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/orders',
        name: 'SellerOrders',
        component: SellerOrders,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Quản lý đơn hàng',
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/revenue',
        name: 'SellerRevenue',
        component: SellerRevenue,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Doanh thu',
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/support',
        name: 'SellerSupport',
        component: SellerSupport,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Đánh giá bình luận',
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/vouchers',
        name: 'SellerVouchers',
        component: SellerVouchers,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Quản lý Vouchers',
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/settings',
        name: 'SellerSettings',
        component: SellerSettings,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Cài đặt',
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/banners',
        name: 'SellerBanners',
        component: SellerBanners,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Quản lý Banners',
            requiresAuth: true,
            role: 'seller'
        }
    },
    {
        path: '/seller/transactions',
        name: 'SellerTransactions',
        component: SellerTransactions,
        beforeEnter: requireSellerAuth,
        meta: {
            title: 'Quản lý giao dịch',
            requiresAuth: true,
            role: 'seller'
        }
    },
    
    // Demo route for testing auto login
    {
        path: '/demo/auto-login',
        name: 'AutoLoginDemo',
        component: () => import('@/components/AutoLoginDemo.vue'),
        meta: {
            title: 'Auto Login Demo',
            requiresAuth: false
        }
    },
    
    // 404 catch-all route - phải để cuối cùng
    {
        path: '/:pathMatch(.*)*',
        name: 'NotFound',
        component: () => import('@/views/errors/404.vue'),
        meta: {
            title: '404 - Trang không tồn tại',
            requiresAuth: false
        }
    }
]

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes,
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition
        } else {
            return {top: 0}
        }
    }
})

// Global navigation guards
router.beforeEach((to, from, next) => {
    // Set page title
    if (to.meta.title) {
        if (to.name === 'NotFound') {
            document.title = to.meta.title
        } else {
            document.title = `${to.meta.title} - MUADIMA`
        }
    } else {
        document.title = 'MUADIMA - E-commerce Management System'
    }

    // console.log(`Navigating from ${from.path} to ${to.path}`)
    next()
})

router.afterEach((to, from) => {
    // console.log(`Navigation completed from ${from.path} to ${to.path}`)
})

export default router
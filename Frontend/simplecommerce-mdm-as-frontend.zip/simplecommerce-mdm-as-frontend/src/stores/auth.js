import {defineStore} from 'pinia'
import {ref, computed} from 'vue'
import {authService} from '@/services/auth/authService'

// Utility functions để mã hóa/giải mã localStorage
const encryptData = (data) => {
    try {
        // Simple base64 encoding (có thể thay thế bằng crypto mạnh hơn)
        return btoa(JSON.stringify(data))
    } catch {
        return data
    }
}

const decryptData = (encryptedData) => {
    try {
        return JSON.parse(atob(encryptedData))
    } catch {
        return encryptedData
    }
}

// Secure localStorage wrapper
const secureStorage = {
    setItem(key, value) {
        localStorage.setItem(`app_${key}`, encryptData(value))
    },
    getItem(key) {
        const encrypted = localStorage.getItem(`app_${key}`)
        return encrypted ? decryptData(encrypted) : null
    },
    removeItem(key) {
        localStorage.removeItem(`app_${key}`)
    },
    clear() {
        // Chỉ xóa các keys của app
        Object.keys(localStorage)
            .filter(key => key.startsWith('app_'))
            .forEach(key => localStorage.removeItem(key))
    }
}

export const useAuthStore = defineStore('auth', () => {
    // State - không lưu tokens trực tiếp, chỉ lưu session info
    const isAuthenticated = ref(false)
    const userInfo = ref(null)
    const isLoading = ref(false)
    const error = ref('')

    // Private methods để xử lý tokens
    const getStoredToken = () => {
        return secureStorage.getItem('access_token')
    }

    const getStoredRefreshToken = () => {
        return secureStorage.getItem('refresh_token')
    }

    const setStoredTokens = (accessToken, refreshToken) => {
        secureStorage.setItem('access_token', accessToken)
        secureStorage.setItem('refresh_token', refreshToken)
    }

    const clearStoredTokens = () => {
        secureStorage.removeItem('access_token')
        secureStorage.removeItem('refresh_token')
        secureStorage.removeItem('user_session')
    }

    // Computed properties
    const currentUser = computed(() => {
        return userInfo.value
    })

    const isTokenExpired = computed(() => {
        const token = getStoredToken()
        if (!token) return true

        try {
            const payload = JSON.parse(atob(token.split('.')[1]))
            const currentTime = Date.now() / 1000
            return payload.exp <= (currentTime + 60) // Thêm buffer 60 giây
        } catch (error) {
            console.error('Error parsing token:', error)
            return true
        }
    })

    // Helper function để parse roles từ token payload
    const parseRolesFromPayload = (payload) => {
        //console.log('Raw payload:', payload)

        // Kiểm tra các field có thể chứa roles
        let roles = []

        if (payload.roles) {
            roles = Array.isArray(payload.roles) ? payload.roles : [payload.roles]
        } else if (payload.authorities) {
            roles = Array.isArray(payload.authorities) ? payload.authorities : [payload.authorities]
        } else if (payload.role) {
            roles = Array.isArray(payload.role) ? payload.role : [payload.role]
        } else if (payload.scopes) {
            roles = Array.isArray(payload.scopes) ? payload.scopes : [payload.scopes]
        }

       // console.log('Parsed roles from token:', roles)
        return roles
    }

    // Helper function để kiểm tra role từ danh sách roles
    const checkRoleInList = (targetRole, rolesList) => {
        if (!rolesList || rolesList.length === 0) return false

     //   console.log(`Checking for role ${targetRole} in:`, rolesList)

        return rolesList.some(role => {
            // Xử lý trường hợp role là object có authority property
            if (typeof role === 'object' && role.authority) {
                const authority = role.authority
                return authority === targetRole ||
                    authority === `ROLE_${targetRole}` ||
                    authority.endsWith(`_${targetRole}`)
            }

            // Xử lý trường hợp role là string
            if (typeof role === 'string') {
                return role === targetRole ||
                    role === `ROLE_${targetRole}` ||
                    role.endsWith(`_${targetRole}`) ||
                    role.toUpperCase() === targetRole.toUpperCase()
            }

            return false
        })
    }

    // Getters
    const hasRole = (role) => {
        console.log(`=== Checking hasRole('${role}') ===`)

        if (!userInfo.value) {
            console.log('No userInfo available')
            return false
        }

     //   console.log('Current userInfo:', userInfo.value)
     //   console.log('User roles:', userInfo.value.roles)

        const result = checkRoleInList(role, userInfo.value.roles)
     //   console.log(`hasRole('${role}') result:`, result)

        return result
    }

    const getUserDisplayName = () => {
        if (!userInfo.value) return 'Người dùng'

        return userInfo.value.fullName ||
            userInfo.value.displayName ||
            userInfo.value.email?.split('@')[0] ||
            'Người dùng'
    }

    const getUserAvatar = () => {
        return userInfo.value?.avatar || '/default-avatar.png'
    }

    const getUserRole = () => {
        if (!userInfo.value || !userInfo.value.roles) return null

        const roles = userInfo.value.roles
        //console.log('Getting user role from:', roles)

        if (checkRoleInList('ADMIN', roles)) {
            return 'ADMIN'
        }
        if (checkRoleInList('SELLER', roles)) {
            return 'SELLER'
        }
        if (checkRoleInList('USER', roles)) {
            return 'USER'
        }

        return null
    }

    // Actions
    const parseTokenToUserInfo = (token) => {
        try {
            const payload = JSON.parse(atob(token.split('.')[1]))
            console.log('=== Parsing JWT Token ===')
          //  console.log('Full JWT payload:', payload)

            const roles = parseRolesFromPayload(payload)

            const userInfo = {
                id: payload.userId || payload.user_id || payload.sub,
                email: payload.sub || payload.email,
                fullName: payload.fullName || payload.full_name || payload.name,
                displayName: payload.displayName || payload.display_name,
                avatar: payload.avatar || payload.picture,
                roles: roles,
                exp: payload.exp,
                iat: payload.iat
            }

            //console.log('Parsed user info:', userInfo)
            return userInfo
        } catch (error) {
            console.error('Error parsing token:', error)
            return null
        }
    }

    const setAuthData = (response) => {
        //console.log('=== Setting Auth Data ===')
        //console.log('Response:', response)

        const tokenData = response.data || response
        const accessToken = tokenData.accessToken
        const refreshToken = tokenData.refreshToken

        if (!accessToken) {
            throw new Error('Missing access token in response')
        }

        // Parse user info từ token
        const parsedUserInfo = parseTokenToUserInfo(accessToken)
        if (!parsedUserInfo) {
            throw new Error('Invalid token format')
        }

        // Lưu tokens an toàn
        setStoredTokens(accessToken, refreshToken)

        // Lưu session info (không nhạy cảm)
        const sessionInfo = {
            email: parsedUserInfo.email,
            fullName: parsedUserInfo.fullName,
            displayName: parsedUserInfo.displayName,
            role: getUserRoleFromInfo(parsedUserInfo),
            loginTime: new Date().toISOString(),
            lastActivity: new Date().toISOString()
        }
        secureStorage.setItem('user_session', sessionInfo)

        // Update state
        userInfo.value = parsedUserInfo
        isAuthenticated.value = true
        error.value = ''

        // console.log('Auth data set successfully:', {
        //     hasAccessToken: !!accessToken,
        //     userRole: getUserRoleFromInfo(parsedUserInfo),
        //     userEmail: parsedUserInfo.email,
        //     userRoles: parsedUserInfo.roles
        // })
    }

    const getUserRoleFromInfo = (info) => {
        if (!info || !info.roles) return null

        const roles = info.roles
       // console.log('Getting role from info roles:', roles)

        if (checkRoleInList('ADMIN', roles)) {
            return 'ADMIN'
        }
        if (checkRoleInList('SELLER', roles)) {
            return 'SELLER'
        }
        if (checkRoleInList('USER', roles)) {
            return 'USER'
        }

        return null
    }

    const clearAuthData = () => {
        isAuthenticated.value = false
        userInfo.value = null
        error.value = ''
        clearStoredTokens()
    }

    const updateLastActivity = () => {
        const session = secureStorage.getItem('user_session')
        if (session) {
            session.lastActivity = new Date().toISOString()
            secureStorage.setItem('user_session', session)
        }
    }

    const loginSeller = async (credentials) => {
        isLoading.value = true
        error.value = ''

        try {
            const response = await authService.loginSeller(credentials)
            console.log('Seller login response received:', response)

            if (!response.data || !response.data.accessToken) {
                throw new Error('Invalid login response')
            }

            setAuthData(response)

            // Validate role - đợi nextTick để đảm bảo state đã được update
            await new Promise(resolve => setTimeout(resolve, 100))

            console.log('Checking seller role access...')
            if (!hasRole('SELLER') && !hasRole('ADMIN')) {
                console.log('Role check failed - clearing auth data')
                clearAuthData()
                throw new Error('Tài khoản không có quyền truy cập Seller Portal')
            }

            console.log('Seller login successful')
            return {success: true, data: response}
        } catch (err) {
            console.error('Seller login error:', err)
            error.value = handleLoginError(err)
            return {success: false, error: error.value}
        } finally {
            isLoading.value = false
        }
    }

    const loginAdmin = async (credentials) => {
        isLoading.value = true
        error.value = ''

        try {
            const response = await authService.loginAdmin(credentials)
            console.log('Admin login response received:', response)

            if (!response.data || !response.data.accessToken) {
                throw new Error('Invalid login response')
            }

            setAuthData(response)

            // Validate role - đợi nextTick để đảm bảo state đã được update
            await new Promise(resolve => setTimeout(resolve, 100))

            console.log('Checking admin role access...')
            console.log('Current userInfo after setAuthData:', userInfo.value)

            if (!hasRole('ADMIN')) {
                console.log('Admin role check failed - clearing auth data')
                // Log thêm thông tin debug
                console.log('Available roles:', userInfo.value?.roles)
                console.log('Role check result:', checkRoleInList('ADMIN', userInfo.value?.roles))

                clearAuthData()
                throw new Error('Tài khoản không có quyền truy cập Admin Portal')
            }

            console.log('Admin login successful')
            return {success: true, data: response}
        } catch (err) {
            console.error('Admin login error:', err)
            error.value = handleLoginError(err)
            return {success: false, error: error.value}
        } finally {
            isLoading.value = false
        }
    }

    const handleLoginError = (err) => {
        let errorMessage = 'Có lỗi xảy ra khi đăng nhập!'

        if (err.response) {
            switch (err.response.status) {
                case 401:
                    errorMessage = 'Email hoặc mật khẩu không chính xác!'
                    break
                case 403:
                    errorMessage = 'Tài khoản không có quyền truy cập!'
                    break
                case 404:
                    errorMessage = 'Tài khoản không tồn tại!'
                    break
                case 500:
                    errorMessage = 'Lỗi máy chủ, vui lòng thử lại sau!'
                    break
                default:
                    errorMessage = err.response.data?.message || errorMessage
            }
        } else if (err.request) {
            errorMessage = 'Không thể kết nối đến máy chủ!'
        } else if (err.message) {
            errorMessage = err.message
        }

        return errorMessage
    }

    const logout = async () => {
        isLoading.value = true

        try {
            const token = getStoredToken()
            if (token) {
                await authService.logout()
            }
        } catch (err) {
            console.error('Logout error:', err)
        } finally {
            clearAuthData()
            isLoading.value = false
        }
    }

    const refreshTokenAction = async () => {
        const refreshToken = getStoredRefreshToken()
        if (!refreshToken) {
            clearAuthData()
            return false
        }

        try {
            const tokenResponse = await authService.refreshToken(refreshToken)
            setAuthData(tokenResponse)
            return true
        } catch (err) {
            console.error('Refresh token error:', err)
            clearAuthData()
            return false
        }
    }

    // Get token for API calls
    const getAccessToken = () => {
        return getStoredToken()
    }

    // Debug function để kiểm tra token
    const debugToken = () => {
        const token = getStoredToken()
        if (token) {
            try {
                const payload = JSON.parse(atob(token.split('.')[1]))
                console.log('=== Debug Token ===')
                console.log('JWT Payload:', payload)
                console.log('Roles field:', payload.roles)
                console.log('Authorities field:', payload.authorities)
                console.log('Role field:', payload.role)
                console.log('Scopes field:', payload.scopes)
                console.log('==================')
            } catch (e) {
                console.error('Error parsing token for debug:', e)
            }
        } else {
            console.log('No token found for debug')
        }
    }

    // Initialize store từ localStorage
    const initializeAuth = () => {
        const token = getStoredToken()
        const session = secureStorage.getItem('user_session')

        if (token && session) {
            // Kiểm tra token expired
            if (!isTokenExpired.value) {
                const parsedUserInfo = parseTokenToUserInfo(token)
                if (parsedUserInfo) {
                    userInfo.value = parsedUserInfo
                    isAuthenticated.value = true
                    updateLastActivity()

                    // console.log('Auth initialized:', {
                    //     email: parsedUserInfo.email,
                    //     role: getUserRoleFromInfo(parsedUserInfo),
                    //     roles: parsedUserInfo.roles
                    // })
                    return
                }
            }
        }

        // Token invalid hoặc expired
        clearAuthData()
    }

    return {
        // State
        isAuthenticated,
        isLoading,
        error,

        // Getters
        currentUser,
        isTokenExpired,
        hasRole,
        getUserDisplayName,
        getUserAvatar,
        getUserRole,
        getAccessToken,

        // Actions
        setAuthData,
        clearAuthData,
        loginSeller,
        loginAdmin,
        logout,
        refreshTokenAction,
        initializeAuth,
        updateLastActivity,
        debugToken // Thêm debug function
    }
})
import { defineStore } from "pinia";
import { adminUserService } from "@/services/admin/user";

export const useUserStore = defineStore("user", {
  state: () => ({
    users: [],
    userStats: {
      totalUsers: 0,
      activeUsers: 0,
      blockedUsers: 0,
    },
    pagination: {
      number: 0,
      size: 5,
      totalElements: 0,
      totalPages: 0,
      first: true,
      last: true,
      numberOfElements: 0,
    },
    lastFetchTime: null,
    cacheDuration: 5 * 60 * 1000, // 5 phút cache
    currentFilters: {},
  }),

  actions: {
    async fetchUsers(params = {}) {
      // Kiểm tra cache và xem có cần fetch không
      const now = Date.now();
      const sameFilters =
        JSON.stringify(params) === JSON.stringify(this.currentFilters);

      if (
        sameFilters &&
        this.lastFetchTime &&
        now - this.lastFetchTime < this.cacheDuration
      ) {
        return;
      }

      try {
        this.currentFilters = { ...params };
        const response = await adminUserService.getAllUsers(params);

        if (response?.data) {
          this.users = response.data.content || [];
          this.pagination = {
            number: response.data.number || 0,
            size: response.data.size || params.size || 5,
            totalElements: response.data.totalElements || 0,
            totalPages: response.data.totalPages || 0,
            first: response.data.first ?? true,
            last: response.data.last ?? true,
            numberOfElements: response.data.numberOfElements || 0,
          };
          this.lastFetchTime = now;
        }
      } catch (error) {
        console.error("Error fetching users:", error);
        throw error;
      }
    },

    async fetchUserStats() {
      try {
        const response = await adminUserService.getUserStatistics();
        if (response?.data) {
          // Đảm bảo giá trị không âm
          this.userStats = {
            totalUsers: Math.max(0, response.data.totalUsers || 0),
            activeUsers: Math.max(0, response.data.activeUsers || 0),
            // user bị khóa bằng tổng - active
            // blockedUsers = totalUsers - activeUsers
            blockedUsers: Math.max(
              0,
              (response.data.totalUsers || 0) - (response.data.activeUsers || 0)
            ),
          };
          // Đảm bảo tổng bằng active + blocked
          if (
            this.userStats.totalUsers !==
            this.userStats.activeUsers + this.userStats.blockedUsers
          ) {
            console.warn("Số liệu thống kê không khớp, điều chỉnh lại");
            this.userStats.totalUsers =
              this.userStats.activeUsers + this.userStats.blockedUsers;
          }
        }
      } catch (error) {
        console.error("Error fetching user stats:", error);
        throw error;
      }
    },

    async updateUserStatus(userId, isActive) {
      try {
        // Optimistic update
        const user = this.users.find((u) => u.id === userId);
        if (user) {
          const oldStatus = user.isActive;
          user.isActive = isActive;

          // Tính toán chính xác số lượng tài khoản bị khóa
          if (isActive && !oldStatus) {
            // Mở khóa: giảm blocked, tăng active
            this.userStats.blockedUsers = Math.max(
              0,
              this.userStats.blockedUsers - 1
            );
            this.userStats.activeUsers++;
          } else if (!isActive && oldStatus) {
            // Khóa: tăng blocked, giảm active
            this.userStats.blockedUsers++;
            this.userStats.activeUsers = Math.max(
              0,
              this.userStats.activeUsers - 1
            );
          }

          const response = await adminUserService.updateUserActiveStatus(
            userId,
            isActive
          );
          return response;
        }
      } catch (error) {
        // Rollback if error
        const user = this.users.find((u) => u.id === userId);
        if (user) {
          user.isActive = !isActive;
          // Rollback stats
          if (isActive) {
            // Nếu đang thử mở khóa nhưng thất bại
            this.userStats.blockedUsers++;
            this.userStats.activeUsers = Math.max(
              0,
              this.userStats.activeUsers - 1
            );
          } else {
            // Nếu đang thử khóa nhưng thất bại
            this.userStats.blockedUsers = Math.max(
              0,
              this.userStats.blockedUsers - 1
            );
            this.userStats.activeUsers++;
          }
        }
        throw error;
      }
    },

    async updateUserRoles(userId, roleNames) {
      try {
        const response = await adminUserService.updateUserRoles(
          userId,
          roleNames
        );
        const user = this.users.find((u) => u.id === userId);
        if (user) {
          user.roles = response.data.roles;
        }
        return response;
      } catch (error) {
        throw error;
      }
    },

    async deleteUser(userId) {
      try {
        await adminUserService.deleteUser(userId);
        this.users = this.users.filter((user) => user.id !== userId);
        this.userStats.totalUsers--;
      } catch (error) {
        throw error;
      }
    },

    async restoreUser(userId) {
      try {
        const response = await adminUserService.restoreUser(userId);
        this.userStats.totalUsers++;
        return response;
      } catch (error) {
        throw error;
      }
    },

    invalidateCache() {
      this.lastFetchTime = null;
    },
  },

  getters: {
    getPageNumbers: (state) => {
      const pages = [];
      const totalPages = state.pagination.totalPages;
      const current = state.pagination.number;

      let start = Math.max(0, current - 2);
      let end = Math.min(totalPages - 1, start + 4);

      if (end - start < 4) {
        start = Math.max(0, end - 4);
      }

      for (let i = start; i <= end; i++) {
        pages.push(i);
      }

      return pages;
    },
  },
});

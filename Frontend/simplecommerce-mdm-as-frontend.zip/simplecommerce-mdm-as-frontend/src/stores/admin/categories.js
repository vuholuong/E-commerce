import { defineStore } from 'pinia'
import { categoriesApi } from '@/services/admin/categories.js'

export const useCategoriesStore = defineStore('categories', {
    state: () => ({
        // Data
        categories: [],
        categoriesMap: new Map(),

        // Loading states
        loading: false,
        refreshing: false,

        // Cache management
        lastFetch: null,
        cacheExpiry: 5 * 60 * 1000, // 5 minutes

        // Pagination
        currentPage: 1,
        pageSize: 10,
        totalItems: 0,

        // Filtering & Search
        searchTerm: '',
        parentFilter: '', // 'root', 'child', ''
        sortBy: 'name',
        sortOrder: 'asc',

        // Tree structure cache
        categoryTree: [],
        parentCategories: [],

        // Error handling
        error: null,
        lastError: null
    }),

    getters: {
        // Basic getters
        allCategories: (state) => state.categories,

        categoriesCount: (state) => state.categories.length,

        isDataStale: (state) => {
            if (!state.lastFetch) return true
            return Date.now() - state.lastFetch > state.cacheExpiry
        },

        // Filtered categories
        filteredCategories: (state) => {
            let filtered = [...state.categories]

            // Apply search filter
            if (state.searchTerm) {
                const term = state.searchTerm.toLowerCase()
                filtered = filtered.filter(cat =>
                    cat.name.toLowerCase().includes(term) ||
                    cat.slug.toLowerCase().includes(term) ||
                    (cat.description && cat.description.toLowerCase().includes(term))
                )
            }

            // Apply parent filter
            if (state.parentFilter === 'root') {
                filtered = filtered.filter(cat => !cat.parentId)
            } else if (state.parentFilter === 'child') {
                filtered = filtered.filter(cat => cat.parentId)
            }

            // Apply sorting
            filtered.sort((a, b) => {
                let aValue = a[state.sortBy]
                let bValue = b[state.sortBy]

                // Handle special sorting for parent categories
                if (state.sortBy === 'name') {
                    // Parent categories first, then alphabetical
                    if (!a.parentId && b.parentId) return -1
                    if (a.parentId && !b.parentId) return 1

                    aValue = aValue?.toLowerCase() || ''
                    bValue = bValue?.toLowerCase() || ''
                }

                if (state.sortOrder === 'asc') {
                    return aValue > bValue ? 1 : -1
                } else {
                    return aValue < bValue ? 1 : -1
                }
            })

            return filtered
        },

        // Paginated categories
        paginatedCategories: (state) => {
            const filtered = state.filteredCategories
            const start = (state.currentPage - 1) * state.pageSize
            const end = start + state.pageSize

            state.totalItems = filtered.length

            return filtered.slice(start, end)
        },

        // Pagination info
        totalPages: (state) => Math.ceil(state.totalItems / state.pageSize),

        hasNextPage: (state) => state.currentPage < Math.ceil(state.totalItems / state.pageSize),

        hasPreviousPage: (state) => state.currentPage > 1,

        // Pagination controls
        visiblePages: (state) => {
            const totalPages = Math.ceil(state.totalItems / state.pageSize)
            const pages = []
            const start = Math.max(1, state.currentPage - 2)
            const end = Math.min(totalPages, start + 4)

            for (let i = start; i <= end; i++) {
                pages.push(i)
            }
            return pages
        },

        // Category utilities
        getCategoryById: (state) => (id) => {
            return state.categoriesMap.get(id) || state.categories.find(cat => cat.id === id)
        },

        getParentCategories: (state) => {
            return state.categories.filter(cat => !cat.parentId)
        },

        getChildCategories: (state) => (parentId) => {
            return state.categories.filter(cat => cat.parentId === parentId)
        },

        getCategoryChildren: (state) => (categoryId) => {
            return state.categories.filter(cat => cat.parentId === categoryId)
        },

        hasChildren: (state) => (categoryId) => {
            return state.categories.some(cat => cat.parentId === categoryId)
        },

        getChildrenCount: (state) => (categoryId) => {
            return state.categories.filter(cat => cat.parentId === categoryId).length
        },

        getParentName: (state) => (parentId) => {
            if (!parentId) return null
            const parent = state.getCategoryById(parentId)
            return parent ? parent.name : null
        },

        // Available parents for form (excluding current category when editing)
        getAvailableParents: (state) => (excludeId = null) => {
            return state.categories.filter(cat =>
                !cat.parentId && (!excludeId || cat.id !== excludeId)
            )
        },

        // Category tree structure
        getCategoryTree: (state) => {
            if (state.categoryTree.length > 0) {
                return state.categoryTree
            }

            const categoryMap = new Map()
            const rootCategories = []

            // Create map for quick lookup
            state.categories.forEach(category => {
                categoryMap.set(category.id, { ...category, children: [] })
            })

            // Build tree structure
            state.categories.forEach(category => {
                const categoryNode = categoryMap.get(category.id)

                if (category.parentId) {
                    const parent = categoryMap.get(category.parentId)
                    if (parent) {
                        parent.children.push(categoryNode)
                    }
                } else {
                    rootCategories.push(categoryNode)
                }
            })

            state.categoryTree = rootCategories
            return rootCategories
        },

        // Category path (breadcrumb)
        getCategoryPath: (state) => (categoryId) => {
            const path = []
            let currentCategory = state.getCategoryById(categoryId)

            while (currentCategory) {
                path.unshift(currentCategory)
                currentCategory = currentCategory.parentId
                    ? state.getCategoryById(currentCategory.parentId)
                    : null
            }

            return path
        }
    },

    actions: {
        // Load categories with cache management
        async loadCategories(force = false) {
            // Check if we need to fetch data
            if (!force && !this.isDataStale && this.categories.length > 0) {
                console.log('Categories cache is fresh, skipping API call')
                return { success: true, fromCache: true }
            }

            this.loading = true
            this.error = null

            try {
                console.log('Fetching categories from API...')
                const result = await categoriesApi.getAll()

                if (result.success) {
                    this.setCategories(result.data)
                    this.lastFetch = Date.now()
                    console.log(`Loaded ${result.data.length} categories`)

                    return { success: true, data: result.data, fromCache: false }
                } else {
                    this.error = result.message
                    this.lastError = {
                        message: result.message,
                        timestamp: Date.now()
                    }
                    return { success: false, error: result.message }
                }
            } catch (error) {
                console.error('Error loading categories:', error)
                this.error = 'Lỗi kết nối khi tải danh mục'
                this.lastError = {
                    message: error.message,
                    timestamp: Date.now()
                }
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        },

        // Refresh categories (force reload)
        async refreshCategories() {
            this.refreshing = true
            const result = await this.loadCategories(true)
            this.refreshing = false
            return result
        },

        // Set categories and update cache
        setCategories(categories) {
            this.categories = categories || []

            // Update categories map for quick lookup
            this.categoriesMap.clear()
            this.categories.forEach(cat => {
                this.categoriesMap.set(cat.id, cat)
            })

            // Clear tree cache to rebuild
            this.categoryTree = []

            // Update parent categories cache
            this.parentCategories = this.categories.filter(cat => !cat.parentId)

            // Reset pagination if filter changed
            this.currentPage = 1
        },

        // Add new category
        async createCategory(categoryData) {
            this.loading = true
            this.error = null

            try {
                const result = await categoriesApi.create(categoryData)

                if (result.success) {
                    // Add to local cache
                    this.categories.push(result.data)
                    this.setCategories(this.categories)

                    return { success: true, data: result.data, message: result.message }
                } else {
                    this.error = result.message
                    return { success: false, error: result.message }
                }
            } catch (error) {
                console.error('Error creating category:', error)
                this.error = 'Lỗi khi tạo danh mục'
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        },

        // Update category
        async updateCategory(id, categoryData) {
            this.loading = true
            this.error = null

            try {
                const result = await categoriesApi.update(id, categoryData)

                if (result.success) {
                    // Update local cache
                    const index = this.categories.findIndex(cat => cat.id === id)
                    if (index !== -1) {
                        this.categories[index] = { ...this.categories[index], ...result.data }
                        this.setCategories(this.categories)
                    }

                    return { success: true, data: result.data, message: result.message }
                } else {
                    this.error = result.message
                    return { success: false, error: result.message }
                }
            } catch (error) {
                console.error('Error updating category:', error)
                this.error = 'Lỗi khi cập nhật danh mục'
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        },

        // Delete category
        async deleteCategory(id) {
            this.loading = true
            this.error = null

            try {
                const result = await categoriesApi.delete(id)

                if (result.success) {
                    // Remove from local cache
                    this.categories = this.categories.filter(cat => cat.id !== id)
                    this.setCategories(this.categories)

                    return { success: true, message: result.message }
                } else {
                    this.error = result.message
                    return { success: false, error: result.message }
                }
            } catch (error) {
                console.error('Error deleting category:', error)
                this.error = 'Lỗi khi xóa danh mục'
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        },

        // Get category by ID (with API fallback)
        async getCategoryDetails(id) {
            // Try cache first
            let category = this.getCategoryById(id)

            if (category) {
                return { success: true, data: category, fromCache: true }
            }

            // Fallback to API
            this.loading = true
            try {
                const result = await categoriesApi.getById(id)

                if (result.success && result.data) {
                    // Add to cache if not exists
                    if (!this.categories.find(cat => cat.id === id)) {
                        this.categories.push(result.data)
                        this.setCategories(this.categories)
                    }

                    return { success: true, data: result.data, fromCache: false }
                } else {
                    return { success: false, error: result.message }
                }
            } catch (error) {
                console.error('Error fetching category details:', error)
                return { success: false, error: 'Lỗi khi tải chi tiết danh mục' }
            } finally {
                this.loading = false
            }
        },

        // Pagination actions
        setPage(page) {
            if (page >= 1 && page <= this.totalPages) {
                this.currentPage = page
            }
        },

        nextPage() {
            if (this.hasNextPage) {
                this.currentPage++
            }
        },

        previousPage() {
            if (this.hasPreviousPage) {
                this.currentPage--
            }
        },

        setPageSize(size) {
            this.pageSize = size
            this.currentPage = 1 // Reset to first page
        },

        // Filter actions
        setSearchTerm(term) {
            this.searchTerm = term
            this.currentPage = 1 // Reset to first page when searching
        },

        setParentFilter(filter) {
            this.parentFilter = filter
            this.currentPage = 1 // Reset to first page when filtering
        },

        setSorting(sortBy, sortOrder = 'asc') {
            this.sortBy = sortBy
            this.sortOrder = sortOrder
            this.currentPage = 1 // Reset to first page when sorting
        },

        // Clear filters and reset pagination
        clearFilters() {
            this.searchTerm = ''
            this.parentFilter = ''
            this.currentPage = 1
        },

        // Cache management
        clearCache() {
            this.categories = []
            this.categoriesMap.clear()
            this.categoryTree = []
            this.parentCategories = []
            this.lastFetch = null
        },

        // Error handling
        clearError() {
            this.error = null
        },

        // Reset store state
        $reset() {
            this.categories = []
            this.categoriesMap.clear()
            this.categoryTree = []
            this.parentCategories = []
            this.loading = false
            this.refreshing = false
            this.lastFetch = null
            this.currentPage = 1
            this.pageSize = 10
            this.totalItems = 0
            this.searchTerm = ''
            this.parentFilter = ''
            this.sortBy = 'name'
            this.sortOrder = 'asc'
            this.error = null
            this.lastError = null
        }
    }
})
// composables/useStats.js
import { ref, reactive } from 'vue'
import statsService from '@/services/seller/statis'
import Swal from 'sweetalert2'

export function useStats() {
  // Reactive data
  const overviewData = ref({})
  const salesData = ref([])
  const paymentBreakdown = ref([])
  const topProducts = ref([])
  const lowStockItems = ref([])
  const avgOrderValue = ref(0)
  const returnsCount = ref(0)

  // Loading states
  const loading = reactive({
    overview: false,
    sales: false,
    payment: false,
    topProducts: false,
    lowStock: false,
    aov: false,
    returns: false
  })

  // Error handling
  const showError = (message, title = 'Lỗi!') => {
    Swal.fire({
      title,
      text: message,
      icon: 'error',
      timer: 3000,
      showConfirmButton: false
    })
  }

  // API methods
  const fetchOverview = async () => {
    try {
      loading.overview = true
      const response = await statsService.getOverview()
      console.log('useStats Overview response:', response) // DEBUG
      
      if (response && response.statusCode === 0) {
        overviewData.value = response.data
        return response.data
      } else {
        console.warn('Unexpected response structure in useStats:', response)
        throw new Error(response?.message || 'Failed to fetch overview')
      }
    } catch (error) {
      console.error('Error fetching overview:', error)
      showError('Không thể tải dữ liệu tổng quan')
      throw error
    } finally {
      loading.overview = false
    }
  }

  const fetchSalesSeries = async (range = '30d') => {
    try {
      loading.sales = true
      const response = await statsService.getSalesSeries(range)
      if (response.statusCode === 0) {
        salesData.value = response.data
        return response.data
      } else {
        throw new Error(response.message || 'Failed to fetch sales series')
      }
    } catch (error) {
      console.error('Error fetching sales series:', error)
      showError('Không thể tải dữ liệu doanh thu')
      throw error
    } finally {
      loading.sales = false
    }
  }

  const fetchPaymentBreakdown = async (range = '30d') => {
    try {
      loading.payment = true
      const response = await statsService.getPaymentBreakdown(range)
      if (response.statusCode === 0) {
        paymentBreakdown.value = response.data
        return response.data
      } else {
        throw new Error(response.message || 'Failed to fetch payment breakdown')
      }
    } catch (error) {
      console.error('Error fetching payment breakdown:', error)
      showError('Không thể tải dữ liệu thanh toán')
      throw error
    } finally {
      loading.payment = false
    }
  }

  const fetchTopProducts = async (sortBy = 'quantity', limit = 10) => {
    try {
      loading.topProducts = true
      const response = await statsService.getTopProducts(sortBy, limit)
      if (response.statusCode === 0) {
        topProducts.value = response.data
        return response.data
      } else {
        throw new Error(response.message || 'Failed to fetch top products')
      }
    } catch (error) {
      console.error('Error fetching top products:', error)
      showError('Không thể tải dữ liệu sản phẩm bán chạy')
      throw error
    } finally {
      loading.topProducts = false
    }
  }

  const fetchLowStock = async (threshold = 10) => {
    try {
      loading.lowStock = true
      const response = await statsService.getLowStock(threshold)
      if (response.statusCode === 0) {
        lowStockItems.value = response.data
        return response.data
      } else {
        throw new Error(response.message || 'Failed to fetch low stock items')
      }
    } catch (error) {
      console.error('Error fetching low stock items:', error)
      showError('Không thể tải dữ liệu hàng tồn kho')
      throw error
    } finally {
      loading.lowStock = false
    }
  }

  const fetchAvgOrderValue = async (range = '30d') => {
    try {
      loading.aov = true
      const response = await statsService.getAvgOrderValue(range)
      if (response.statusCode === 0) {
        avgOrderValue.value = response.data
        return response.data
      } else {
        throw new Error(response.message || 'Failed to fetch AOV')
      }
    } catch (error) {
      console.error('Error fetching AOV:', error)
      showError('Không thể tải dữ liệu giá trị đơn hàng trung bình')
      throw error
    } finally {
      loading.aov = false
    }
  }

  const fetchReturns = async (range = '30d') => {
    try {
      loading.returns = true
      const response = await statsService.getReturns(range)
      if (response.statusCode === 0) {
        returnsCount.value = response.data
        return response.data
      } else {
        throw new Error(response.message || 'Failed to fetch returns')
      }
    } catch (error) {
      console.error('Error fetching returns:', error)
      showError('Không thể tải dữ liệu trả hàng')
      throw error
    } finally {
      loading.returns = false
    }
  }

  // Utility methods
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount || 0)
  }

  const formatNumber = (number) => {
    return new Intl.NumberFormat('vi-VN').format(number || 0)
  }

  const getStockBadgeClass = (quantity) => {
    if (quantity <= 0) return 'bg-danger'
    if (quantity <= 5) return 'bg-warning'
    if (quantity <= 10) return 'bg-info'
    return 'bg-success'
  }

  const getGrowthPercentage = (current, previous) => {
    if (!previous || previous === 0) return 0
    return Math.round(((current - previous) / previous) * 100)
  }

  const getGrowthClass = (percentage) => {
    if (percentage > 0) return 'text-success'
    if (percentage < 0) return 'text-danger'
    return 'text-muted'
  }

  const getGrowthIcon = (percentage) => {
    if (percentage > 0) return '↗️'
    if (percentage < 0) return '↘️'
    return '→'
  }

  // Batch operations
  const fetchDashboardData = async (range = '30d') => {
    const promises = [
      fetchOverview(),
      fetchSalesSeries(range),
      fetchPaymentBreakdown(range),
      fetchAvgOrderValue(range),
      fetchReturns(range)
    ]

    try {
      await Promise.allSettled(promises)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    }
  }

  const fetchStatisticsData = async (range = '30d') => {
    const promises = [
      fetchOverview(),
      fetchSalesSeries(range),
      fetchTopProducts('quantity', 5),
      fetchLowStock(10),
      fetchReturns(range)
    ]

    try {
      await Promise.allSettled(promises)
    } catch (error) {
      console.error('Error fetching statistics data:', error)
    }
  }

  const refreshAllData = async (range = '30d') => {
    const promises = [
      fetchOverview(),
      fetchSalesSeries(range),
      fetchPaymentBreakdown(range),
      fetchTopProducts('quantity', 10),
      fetchLowStock(10),
      fetchAvgOrderValue(range),
      fetchReturns(range)
    ]

    try {
      await Promise.allSettled(promises)
      Swal.fire({
        title: 'Thành công!',
        text: 'Dữ liệu đã được cập nhật',
        icon: 'success',
        timer: 2000,
        showConfirmButton: false
      })
    } catch (error) {
      console.error('Error refreshing all data:', error)
      showError('Có lỗi xảy ra khi cập nhật dữ liệu')
    }
  }

  return {
    // Data
    overviewData,
    salesData,
    paymentBreakdown,
    topProducts,
    lowStockItems,
    avgOrderValue,
    returnsCount,
    loading,

    // Methods
    fetchOverview,
    fetchSalesSeries,
    fetchPaymentBreakdown,
    fetchTopProducts,
    fetchLowStock,
    fetchAvgOrderValue,
    fetchReturns,
    
    // Batch operations
    fetchDashboardData,
    fetchStatisticsData,
    refreshAllData,

    // Utilities
    formatCurrency,
    formatNumber,
    getStockBadgeClass,
    getGrowthPercentage,
    getGrowthClass,
    getGrowthIcon,
    showError
  }
}
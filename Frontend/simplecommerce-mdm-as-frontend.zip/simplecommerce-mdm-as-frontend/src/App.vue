<template>
  <div id="app">
    <!-- Auto Login Notification -->
    <AutoLoginNotification />
    
    <!-- Main Router View -->
    <router-view />
  </div>
</template>

<script setup>
import AutoLoginNotification from '@/components/AutoLoginNotification.vue'

// Main app component with router
</script>

<style>
@import 'bootstrap/dist/css/bootstrap.min.css';

body {
  margin: 0;
  font-family:  'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

#app {
  min-height: 100vh;
}

/* Global Responsive Utilities */
.table-responsive {
  overflow-x: auto;
}

.card {
  margin-bottom: 1rem;
}

.btn {
  white-space: nowrap;
}

/* Mobile specific styles */
@media (max-width: 768px) {
  .table th,
  .table td {
    padding: 0.5rem 0.25rem;
    font-size: 0.875rem;
  }
  
  .card-header h5,
  .card-header h6 {
    font-size: 1rem;
    margin-bottom: 0;
  }
  
  .btn-group {
    flex-direction: column;
  }
  
  .btn-group .btn {
    margin-bottom: 0.25rem;
    border-radius: 0.25rem !important;
  }
  
  .d-flex.gap-2 {
    flex-direction: column;
    gap: 0.5rem !important;
  }
  
  .col-md-6,
  .col-md-4,
  .col-md-3 {
    margin-bottom: 1rem;
  }
  
  .form-control,
  .form-select {
    font-size: 16px; /* Prevents zoom on iOS */
  }
}

@media (max-width: 576px) {
  .container-fluid {
    padding-left: 0.5rem;
    padding-right: 0.5rem;
  }
  
  .card-body {
    padding: 1rem 0.75rem;
  }
  
  .table-responsive {
    font-size: 0.75rem;
  }
  
  .btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.75rem;
  }
  
  .modal-dialog {
    margin: 0.5rem;
  }
  
  .modal-content {
    border-radius: 0.5rem;
  }
}

/* Utility classes for mobile */
@media (max-width: 768px) {
  .d-md-none {
    display: none !important;
  }
  
  .d-block-mobile {
    display: block !important;
  }
  
  .text-truncate-mobile {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
</style>
# Auto Login Feature - Hướng dẫn sử dụng

## Tổng quan

Tính năng Auto Login cho phép user được tự động đăng nhập khi được redirect từ trang khác với JWT token. Đây là một tính năng SSO (Single Sign-On) hữu ích cho việc tích hợp giữa các hệ thống.

## Cách hoạt động

### 1. Flow hoạt động
```
User click "Quản lý Shop" → Vue.js app → Mở tab mới với URL chứa token → 
Trang quản lý shop tự động đọc token → Đăng nhập thành công → Hiển thị dashboard
```

### 2. URL format
```
https://simplecommerce-mdm-as.nammai.id.vn/seller/dashboard?token=JWT_TOKEN_HERE
```

## Các thành phần chính

### 1. AutoLoginService (`src/services/auth/autoLoginService.js`)
- Service chính xử lý tự động đăng nhập
- Kiểm tra token từ URL và localStorage
- Verify token với backend
- Load user profile và cập nhật UI

### 2. RedirectUtils (`src/utils/redirectUtils.js`)
- Utility functions để tạo URL redirect
- Hỗ trợ cả shop và admin management
- Tạo button/link HTML động

### 3. AutoLoginNotification (`src/components/AutoLoginNotification.vue`)
- Component hiển thị thông báo đăng nhập thành công
- Tự động ẩn sau 5 giây
- Responsive design

### 4. AutoLoginDemo (`src/components/AutoLoginDemo.vue`)
- Component demo để test tính năng
- Tạo URL với token
- Mở tab mới để test

## Cách sử dụng

### 1. Test tính năng
Truy cập: `/demo/auto-login`

1. Nhập JWT token vào ô input
2. Click "Test Auto Login" để test notification
3. Click "Mở Quản lý Shop/Admin" để mở tab mới
4. Copy URL để chia sẻ

### 2. Tích hợp vào component khác

```vue
<template>
  <div>
    <!-- Button mở quản lý shop -->
    <button @click="openShopManagement" class="btn btn-primary">
      <i class="bi bi-shop"></i> Quản lý Shop
    </button>
  </div>
</template>

<script setup>
import { openShopManagementInNewTab } from '@/utils/redirectUtils'
import { useAuthStore } from '@/stores/auth'

const authStore = useAuthStore()

const openShopManagement = () => {
  const token = localStorage.getItem('app_access_token')
  if (token) {
    openShopManagementInNewTab(token)
  }
}
</script>
```

### 3. Sử dụng utility functions

```javascript
import { 
  createShopManagementUrl, 
  redirectToManagementByRole 
} from '@/utils/redirectUtils'

// Tạo URL quản lý shop
const shopUrl = createShopManagementUrl(token)

// Redirect theo role
redirectToManagementByRole(token, 'ROLE_SELLER')

// Tạo button HTML
const buttonHtml = createManagementButton(token, 'ROLE_SELLER', 'Quản lý Shop')
```

## Cấu hình

### 1. Base URLs
Mặc định sử dụng: `https://simplecommerce-mdm-as.nammai.id.vn`

Có thể thay đổi trong `src/utils/redirectUtils.js`:

```javascript
export function createShopManagementUrl(token, baseUrl = 'YOUR_BASE_URL') {
  // ...
}
```

### 2. API endpoints
Token verification sử dụng endpoint: `/api/v1/auth/verify`

Có thể thay đổi trong `src/services/auth/authService.js`:

```javascript
async verifyToken(token) {
  const response = await apiClient.post('/verify', {}, {
    headers: { Authorization: `Bearer ${token}` }
  })
  // ...
}
```

## Bảo mật

### 1. Token handling
- Token chỉ được truyền qua URL một lần
- Sau khi nhận token, xóa ngay khỏi URL
- Verify token với backend trước khi sử dụng
- Xử lý lỗi khi token hết hạn

### 2. CORS và CSP
- Đảm bảo backend cho phép CORS từ domain gửi token
- Cấu hình CSP phù hợp nếu cần

## Troubleshooting

### 1. Token không được nhận
- Kiểm tra URL có chứa parameter `token` không
- Kiểm tra console log của AutoLoginService
- Verify token format (JWT)

### 2. Auto login không hoạt động
- Kiểm tra localStorage có token không
- Kiểm tra network tab xem API calls
- Verify backend endpoint `/verify` hoạt động

### 3. UI không cập nhật
- Kiểm tra event `userLoggedIn` có được trigger không
- Kiểm tra component `AutoLoginNotification` có được import không
- Verify auth store được cập nhật

## Logs và Debug

### 1. Console logs
AutoLoginService sẽ log các bước quan trọng:

```
🚀 Khởi tạo Auto Login Service...
🔐 Tìm thấy token trong localStorage, kiểm tra tính hợp lệ...
🎯 Nhận được token từ URL, bắt đầu tự động đăng nhập...
🔍 Đang verify token với backend...
✅ Token hợp lệ, user data: {...}
👤 Đang load user profile...
✅ User profile loaded: {...}
🔒 Đã xóa token khỏi URL để bảo mật
```

### 2. Network tab
Kiểm tra các API calls:
- `POST /api/v1/auth/verify` - Verify token
- `GET /api/v1/users/profile` - Load user profile

## Ví dụ thực tế

### 1. Từ Vue.js app
```javascript
// User click "Quản lý Shop"
const handleShopManagement = () => {
  const token = getCurrentUserToken()
  const shopUrl = createShopManagementUrl(token)
  window.open(shopUrl, '_blank')
}
```

### 2. Từ email hoặc SMS
```
Link: https://simplecommerce-mdm-as.nammai.id.vn/seller/dashboard?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 3. Từ mobile app
```javascript
// Deep link với token
const deepLink = `simplecommerce://shop?token=${token}`
```

## Kết luận

Tính năng Auto Login cung cấp trải nghiệm seamless cho user khi chuyển đổi giữa các hệ thống. Với cấu trúc modular và dễ mở rộng, có thể dễ dàng tích hợp vào các component khác và tùy chỉnh theo nhu cầu cụ thể.

## Liên hệ

Nếu có vấn đề hoặc cần hỗ trợ, vui lòng kiểm tra:
1. Console logs
2. Network tab
3. LocalStorage
4. Backend API status

# SimpleCommerce MDM Frontend

A Vue.js 3 frontend application for the SimpleCommerce Master Data Management system.

## 🚀 Features

- **Vue 3 Composition API** - Modern Vue.js development
- **Pinia State Management** - Lightweight and intuitive state management
- **Vue Router 4** - Client-side routing
- **Bootstrap 5** - Responsive UI components
- **Tailwind CSS** - Utility-first CSS framework
- **Vite** - Fast build tool and dev server
- **Axios** - HTTP client for API calls

## 📁 Project Structure

```
src/
├── api/           # API configuration and interceptors
├── assets/        # Static assets (images, styles)
├── components/    # Reusable Vue components
│   ├── cart/      # Shopping cart components
│   ├── common/    # Common UI components
│   ├── forms/     # Form components
│   ├── icons/     # Icon components
│   ├── orders/    # Order management components
│   ├── products/  # Product-related components
│   └── ui/        # UI components
├── constants/     # Application constants and configuration
├── layouts/       # Layout components
├── router/        # Vue Router configuration
├── services/      # Business logic services
├── stores/        # Pinia stores
├── utils/         # Utility functions
└── views/         # Page components
    ├── admin/     # Admin panel views
    ├── auth/      # Authentication views
    ├── buyer/     # Buyer/customer views
    ├── seller/    # Seller views
    └── shared/    # Shared/common views
```

## 🛠️ Setup & Development

### Prerequisites

- Node.js 16+
- npm or yarn

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

### Build

```bash
npm run build
```

### Preview Build

```bash
npm run preview
```

## 🔧 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint (if configured)
- `npm run format` - Format code with Prettier (if configured)

## 🌐 API Configuration

The application is configured to proxy API requests to `http://localhost:8080` during development. Update the proxy configuration in `vite.config.js` for different environments.

## 📱 Layouts

- **MainLayout** - Main application layout with header, navigation, and footer
- **AuthLayout** - Authentication pages layout

## 🗂️ State Management

Pinia stores are organized by feature:

- `auth.js` - Authentication state
- `cart.js` - Shopping cart state
- `product.js` - Product management
- `shop.js` - Shop information
- `category.js` - Category management
- `addressStore.js` - Address management

## 🎨 Styling

- Bootstrap 5 for component styling
- Tailwind CSS for utility classes
- SCSS support for custom styles

## 📝 Code Quality

- ESLint configuration for code linting
- Prettier for code formatting
- Consistent import paths using `@` alias
- Proper naming conventions (PascalCase for components, camelCase for variables)

## 🏗️ Architecture Improvements

### Naming Conventions

- **Components**: PascalCase (e.g., `ProductGrid.vue`, `ShoppingCart.vue`)
- **Views**: PascalCase with descriptive names (e.g., `ProductDetail.vue`, `UserProfile.vue`)
- **Routes**: camelCase (e.g., `productDetail`, `shoppingCart`)
- **Files**: PascalCase for components, camelCase for utilities

### File Organization

- **Components**: Organized by feature (cart, products, orders, etc.)
- **Views**: Organized by user role (buyer, seller, admin, shared)
- **Constants**: Centralized configuration and constants
- **Utils**: Reusable utility functions

### Import Structure

- Use `@/` alias for consistent imports
- Group imports by type (Vue, external libraries, internal)
- Use named exports for better tree-shaking

## 🤝 Contributing

1. Follow the existing code style and naming conventions
2. Use consistent import paths with `@` alias
3. Keep components focused and reusable
4. Add proper error handling
5. Test your changes
6. Use the provided utility functions and constants

## 📄 License

This project is private and proprietary.

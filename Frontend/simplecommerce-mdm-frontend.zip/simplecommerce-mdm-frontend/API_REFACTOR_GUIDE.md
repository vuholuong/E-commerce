# 🚀 Hướng dẫn Tái cấu trúc API - Vue.js Frontend

## 📋 Tổng quan

Tài liệu này hướng dẫn cách tái cấu trúc mã nguồn Vue.js để quản lý API một cách tập trung và sử dụng biến môi trường, giải quyết vấn đề hardcode URL và không nhất quán khi deploy.

## 🎯 Mục tiêu

1. **Sử dụng biến môi trường** để quản lý URL API
2. **Tạo API client tập trung** với axios instance
3. **Chuẩn hóa API endpoints** thông qua constants
4. **Cập nhật tất cả components** để sử dụng API client mới
5. **Cấu hình Vercel** với biến môi trường

## 🏗️ Cấu trúc đã được tái cấu trúc

### 1. File biến môi trường

Tạo các file sau trong thư mục gốc:

#### `.env.local` (cho development)
```bash
# Development Environment
VITE_API_BASE_URL=http://localhost:8080/api/v1
VITE_API_TIMEOUT=10000
```

#### `.env.production` (cho production)
```bash
# Production Environment
VITE_API_BASE_URL=https://sc-mdm-api.nammai.id.vn/api/v1
VITE_API_TIMEOUT=10000
```

#### `.env.example` (mẫu)
```bash
# Environment Variables Example
# Copy this file to .env.local for development
# Copy this file to .env.production for production

# API Configuration
VITE_API_BASE_URL=http://localhost:8080/api/v1
VITE_API_TIMEOUT=10000
```

### 2. API Client tập trung (`src/api/axios.js`)

```javascript
import axios from 'axios';
import { useAuthStore } from '@/stores/auth';
import router from '@/router';

// Lấy API base URL từ biến môi trường
const getApiBaseUrl = () => {
  // Trong development, sử dụng proxy Vite
  if (import.meta.env.DEV) {
    return '/api';
  }
  
  // Trong production, sử dụng biến môi trường
  return import.meta.env.VITE_API_BASE_URL || 'https://sc-mdm-api.nammai.id.vn/api/v1';
};

// Tạo axios instance với cấu hình tập trung
const api = axios.create({
  baseURL: getApiBaseUrl(),
  timeout: parseInt(import.meta.env.VITE_API_TIMEOUT) || 10000,
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptors cho request và response
// ... (xem file gốc để biết chi tiết)

export default api;
```

### 3. API Constants (`src/constants/api.js`)

```javascript
// API Endpoints Constants
export const API_ENDPOINTS = {
  // Auth endpoints
  AUTH: {
    LOGIN: '/auth/login',
    REGISTER: '/auth/register',
    LOGOUT: '/auth/logout',
    GOOGLE: '/auth/google',
    VERIFY_EMAIL: '/auth/verify-email',
  },
  
  // Product endpoints
  PRODUCT: {
    LIST: '/products',
    DETAIL: (id) => `/products/${id}`,
    RELATED: (id) => `/products/${id}/related`,
    BY_SHOP: (shopId) => `/products/shops/${shopId}`,
  },
  
  // ... (xem file gốc để biết đầy đủ)
};
```

## 🔄 Cách sử dụng mới

### Trước (cách cũ):
```javascript
// ❌ Không tốt - hardcode URL
import axios from 'axios';

const res = await axios.get('http://localhost:8080/api/v1/products');
const res = await axios.post('/api/v1/auth/login', { email, password });
```

### Sau (cách mới):
```javascript
// ✅ Tốt - sử dụng API client tập trung
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

const res = await api.get(API_ENDPOINTS.PRODUCT.LIST);
const res = await api.post(API_ENDPOINTS.AUTH.LOGIN, { email, password });
```

## 📝 Các file đã được cập nhật

### Stores:
- ✅ `src/stores/auth.js`
- ✅ `src/stores/shop.js`
- ✅ `src/stores/category.js`
- ✅ `src/stores/review.js`
- ✅ `src/stores/register.js`

### Services:
- ✅ `src/services/authService.js`
- ✅ `src/services/addressService.js`

### Components:
- ✅ `src/layouts/nav.vue`
- ✅ `src/components/cart/ShoppingCart.vue`

### Constants:
- ✅ `src/constants/api.js`
- ✅ `src/constants/index.js`

## 🚀 Cấu hình Vercel

### Bước 1: Đăng nhập Vercel Dashboard
1. Truy cập [vercel.com](https://vercel.com)
2. Đăng nhập và chọn project của bạn

### Bước 2: Thêm Environment Variables
1. Vào **Settings** → **Environment Variables**
2. Thêm biến mới:
   - **Name**: `VITE_API_BASE_URL`
   - **Value**: `https://sc-mdm-api.nammai.id.vn/api/v1`
   - **Environment**: Production (và Preview nếu muốn)

### Bước 3: Redeploy
1. Sau khi thêm biến môi trường, Vercel sẽ tự động redeploy
2. Hoặc bạn có thể trigger manual redeploy

## 🔧 Cấu hình Vite

File `vite.config.js` đã được cập nhật để hỗ trợ proxy trong development:

```javascript
export default defineConfig({
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'https://sc-mdm-api.nammai.id.vn',
        changeOrigin: true,
        secure: false,
        rewrite: (path) => path.replace(/^\/api/, '/api'),
      },
    },
  },
  // ... other config
});
```

## ✅ Lợi ích của việc tái cấu trúc

1. **Quản lý tập trung**: Tất cả API calls đều thông qua một instance duy nhất
2. **Dễ bảo trì**: Thay đổi URL chỉ cần sửa ở một nơi
3. **Môi trường linh hoạt**: Tự động chuyển đổi giữa dev và production
4. **Xử lý lỗi nhất quán**: Interceptors xử lý tất cả responses
5. **Logging tự động**: Trong development mode
6. **Type safety**: Constants giúp tránh lỗi typo

## 🚨 Lưu ý quan trọng

1. **Không commit file `.env.local`** vào git (đã có trong .gitignore)
2. **Luôn sử dụng `api` instance** thay vì import axios trực tiếp
3. **Sử dụng constants** cho tất cả API endpoints
4. **Test kỹ** trước khi deploy lên production

## 🔍 Kiểm tra sau khi tái cấu trúc

1. ✅ Tất cả API calls đều sử dụng `api` instance
2. ✅ Không còn hardcode URL localhost
3. ✅ Constants được sử dụng cho endpoints
4. ✅ Biến môi trường được cấu hình đúng
5. ✅ Vercel environment variables đã được set

## 📞 Hỗ trợ

Nếu gặp vấn đề trong quá trình tái cấu trúc, hãy kiểm tra:
1. Console errors trong browser
2. Network tab trong DevTools
3. Vercel deployment logs
4. Environment variables configuration

---

**Chúc bạn tái cấu trúc thành công! 🎉**

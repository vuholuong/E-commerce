<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue';

import { useRoute, useRouter } from 'vue-router';
import Swal from 'sweetalert2';
import { useAuthStore } from '@/stores/auth';
import { useProductStore } from '@/stores/product';
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

async function fetchSuggestions(keyword) {
  try {
    const res = await api.get(API_ENDPOINTS.PRODUCT.LIST, {
      params: { searchTerm: keyword, size: 5 },
    });
    suggestions.value = res.data.data?.products || res.data.data || [];
    showSuggestions.value = true;
  } catch (e) {
    suggestions.value = [];
    showSuggestions.value = false;
  }
}
const router = useRouter();
const route = useRoute();
const authStore = useAuthStore();
const store = useProductStore();
// state cho tìm kiếm
const searchQuery = ref('');
const suggestions = ref([]);
const showSuggestions = ref(false);
let debounceTimer = null;
// Theo dõi searchQuery, debounce 300ms để tránh spam API
watch(searchQuery, newVal => {
  clearTimeout(debounceTimer);
  if (!newVal) {
    suggestions.value = [];
    return;
  }
  debounceTimer = setTimeout(() => fetchSuggestions(newVal), 300);
});
// chọn 1 sản phẩm từ dropdown
function selectSuggestion(item) {
  suggestions.value = [];
  searchQuery.value = '';
  showSuggestions.value = false;
  router.push(`/product/${item.id}`);
}

// xử lý submit form (ấn Enter hoặc nút tìm kiếm)
function handleSearch() {
  if (suggestions.value.length > 0) {
    selectSuggestion(suggestions.value[0]); // mặc định lấy sản phẩm đầu tiên
  }
}

function handleLogout() {
  authStore.logoutWithAPI();
  Swal.fire({
    title: 'Đăng xuất thành công!',
    icon: 'success',
    showConfirmButton: false,
    timer: 1500,
  }).then(() => {
    router.push('/login');
  });
}

function goToShopManagement() {
  if (authStore.token) {
    const shopManagementUrl = `https://simplecommerce-mdm-as.nammai.id.vn/seller/dashboard?token=${authStore.token}`;
    window.open(shopManagementUrl, '_blank');
  } else {
    Swal.fire({
      title: 'Lỗi!',
      text: 'Vui lòng đăng nhập để quản lý shop.',
      icon: 'error',
      showConfirmButton: true,
    });
  }
}

// Function sử dụng postMessage để truyền data (optional)
function goToShopManagementWithPostMessage() {
  if (authStore.token) {
    const shopWindow = window.open('https://simplecommerce-mdm-as.nammai.id.vn/seller/dashboard', '_blank');
    
    // Đợi window mở xong rồi gửi message
    setTimeout(() => {
      if (shopWindow && !shopWindow.closed) {
        shopWindow.postMessage({
          type: 'AUTH_DATA',
          token: authStore.token,
          user: authStore.user,
          profile: authStore.profile
        }, 'https://simplecommerce-mdm-as.nammai.id.vn');
      }
    }, 1000);
  } else {
    Swal.fire({
      title: 'Lỗi!',
      text: 'Vui lòng đăng nhập để quản lý shop.',
      icon: 'error',
      showConfirmButton: true,
    });
  }
}

onMounted(async () => {
  if (authStore.token && (!authStore.user || !authStore.user.lastName)) {
    await authStore.fetchProfile();
  }
});

const showSubMenu = ref(true);
let lastScroll = window.scrollY;
const showScrollTop = ref(false);

const handleScroll = () => {
  if (window.scrollY <= 0) showSubMenu.value = true;
  else if (window.scrollY > lastScroll) showSubMenu.value = false;
  else showSubMenu.value = true;

  lastScroll = window.scrollY;
  showScrollTop.value = window.scrollY > 200;
};

const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

onMounted(() => window.addEventListener('scroll', handleScroll));
onUnmounted(() => window.removeEventListener('scroll', handleScroll));
</script>
<template>
  <div class="fixed-top">
    <!-- NAVBAR -->
    <nav class="navbar bg-primary">
      <div class="container ">
        <!-- Logo -->
        <a class="navbar-brand fw-bold fs-3 d-flex align-items-center gap-2" href="/">
          <img src="@/assets/images/logomuadima4.png" style="width: 150px" alt="Logo" />
        </a>
        <!-- Search -->
        <div class="search-box-wrap">
          <input
            v-model="searchQuery"
            class="search-input"
            type="search"
            placeholder="Tìm sản phẩm..."
            @focus="showSuggestions = suggestions.length > 0"
            @blur="setTimeout(() => (showSuggestions = false), 200)"
          />
          <button class="search-btn" @click.prevent="handleSearch">
            <i class="fa fa-search"></i>
          </button>

          <!-- Dropdown gợi ý -->
          <ul v-if="showSuggestions" class="suggestion-list">
            <li
              v-for="item in suggestions"
              :key="item.id"
              class="suggestion-item"
              @mousedown.prevent="selectSuggestion(item)"
            >
              <img :src="item.imageUrls?.[0] || '/images/no-image.jpg'" alt="Sản phẩm" />
              <span>{{ item.name }}</span>
            </li>
            <li v-if="!suggestions.length" class="suggestion-empty">Không tìm thấy sản phẩm</li>
          </ul>
        </div>
        <!-- Actions -->
        <div class="d-flex gap-3 align-items-center nav-actions">
          <a class="nav-link nav-hover fw-bold" href="#"
            ><i class="fa-solid fa-mobile-retro"></i>&nbsp;HotLine</a
          >
          <router-link class="nav-link nav-hover fw-bold" to="/cart">
            <i class="fa-solid fa-cart-shopping"></i>&nbsp;Giỏ hàng
          </router-link>

          <!-- User Dropdown -->
          <div class="nav-item dropdown fw-bold">
            <!-- Thanh nav hiện tên người dùng -->
            <a
              class="nav-link dropdown-toggle nav-hover"
              href="#"
              id="accountDropdown"
              role="button"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              <i class="fa-solid fa-circle-user"></i>&nbsp;
              <span class="user-name">
                {{ authStore.profile?.firstName || '' }}
                {{ authStore.profile?.lastName || 'Tài khoản' }}
              </span>
            </a>
            <!-- Dropdown menu -->
            <ul
              class="dropdown-menu dropdown-menu-end animate__animated animate__fadeInDown"
              aria-labelledby="accountDropdown"
            >
              <!-- Nếu đã đăng nhập -->
              <template v-if="authStore.user">
                <li>
                  <router-link class="dropdown-item register-item" to="/profile">
                    <i class="fa-solid fa-user me-2 text-success"></i>
                    <span class="fw-bold text-success">Thông tin tài khoản</span>
                  </router-link>
                </li>
                <li>
                  <router-link class="dropdown-item register-item" to="/order-history">
                    <i class="fa-solid fa-box me-2 text-success"></i>
                    <span class="fw-bold text-success">Đơn hàng của tôi</span>
                  </router-link>
                </li>
                <!-- Nút Quản lý Shop cho ROLE_SELLER -->
                <li v-if="authStore.user?.role?.[0]?.authority === 'ROLE_SELLER'">
                  <a 
                    class="dropdown-item shop-management-item" 
                    href="#" 
                    @click.prevent="goToShopManagement"
                  >
                    <i class="fa-solid fa-store me-2 text-warning"></i>
                    <span class="fw-bold text-warning">Quản lý Shop</span>
                  </a>
                </li>
                <li>
                  <a class="dropdown-item logout-item" href="#" @click.prevent="handleLogout">
                    <i class="fa-solid fa-arrow-right-from-bracket me-2 text-danger"></i>
                    <span class="text-danger fw-bold">Đăng xuất</span>
                  </a>
                </li>
              </template>

              <!-- Nếu chưa đăng nhập -->
              <template v-else>
                <li>
                  <router-link class="dropdown-item login-item" to="/login">
                    <i class="fa-solid fa-right-to-bracket me-2 text-primary"></i>
                    <span class="fw-bold text-primary">Đăng nhập</span>
                  </router-link>
                </li>
                <li>
                  <router-link class="dropdown-item register-item" to="/register">
                    <i class="fa-solid fa-user-plus me-2 text-success"></i>
                    <span class="fw-bold text-success">Đăng ký</span>
                  </router-link>
                </li>
              </template>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!-- SUB-MENU + BREADCRUMB -->
    <div class="container">
      <div class="sub-menu" :class="{ 'sub-menu-hide': !showSubMenu }">
        <div class="container ">
          <router-link class="sub-menu-link text-black" to="/">Trang chủ</router-link>
          <router-link class="sub-menu-link text-black" to="/products/all">Sản phẩm</router-link>
          <router-link class="sub-menu-link text-black" to="/sale">Khuyến mãi</router-link>
          <router-link class="sub-menu-link text-black" to="/contact">Liên hệ</router-link>
        </div>
      </div>
    </div>

    <!-- Scroll to top -->
    <button
      v-show="showScrollTop"
      class="scroll-top-btn"
      @click="scrollToTop"
      aria-label="Lên đầu trang"
    >
      <i class="fa-solid fa-arrow-up"></i>
    </button>
  </div>
</template>

<style>
/* Search box wrapper */
.search-box-wrap {
  position: relative;
  flex: 1;
  max-width: 500px;
  display: flex;
  align-items: center;
}

/* Input */
.search-input {
  width: 100%;
  height: 42px;
  border-radius: 25px;
  border: 1.5px solid #e0e0e0;
  padding: 0 45px 0 18px;
  font-size: 0.95rem;
  background: #fff;
  transition: all 0.25s ease;
}

.search-input:focus {
  border-color: #42a5f5;
  box-shadow: 0 0 0 3px rgba(66, 165, 245, 0.2);
  outline: none;
}

/* Search button */
.search-btn {
  position: absolute;
  right: 8px;
  background: transparent;
  border: none;
  color: #1976d2;
  font-size: 1.1rem;
  cursor: pointer;
  padding: 6px 10px;
  border-radius: 50%;
  transition: background 0.2s;
}

.search-btn:hover {
  background: #e3f2fd;
}

/* Dropdown gợi ý */
.suggestion-list {
  position: absolute;
  top: 46px;
  left: 0;
  width: 100%;
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  margin-top: 4px;
  list-style: none;
  padding: 0;
  max-height: 300px;
  overflow-y: auto;
  z-index: 2000;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
}

.suggestion-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  cursor: pointer;
  transition: background 0.2s;
}

.suggestion-item:hover {
  background: #f7f9fc;
}

.suggestion-item img {
  width: 38px;
  height: 38px;
  object-fit: cover;
  border-radius: 6px;
  border: 1px solid #eee;
}

.suggestion-empty {
  padding: 12px 14px;
  color: #777;
  font-style: italic;
  text-align: center;
}

/* Responsive */
@media (max-width: 768px) {
  .search-box-wrap {
    max-width: 100%;
    margin: 8px 0;
  }

  .search-input {
    height: 38px;
    font-size: 0.9rem;
  }

  .search-btn {
    font-size: 1rem;
  }
}

.suggestion-item span {
  color: #222;
  /* đen nhẹ cho dễ nhìn */
  font-size: 0.95rem;
  font-weight: 500;
}

.suggestion-empty {
  color: #555;
  /* xám vừa */
}

/* logout login*/
.logout-item {
  border-top: 1px solid #e3e8f0;
  margin-top: 4px;
  color: #f44336 !important;
  font-weight: 600;
  transition:
    background 0.18s,
    color 0.18s;
}

.logout-item:hover,
.logout-item:focus {
  background: #ffeaea !important;
  color: #d32f2f !important;
}

.logout-item .fa-arrow-right-from-bracket {
  font-size: 1.08em;
}

.login-item {
  color: #1976d2 !important;
  font-weight: 600;
  transition:
    background 0.18s,
    color 0.18s;
}

.login-item:hover,
.login-item:focus {
  background: #e3f2fd !important;
  color: #1565c0 !important;
}

.login-item .fa-right-to-bracket {
  font-size: 1.08em;
}

.register-item {
  color: #43a047 !important;
  font-weight: 600;
  transition:
    background 0.18s,
    color 0.18s;
}

.register-item:hover,
.register-item:focus {
  background: #e8f5e9 !important;
  color: #1b5e20 !important;
}

.register-item .fa-user-plus {
  font-size: 1.08em;
}

.search-box-wrap {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
}

.search-box-wrap input.form-control {
  width: 100%;
  border-radius: 30px;
  border: 1.5px solid #e0e0e0;
  padding: 10px 18px 10px 42px;
  /* chừa chỗ cho icon */
  font-size: 1rem;
  background: #f9fbfd;
  transition: all 0.25s ease;
}

.search-box-wrap input.form-control:focus {
  background: #fff;
  border-color: #42a5f5;
  box-shadow: 0 0 0 3px rgba(66, 165, 245, 0.2);
  outline: none;
}

/* Nút tìm kiếm */
.search-box-wrap button {
  border-radius: 30px;
  padding: 0 20px;
  font-weight: 500;
  margin-left: 8px;
}

/* NAVBAR */
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 64px;
  color: #fff;
  display: flex;
  align-items: center;
  z-index: 1000;
  box-shadow: 0 4px 24px 0 rgba(33, 150, 243, 0.15);
  transition: background 0.3s;
  border-bottom: 2px solid #00e5ff;
}

.scroll-top-btn {
  position: fixed;
  bottom: 32px;
  left: 32px;
  z-index: 9999;
  background: linear-gradient(135deg, #2575fc, #6a11cb);
  color: #fff;
  border: none;
  border-radius: 50%;
  width: 48px;
  height: 48px;
  font-size: 1.5rem;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18);
  cursor: pointer;
  opacity: 0.85;
  transition:
    opacity 0.2s,
    transform 0.2s;
}

/* SUB-MENU */
.sub-menu {
  position: sticky;
  top: 64px;
  z-index: 1000;
  background: linear-gradient(90deg, #ffffff 60%, #e3f2fd 100%);
  border-bottom: 2px solid #00e5ff;
  transition: transform 0.3s ease;
}

.sub-menu-hide {
  transform: translateY(-100%);
}

.sub-menu-link {
  font-size: 13px;
  /* nhỏ hơn chút để không bị xuống dòng */
  white-space: nowrap;
  /* không cho chữ xuống dòng */
  padding: 6px 10px;
  font-weight: 500;
  color: #004080;
  text-decoration: none;
  transition: all 0.3s;
}

.sub-menu-link:hover,
.router-link-exact-active.sub-menu-link {
  background: linear-gradient(to right, #00e5ff, #42a5f5);
  color: white;
  border-radius: 6px;
}

/* Responsive cải tiến */
@media (max-width: 768px) {
  .breadcrumb-wrapper {
    height: 40px;
    padding-left: 0.75rem;
    padding-right: 0.75rem;
  }

  .breadcrumb-item {
    font-size: 0.88rem;
  }

  .sub-menu-link {
    font-size: 0.9rem;
    padding: 6px 10px;
  }

  .container2 {
    gap: 14px;
  }
}

.scroll-top-btn:hover {
  opacity: 1;
  transform: scale(1.08);
}

.navbar-brand {
  display: flex;
  align-items: center;
  gap: 12px;
  text-decoration: none;
  color: #fff;
  font-weight: bold;
  font-size: 2.2rem;
  letter-spacing: 2px;
  transition: color 0.2s;
  text-shadow: 0 2px 8px rgba(33, 150, 243, 0.15);
}

.navbar-brand img {
  height: 52px;
  width: auto;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.12);
}

.navbar-brand:hover {
  color: #ffd600;
  text-shadow: 0 2px 12px #ffd60099;
}

.nav-actions {
  display: flex;
  gap: 20px;
  align-items: center;
}

.nav-link,
.dropdown-toggle {
  color: #fff;
  font-size: 1.08rem;
  text-decoration: none;
  padding: 10px 18px;
  border-radius: 8px;
  transition:
    background 0.2s,
    color 0.2s,
    box-shadow 0.2s;
  cursor: pointer;
  display: flex;
  align-items: center;
  font-weight: 500;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.08);
}

.nav-link.nav-hover:hover,
.dropdown-toggle.nav-hover:hover {
  background: linear-gradient(90deg, #00e5ff 0%, #42a5f5 100%);
  color: #fff;
  box-shadow: 0 4px 16px #00e5ff33;
}

.dropdown-menu {
  min-width: 170px;
  border-radius: 10px;
  box-shadow: 0 8px 32px rgba(33, 150, 243, 0.18);
  border: none;
  margin-top: 10px;
  background: #fff;
  color: #1976d2;
  font-size: 1rem;
  animation: fadeInDown 0.25s;
}

@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dropdown-item {
  padding: 12px 20px;
  border-radius: 8px;
  color: #1976d2;
  transition:
    background 0.2s,
    color 0.2s;
  font-weight: 500;
}

.dropdown-item:hover {
  background: #e3f2fd;
  color: #00bcd4;
}

/* Styling cho nút Quản lý Shop */
.shop-management-item {
  border-left: 3px solid #ff9800;
  background: linear-gradient(135deg, #fff8e1 0%, #fff3e0 100%);
}

.shop-management-item:hover {
  background: linear-gradient(135deg, #ffecb3 0%, #ffe0b2 100%);
  color: #f57c00;
  transform: translateX(5px);
  transition: all 0.3s ease;
}

.shop-management-item i {
  color: #ff9800;
}

.shop-management-item:hover i {
  color: #f57c00;
}

.fa-cart-shopping {
  font-size: 1.25rem;
}

.fa-circle-user,
.fa-mobile-retro {
  font-size: 1.15rem;
}

/* SUB-MENU */
.sub-menu {
  position: static;
  height: 48px;
  background: linear-gradient(90deg, #fff 60%, #e3f2fd 100%);
  z-index: 999;
  display: flex;
  align-items: center;
  border-bottom: 2px solid #00e5ff;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.06);
}

.sub-menu .container {
  display: flex;
  gap: 36px;
  align-items: center;
  height: 100%;
}

.sub-menu-link {
  color: #1976d2;
  font-weight: 600;
  font-size: 1.12rem;
  text-decoration: none;
  padding: 10px 22px;
  border-radius: 8px;
  transition:
    background 0.22s,
    color 0.22s,
    box-shadow 0.22s;
  letter-spacing: 0.5px;
  position: relative;
}

.sub-menu-link:hover,
.router-link-exact-active.sub-menu-link {
  background: linear-gradient(90deg, #00e5ff 0%, #42a5f5 100%);
  color: #fff;
  box-shadow: 0 2px 8px #00e5ff33;
}

.sub-menu-link::after {
  content: '';
  display: block;
  margin: 0 auto;
  width: 0%;
  height: 3px;
  background: linear-gradient(90deg, #00e5ff 0%, #42a5f5 100%);
  border-radius: 2px;
  transition: width 0.22s;
}

.sub-menu-link:hover::after,
.router-link-exact-active.sub-menu-link::after {
  width: 80%;
}

.sub-menu .container {
  display: flex;
  gap: 36px;
  align-items: center;
  height: 100%;
  justify-content: center;
  /* Thêm dòng này để căn giữa menu */
}

/* Đảm bảo nội dung không bị che */
.content {
  padding-top: 64px;
  /* Chỉ còn navbar (64px) */
}

.breadcrumb-container .breadcrumb {
  display: flex;
  justify-content: flex-end;
}

/* Responsive */
@media (max-width: 900px) {
  .search-box {
    width: 180px;
    font-size: 0.98rem;
  }

  .sub-menu .container {
    gap: 16px;
  }

  .navbar-brand {
    font-size: 1.3rem;
  }
}

@media (max-width: 600px) {
  .navbar {
    flex-direction: column;
    height: auto;
    padding: 8px 0;
  }

  .navbar-brand {
    font-size: 1.1rem;
  }

  .search-box-wrap {
    margin: 8px 0;
  }

  .nav-actions {
    gap: 8px;
  }

  .sub-menu {
    height: auto;
    padding: 6px 0;
  }

  .sub-menu-link {
    padding: 6px 10px;
    font-size: 0.98rem;
  }
}

/*breadcrumb*/
.breadcrumb-nav {
  position: relative;
  z-index: 1100;
  background: #fff;
  overflow-x: auto;
  padding-left: 1rem;
  /* tùy chỉnh nếu muốn lùi nhẹ */
  padding-right: 1rem;
}

.breadcrumb::-webkit-scrollbar {
  display: none;
  /* ẩn scrollbar */
}

.breadcrumb-item {
  flex-shrink: 0;
  display: inline-block;
}

.breadcrumb-item + .breadcrumb-item::before {
  content: '>';
  color: #1976d2;
  padding: 0 6px;
}

.breadcrumb-item.active {
  color: #1976d2;
  font-weight: 600;
}

.breadcrumb-wrapper {
  width: 100%;
  overflow-x: auto;
  overflow-y: hidden;
  white-space: nowrap;
  height: 40px;
  /* hoặc chiều cao vừa đủ cho breadcrumb */
  line-height: 40px;
  background-color: #fff;
  border-bottom: 1px solid #e0e0e0;
  box-sizing: border-box;
}

.breadcrumb-scroll {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0 1rem;
  white-space: nowrap;
  height: 100%;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.breadcrumb-scroll::-webkit-scrollbar {
  display: none;
}

.breadcrumb-item {
  white-space: nowrap;
  flex-shrink: 0;
  font-size: 0.9rem;
}

.breadcrumb-item + .breadcrumb-item::before {
  content: '›';
  margin: 0 0.5rem;
  color: #1976d2;
}
</style>

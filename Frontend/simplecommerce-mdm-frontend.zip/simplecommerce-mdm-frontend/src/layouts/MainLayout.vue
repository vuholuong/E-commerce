<template>
  <div>
    <TheNav />
    <div class="content">
      <TheHeader />
      <router-view />
      <TheFooter />
    </div>
  </div>
</template>

<script setup>
import TheNav from '@/layouts/nav.vue';
import TheHeader from '@/layouts/header.vue';
import TheFooter from '@/layouts/footer.vue';
</script>

<style>
.content {
  padding-top: 108px; /* navbar (64px) + submenu (44px) */
}
</style>

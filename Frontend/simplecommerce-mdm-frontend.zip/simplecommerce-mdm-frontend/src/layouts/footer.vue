<template>
  <footer>
    <div class="container mt-4 section-wrapper">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-3 mb-md-0">
            <h6>Dịch vụ khách hàng</h6>
            <p>
              <a href="#" class="footer-link">Chính sách bảo mật</a><br />
              <a href="#" class="footer-link">Chính sách vận chuyển</a><br />
              <a href="#" class="footer-link">Trung tâm hỗ trợ</a>
            </p>
          </div>
          <div class="col-md-4 mb-3 mb-md-0">
            <h6>Thanh toán</h6>
            <div class="footer-icons mb-2">
              <img src="@/assets/images/logovnpay.jpg" alt="VNPay" class="payment-img" />
              <img src="@/assets/images/logomomo.jpg" alt="MoMo" class="payment-img" />
            </div>
            <h6>Vận chuyển</h6>
            <div class="footer-icons">
              <img src="@/assets/images/logovtp.jpg" alt="ViettelPost" class="shipping-img" />
              <img src="@/assets/images/logospx.jpg" alt="J&T Express" class="shipping-img" />
              <img src="@/assets/images/logovnp.jpg" alt="MoMo" class="payment-img" />
            </div>
          </div>
          <div class="col-md-4">
            <h6>Theo dõi shop</h6>
            <div class="footer-icons mb-2">
              <a href="#" class="footer-social"><i class="fa-brands fa-facebook-f"></i></a>
              <a href="#" class="footer-social"><i class="fa-brands fa-instagram"></i></a>
              <a href="#" class="footer-social"><i class="fa-brands fa-youtube"></i></a>
            </div>
            <p class="footer-hotline"><i class="fa-solid fa-phone"></i> Hotline: <b>113</b></p>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>
<style scoped>
footer {
  background: linear-gradient(90deg, #f8e7f1 0%, #e3f0ff 100%);
  border-top: 4px solid #2575fc;
  font-size: 1rem;
  margin-top: 30px;
  padding: 36px 0 16px 0;
  box-shadow: 0 0 24px rgba(37, 117, 252, 0.04);
}
.section-wrapper {
  background: #fff;
  border-radius: 18px;
  padding: 24px 18px 18px 18px;
  box-shadow: 0 2px 12px rgba(37, 117, 252, 0.06);
}
h6 {
  color: #2575fc;
  font-weight: 700;
  margin-bottom: 10px;
  letter-spacing: 1px;
}
p {
  color: #444;
  font-size: 1.05em;
  margin-bottom: 10px;
}
.footer-link {
  color: #2575fc;
  text-decoration: none;
  transition: color 0.2s;
}
.footer-link:hover {
  color: #eb3586;
  text-decoration: underline;
}
.footer-icons {
  display: flex;
  align-items: center;
  gap: 14px;
  flex-wrap: wrap;
}
.payment-icon {
  font-size: 2rem;
  color: #1976d2;
  background: #fafdff;
  border-radius: 8px;
  padding: 6px 10px;
  box-shadow: 0 2px 8px #1976d211;
}
.payment-img {
  height: 32px;
  width: auto;
  border-radius: 8px;
  background: #fafdff;
  padding: 3px 8px;
  box-shadow: 0 2px 8px #1976d211;
}
.shipping-img {
  height: 32px;
  width: auto;
  border-radius: 8px;
  background: #fafdff;
  padding: 3px 8px;
  box-shadow: 0 2px 8px #1976d211;
}
.footer-social {
  color: #fff;
  background: linear-gradient(135deg, #2575fc, #eb3586);
  border-radius: 50%;
  width: 36px;
  height: 36px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 1.3rem;
  margin-right: 6px;
  transition:
    background 0.2s,
    color 0.2s,
    transform 0.15s;
  box-shadow: 0 2px 8px #1976d211;
}
.footer-social:hover {
  background: linear-gradient(135deg, #eb3586, #2575fc);
  color: #fff700;
  transform: scale(1.08);
}
.footer-hotline {
  color: #eb3586;
  font-weight: 600;
  font-size: 1.08em;
  margin-top: 10px;
}
@media (max-width: 768px) {
  .section-wrapper {
    padding: 18px 6px 12px 6px;
  }
  .footer-icons {
    gap: 8px;
  }
}
</style>

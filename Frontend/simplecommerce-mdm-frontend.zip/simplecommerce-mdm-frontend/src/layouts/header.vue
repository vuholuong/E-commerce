<template>
  <div class="header-wrapper container">
    <div class="d-flex gap-4 flex-wrap">
      <!-- Sidebar -->
      <div class="sidebar d-none d-lg-block fw-bold ">
        <div class="card custom-card mb-3 shadow-sm">
          <div class="card-body bg-primary p-3">
            <nav class="nav flex-column gap-2">
              <router-link to="/" class="nav-link active">
                <i class="fa-regular fa-calendar"></i> Dashboard
              </router-link>
              <a class="nav-link" href="#"><i class="fa-regular fa-calendar"></i> Siêu sale</a>
              <a class="nav-link" href="#"
                ><i class="fa-regular fa-circle-up"></i> Giá Tốt Mỗi Ngày</a
              >
              <a class="nav-link" href="#"><i class="fa-solid fa-cart-shopping"></i> Voucher</a>
            </nav>
          </div>
        </div>
        <div class="card custom-card shadow-sm">
          <div class="card-body bg-primary  p-3">
            <nav class="nav flex-column gap-2">
              <router-link
                v-for="cat in categoryStore.parentCategories"
                :key="cat.id"
                class="nav-link"
                :to="`/category/${cat.id}`"
              >
                <i class="fa-solid fa-folder"></i> {{ cat.name }}
              </router-link>
            </nav>
          </div>
        </div>
      </div>

      <!-- Banner + Voucher -->
      <div class="flex-grow-1">
        <div class="banner-voucher-row d-flex">
          <div class="banner-box">
            <img
              v-for="(img, idx) in bannerImages"
              :key="idx"
              :src="img"
              class="img-fluid rounded-banner"
              :class="getBannerClass(idx)"
              alt="Banner"
              :style="{ visibility: isBannerVisible(idx) ? 'visible' : 'hidden' }"
            />
            <button class="btn btn-light banner-nav left" @click="prevBanner">‹</button>
            <button class="btn btn-light banner-nav right" @click="nextBanner">›</button>
          </div>
          <div class="voucher-col d-flex flex-column justify-content-between">
            <img src="../assets/images/vocher1.jpg" class="voucher-img shadow-sm" alt="Voucher 1" />
            <img src="../assets/images/vocher2.jpg" class="voucher-img shadow-sm" alt="Voucher 2" />
          </div>
        </div>

        <!-- Deal sốc mỗi ngày -->
        <!-- Sản phẩm nổi bật -->
        <div class="section-wrapper mt-3">
          <h5 class="fw-bold mb-3 text-dark">🌟 Sản phẩm nổi bật</h5>
          <div class="row g-3">
            <div v-for="product in featuredProducts" :key="product.id" class="col-md-3">
              <div class="product-card text-center" @click="goToDetail(product.id)">
                <img
                  :src="product.imageUrls?.[0] || fallbackImage"
                  alt="image"
                  class="product-img"
                />
                <p>
                  {{ product.name }}<br />
                  <strong class="text-danger">{{ formatPrice(product.basePrice) }}</strong>
                </p>
                <a class="btn-cart" @click="addToCart(product)">🛒 Thêm vào giỏ</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue';
import { useRouter } from 'vue-router';
import { useProductStore } from '@/stores/product';
import { useCategoryStore } from '@/stores/category'; // thêm
import { useCartStore } from '@/stores/cart';

const cartStore = useCartStore();
const router = useRouter();
const productStore = useProductStore();
const fallbackImage = '/images/no-image.jpg';
const categoryStore = useCategoryStore(); // thêm
// Gọi API khi load trang
onMounted(async () => {
  if (!productStore.allProducts.length) {
    await productStore.fetchProducts();
  }
  intervalId = setInterval(nextBanner, 4000);
});
onMounted(async () => {
  if (!productStore.allProducts.length) {
    await productStore.fetchProducts();
  }
  if (!categoryStore.categories.length) {
    await categoryStore.fetchCategories();
  }
  intervalId = setInterval(nextBanner, 4000);
});

onUnmounted(() => {
  clearInterval(intervalId);
});

// Dữ liệu banner
const bannerImages = [
  new URL('@/assets/images/hinh1.png', import.meta.url).href,
  new URL('@/assets/images/hinh2.jpg', import.meta.url).href,
  new URL('@/assets/images/hinh3.jpg', import.meta.url).href,
];
const currentBanner = ref(0);
const nextIndex = ref(null);
const direction = ref('next');
let intervalId = null;

function getBannerClass(idx) {
  if (idx === currentBanner.value) return 'banner-slide-active';
  if (idx === nextIndex.value)
    return direction.value === 'next' ? 'banner-slide-next' : 'banner-slide-prev';
  return '';
}
function isBannerVisible(idx) {
  return idx === currentBanner.value || idx === nextIndex.value;
}
function nextBanner() {
  if (nextIndex.value !== null) return;
  direction.value = 'next';
  nextIndex.value = (currentBanner.value + 1) % bannerImages.length;
  setTimeout(() => {
    currentBanner.value = nextIndex.value;
    nextIndex.value = null;
  }, 600);
}
function prevBanner() {
  if (nextIndex.value !== null) return;
  direction.value = 'prev';
  nextIndex.value = (currentBanner.value - 1 + bannerImages.length) % bannerImages.length;
  setTimeout(() => {
    currentBanner.value = nextIndex.value;
    nextIndex.value = null;
  }, 600);
}
// Format giá
function formatPrice(value) {
  if (value == null) return 'Liên hệ';
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(value);
}

function goToDetail(productId) {
  router.push(`/product/${productId}`);
}
const addToCart = async product => {
  try {
    await cartStore.addToCart(product.variantId, 1);
  } catch (err) {
    console.error(err);
  }
};

// Sản phẩm nổi bật
const featuredProducts = computed(() => {
  return productStore.allProducts
    .filter(p => Boolean(p.isFeatured)) // chấp nhận true, "true", 1
    .slice(0, 8);
});
</script>

<style scoped>
.product-card {
  background: #fff;
  border-radius: 14px;
  box-shadow: 0 2px 12px rgba(37, 117, 252, 0.06);
  padding: 12px;
  transition:
    transform 0.18s,
    box-shadow 0.18s;
  cursor: pointer;
}

.product-card:hover {
  transform: translateY(-6px) scale(1.03);
  box-shadow: 0 8px 32px rgba(37, 117, 252, 0.13);
}

.product-img {
  width: 100%;
  height: 200px; /* Giới hạn chiều cao ảnh */
  object-fit: contain; /* Giữ nguyên tỉ lệ, không bị méo */
  background-color: #fff;
  border-radius: 10px;
}

.header-wrapper {
  margin-top: 18px;
  margin-bottom: 0;
}
.banner-voucher-row {
  display: flex;
  gap: 12px; /* Khoảng cách nhỏ giữa banner và voucher */
  align-items: stretch;
}

.banner-box {
  position: relative;
  overflow: hidden;
  height: 230px;
  min-width: 0;
  width: 100%;
  flex: 1 1 0;
  border-radius: 10px;
  background: #e3e8f0;
  display: block;
}
.banner-voucher-row {
  display: flex;
  gap: 40px; /* Khoảng cách nhỏ giữa banner và voucher */
  align-items: stretch;
}
.img-fluid.rounded-banner {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 10px;
  position: absolute;
  left: 0;
  top: 0;
  transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
  z-index: 2;
}
.banner-fade {
  opacity: 0;
}
.banner-nav {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  background: rgba(255, 255, 255, 0.85);
  border: none;
  border-radius: 50%;
  width: 32px;
  height: 32px;
  font-size: 1.3em;
  color: #1976d2;
  cursor: pointer;
  z-index: 2;
  transition:
    background 0.18s,
    color 0.18s,
    box-shadow 0.18s;
  box-shadow: 0 2px 8px #1976d233;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
}
.banner-slide-active {
  transform: translateX(0%);
  z-index: 3;
  opacity: 1;
}
.banner-slide-next {
  transform: translateX(100%);
  opacity: 1;
}
.banner-slide-prev {
  transform: translateX(-100%);
  opacity: 1;
}
.banner-nav.left {
  left: 8px;
}
.banner-nav.right {
  right: 8px;
}
.banner-nav:hover {
  background: #1976d2;
  color: #fff;
  box-shadow: 0 4px 16px #1976d244;
}
.voucher-col {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: stretch;
  height: 150px;
  gap: 40px;
  width: 180px; /* Điều chỉnh cho vừa 2 voucher nhỏ */
}

.voucher-img {
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(106, 17, 203, 0.08);
  transition:
    transform 0.18s,
    box-shadow 0.18s;
  width: 100%;
  height: 56px;
  object-fit: cover;
  margin: 0;
  background: #fff;
}
.voucher-img:hover {
  transform: scale(1.05) rotate(-2deg);
  box-shadow: 0 6px 24px rgba(37, 117, 252, 0.14);
}

.section-wrapper {
  background: #fff;
  border-radius: 18px;
  padding: 20px 14px 14px 14px;
  box-shadow: 0 2px 12px rgba(37, 117, 252, 0.06);
}
h5 {
  color: #2575fc;
  font-weight: 700;
  letter-spacing: 1px;
}
.deal-item {
  background: #f8faff;
  border-radius: 14px;
  box-shadow: 0 2px 12px rgba(37, 117, 252, 0.06);
  transition:
    transform 0.18s,
    box-shadow 0.18s;
  padding: 10px 4px 8px 4px;
  cursor: pointer;
  position: relative;
  min-height: 180px;
  font-size: 0.97em;
  border: 1px solid #e3e8f0;
}
.deal-item:hover {
  transform: translateY(-6px) scale(1.03);
  box-shadow: 0 8px 32px rgba(37, 117, 252, 0.13);
  z-index: 2;
  background: #fff;
}
.deal-img {
  border-radius: 10px;
  transition: transform 0.18s;
  max-height: 70px;
  object-fit: contain;
  margin-bottom: 8px;
  background: #fff;
  box-shadow: 0 2px 8px #e3e8f033;
}
.deal-item .fw-semibold {
  font-size: 1em;
  min-height: 36px;
  margin-bottom: 2px;
}
.deal-item .fw-bold {
  font-size: 1.08em;
}
.deal-item small {
  font-size: 0.92em;
}
.deal-item .badge {
  font-size: 0.92em;
  padding: 4px 10px;
  border-radius: 7px;
  margin-top: 2px;
  box-shadow: 0 2px 8px rgba(255, 0, 0, 0.08);
}

.voucher-col img:first-child {
  margin-top: 50px; /* hoặc giá trị bạn muốn, ví dụ 16px, 20px */
}
.row.g-3 {
  gap: 0.5rem 0 !important;
}
@media (max-width: 992px) {
  .header-wrapper {
    flex-direction: column;
  }
  .sidebar {
    display: none !important;
  }
}
.product-card {
  background: #fff;
  border-radius: 14px;
  box-shadow: 0 2px 12px rgba(37, 117, 252, 0.06);
  padding: 12px;
  transition:
    transform 0.3s ease,
    box-shadow 0.3s ease;
  cursor: pointer;
  overflow: hidden;
  position: relative;
}

.product-card:hover {
  transform: translateY(-6px) scale(1.03);
  box-shadow: 0 8px 32px rgba(37, 117, 252, 0.13);
}

.product-img {
  width: 100%;
  height: 200px;
  object-fit: contain;
  background-color: #fff;
  border-radius: 10px;
  transition: transform 0.3s ease;
}

.product-card:hover .product-img {
  transform: scale(1.05);
}

.btn-cart {
  display: inline-block;
  padding: 8px 14px;
  font-size: 0.9rem;
  background: linear-gradient(135deg, #2575fc, #6a11cb);
  color: white;
  border-radius: 6px;
  text-decoration: none;
  transition: all 0.3s ease;
}

.btn-cart:hover {
  background: linear-gradient(135deg, #6a11cb, #2575fc);
  color: #fff;
  box-shadow: 0 4px 12px rgba(37, 117, 252, 0.3);
  transform: translateY(-2px);
}
</style>

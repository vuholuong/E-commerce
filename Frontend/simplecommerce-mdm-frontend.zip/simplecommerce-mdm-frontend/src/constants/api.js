// API Endpoints Constants
export const API_ENDPOINTS = {
  // Auth endpoints
  AUTH: {
    LOGIN: '/v1/auth/login',
    REGISTER: '/v1/auth/register',
    LOGOUT: '/v1/auth/logout',
    GOOGLE: '/v1/auth/google',
    VERIFY_EMAIL: '/v1/auth/verify-email',
    FORGOT_PASSWORD: '/v1/auth/forgotpassword',
    CHANGE_PASSWORD: '/v1/auth/changepassword',
  },
  
  // User endpoints
  USER: {
    PROFILE: '/v1/users/profile',
    SHOP: '/v1/user/shop',
    CHANGE_PASSWORD: '/v1/users/change-password',
  },
  
  // Product endpoints
  PRODUCT: {
    LIST: '/v1/products',
    DETAIL: (id) => `/v1/products/${id}`,
    RELATED: (id) => `/v1/products/${id}/related`,
    BY_SHOP: (shopId) => `/v1/products/shops/${shopId}`,
    BY_CATEGORY: (categoryId) => `/v1/products/categories/${categoryId}`,
    FEATURED: '/v1/products/featured',
  },
  
  // Shop endpoints
  SHOP: {
    DETAIL: (id) => `/v1/shops/${id}`,
  },
  
  // Category endpoints
  CATEGORY: {
    LIST: '/v1/categories',
  },
  
  // Cart endpoints
  CART: {
    LIST: '/v1/cart',
    COUNT: '/v1/cart/count',
    ADD_ITEM: '/v1/cart/items',
    REMOVE_ITEM: '/v1/cart',
    UPDATE_ITEM: (id) => `/v1/cart/items/${id}`,
  },
  
  // Order endpoints
  ORDER: {
    LIST: '/v1/orders',
    CREATE: '/v1/orders',
    DETAIL: (id) => `/v1/orders/${id}`,
    CANCEL: (id) => `/v1/orders/${id}/cancel`,
    RETURN: (id) => `/v1/orders/${id}/return`,
  },
  
  // Review endpoints
  REVIEW: {
    BY_PRODUCT: (productId) => `/v1/reviews/product/${productId}`,
    STATISTICS: (productId) => `/v1/reviews/product/${productId}/statistics`,
    CREATE: '/v1/reviews',
  },
  
  // Address endpoints
  ADDRESS: {
    LIST: '/v1/addresses',
    CREATE: '/v1/addresses',
    UPDATE: (id) => `/v1/addresses/${id}`,
    DELETE: (id) => `/v1/addresses/${id}`,
    SET_DEFAULT_SHIPPING: (id) => `/v1/addresses/${id}/default-shipping`,
    SET_DEFAULT_BILLING: (id) => `/v1/addresses/${id}/default-billing`,
  },
};

// API Response Status Codes
export const API_STATUS = {
  SUCCESS: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  INTERNAL_SERVER_ERROR: 500,
};

// API Error Messages
export const API_ERROR_MESSAGES = {
  NETWORK_ERROR: 'Lỗi kết nối mạng. Vui lòng kiểm tra kết nối internet.',
  UNAUTHORIZED: 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.',
  FORBIDDEN: 'Bạn không có quyền truy cập tài nguyên này.',
  NOT_FOUND: 'Tài nguyên bạn tìm kiếm không tồn tại.',
  INTERNAL_ERROR: 'Đã xảy ra lỗi hệ thống. Vui lòng thử lại sau.',
};

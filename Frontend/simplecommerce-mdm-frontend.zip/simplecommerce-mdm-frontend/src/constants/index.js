// Application constants

// Storage Keys
export const STORAGE_KEYS = {
  ACCESS_TOKEN: 'app_access_token',
  REFRESH_TOKEN: 'app_refresh_token',
  USER_SESSION: 'app_user_session',
  // Backward compatibility
  OLD_TOKEN: 'token',
  OLD_USER: 'user',
};

// API Configuration
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || '/api',
  TIMEOUT: parseInt(import.meta.env.VITE_API_TIMEOUT) || 10000,
  RETRY_ATTEMPTS: 3,
};

// Export API constants
export { API_ENDPOINTS, API_STATUS, API_ERROR_MESSAGES } from './api';

// Route Names
export const ROUTE_NAMES = {
  HOME: 'home',
  LOGIN: 'login',
  REGISTER: 'register',
  REGISTER_SELLER: 'registerSeller',
  FORGOT_PASSWORD: 'forgotPassword',
  PRODUCT_CATALOG: 'productCatalog',
  PRODUCT_DETAIL: 'productDetail',
  ALL_PRODUCTS: 'allProducts',
  CATEGORY: 'category',
  ORDER: 'order',
  SHOPPING_CART: 'shoppingCart',
  ORDER_HISTORY: 'orderHistory',
  USER_PROFILE: 'userProfile',
  SHOP_PAGE: 'shopPage',
  SHOP_DETAIL: 'shopDetail',
  SALE_PAGE: 'salePage',
  CONTACT_PAGE: 'contactPage',
  NOT_FOUND: 'NotFound',
};

// Route Paths
export const ROUTE_PATHS = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  REGISTER_SELLER: '/register-seller',
  FORGOT_PASSWORD: '/forgot-password',
  PRODUCT_CATALOG: '/products',
  PRODUCT_DETAIL: '/product/:id',
  ALL_PRODUCTS: '/products/all',
  CATEGORY: '/category/:id',
  ORDER: '/order',
  SHOPPING_CART: '/cart',
  ORDER_HISTORY: '/order-history',
  USER_PROFILE: '/profile',
  SHOP_PAGE: '/shop',
  SHOP_DETAIL: '/shop/:shopId',
  SALE_PAGE: '/sale',
  CONTACT_PAGE: '/contact',

  // Legacy paths (for backward compatibility)
  LEGACY_LOGIN: '/dn',
  LEGACY_REGISTER: '/dk',
  LEGACY_REGISTER_SELLER: '/RegisterSeller',
  LEGACY_PRODUCT_CATALOG: '/all',
  LEGACY_ORDER: '/dh',
  LEGACY_SHOPPING_CART: '/gh',
  LEGACY_USER_PROFILE: '/info',
  LEGACY_ORDER_HISTORY: '/dhct',
  LEGACY_SHOP: '/cuahang',
  LEGACY_ALL_PRODUCTS: '/Allsanpham',
};

// HTTP Status Codes
export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  INTERNAL_SERVER_ERROR: 500,
};

// Pagination
export const PAGINATION = {
  DEFAULT_PAGE_SIZE: 12,
  MAX_PAGE_SIZE: 100,
  DEFAULT_PAGE: 1,
};

// Currency
export const CURRENCY = {
  DEFAULT: 'VND',
  LOCALE: 'vi-VN',
};

// Date Format
export const DATE_FORMAT = {
  LOCALE: 'vi-VN',
  DISPLAY: {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  },
  SHORT: {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  },
};

// Validation Rules
export const VALIDATION = {
  PASSWORD_MIN_LENGTH: 8,
  PASSWORD_MAX_LENGTH: 128,
  USERNAME_MIN_LENGTH: 3,
  USERNAME_MAX_LENGTH: 50,
  EMAIL_MAX_LENGTH: 255,
  PHONE_MAX_LENGTH: 15,
};

// Error Messages
export const ERROR_MESSAGES = {
  REQUIRED_FIELD: 'Trường này là bắt buộc',
  INVALID_EMAIL: 'Email không hợp lệ',
  PASSWORD_TOO_SHORT: 'Mật khẩu phải có ít nhất 8 ký tự',
  PASSWORDS_NOT_MATCH: 'Mật khẩu không khớp',
  NETWORK_ERROR: 'Lỗi kết nối mạng',
  SERVER_ERROR: 'Lỗi máy chủ',
  UNAUTHORIZED: 'Bạn không có quyền truy cập',
  NOT_FOUND: 'Không tìm thấy dữ liệu',
};

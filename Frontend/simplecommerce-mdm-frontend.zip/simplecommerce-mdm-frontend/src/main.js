import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import router from './router';
import 'bootstrap/dist/css/bootstrap.css';
import { setupAxiosInterceptors, checkTokenExpiry } from '@/stores/auth';

const app = createApp(App);
const pinia = createPinia();
app.use(pinia);
app.use(router);

// ✅ setup axios interceptor sau khi Pinia đã được khởi tạo
setupAxiosInterceptors();

// ✅ check token expiry ngay khi load app
checkTokenExpiry();

app.mount('#app');
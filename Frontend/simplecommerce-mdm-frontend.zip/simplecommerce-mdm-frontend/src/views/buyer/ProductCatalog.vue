<template>
  <div class="store-container">
    <!-- Header Store Banner -->
    <div class="position-relative mb-2 shop-banner">
      <img
        src="/src/assets/images/banershop.png"
        class="img-fluid w-100 rounded-top"
        style="height: 200px; object-fit: cover"
        alt="Store banner"
      />
      <div class="position-absolute top-0 start-0 d-flex align-items-center p-3 w-100">
        <img
          src="/src/assets/images/logofaker.jpg"
          alt="avatar"
          style="
            width: 56px;
            height: 56px;
            border-radius: 50%;
            border: 2px solid #fff;
            object-fit: cover;
          "
        />
        <div class="ms-3">
          <div class="fw-bold" style="font-size: 1.2rem; color: #d48ca6">Faker Store</div>
          <div class="small text-dark">
            <span>⭐ 4.9/5</span>
            <span class="mx-2">|</span>
            <span>200 người theo dõi</span>
            <span class="mx-2">|</span>
            <span>Tỉ lệ hồi chat: 90%</span>
          </div>
        </div>
        <div class="ms-auto d-flex gap-1">
          <button
            class="btn btn-outline-secondary btn-sm"
            style="color: #f7a9c4; border-color: #f7a9c4"
          >
            <i class="bi bi-chat-dots"></i> Chat
          </button>
          <button
            class="btn btn-outline-secondary btn-sm"
            style="color: #f7a9c4; border-color: #f7a9c4"
          >
            <i class="bi bi-person-plus"></i> Theo dõi
          </button>
        </div>
      </div>
      <ul
        class="nav nav-underline position-absolute bottom-0 start-0 w-100 px-3"
        style="background: rgba(255, 255, 255, 0.9)"
      >
        <li class="nav-item">
          <router-link class="nav-link" :to="{ name: 'shopPage' }">Cửa hàng</router-link>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="#">Tất cả sản phẩm</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Mã sốc hôm nay</a>
        </li>
      </ul>
    </div>

    <!-- BANNER SLIDER START -->
    <div id="bannerCarousel" class="carousel slide carousel-fade mb-4" data-bs-ride="carousel">
      <div class="carousel-indicators">
        <button
          type="button"
          data-bs-target="#bannerCarousel"
          data-bs-slide-to="0"
          class="active"
        ></button>
        <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="2"></button>
        <button type="button" data-bs-target="#bannerCarousel" data-bs-slide-to="3"></button>
      </div>

      <div class="carousel-inner rounded-4 shadow">
        <div class="carousel-item active">
          <img
            src="/src/assets/images/banner3.png"
            class="d-block w-100"
            alt="Banner 1"
            style="object-fit: cover; height: 570px"
            loading="lazy"
          />
        </div>
        <div class="carousel-item">
          <img
            src="/src/assets/images/baner2.png"
            class="d-block w-100"
            alt="Banner 2"
            style="object-fit: cover; height: 570px"
            loading="lazy"
          />
        </div>
        <div class="carousel-item">
          <img
            src="/src/assets/images/baner4.png"
            class="d-block w-100"
            alt="Banner 3"
            style="object-fit: cover; height: 570px"
            loading="lazy"
          />
        </div>
        <div class="carousel-item">
          <img
            src="/src/assets/images/banner5.png"
            class="d-block w-100"
            alt="Banner 4"
            style="object-fit: cover; height: 570px"
            loading="lazy"
          />
        </div>
      </div>

      <button
        class="carousel-control-prev"
        type="button"
        data-bs-target="#bannerCarousel"
        data-bs-slide="prev"
      >
        <span class="carousel-control-prev-icon"></span>
      </button>
      <button
        class="carousel-control-next"
        type="button"
        data-bs-target="#bannerCarousel"
        data-bs-slide="next"
      >
        <span class="carousel-control-next-icon"></span>
      </button>
    </div>
    <!-- BANNER SLIDER END -->

    <!-- Gợi ý cho bạn -->
    <div class="mb-4">
      <div class="row g-4 justify-content-center">
        <div class="col-5th d-flex" v-for="(item, idx) in suggestProducts" :key="'suggest-' + idx">
          <div class="card h-100 border-0 flex-fill shadow-sm">
            <img
              :src="item.img"
              class="card-img-top rounded"
              alt=""
              style="height: 240px; object-fit: cover"
            />
            <div class="card-body p-3 text-center">
              <p class="card-text fw-bold mb-2" style="font-size: 1.15rem">{{ item.name }}</p>
              <div class="d-flex justify-content-center align-items-center mb-2" style="gap: 8px">
                <span class="fw-bold text-primary" style="font-size: 1.1rem"
                  >{{ item.price.toLocaleString() }}VND</span
                >
                <span class="badge bg-light border text-secondary" style="font-size: 1rem">{{
                  item.discount
                }}</span>
              </div>
              <div class="d-flex justify-content-center align-items-center" style="gap: 8px">
                <span style="color: #f7a900; font-size: 1.2rem">★</span>
                <span style="font-size: 1.05rem">4.9</span>
                <span class="text-muted" style="font-size: 1rem">Đã bán {{ item.sold }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const suggestProducts = [
  {
    img: '/src/assets/images/aothuntheu.webp',
    name: 'Áo thun thêu hoa bất tử',
    price: 86000,
    discount: '-49%',
    sold: '3k',
  },
  {
    img: '/src/assets/images/aothunnu.webp',
    name: 'Áo thun nữ dáng ôm',
    price: 82000,
    discount: '-49%',
    sold: '2k',
  },
  {
    img: '/src/assets/images/aothunhoatiet.webp',
    name: 'Áo thun họa tiết nơ',
    price: 65000,
    discount: '-54%',
    sold: '1k',
  },
  {
    img: '/src/assets/images/aothun1.webp',
    name: 'Áo thun HEAVEN BUTTERFLY',
    price: 81000,
    discount: '-44%',
    sold: '1k',
  },
  {
    img: '/src/assets/images/aobabylove.webp',
    name: 'Áo thun body thuê',
    price: 65000,
    discount: '-54%',
    sold: '1.5k',
  },

  {
    img: '/src/assets/images/aothuntaylo.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 37000,
    discount: '-54%',
    sold: '5k',
    active: true,
  },
  {
    img: '/src/assets/images/aothuntaylo2.webp',
    name: 'Áo thun nữ tay lỡ',
    price: 37000,
    discount: '-54%',
    sold: '300',
    active: false,
  },
  {
    img: '/src/assets/images/aobabyteee.webp',
    name: 'Áo baby tee đình nơ',
    price: 52000,
    discount: '-49%',
    sold: '4k',
    active: false,
  },
  {
    img: '/src/assets/images/aonamnu2.webp',
    name: 'Áo thun nam rớt form rộng',
    price: 35000,
    discount: '-54%',
    sold: '1k',
    active: false,
  },
  {
    img: '/src/assets/images/aoboxy.webp',
    name: 'Áo thun boxy',
    price: 161000,
    discount: '-49%',
    sold: '2k',
    active: false,
  },

  {
    img: '/src/assets/images/aovn.webp',
    name: 'Áo thun nam nữ unisex',
    price: 65000,
    // discount: '-54%',
    sold: '1k',
    active: false,
  },
  {
    img: '/src/assets/images/aothuntheucotton.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 97000,
    discount: '-51%',
    sold: '1k',
    active: false,
  },
  {
    img: '/src/assets/images/aothunin.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 39000,
    discount: '-44%',
    sold: '1k',
    active: false,
  },
  {
    img: '/src/assets/images/aothunso7.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 79000,
    discount: '-41%',
    sold: '1.5k',
    active: false,
  },
  {
    img: '/src/assets/images/aopolo.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 149000,
    discount: '-50%',
    sold: '2k',
    active: false,
  },

  {
    img: '/src/assets/images/aothunphoi1.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 89000,
    discount: '-49%',
    sold: '2k',
    active: false,
  },
  {
    img: '/src/assets/images/aobabyteee.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 37000,
    discount: '-40%',
    sold: '3k',
    active: false,
  },
  {
    img: '/src/assets/images/aothun.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 35000,
    discount: '-13%',
    sold: '1k',
    active: false,
  },
  {
    img: '/src/assets/images/aothun2.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 35000,
    discount: '-55%',
    sold: '6k',
    active: false,
  },
  {
    img: '/src/assets/images/aothunom.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 39000,
    discount: '-54%',
    sold: '5k',
    active: false,
  },
];
</script>

<style scoped>
.store-container {
  max-width: 1280px;
  margin: 40px auto 0 auto;
  border-radius: 18px;
  background: #fff;
  border: 1px solid #e5e7eb;
  box-shadow: 0 2px 16px 0 rgba(0, 0, 0, 0.06);
  padding: 40px 40px 40px 40px;
}

.shop-banner {
  border-radius: 18px 18px 0 0;
  overflow: hidden;
}

.card-img-top {
  height: 240px;
  object-fit: cover;
}

.card {
  border-radius: 16px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.07);
  padding-bottom: 12px;
  transition:
    box-shadow 0.2s,
    transform 0.2s;
  background: #fff;
}

.card-body {
  background: #fff;
}

.card:hover {
  box-shadow: 0 4px 24px 0 rgba(212, 140, 166, 0.15);
  transform: translateY(-4px) scale(1.03);
}

.text-pink {
  color: #d48ca6 !important;
}

.nav-underline .nav-link {
  color: #1976d2 !important;
  border: 1.5px solid transparent;
  border-radius: 12px 12px 0 0;
  background: #fff;
  font-weight: 500;
  margin-right: 8px;
  padding: 8px 22px 8px 22px;
  transition: all 0.2s;
}

.nav-underline .nav-link.active {
  background: #f7e3ea;
  color: #c06b8e !important;
  border: 1.5px solid #f7a9c4;
  border-bottom: 3px solid #f7a9c4;
  font-weight: bold;
  box-shadow: 0 2px 8px 0 rgba(212, 140, 166, 0.1);
}

.nav-underline .nav-link:not(.active):hover {
  border: none;
  border-bottom: 2px solid #1976d2;
  color: #1976d2 !important;
  background: #fff;
  box-shadow: none;
}

.col-5th {
  flex: 0 0 20%;
  max-width: 20%;
}

@media (max-width: 1200px) {
  .col-5th {
    flex: 0 0 25%;
    max-width: 25%;
  }
}

@media (max-width: 992px) {
  .col-5th {
    flex: 0 0 33.3333%;
    max-width: 33.3333%;
  }
}

@media (max-width: 768px) {
  .col-5th {
    flex: 0 0 50%;
    max-width: 50%;
  }
}

@media (max-width: 576px) {
  .col-5th {
    flex: 0 0 100%;
    max-width: 100%;
  }
}
</style>

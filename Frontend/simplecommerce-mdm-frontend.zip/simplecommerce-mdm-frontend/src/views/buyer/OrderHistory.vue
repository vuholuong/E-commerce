<template>
  <div class="container my-5" v-if="profileLoaded">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-3 col-lg-2 bg-info text-white py-4 min-vh-100">
        <div class="d-flex align-items-center mb-4">
          <div class="ms-3 text-center">
            <div class="fw-bold">Tài khoản của</div>
            <img :src="avatarPreview" alt="avatar" class="rounded-circle" width="100" height="100" />
            <div>{{ form.firstName }} {{ form.lastName }}</div>
            <!-- Nút đăng ký seller -->
            <button class="btn btn-outline-light btn-sm mt-2" @click="goToSellerRegistration">
              <i class="bi bi-shop me-1"></i>
              Đăng ký Seller
            </button>
          </div>
        </div>
        <ul class="nav flex-column">
          <li class="nav-item mb-2 d-flex align-items-center">
            <i class="bi bi-card-list me-2"></i>
            <router-link class="dropdown-item ps-0" to="/cart">Quản lý giỏ hàng</router-link>
          </li>
          <li class="nav-item mb-2 d-flex align-items-center">
            <i class="bi bi-person me-2"></i>
            <router-link class="dropdown-item ps-0" to="/profile">Thông tin tài khoản</router-link>
          </li>
          <li class="nav-item mb-2 d-flex align-items-center">
            <i class="bi bi-key me-2"></i>
            <button class="dropdown-item ps-0 text-start text-white" @click="showPasswordModal = true">
              Đổi mật khẩu
            </button>
          </li>
        </ul>
      </div>

      <!-- Modal đổi mật khẩu -->
      <div class="modal fade" tabindex="-1" :class="{ show: showPasswordModal }" style="display: block" v-if="showPasswordModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title"><b>Đổi mật khẩu</b></h5>
              <button type="button" class="btn-close" @click="closePasswordModal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label">Mật khẩu cũ</label>
                <input type="password" class="form-control" v-model="passwordForm.oldPassword" />
              </div>
              <div class="mb-3">
                <label class="form-label">Mật khẩu mới</label>
                <input type="password" class="form-control" v-model="passwordForm.newPassword" />
              </div>
              <div class="mb-3">
                <label class="form-label">Xác nhận mật khẩu mới</label>
                <input type="password" class="form-control" v-model="passwordForm.confirmPassword" />
              </div>
            </div>
            <div class="modal-footer">
              <button class="btn btn-secondary" @click="closePasswordModal">Hủy</button>
              <button class="btn btn-primary" :disabled="loadingPassword" @click="changePassword">
                <span v-if="loadingPassword" class="spinner-border spinner-border-sm me-1"></span>
                {{ loadingPassword ? "Đang đổi..." : "Đổi mật khẩu" }}
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-backdrop fade show" v-if="showPasswordModal"></div>

      <!-- Content -->
      <div class="col-md-9 col-lg-10">
        <div class="order-container">
          <h2 class="mb-4">Danh sách đơn hàng</h2>

          <!-- Tabs -->
          <div class="tab-bar">
            <button
                v-for="(label, key) in statusTabs"
                :key="key"
                class="tab-btn"
                :class="{ active: activeTab === key }"
                @click="activeTab = key"
            >
              {{ label }}
              <span v-if="countOrdersByStatus(key) > 0" class="badge">
                {{ countOrdersByStatus(key) }}
              </span>
            </button>
          </div>

          <!-- Loading / Empty -->
          <div v-if="loading" class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
              <span class="visually-hidden">Đang tải...</span>
            </div>
            <p class="mt-2">Đang tải đơn hàng...</p>
          </div>
          <div v-else-if="filteredOrders.length === 0" class="text-center py-5">
            <i class="bi bi-cart-x" style="font-size: 3rem;"></i>
            <p class="mt-3">Không có đơn hàng nào.</p>
          </div>

          <!-- Danh sách đơn -->
          <div v-else>
            <div v-for="order in filteredOrders" :key="order.id" class="order-card">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <h5 class="m-0">Đơn hàng #{{ order.orderNumber }}</h5>
                <div class="d-flex gap-2">
                  <span
                      v-for="s in mapStatus(order.orderStatus)"
                      :key="s"
                      class="status-tag"
                      :class="statusClass(s)"
                  >
                    {{ s }}
                  </span>
                </div>
              </div>

              <!-- Shop -->
              <div class="order-header">
                <span class="shop-name">🏬 {{ order.shopName }}</span>
              </div>

              <!-- Danh sách sản phẩm -->
              <div v-if="order.orderItems && order.orderItems.length" class="order-items">
                <div v-for="item in order.orderItems" :key="item.id" class="order-item">
                  <img
                      v-if="getProductImage(item, order)"
                      :src="getProductImage(item, order)"
                      alt="product image"
                      class="order-img"
                  />

                  <div class="item-info">
                    <p class="product-name">{{ item.productNameSnapshot || 'Sản phẩm' }}</p>
                    <p v-if="item.variantOptionsSnapshot" class="variant">
                      <b>Phân loại hàng:</b> {{ item.variantOptionsSnapshot }}
                    </p>
                    <p class="quantity"><b>Số Lượng:</b> {{ item.quantity }}</p>
                    <p class="date"><b>Ngày đặt:</b> {{ formatDate(order.orderedAt) }}</p>
                  </div>

                  <div class="item-actions">
                    <p class="price">
                      <strong>Đơn Giá: </strong>
                      <span class="number">{{ formatCurrency(item.unitPrice) }}</span>
                    </p>
                    <p class="total">
                      <strong>Tổng: </strong>
                      <span class="number">{{ formatCurrency(item.subtotal) }}</span>
                    </p>

                    <button v-if="order.orderStatus === 'DELIVERED' && item.reviewed" class="view-review-btn" @click="viewReview(item.reviewId, item)"> Xem đánh giá </button>
                    <button v-if="order.orderStatus === 'DELIVERED' && !item.reviewed" class="review-btn" @click="openReviewModal(order.id, item, order)"> Đánh giá </button>
                  </div>
                </div>
                <!-- ✅ nút HỦY & TRẢ HÀNG chỉ hiện 1 lần cho cả đơn -->
                <div class="item-actions">
                  <button v-if="order.orderStatus === 'AWAITING_CONFIRMATION'"
                          class="cancel-btn"
                          @click="cancelOrder(order.id)">
                    Hủy đơn
                  </button>
                </div>
                <!-- Tổng đơn hàng -->
                <div class="order-total mt-3 pt-3 border-top">
                  <p class="text-end fw-bold fs-5">
                    Tổng cộng: <span class="text-danger">{{ formatCurrency(order.totalAmount) }}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> <!-- End content -->
    </div>

    <!-- Review Modal -->
    <div v-if="showReviewModal" class="modal-overlay" @click="closeReviewModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h5>Đánh giá sản phẩm</h5>
          <button type="button" class="btn-close" @click="closeReviewModal"></button>
        </div>
        <div class="modal-body">
          <div class="review-product-info">
            <img :src="reviewImage || fallbackImage" class="review-product-img" />
            <div>
              <h6>{{ reviewItem?.productNameSnapshot || 'Sản phẩm' }}</h6>
              <p v-if="reviewItem?.variantOptionsSnapshot">{{ reviewItem.variantOptionsSnapshot }}</p>
            </div>
          </div>
          <div class="rating-section">
            <label>Chất lượng sản phẩm:</label>
            <div class="star-rating">
              <span v-for="star in 5" :key="star" class="star" :class="{ filled: star <= reviewRating }" @click="setReviewRating(star)">★</span>
            </div>
          </div>
          <div class="form-group">
            <label>Nội dung đánh giá:</label>
            <textarea v-model="reviewComment" class="form-control" rows="4" maxlength="1000" placeholder="Chia sẻ cảm nhận của bạn..."></textarea>
            <small class="text-muted">{{ reviewComment.length }}/1000 ký tự</small>
          </div>
          <div v-if="submitError" class="alert alert-danger mt-3">
            <i class="bi bi-exclamation-triangle me-2"></i>{{ submitError }}
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="closeReviewModal">Hủy</button>
          <button class="btn btn-primary" @click="submitReview" :disabled="submittingReview || reviewRating === 0">
            <span v-if="submittingReview" class="spinner-border spinner-border-sm me-1"></span>
            {{ submittingReview ? 'Đang gửi...' : 'Gửi đánh giá' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from "@/api/axios";
import { API_ENDPOINTS } from "@/constants";
import { useAuthStore } from '@/stores/auth';
import { ref, reactive, computed, onMounted } from 'vue';
import Swal from "sweetalert2";
import { useRouter } from 'vue-router';

export default {
  name: "OrderProduct",
  setup() {
    const router = useRouter();
    const authStore = useAuthStore();

    // Profile
    const profileLoaded = ref(false);
    const form = reactive({ firstName: '', lastName: '' });
    const avatarPreview = ref('');

    // Orders
    const orders = ref([]);
    const loading = ref(false);
    const activeTab = ref("ALL");
    const fallbackImage = ref("/images/no-image.jpg");
    const statusTabs = reactive({
      ALL: "Tất cả",
      AWAITING_CONFIRMATION: "Chờ xác nhận",
      PROCESSING: "Đang xử lý",
      SHIPPED: "Đang giao",
      DELIVERED: "Đã giao",
      CANCEL_RETURN: "Đã hủy / Trả hàng",
      COMPLETED: "Hoàn tất"
    });

    // Review modal
    const showReviewModal = ref(false);
    const reviewItem = ref(null);
    const reviewImage = ref(null);
    const reviewRating = ref(0);
    const reviewComment = ref('');
    const submittingReview = ref(false);
    const orderIdForReview = ref(null);
    const submitError = ref(null);

    // Password modal
    const showPasswordModal = ref(false);
    const passwordForm = reactive({ oldPassword: '', newPassword: '', confirmPassword: '' });
    const loadingPassword = ref(false);

    // Fetch profile
    async function loadProfile() {
      try {
        await authStore.fetchProfile();
        if (authStore.profile) {
          Object.assign(form, authStore.profile);
          avatarPreview.value = authStore.profile.avatarUrl || '';
        }
      } catch (e) {
        console.error("Lỗi fetch profile:", e);
      } finally {
        profileLoaded.value = true;
      }
    }

    // Fetch orders (list + details)
    async function fetchOrders() {
      loading.value = true;
      try {
        const res = await api.get(API_ENDPOINTS.ORDER.LIST, {
          params: { page: 0, size: 50 }
        });

        const list = res.data?.data?.content || [];

        // Map to detailed orders (fetch detail per order)
        orders.value = await Promise.all(list.map(async o => {
          try {
            const detail = await api.get(API_ENDPOINTS.ORDER.DETAIL(o.id));

            const orderDetail = detail.data?.data || o;

            // ensure orderItems images
            if (orderDetail.orderItems) {
              orderDetail.orderItems = await Promise.all(
                  orderDetail.orderItems.map(async i => {
                    if (!i.imageUrl && i.productId) {
                      try {
                        const productRes = await api.get(API_ENDPOINTS.PRODUCT.DETAIL(i.productId));
                        i.imageUrl = productRes.data.data?.imageUrls?.[0] || fallbackImage.value;
                      } catch (err) {
                        console.error("❌ Lỗi khi fetch hình ảnh sản phẩm:", err);
                        i.imageUrl = fallbackImage.value;
                      }
                    }
                    return i;
                  })
              );
            }

            return orderDetail;
          } catch (err) {
            console.error("❌ Lỗi khi lấy chi tiết đơn:", err);
            return o;
          }
        }));
      } catch (e) {
        console.error("❌ Lỗi khi fetch orders:", e);
        Swal.fire("Lỗi", "Không thể tải đơn hàng", "error");
      } finally {
        loading.value = false;
      }
    }

    // cancel order
    async function cancelOrder(id) {
      const confirm = await Swal.fire({ title: "Bạn có chắc?", text: "Hủy đơn?", showCancelButton: true });
      if (!confirm.isConfirmed) return;
      try {
        await api.put(API_ENDPOINTS.ORDER.CANCEL(id));
        Swal.fire("Thành công", "Đã hủy đơn", "success");
        await fetchOrders();
      } catch (e) {
        Swal.fire("Lỗi", "Hủy đơn thất bại", "error");
      }
    }

    // request return
    async function requestReturn(id) {
      const confirm = await Swal.fire({ title: "Trả hàng?", showCancelButton: true });
      if (!confirm.isConfirmed) return;
      try {
        await api.put(API_ENDPOINTS.ORDER.RETURN(id));
        Swal.fire("Thành công", "Đã gửi yêu cầu trả", "success");
        await fetchOrders();
      } catch (e) {
        Swal.fire("Lỗi", "Trả hàng thất bại", "error");
      }
    }

    // get product image with fallback logic
    function getProductImage(item, order) {
      if (item?.imageUrl) return item.imageUrl;
      if (order?.orderItems) {
        const currentItem = order.orderItems.find(i => i.id === item.id);
        if (currentItem && currentItem.imageUrl) return currentItem.imageUrl;
      }
      return fallbackImage.value;
    }

    // review modal open/close
    function openReviewModal(orderId, item, order) {
      if (!item?.productId) {
        Swal.fire("Lỗi", "Thiếu thông tin sản phẩm", "error");
        return;
      }
      orderIdForReview.value = orderId;
      reviewItem.value = item;
      reviewImage.value = getProductImage(item, order);
      reviewRating.value = 0;
      reviewComment.value = '';
      submitError.value = null;
      showReviewModal.value = true;
      console.log("Mở modal đánh giá cho:", item.productId);
    }

    function closeReviewModal() {
      showReviewModal.value = false;
      reviewItem.value = null;
      reviewImage.value = null;
      orderIdForReview.value = null;
      reviewRating.value = 0;
      reviewComment.value = '';
      submitError.value = null;
    }

    function setReviewRating(star) {
      reviewRating.value = star;
    }

    // submit review
    async function submitReview() {
      if (reviewRating.value === 0) {
        submitError.value = "Vui lòng chọn sao";
        return;
      }
      submittingReview.value = true;
      submitError.value = null;
      try {
        const token = localStorage.getItem("app_access_token");
        const data = {
          productId: reviewItem.value.productId,
          orderId: orderIdForReview.value,
          rating: reviewRating.value,
          comment: reviewComment.value
        };
        console.log("Dữ liệu gửi đi:", data);
        const res = await api.post(API_ENDPOINTS.REVIEW.CREATE, data);
        Swal.fire("Thành công", res.data?.message || "Đã gửi đánh giá", "success");
        closeReviewModal();
        await fetchOrders();
      } catch (e) {
        console.error("Lỗi khi gửi đánh giá:", e.response?.data || e);
        submitError.value = e.response?.data?.message || "Gửi đánh giá thất bại";
        Swal.fire("Lỗi", submitError.value, "error");
      } finally {
        submittingReview.value = false;
      }
    }

    // view review (navigate)
    function viewReview(id, item) {
      if (item?.productId) {
        router.push(`/product/${item.productId}?reviewId=${id}`);
      } else {
        Swal.fire("Lỗi", "Không thể xem đánh giá", "error");
      }
    }

    // tab helpers
    function countOrdersByStatus(s) {
      if (s === "ALL") return orders.value.length;
      if (s === "CANCEL_RETURN") {
        return orders.value.filter(o =>
            ["CANCELLED","CANCELLED_BY_USER","CANCELLED_BY_SELLER","CANCELLED_BY_ADMIN","RETURN_REQUESTED","RETURN_APPROVED","RETURNED"]
                .includes(o.orderStatus)
        ).length;
      }
      return orders.value.filter(o => o.orderStatus === s).length;
    }

    function statusClass(txt) {
      if (txt.includes("Chờ")) return "status-pending";
      if (txt.includes("Xử lý") || txt.includes("giao")) return "status-processing";
      if (txt.includes("Hoàn tất") || txt.includes("thanh toán")) return "status-success";
      if (txt.includes("hủy") || txt.includes("trả")) return "status-cancel";
      return "";
    }

    function formatDate(d) {
      return d ? new Date(d).toLocaleString("vi-VN") : "";
    }

    function formatCurrency(a) {
      return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(a || 0);
    }

    function mapStatus(s) {
      return {
        PENDING_PAYMENT: ["Chờ thanh toán"],
        AWAITING_CONFIRMATION: ["Chờ xác nhận"],
        PROCESSING: ["Đang xử lý"],
        SHIPPED: ["Đang giao"],
        DELIVERED: ["Đã giao"],
        COMPLETED: ["Hoàn tất"],
        CANCELLED: ["Đã hủy"],
        CANCELLED_BY_USER: ["Hủy bởi khách"],
        CANCELLED_BY_SELLER: ["Hủy bởi shop"],
        CANCELLED_BY_ADMIN: ["Hủy bởi admin"],
        RETURN_REQUESTED: ["Yêu cầu trả hàng"],
        RETURN_APPROVED: ["Đã chấp nhận trả"],
        RETURNED: ["Đã trả"],
        FAILED: ["Thất bại"]
      }[s] || [s];
    }

    // password modal handlers
    function closePasswordModal() {
      showPasswordModal.value = false;
      passwordForm.oldPassword = '';
      passwordForm.newPassword = '';
      passwordForm.confirmPassword = '';
    }

    async function changePassword() {
      const { oldPassword, newPassword, confirmPassword } = passwordForm;
      if (!oldPassword || !newPassword || !confirmPassword) {
        Swal.fire('Lỗi', 'Vui lòng nhập đầy đủ các trường mật khẩu.', 'error');
        return;
      }
      const pwdRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,255}$/;
      if (!pwdRegex.test(newPassword)) {
        Swal.fire('Lỗi', 'Mật khẩu mới phải từ 8 ký tự, gồm ít nhất 1 chữ thường, 1 chữ hoa, 1 số và 1 ký tự đặc biệt (@$!%*?&).', 'error');
        return;
      }
      if (newPassword === oldPassword) {
        Swal.fire('Lỗi', 'Mật khẩu mới phải khác mật khẩu hiện tại.', 'error');
        return;
      }
      if (newPassword !== confirmPassword) {
        Swal.fire('Lỗi', 'Xác nhận mật khẩu không khớp.', 'error');
        return;
      }

      loadingPassword.value = true;
      try {
        const ok = await authStore.changePassword(oldPassword, newPassword, confirmPassword);
        if (ok) {
          Swal.fire('Thành công', 'Đổi mật khẩu thành công.', 'success');
          closePasswordModal();
        } else {
          const backendMsg = (authStore.error || '').toLowerCase();
          let vnMsg = 'Đổi mật khẩu thất bại.';
          if (backendMsg.includes('current password is incorrect')) vnMsg = 'Mật khẩu hiện tại không đúng.';
          else if (backendMsg.includes('new password must be different')) vnMsg = 'Mật khẩu mới phải khác mật khẩu hiện tại.';
          else if (backendMsg.includes('confirm password does not match')) vnMsg = 'Xác nhận mật khẩu không khớp.';
          Swal.fire('Lỗi', vnMsg, 'error');
        }
      } catch (e) {
        console.error("Lỗi đổi mật khẩu:", e);
        Swal.fire('Lỗi', 'Đổi mật khẩu thất bại.', 'error');
      } finally {
        loadingPassword.value = false;
      }
    }

    // seller registration nav
    function goToSellerRegistration() {
      router.push('/register-seller');
    }

    // computed filteredOrders
    const filteredOrders = computed(() => {
      if (activeTab.value === "ALL") return orders.value;
      if (activeTab.value === "CANCEL_RETURN") {
        return orders.value.filter(o =>
            ["CANCELLED","CANCELLED_BY_USER","CANCELLED_BY_SELLER","CANCELLED_BY_ADMIN","RETURN_REQUESTED","RETURN_APPROVED","RETURNED"]
                .includes(o.orderStatus)
        );
      }
      return orders.value.filter(o => o.orderStatus === activeTab.value);
    });

    // initial load
    onMounted(async () => {
      await loadProfile();
      await fetchOrders();
    });

    return {
      // profile
      profileLoaded, form, avatarPreview,

      // orders
      orders, loading, activeTab, fallbackImage, statusTabs,
      filteredOrders,

      // methods & helpers
      fetchOrders, cancelOrder, requestReturn, getProductImage,
      openReviewModal, closeReviewModal, submitReview, viewReview,
      countOrdersByStatus, statusClass, formatDate, formatCurrency, mapStatus,

      // review modal state
      showReviewModal, reviewItem, reviewImage, reviewRating, reviewComment,
      submittingReview, orderIdForReview, submitError, setReviewRating,

      // password modal
      showPasswordModal, passwordForm, loadingPassword, closePasswordModal, changePassword,

      // seller
      goToSellerRegistration
    };
  }
};
</script>

<style scoped>
/* Container tổng */
.container {
  background: #f9fafb;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: #333;
}

/* Sidebar */
.col-md-3.col-lg-2 {
  background: linear-gradient(180deg, #4facfe, #00f2fe);
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  position: sticky;
  top: 1rem;
  height: fit-content;
}

.col-md-3.col-lg-2 .fw-bold {
  font-size: 0.9rem;
  opacity: 0.9;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.col-md-3.col-lg-2 img {
  border: 3px solid #fff;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
  margin: 0.5rem 0;
}

.nav .nav-item {
  padding: 0.6rem 0.8rem;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.nav .nav-item:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateX(5px);
}

.nav .nav-item i {
  font-size: 1.1rem;
}

.nav .dropdown-item {
  color: #fff !important;
  font-weight: 500;
  text-decoration: none;
}

/* Nút đăng ký seller */
.btn-outline-light {
  border: 1px solid rgba(255, 255, 255, 0.5);
  color: #fff;
  transition: all 0.3s ease;
}

.btn-outline-light:hover {
  background: rgba(255, 255, 255, 0.2);
  border-color: #fff;
  transform: translateY(-2px);
}

/* Nội dung bên phải */
.col-md-9.col-lg-10 {
  background: #fff;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
}

/* Tiêu đề section */
h2 {
  font-weight: 600;
  color: #4facfe;
  border-left: 4px solid #00f2fe;
  padding-left: 10px;
  margin-bottom: 1.5rem;
}

/* Tabs */
.tab-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  flex-wrap: wrap;
  border-bottom: 1px solid #eee;
  padding-bottom: 15px;
}

.tab-btn {
  background: #f1f1f1;
  border: 1px solid #ddd;
  padding: 8px 16px;
  border-radius: 25px;
  cursor: pointer;
  transition: all 0.2s;
  font-weight: 500;
  color: #333;
}

.tab-btn.active {
  background: linear-gradient(90deg, #4facfe, #00f2fe);
  color: #fff;
  border-color: #4facfe;
}

.badge {
  background: #fff;
  color: #4facfe;
  border-radius: 50%;
  padding: 2px 8px;
  margin-left: 5px;
  font-size: 0.8rem;
}

/* Order Card */
.order-card {
  border: 1px solid #e0e0e0;
  padding: 20px;
  margin-bottom: 20px;
  border-radius: 12px;
  background: white;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}
.item-actions {
  display: flex;
  flex-direction: column; /* ép xuống dòng */
  align-items: flex-end;  /* nếu muốn căn phải */
  gap: 4px;               /* khoảng cách giữa 2 dòng */
}


.item-actions button {
  font-size: 15px;        /* chữ nhỏ lại */
  padding: 4px 10px;      /* nút nhỏ gọn */
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.cancel-btn {
  background: #ff4d4f;
  color: #fff;
  border: none;
}

.cancel-btn:hover {
  background: #d9363e;
}

.return-btn {
  background: #4facfe;
  color: #fff;
  border: none;
}

.return-btn:hover {
  background: #3a8dde;
}

/* Status Tag */
.status-tag {
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 0.9rem;
  font-weight: 600;
}

.status-pending {
  background: #fff3cd;
  color: #856404;
}

.status-processing {
  background: #cce5ff;
  color: #004085;
}

.status-success {
  background: #d4edda;
  color: #155724;
}

.status-cancel {
  background: #f8d7da;
  color: #721c24;
}

/* Order Items */
.order-items {
  margin-top: 10px;
  border-top: 1px solid #eee;
}

.order-item {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
  gap: 12px;
}

.order-img {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border: 1px solid #eee;
  border-radius: 6px;
}

.item-info {
  flex: 1;
  font-size: 14px;
  color: #444;
}

.item-info .product-name {
  font-weight: 600;
  margin-bottom: 4px;
}

.item-info .variant {
  font-size: 13px;
  color: #666;
}

.item-info .quantity,
.item-info .date {
  font-size: 13px;
  color: #888;
}

.item-actions {
  text-align: right;
  min-width: 120px;
}

.item-actions .price {
  font-size: 14px;
  font-weight: 500;
  color: #222;
}

.item-actions .total {
  font-size: 13px;
  color: #555;
  margin-bottom: 8px;
}

.price .number {
  color: #ee4d2d;
  font-size: 15px;
  font-weight: 600;
}

.total .number {
  color: #ee4d2d;
  font-size: 17px;
  font-weight: 700;
}

.order-total {
  border-top: 2px dashed #ddd !important;
}

/* Loading spinner */
.spinner-border {
  width: 3rem;
  height: 3rem;
}

/* Review Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}

.modal-header {
  padding: 1rem;
  border-bottom: 1px solid #dee2e6;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: linear-gradient(90deg, #4facfe, #00f2fe);
  color: white;
  border-radius: 8px 8px 0 0;
}

.modal-body {
  padding: 1.5rem;
}

.modal-footer {
  padding: 1rem;
  border-top: 1px solid #dee2e6;
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}

.review-product-info {
  display: flex;
  align-items: center;
  margin-bottom: 1.5rem;
  gap: 1rem;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
}

.review-product-img {
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 4px;
  border: 1px solid #ddd;
}

.star-rating {
  display: flex;
  gap: 0.5rem;
  margin: 0.5rem 0;
}

.star {
  font-size: 2rem;
  color: #ccc;
  cursor: pointer;
  transition: color 0.2s, transform 0.2s;
}

.star.filled {
  color: #ffc107;
  transform: scale(1.1);
}

.star:hover {
  color: #ffc107;
  transform: scale(1.2);
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: #333;
}

.form-control {
  border: 1px solid #ced4da;
  border-radius: 0.375rem;
  padding: 0.75rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.form-control:focus {
  border-color: #86b7fe;
  outline: 0;
  box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

.alert-danger {
  background-color: #f8d7da;
  border-color: #f5c6cb;
  color: #721c24;
  padding: 0.75rem 1.25rem;
  border-radius: 0.25rem;
  margin-top: 1rem;
  display: flex;
  align-items: center;
}

/* Action Buttons */
.cancel-btn, .return-btn, .review-btn, .view-review-btn {
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  cursor: pointer;
  margin-top: 10px;
  font-weight: 500;
  display: block;
  width: 100%;
  text-align: center;
  transition: all 0.3s ease;
}

.cancel-btn {
  background-color: #dc3545;
}
.cancel-btn:hover {
  background-color: #c82333;
  transform: translateY(-2px);
}
.return-btn {
  background-color: #ff9800;
}
.return-btn:hover {
  background-color: #e68900;
  transform: translateY(-2px);
}
.review-btn {
  background: linear-gradient(90deg, #4facfe, #00f2fe);
}
.review-btn:hover {
  opacity: 0.9;
  transform: translateY(-2px);
}
.view-review-btn {
  background-color: #17a2b8;
}
.view-review-btn:hover {
  background-color: #138496;
  transform: translateY(-2px);
}

/* Responsive design */
@media (max-width: 768px) {
  .order-item {
    flex-direction: column;
    align-items: flex-start;
  }

  .item-actions {
    text-align: left;
    width: 100%;
    margin-top: 1rem;
  }

  .review-product-info {
    flex-direction: column;
    text-align: center;
  }

  .modal-content {
    width: 95%;
    margin: 1rem;
  }

  .tab-bar {
    overflow-x: auto;
    padding-bottom: 0.5rem;
  }
}
</style>

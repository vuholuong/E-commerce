<template>
  <div class="voucher-bg py-3">
    <div class="container">
      <!-- Banner -->
      <div class="voucher-banner text-center mb-4">
        <img
          src="https://i.pinimg.com/736x/9b/e7/de/9be7debcfe8b1c93d7ad82b14e7c2595.jpg"
          alt="banner"
          class="img-fluid"
          style="max-width: 100%; border-radius: 20px"
          height="100%"
          width="100%"
        />
      </div>
      <!-- Title -->
      <div class="mb-3" style="font-size: 1.15rem">Voucher giảm giá phí vận chuyển</div>
      <!-- Voucher List -->
      <div class="d-flex flex-wrap gap-3">
        <div
          class="voucher-card d-flex flex-row align-items-center"
          v-for="(voucher, idx) in vouchers"
          :key="idx"
        >
          <div class="voucher-logo d-flex flex-column align-items-center justify-content-center">
            <div class="voucher-logo-main">MUADI<br /><span class="vip">VIP</span></div>
            <div class="voucher-logo-sub">Miễn phí<br />vận chuyển</div>
          </div>
          <div class="voucher-info flex-grow-1 px-3 py-2">
            <div class="voucher-type mb-1">
              <span class="badge bg-primary text-white">{{ voucher.type }}</span>
            </div>
            <div class="voucher-title fw-bold mb-1">{{ voucher.title }}</div>
            <div class="voucher-desc text-muted mb-1" style="font-size: 0.98rem">
              {{ voucher.desc }}
            </div>
            <div class="voucher-exp text-muted" style="font-size: 0.95rem">
              HSD: {{ voucher.exp }}
            </div>
          </div>
          <div
            class="voucher-action d-flex flex-column align-items-end justify-content-between h-100 py-2 pe-3"
          >
            <button class="btn btn-primary btn-sm">Lưu</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const vouchers = [
  {
    type: 'Vàng',
    title: 'Giảm 10K',
    desc: 'Số lượng có hạn',
    exp: '30/06/25',
  },
  {
    type: 'Vàng',
    title: 'Giảm 50K',
    desc: 'Cho đơn hàng từ 250K',
    exp: '30/06/25',
  },
  {
    type: 'Bạc',
    title: 'Giảm 20K',
    desc: 'Cho đơn từ 100K',
    exp: '30/07/25',
  },
  {
    type: 'Đồng',
    title: 'Giảm 5K',
    desc: 'Số lượng có hạn',
    exp: '15/07/25',
  },
  {
    type: 'Đồng',
    title: 'Giảm 15K',
    desc: 'Cho đơn từ 150K',
    exp: '15/07/25',
  },
  {
    type: 'Đồng',
    title: 'Giảm 30K',
    desc: 'Cho đơn từ 200K',
    exp: '15/07/25',
  },
];
</script>

<style scoped>
.voucher-bg {
  background: #e6f1fd;
  min-height: 100vh;
}
.voucher-banner {
  margin-bottom: 32px;
}
.voucher-card {
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 2px 12px #0001;
  min-width: 380px;
  max-width: 420px;
  width: 100%;
  padding: 0;
  margin-bottom: 12px;
  border: 2px solid #fff;
  transition:
    box-shadow 0.2s,
    border 0.2s;
}
.voucher-card:hover {
  box-shadow: 0 4px 24px #1976d222;
  border: 2px solid #1976d2;
}
.voucher-logo {
  background: #4fc08d;
  color: #fff;
  width: 110px;
  min-width: 110px;
  height: 100%;
  border-radius: 14px 0 0 14px;
  justify-content: center;
  align-items: center;
  padding: 18px 0 18px 0;
  text-align: center;
}
.voucher-logo-main {
  font-size: 1.35rem;
  font-weight: bold;
  line-height: 1.1;
}
.voucher-logo-main .vip {
  background: #fff;
  color: #4fc08d;
  border-radius: 4px;
  font-size: 0.85rem;
  padding: 1px 6px;
  margin-left: 2px;
  font-weight: 700;
  display: inline-block;
}
.voucher-logo-sub {
  font-size: 0.98rem;
  margin-top: 6px;
  line-height: 1.1;
}
.voucher-info {
  min-width: 0;
}
.voucher-title {
  font-size: 1.15rem;
  color: #222;
}
.voucher-action {
  min-width: 100px;
}
</style>

<template>
  <div class="container my-5" v-if="profileLoaded">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-3 col-lg-2 bg-dark text-white py-4 min-vh-100">
        <div class="d-flex align-items-center mb-4">
          <div class="ms-3 text-center">
            <div class="fw-bold">Tài khoản của</div>
            <img :src="avatarPreview" alt="avatar" class="rounded-circle" width="100" height="100" />
            <div>{{ form.firstName }} {{ form.lastName }}</div>
            <!-- Nút đăng ký seller -->
            <button class="btn btn-outline-light btn-sm mt-2" @click="goToSellerRegistration">
              <i class="bi bi-shop me-1"></i>
              Đăng ký Seller
            </button>
          </div>
        </div>
        <ul class="nav flex-column">
          <li class="nav-item mb-2 d-flex align-items-center">
            <i class="bi bi-person me-2"></i>
            <router-link class="dropdown-item ps-0" to="/profile">Thông tin tài khoản</router-link>
          </li>
          <li class="nav-item mb-2 d-flex align-items-center">
            <i class="bi bi-card-list me-2"></i>
            <router-link class="dropdown-item ps-0" to="/order-history">Quản lý đơn hàng</router-link>
          </li>
          <li class="nav-item mb-2 d-flex align-items-center">
            <i class="bi bi-key me-2"></i>
            <button class="dropdown-item ps-0 text-start text-white" @click="showPasswordModal = true">
              Đổi mật khẩu
            </button>
          </li>
        </ul>
      </div>

      <!-- Modal đổi mật khẩu -->
      <div class="modal fade" tabindex="-1" :class="{ show: showPasswordModal }" style="display: block"
        v-if="showPasswordModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title"><b>Đổi mật khẩu</b></h5>
              <button type="button" class="btn-close" @click="closePasswordModal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label">Mật khẩu cũ</label>
                <input type="password" class="form-control" v-model="passwordForm.oldPassword" />
              </div>
              <div class="mb-3">
                <label class="form-label">Mật khẩu mới</label>
                <input type="password" class="form-control" v-model="passwordForm.newPassword" />
              </div>
              <div class="mb-3">
                <label class="form-label">Xác nhận mật khẩu mới</label>
                <input type="password" class="form-control" v-model="passwordForm.confirmPassword" />
              </div>
            </div>
            <div class="modal-footer">
              <button class="btn btn-secondary" @click="closePasswordModal">Hủy</button>
              <button class="btn btn-primary" @click="changePassword" :disabled="loadingPassword">
                {{ loadingPassword ? 'Đang xử lý...' : 'Đổi mật khẩu' }}
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-backdrop fade show" v-if="showPasswordModal"></div>

      <!-- Nội dung -->
      <div class="col-md-9 col-lg-10">
        <div class="row">
          <!-- Thông tin cá nhân -->
          <div class="col-md-6 border-end">
            <h5 class="mb-4">Thông tin cá nhân</h5>
            <div class="mb-3 text-center">
              <img :src="avatarPreview" alt="avatar" class="rounded-circle" width="100" height="100" />
              <div class="mt-2">
                <button class="btn btn-outline-secondary btn-sm" @click="triggerFileInput">
                  Chọn ảnh
                </button>
                <input ref="fileInput" type="file" accept="image/*" class="d-none" @change="onAvatarChange" />
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label">Họ</label>
              <input type="text" class="form-control" v-model="form.lastName" />
            </div>
            <div class="mb-3">
              <label class="form-label">Tên</label>
              <input type="text" class="form-control" v-model="form.firstName" />
            </div>
            <div class="mb-3">
              <label class="form-label">Ngày sinh</label>
              <input type="date" class="form-control" v-model="form.birthDate" />
            </div>
            <div class="mb-3">
              <label class="form-label">Giới tính</label>
              <select class="form-control" v-model="form.gender">
                <option value="">Chọn giới tính</option>
                <option value="male">Nam</option>
                <option value="female">Nữ</option>
                <option value="other">Khác</option>
              </select>
            </div>

            <button class="btn btn-primary" @click="updateProfile" :disabled="loadingProfile">
              {{ loadingProfile ? 'Đang lưu...' : 'Lưu thay đổi' }}
            </button>
          </div>

          <!-- Tài khoản -->
          <div class="col-md-6">
            <h5 class="mb-4">Tài khoản</h5>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" :value="authStore.profile?.email" readonly />
            </div>
            <div class="mb-3">
              <label class="form-label">Số điện thoại</label>
              <div v-if="!authStore.profile?.phoneNumber">
                <input type="text" class="form-control" placeholder="Nhập số điện thoại" v-model="newPhoneNumber" />
              </div>
              <div v-else>
                <input type="text" class="form-control" :value="authStore.profile.phoneNumber" readonly />
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label">Ngày tạo tài khoản</label>
              <input type="text" class="form-control" :value="authStore.profile?.createdAt
                ? new Date(authStore.profile.createdAt).toLocaleDateString()
                : 'Chưa có'
                " readonly />
            </div>
            <!-- Địa chỉ -->
            <div class="mb-3">
              <label class="form-label">Địa chỉ</label>
              <div v-if="addressStore.addresses.length">
                <div v-for="addr in addressStore.addresses" :key="addr.id"
                  class="border rounded p-2 mb-2 d-flex justify-content-between align-items-start">
                  <div>
                    <div>
                      <b>{{ addr.contactFullName }}</b> - {{ addr.contactPhoneNumber }}
                    </div>
                    <div>
                      {{ addr.streetAddress1 }}
                      <span v-if="addr.streetAddress2">, {{ addr.streetAddress2 }}</span>, {{ addr.ward }}, {{
                        addr.district }}, {{ addr.city }},
                      {{ addr.countryCode === 'VN' ? 'Việt Nam' : addr.countryCode }}
                    </div>

                    <div>
                      <small>
                        <span v-if="addr.isDefaultShipping">[Mặc định giao hàng]</span>
                        <span v-if="addr.isDefaultBilling">[Mặc định thanh toán]</span>
                      </small>
                    </div>
                  </div>
                  <div class="d-flex flex-column ms-3">
                    <button class="btn btn-outline-primary btn-compact" @click="editAddress(addr)">
                      Sửa
                    </button>
                    <button class="btn btn-outline-danger btn-compact" @click="deleteAddress(addr.id)">
                      Xóa
                    </button>
                  </div>
                </div>
              </div>
              <div v-else>Chưa có địa chỉ</div>
              <button class="btn btn-outline-primary btn-sm mt-2" @click="openAddressModal">
                <i class="bi bi-plus"></i> Thêm địa chỉ
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal địa chỉ -->
  <div class="modal fade" tabindex="-1" :class="{ show: showAddressModal }" style="display: block"
    v-if="showAddressModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">
            <b>{{ editingAddress ? 'Cập nhật địa chỉ' : 'Thêm địa chỉ' }}</b>
          </h5>
          <button type="button" class="btn-close" @click="closeAddressModal"></button>
        </div>
        <div class="modal-body">
          <!-- Form thêm / sửa -->
          <div class="mb-2">
            <label class="form-label">Họ tên</label>
            <input v-model="addressForm.contactFullName" type="text" class="form-control"
              :class="{ 'is-invalid': addressErrors.contactFullName }" />
            <div v-if="addressErrors.contactFullName" class="text-danger">
              {{ addressErrors.contactFullName }}
            </div>
          </div>

          <div class="mb-2">
            <label class="form-label">Số điện thoại</label>
            <input v-model="addressForm.contactPhoneNumber" type="text" class="form-control"
              :class="{ 'is-invalid': addressErrors.contactPhoneNumber }" />
            <div v-if="addressErrors.contactPhoneNumber" class="text-danger">
              {{ addressErrors.contactPhoneNumber }}
            </div>
          </div>

          <div class="mb-2">
            <label class="form-label">Tỉnh/Thành phố</label>
            <select v-model="addressForm.city" class="form-control" @change="onProvinceChange"
              :class="{ 'is-invalid': addressErrors.city }" :disabled="loadingProvinces">
              <option value="">
                {{ loadingProvinces ? 'Đang tải...' : 'Chọn tỉnh/thành phố' }}
              </option>
              <option v-for="province in provinces" :key="province.code" :value="province.name">
                {{ province.name }}
              </option>
            </select>
            <div v-if="addressErrors.city" class="text-danger">{{ addressErrors.city }}</div>
          </div>

          <div class="mb-2">
            <label class="form-label">Phường/Xã</label>
            <select v-model="addressForm.ward" class="form-control" @change="onWardChange"
              :class="{ 'is-invalid': addressErrors.ward }" :disabled="loadingWards || !addressForm.city">
              <option value="">
                {{
                  loadingWards
                    ? 'Đang tải...'
                    : !addressForm.city
                      ? 'Vui lòng chọn tỉnh trước'
                      : 'Chọn phường/xã'
                }}
              </option>
              <option v-for="ward in filteredWards" :key="ward.code" :value="ward.name">
                {{ ward.name }}
              </option>
            </select>
            <div v-if="addressErrors.ward" class="text-danger">{{ addressErrors.ward }}</div>
          </div>

          <div class="mb-2">
            <label class="form-label">Địa chỉ</label>
            <input v-model="addressForm.streetAddress1" type="text" class="form-control"
              :class="{ 'is-invalid': addressErrors.streetAddress1 }" />
            <div v-if="addressErrors.streetAddress1" class="text-danger">
              {{ addressErrors.streetAddress1 }}
            </div>
          </div>

          <div class="mb-2">
            <label class="form-label">Địa chỉ bổ sung</label>
            <input v-model="addressForm.streetAddress2" type="text" class="form-control" />
          </div>

          <div class="mb-2">
            <label class="form-label">Quốc gia</label>
            <input type="text" class="form-control" value="Việt Nam" readonly />
          </div>

          <div class="mb-2">
            <label class="form-label">Loại địa chỉ</label>
            <select v-model="addressForm.addressType" class="form-control">
              <option value="SHIPPING">Giao hàng</option>
              <option value="BILLING">Thanh toán</option>
            </select>
          </div>

          <div class="form-check mb-2">
            <input v-model="addressForm.isDefaultShipping" type="checkbox" class="form-check-input"
              id="defaultShipping" />
            <label class="form-check-label" for="defaultShipping">Đặt làm mặc định giao hàng</label>
          </div>

          <div class="form-check mb-2">
            <input v-model="addressForm.isDefaultBilling" type="checkbox" class="form-check-input"
              id="defaultBilling" />
            <label class="form-check-label" for="defaultBilling">Đặt làm mặc định thanh toán</label>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="closeAddressModal">Đóng</button>
          <button class="btn btn-primary" @click="saveAddress" :disabled="loadingSave">
            {{ loadingSave ? 'Đang lưu...' : editingAddress ? 'Cập nhật' : 'Thêm' }}
          </button>
        </div>
      </div>
    </div>
  </div>
  <div class="modal-backdrop fade show" v-if="showAddressModal"></div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useAuthStore } from '@/stores/auth';
import { useAddressStore } from '@/stores/addressStore';
import { useRouter } from 'vue-router';
import Swal from 'sweetalert2';

const authStore = useAuthStore();
const addressStore = useAddressStore();
const router = useRouter();

// ===== PROFILE =====
const profileLoaded = ref(false);
const loadingProfile = ref(false);
const form = ref({
  firstName: '',
  lastName: '',
  birthDate: '',
  gender: '',
});
const avatarFile = ref(null);
const avatarPreview = ref('https://cdn-icons-png.flaticon.com/512/847/847969.png');
const fileInput = ref(null);

// Simple cache helpers using sessionStorage to reduce Firebase calls
const CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
function getCache(key) {
  try {
    const raw = sessionStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || Date.now() - parsed.timestamp > CACHE_TTL_MS) return null;
    return parsed.data;
  } catch {
    return null;
  }
}
function setCache(key, data) {
  try {
    sessionStorage.setItem(key, JSON.stringify({ timestamp: Date.now(), data }));
  } catch { }
}

function triggerFileInput() {
  fileInput.value.click();
}

function onAvatarChange(e) {
  const file = e.target.files[0];
  if (file) {
    avatarFile.value = file;
    avatarPreview.value = URL.createObjectURL(file);
  }
}

async function updateProfile() {
  loadingProfile.value = true;

  try {
    // Parse metadata từ form
    const metadata = {
      birthDate: form.value.birthDate,
      gender: form.value.gender,
    };

    const updateData = {
      firstName: form.value.firstName,
      lastName: form.value.lastName,
      metadata: JSON.stringify(metadata),
    };

    const ok = await authStore.updateProfile(updateData, avatarFile.value);
    if (ok) {
      Swal.fire('Thành công', 'Cập nhật hồ sơ thành công', 'success');
    } else {
      Swal.fire('Lỗi', authStore.error || 'Cập nhật thất bại', 'error');
    }
  } catch (error) {
    Swal.fire('Lỗi', 'Có lỗi xảy ra khi cập nhật hồ sơ', 'error');
  }

  loadingProfile.value = false;
}

// ===== PASSWORD =====
const showPasswordModal = ref(false);
const passwordForm = ref({ oldPassword: '', newPassword: '', confirmPassword: '' });
const loadingPassword = ref(false);

function closePasswordModal() {
  showPasswordModal.value = false;
  passwordForm.value = { oldPassword: '', newPassword: '', confirmPassword: '' };
}

async function changePassword() {
  const { oldPassword, newPassword, confirmPassword } = passwordForm.value;
  // Client-side validations for consistent UX
  if (!oldPassword || !newPassword || !confirmPassword) {
    Swal.fire('Lỗi', 'Vui lòng nhập đầy đủ các trường mật khẩu.', 'error');
    return;
  }
  // Must be between 8 and 255 characters and satisfy complexity
  const pwdRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,255}$/;
  if (!pwdRegex.test(newPassword)) {
    Swal.fire(
      'Lỗi',
      'Mật khẩu mới phải từ 8 ký tự, gồm ít nhất 1 chữ thường, 1 chữ hoa, 1 số và 1 ký tự đặc biệt (@$!%*?&).',
      'error'
    );
    return;
  }
  if (newPassword === oldPassword) {
    Swal.fire('Lỗi', 'Mật khẩu mới phải khác mật khẩu hiện tại.', 'error');
    return;
  }
  if (newPassword !== confirmPassword) {
    Swal.fire('Lỗi', 'Xác nhận mật khẩu không khớp.', 'error');
    return;
  }
  loadingPassword.value = true;
  try {
    const ok = await authStore.changePassword(oldPassword, newPassword, confirmPassword);
    if (ok) {
      Swal.fire('Thành công', 'Đổi mật khẩu thành công.', 'success');
      closePasswordModal();
    } else {
      // Map backend English messages to Vietnamese for consistency
      const backendMsg = (authStore.error || '').toLowerCase();
      let vnMsg = 'Đổi mật khẩu thất bại.';
      if (backendMsg.includes('current password is incorrect')) vnMsg = 'Mật khẩu hiện tại không đúng.';
      else if (backendMsg.includes('new password must be different')) vnMsg = 'Mật khẩu mới phải khác mật khẩu hiện tại.';
      else if (backendMsg.includes('confirm password does not match')) vnMsg = 'Xác nhận mật khẩu không khớp.';
      Swal.fire('Lỗi', vnMsg, 'error');
    }
  } finally {
    loadingPassword.value = false;
  }
}

// ===== SELLER REGISTRATION =====
function goToSellerRegistration() {
  router.push('/register-seller');
}

// ===== Địa chỉ =====
const showAddressModal = ref(false);
const editingAddress = ref(null);
const loadingSave = ref(false);
const addressErrors = ref({});

// Data for dropdowns
const provinces = ref([]);
const wards = ref([]);
const filteredWards = ref([]);
const loadingProvinces = ref(false);
const loadingWards = ref(false);

const addressForm = ref({
  streetAddress1: '',
  streetAddress2: '',
  ward: '',
  district: '',
  city: '',
  postalCode: '',
  countryCode: 'VN', // mặc định VN
  contactFullName: '',
  contactPhoneNumber: '',
  addressType: 'SHIPPING', // hoặc 'BILLING'
  isDefaultShipping: false,
  isDefaultBilling: false,
});

// Fetch provinces from Firebase API with cache
const fetchProvinces = async () => {
  loadingProvinces.value = true;
  try {
    const cached = getCache('vn_provinces');
    if (cached && Array.isArray(cached) && cached.length) {
      provinces.value = cached;
      return;
    }
    const response = await fetch(
      'https://vietnam-address-api-default-rtdb.asia-southeast1.firebasedatabase.app/provinces.json',
      {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        mode: 'cors',
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (!data) {
      console.error('No data received from provinces API');
      Swal.fire('Lỗi', 'Không nhận được dữ liệu từ API', 'error');
      return;
    }

    // Convert object to array and filter out null values
    const provincesArray = Object.values(data).filter(province => province && province.name);

    if (provincesArray.length === 0) {
      console.error('No valid provinces found in API response');
      Swal.fire('Lỗi', 'Không tìm thấy dữ liệu tỉnh/thành phố hợp lệ', 'error');
      return;
    }

    // Sort by name
    provinces.value = provincesArray.sort((a, b) => a.name.localeCompare(b.name, 'vi'));
    setCache('vn_provinces', provinces.value);
  } catch (error) {
    console.error('Error fetching provinces:', error);
    Swal.fire('Lỗi', 'Không thể tải danh sách tỉnh/thành phố: ' + error.message, 'error');
  } finally {
    loadingProvinces.value = false;
  }
};

// Fetch wards from Firebase API with cache
const fetchWards = async () => {
  loadingWards.value = true;
  try {
    const cached = getCache('vn_wards');
    if (cached && Array.isArray(cached) && cached.length) {
      wards.value = cached;
      return;
    }
    const response = await fetch(
      'https://vietnam-address-api-default-rtdb.asia-southeast1.firebasedatabase.app/wards.json'
    );
    const data = await response.json();

    if (!data) {
      console.error('No data received from wards API');
      Swal.fire('Lỗi', 'Không nhận được dữ liệu từ API phường/xã', 'error');
      return;
    }

    // Convert object to array and filter out null values
    const wardsArray = Object.values(data).filter(ward => ward && ward.name);

    if (wardsArray.length === 0) {
      console.error('No valid wards found in API response');
      Swal.fire('Lỗi', 'Không tìm thấy dữ liệu phường/xã hợp lệ', 'error');
      return;
    }

    wards.value = wardsArray;
    setCache('vn_wards', wards.value);
  } catch (error) {
    console.error('Error fetching wards:', error);
    Swal.fire('Lỗi', 'Không thể tải danh sách phường/xã: ' + error.message, 'error');
  } finally {
    loadingWards.value = false;
  }
};

// Filter wards based on selected province
const filterWardsByProvince = provinceName => {
  if (!provinceName || !wards.value.length) {
    filteredWards.value = [];
    return;
  }

  filteredWards.value = wards.value
    .filter(ward => ward.path_with_type?.includes(provinceName))
    .sort((a, b) => a.name.localeCompare(b.name, 'vi'));

  // no-op
};

// Handle province selection
const onProvinceChange = event => {
  const selectedProvince = provinces.value.find(p => p.name === event.target.value);
  if (selectedProvince) {
    addressForm.value.city = selectedProvince.name;
    filterWardsByProvince(selectedProvince.name_with_type);
  } else {
    addressForm.value.city = '';
    filteredWards.value = [];
  }
  // Clear ward selection when province changes
  addressForm.value.ward = '';
};

// Handle ward selection
const onWardChange = event => {
  const selectedWard = filteredWards.value.find(w => w.name === event.target.value);
  if (selectedWard) {
    addressForm.value.ward = selectedWard.name;
  }
};

// Validation rules
const validateAddressForm = () => {
  const errors = {};

  // Required fields
  if (!addressForm.value.streetAddress1?.trim()) {
    errors.streetAddress1 = 'Địa chỉ là bắt buộc';
  }

  if (!addressForm.value.ward?.trim()) {
    errors.ward = 'Phường/Xã là bắt buộc';
  }

  if (!addressForm.value.city?.trim()) {
    errors.city = 'Tỉnh/Thành phố là bắt buộc';
  }

  if (!addressForm.value.contactFullName?.trim()) {
    errors.contactFullName = 'Họ tên là bắt buộc';
  }

  if (!addressForm.value.contactPhoneNumber?.trim()) {
    errors.contactPhoneNumber = 'Số điện thoại là bắt buộc';
  } else if (!/^[0-9]{10,11}$/.test(addressForm.value.contactPhoneNumber)) {
    errors.contactPhoneNumber = 'Số điện thoại phải có 10-11 chữ số';
  }

  addressErrors.value = errors;
  return Object.keys(errors).length === 0;
};

function resetForm() {
  addressForm.value = {
    contactFullName: '',
    contactPhoneNumber: '',
    streetAddress1: '',
    streetAddress2: '',
    ward: '',
    district: '',
    city: '',
    postalCode: '',
    countryCode: 'VN',
    addressType: 'SHIPPING',
    isDefaultShipping: false,
    isDefaultBilling: false,
  };
  addressErrors.value = {}; // Clear validation errors
  filteredWards.value = []; // Clear filtered wards
}

function closeAddressModal() {
  showAddressModal.value = false;
  editingAddress.value = null;
  resetForm();
}

// New function to ensure address data (provinces/wards) is loaded
const ensureAddressDataLoaded = async () => {
  if (provinces.value.length === 0 && !loadingProvinces.value) {
    await fetchProvinces();
  }
  if (wards.value.length === 0 && !loadingWards.value) {
    await fetchWards();
  }
};

async function openAddressModal() {
  await ensureAddressDataLoaded(); // Ensure data is loaded before showing modal
  showAddressModal.value = true;
}

async function editAddress(addr) {
  editingAddress.value = addr;
  addressForm.value = { ...addr };
  addressErrors.value = {}; // Clear validation errors when editing

  await ensureAddressDataLoaded(); // Ensure data is loaded

  // Now populate the dropdowns
  if (addr.city) {
    const province = provinces.value.find(p => p.name === addr.city);
    if (province) {
      addressForm.value.city = province.name; // Set the city name for the dropdown
      // Manually trigger the ward filtering based on the selected province
      filterWardsByProvince(province.name_with_type);

      // After filtering wards, set the specific ward
      const ward = filteredWards.value.find(w => w.name === addr.ward);
      if (ward) {
        addressForm.value.ward = ward.name; // Set the ward name for the dropdown
      } else {
        addressForm.value.ward = ''; // Clear if not found
      }
    } else {
      addressForm.value.city = ''; // Clear if province not found
      addressForm.value.ward = ''; // Clear ward too
    }
  } else {
    addressForm.value.city = ''; // Clear if no city in address
    addressForm.value.ward = ''; // Clear ward too
  }

  showAddressModal.value = true; // Open the modal
}

async function saveAddress() {
  if (!validateAddressForm()) {
    Swal.fire('Lỗi', 'Vui lòng điền đầy đủ và đúng thông tin địa chỉ.', 'error');
    return;
  }

  loadingSave.value = true;
  try {
    if (editingAddress.value) {
      await addressStore.updateAddress(editingAddress.value.id, addressForm.value);
      Swal.fire('Thành công', 'Cập nhật địa chỉ thành công', 'success');
    } else {
      await addressStore.createAddress(addressForm.value);
      Swal.fire('Thành công', 'Thêm địa chỉ thành công', 'success');
    }
    await addressStore.fetchAddresses();
    resetForm();
    editingAddress.value = null;
    showAddressModal.value = false;
  } catch (e) {
    Swal.fire('Lỗi', addressStore.error || 'Không lưu được địa chỉ', 'error');
  } finally {
    loadingSave.value = false;
  }
}

async function deleteAddress(id) {
  // Client-side guard: prevent deleting only/default address to align with backend
  const addr = addressStore.addresses.find(a => a.id === id);
  if (addressStore.addresses.length <= 1) {
    Swal.fire('Lỗi', 'Không thể xóa địa chỉ duy nhất. Bạn phải có ít nhất một địa chỉ.', 'error');
    return;
  }
  if (addr && (addr.isDefaultShipping || addr.isDefaultBilling)) {
    Swal.fire('Lỗi', 'Không thể xóa địa chỉ mặc định. Vui lòng đặt địa chỉ khác làm mặc định trước.', 'error');
    return;
  }

  const result = await Swal.fire({
    title: 'Xác nhận xóa địa chỉ',
    text: 'Bạn có chắc muốn xóa địa chỉ này? Hành động này không thể hoàn tác.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy',
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
  });

  if (!result.isConfirmed) return;

  try {
    await addressStore.deleteAddress(id);
    Swal.fire('Thành công', 'Đã xóa địa chỉ thành công', 'success');
  } catch (e) {
    // Error message is already set in store with Vietnamese translation
    Swal.fire('Lỗi', addressStore.error, 'error');
  }
}

// ===== On mounted =====
onMounted(async () => {
  // Clean up old hiddenAddressIds from localStorage
  localStorage.removeItem('hiddenAddressIds');

  await authStore.fetchProfile();
  if (authStore.profile) {
    form.value = {
      firstName: authStore.profile.firstName || '',
      lastName: authStore.profile.lastName || '',
      birthDate: '',
      gender: '',
    };

    // Parse metadata để lấy birthDate và gender
    if (authStore.profile.metadata) {
      try {
        const metadata = JSON.parse(authStore.profile.metadata);
        form.value.birthDate = metadata.birthDate || '';
        form.value.gender = metadata.gender || '';
      } catch (error) {
        console.error('Error parsing metadata:', error);
      }
    }

    if (authStore.profile.avatarUrl) {
      avatarPreview.value = authStore.profile.avatarUrl;
    }
  }

  await addressStore.fetchAddresses();

  // Load address data early to improve UX
  await ensureAddressDataLoaded();

  profileLoaded.value = true;
});
</script>

<style scoped>
/* Container tổng */
.container {
  background: #f9fafb;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: #333;
}

/* Sidebar */
.col-md-3.col-lg-2 {
  background: linear-gradient(180deg, #4facfe, #00f2fe);
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  position: sticky;
  top: 1rem;
  height: fit-content;
}

.col-md-3.col-lg-2 .fw-bold {
  font-size: 0.9rem;
  opacity: 0.9;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.col-md-3.col-lg-2 img {
  border: 3px solid #fff;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
  margin: 0.5rem 0;
}

.nav .nav-item {
  padding: 0.6rem 0.8rem;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.nav .nav-item:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateX(5px);
}

.nav .nav-item i {
  font-size: 1.1rem;
}

.nav .dropdown-item {
  color: #fff !important;
  font-weight: 500;
  text-decoration: none;
}

/* Nút đăng ký seller */
.btn-outline-light {
  border: 1px solid rgba(255, 255, 255, 0.5);
  color: #fff;
  transition: all 0.3s ease;
}

.btn-outline-light:hover {
  background: rgba(255, 255, 255, 0.2);
  border-color: #fff;
  transform: translateY(-2px);
}

/* Nội dung bên phải */
.col-md-9.col-lg-10 {
  background: #fff;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
}

/* Tiêu đề section */
h5 {
  font-weight: 600;
  color: #4facfe;
  border-left: 4px solid #00f2fe;
  padding-left: 10px;
  margin-bottom: 1.5rem;
}

/* Avatar */
.text-center img {
  border: 3px solid #4facfe;
  padding: 2px;
  transition: all 0.3s;
}

.text-center img:hover {
  transform: scale(1.05);
}

/* Input và nút */
.form-label {
  font-weight: 500;
  color: #555;
}

.form-control {
  border-radius: 8px;
  border: 1px solid #ddd;
  padding: 0.6rem 1rem;
  transition: border 0.3s;
}

.form-control:focus {
  border-color: #4facfe;
  box-shadow: 0 0 0 0.15rem rgba(79, 172, 254, 0.25);
}

.btn {
  border-radius: 8px;
  padding: 0.6rem 1.2rem;
  font-weight: 500;
  transition: all 0.3s ease;
}

.btn-primary {
  background: linear-gradient(90deg, #4facfe, #00f2fe);
  border: none;
}

.btn-primary:hover {
  opacity: 0.9;
  transform: translateY(-2px);
}

.btn-outline-secondary {
  border-radius: 50px;
  border: 1px solid #aaa;
}

/* Modal */
.modal-content {
  border-radius: 12px;
  overflow: hidden;
  color: #333;
}

.modal-header {
  background: linear-gradient(90deg, #4facfe, #00f2fe);
}

.modal-header .modal-title {
  color: #fff !important;
  font-weight: 600;
}

.modal-body label {
  font-weight: 500;
  color: #444;
}

.modal-footer .btn-secondary {
  background: #f1f1f1;
  color: #333;
  border: none;
}

.modal-footer .btn-secondary:hover {
  background: #e2e2e2;
}

.modal-footer .btn-primary {
  background: linear-gradient(90deg, #4facfe, #00f2fe);
  color: #fff;
  border: none;
}

/* Validation error styling */
.text-danger {
  color: #dc3545;
  font-size: 0.875rem;
  margin-top: 0.25rem;
}

.form-control.is-invalid {
  border-color: #dc3545;
  box-shadow: 0 0 0 0.15rem rgba(220, 53, 69, 0.25);
}

.form-control.is-invalid:focus {
  border-color: #dc3545;
  box-shadow: 0 0 0 0.15rem rgba(220, 53, 69, 0.25);
}

/* Custom button classes */
.btn-compact {
  padding: 0.4rem 0.8rem;
  font-size: 0.85rem;
  border-radius: 6px;
}
</style>

<template>
  <div class="container py-4">
    <!-- Loading state -->
    <div v-if="productStore.isLoading" class="text-center py-5">
      <span class="spinner-border text-primary"></span>
      <p>Đang tải sản phẩm...</p>
    </div>

    <!-- Error state -->
    <div v-else-if="productStore.error" class="alert alert-danger">
      {{ productStore.error }}
    </div>

    <!-- Main content -->
    <div v-else-if="product" class="row g-3">
      <!-- Product images -->
      <div class="col-md-5">
        <div class="border rounded p-3 h-100 bg-white">
          <img
            :src="selectedImg"
            class="img-fluid mb-3 border rounded"
            alt="Product image"
            style="max-height: 400px; object-fit: contain"
            @error="handleImageError"
          />
          <div v-if="product.imageUrls?.length" class="d-flex gap-2 justify-content-center flex-wrap">
            <img
              v-for="(img, i) in product.imageUrls"
              :key="i"
              :src="img"
              class="img-thumbnail"
              :class="{ 'border-primary': selectedImg === img }"
              style="width: 60px; height: 60px; cursor: pointer; object-fit: cover"
              @click="selectedImg = img"
              @error="handleImageError"
            />
          </div>
        </div>
      </div>

      <!-- Product info -->
      <div class="col-md-7">
        <div class="border rounded p-4 h-100 bg-white">
          <h3 class="fw-bold mb-4">{{ product.name }}</h3>

          <!-- Rating & sold -->
          <div class="d-flex align-items-center mb-3">
            <div class="fw-bold" style="font-size: 1.1rem">{{ avgRating }}/5</div>
                <div style="color: #f7a900; font-size: 1rem; line-height: 1">
                  <span v-for="i in 5" :key="i">★</span>
                </div>
                <a href="#reviews-section" style="color: #2a7be4; font-size: 0.85rem">
                  {{ reviewStatistics?.totalReviews || 0 }} đánh giá
                </a>
              <!-- <span class="text-secondary small">({{ reviewStatistics?.totalReviews || 0 }} đánh giá)</span>
              <span class="mx-2">|</span>
              <span class="text-secondary small">Đã bán: {{ product.soldCount || '1k+' }}</span> -->
          </div>

          <!-- Price -->
          <div class="mb-2">
            <!-- Nếu đã chọn biến thể -->
            <span v-if="selectedVariant" class="h4 text-danger fw-bold">
    {{ formatPrice(selectedVariant.finalPrice) }}
  </span>

            <!-- Nếu chưa chọn, chỉ hiện giá nhỏ nhất -->
            <span v-else class="h4 text-danger fw-bold">
    {{ formatPrice(minPrice) }}
  </span>
          </div>


          <!-- Description -->
          <div class="mb-4" v-if="product.description">
            <div class="fw-bold mb-2">Mô tả sản phẩm:</div>
            <div class="product-description" v-html="product.description"></div>
          </div>

          <!-- Variants -->
          <div v-if="product.variants?.length" class="mt-4">
            <span class="block mb-2 font-semibold">Chọn thuộc tính:</span>
            <div class="flex gap-2">
              <button
                v-for="(variant, index) in product.variants"
                :key="index"
                @click="selectedOption = variant.options"
                :class="[
                  'px-4 py-2 border rounded transition-colors',
                  selectedOption === variant.options
                    ? 'bg-pink-200 border-pink-400 text-pink-700'
                    : 'bg-white hover:bg-gray-100',
                ]"
              >
                {{ variant.options }}
              </button>
            </div>
          </div>

          <!-- Quantity -->
          <div class="mb-4">
            <div class="fw-bold mb-2">SỐ LƯỢNG</div>
            <div class="quantity-group">
              <button class="btn btn-outline-secondary" @click="decreaseQty">-</button>
              <input type="number" v-model="quantity" min="1" readonly />
              <button class="btn btn-outline-secondary" @click="increaseQty">+</button>
            </div>
          </div>

          <!-- Action -->
          <div class="d-flex gap-4">
            <button class="btn btn-pink flex-grow-1 fw-bold" @click="goToCheckout">
              <h3>MUA NGAY</h3>
            </button>
            <button class="btn btn-outline-dark flex-grow-1 fw-bold" @click="addToCart">
              <h3>THÊM VÀO GIỎ</h3>
            </button>
          </div>
        </div>
      </div>

      <!-- Shop info -->
      <div class="col-12" v-if="shopData">
        <div class="shop-card-small border rounded bg-white p-3 mb-3 d-flex align-items-center justify-content-between flex-wrap">
          <div class="d-flex align-items-center" style="gap: 12px; min-width: 220px">
            <img :src="shopData.logoUrl || '/images/default-shop.png'" alt="Shop avatar" class="shop-logo-small"/>
            <div>
              <h5 class="mb-1">{{ shopData.name || 'Tên shop' }}</h5>
              <div class="d-flex align-items-center gap-2 mt-1">
                <button class="btn btn-outline-pink btn-sm" @click="goToShop(shopData.id)">
                  Xem cửa hàng
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

    <!-- Product details -->
<div class="col-md-4">
  <div class="product-info-card border rounded bg-white p-4 h-100 shadow-sm">
    <div class="section-title-custom mb-3">THÔNG TIN SẢN PHẨM</div>
    
    <h3 class="fw-bold mb-3 product-name">{{ product.name }}</h3>
    
    <p class="mb-2"><strong>Giá:</strong> <span class="text-danger">{{ formatPrice(product.basePrice) }} VNĐ</span></p>
    
    <p class="mb-2"><strong>Mô tả:</strong> {{ product.description }}</p>
    
    <p class="mb-2"><strong>Danh mục:</strong> {{ product.categoryName }}</p>
    
    <p class="mb-2"><strong>Cửa hàng:</strong> {{ product.shopName }}</p>
    
    <div class="mb-2" v-if="product.variants && product.variants.length">
      <strong>Loại Sản Phẩm:</strong>
      <ul class="variant-list mt-1">
        <li v-for="variant in product.variants" :key="variant.id">
          {{ variant.options }} - <span class="text-primary">{{ formatPrice(variant.finalPrice) }} VNĐ</span> - {{ variant.stockQuantity }} sản phẩm còn lại
        </li>
      </ul>
    </div>

    <div class="mt-3">
      <strong>Hình ảnh:</strong>
      <div class="d-flex flex-wrap gap-2 mt-2 image-list">
        <img v-for="url in product.imageUrls" :key="url" :src="url" class="img-fluid rounded border" />
      </div>
    </div>
  </div>
</div>


      <!-- Reviews -->
      <div class="col-md-8">
        <div class="border rounded bg-white p-3 h-100">
          <div class="section-title-custom mb-3">ĐÁNH GIÁ SẢN PHẨM</div>

          <!-- Rating overview -->
          <div class="mb-3 d-flex justify-content-center" v-if="reviewStatistics">
            <div class="d-flex align-items-center" style="gap: 12px">
              <div class="text-center" style="min-width: 80px">
                <div class="fw-bold" style="font-size: 1.1rem">{{ avgRating }}/5</div>
                <div style="color: #f7a900; font-size: 1rem; line-height: 1">
                  <span v-for="i in 5" :key="i">★</span>
                </div>
                <a href="#reviews-section" style="color: #2a7be4; font-size: 0.85rem">
                  {{ reviewStatistics?.totalReviews || 0 }} đánh giá
                </a>
              </div>
              <div style="width: 1px; background: #ddd; height: 38px"></div>
              <div style="min-width: 250px; max-width: 160px">
                <div v-for="star in [5,4,3,2,1]" :key="star" class="d-flex align-items-center mb-1" style="font-size: 0.85rem">
                  <span style="width: 18px; color: #f7a900">{{ star }}★</span>
                  <div class="progress flex-grow-1 mx-1" style="height: 5px; background: #eee">
                    <div class="progress-bar bg-pink" :style="{ width: calculateRatingPercentage(star), borderRadius: '3px' }"></div>
                  </div>
                  <span class="small text-secondary" style="width: 80px; text-align: right">
                    {{ getStarCount(star) }} đánh giá
                  </span>
                </div>
              </div>
            </div>
          </div>

          <!-- Reviews list -->
          <div id="reviews-section">
            <div v-if="reviewStore.isLoading" class="text-center py-3">
              <span class="spinner-border spinner-border-sm text-primary"></span>
              <span class="ms-2">Đang tải đánh giá...</span>
            </div>
            <div v-else-if="reviewStore.error" class="alert alert-warning py-2">
              <small>{{ reviewStore.error }}</small>
            </div>
            <div v-else>
              <div v-if="reviewStore.reviews.length">
                <div v-for="review in reviewStore.reviews" :key="review.id" class="d-flex align-items-start mb-3 py-3 border-bottom">
                  <div class="user-avatar me-3 flex-shrink-0" :style="{ backgroundColor: stringToColor(review.userName) }">
                    {{ getUserInitials(review.userName) }}
                  </div>
                  <div class="flex-grow-1">
                    <div class="d-flex align-items-center mb-1">
                      <span class="fw-bold me-2">{{ review.userName || 'Khách hàng' }}</span>
                      <span class="small text-secondary me-2">
                        <i class="bi bi-clock"></i> {{ formatDate(review.createdAt) }}
                      </span>
                      <span v-if="review.isVerifiedPurchase" class="badge bg-success ms-2" style="font-size: 0.7rem">
                        <i class="bi bi-patch-check-fill me-1"></i>Đã mua hàng
                      </span>
                    </div>
                    <div class="mb-1" style="color: #f7a900; font-size: 1.1rem">
                      <span v-for="i in review.rating" :key="i">★</span>
                    </div>
                    <div class="mb-2">{{ review.comment || 'Không có nhận xét' }}</div>
                  </div>
                </div>

                <!-- Pagination -->
     <nav v-if="totalReviewPages > 1" class="mt-4">
  <ul class="pagination pagination-sm justify-content-center">
    <li 
      v-for="page in totalReviewPages" 
      :key="page" 
      class="page-item" 
      :class="{ active: currentReviewPage === page - 1 }"
    >
      <button class="page-link" @click="changeReviewPage(page - 1)">
        {{ page }}
      </button>
    </li>
  </ul>
</nav>



              </div>
              <div v-else class="text-center text-muted py-4">
                <p>Chưa có đánh giá nào cho sản phẩm này</p>
                <button class="btn btn-outline-primary">Viết đánh giá đầu tiên</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Similar products -->
      <div class="mt-5 similar-products">
        <h4 class="mb-3">Sản phẩm tương tự</h4>
        <div v-if="similarProducts.length" class="row g-3">
          <div v-for="item in paginatedProducts" :key="item.id" class="col-6 col-md-3">
            <div class="card h-100">
              <div class="product-card" @click="goToDetail(item.id)">
                <img :src="item.imageUrls?.[0] || '/images/no-image.jpg'" class="card-img-top" alt="product"/>
              </div>
              <div class="p-3">
                <h6 class="card-title text-truncate">{{ item.name }}</h6>
                <p class="text-danger fw-bold mb-2">{{ formatPrice(item.basePrice) }}</p>
                <button class="btn btn-sm btn-outline-primary w-100" @click="goToDetail(item.id)">
                  Xem chi tiết
                </button>
              </div>
            </div>
          </div>
        </div>
        <div v-else class="text-center py-4 text-muted">
          <p>Không có sản phẩm tương tự</p>
        </div>
        <nav v-if="totalPages > 1" class="mt-3">
          <ul class="pagination pagination-sm justify-content-center">
            <li v-for="page in totalPages" :key="page" class="page-item" :class="{ active: currentPage === page }">
              <button class="page-link" @click="currentPage = page">{{ page }}</button>
            </li>
          </ul>
        </nav>
      </div>
    </div>

    <!-- Empty state -->
    <div v-else class="text-center py-5 text-muted">
      <i class="bi bi-exclamation-circle" style="font-size: 3rem"></i>
      <h4 class="mt-3">Không tìm thấy sản phẩm</h4>
      <p class="mb-4">Sản phẩm bạn đang tìm kiếm không tồn tại hoặc đã bị xóa</p>
      <router-link to="/" class="btn btn-primary">Quay về trang chủ</router-link>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useProductStore } from '@/stores/product'
import { useReviewStore } from '@/stores/review'
import { useCartStore } from '@/stores/cart'
import api from '@/api/axios'
import { API_ENDPOINTS } from '@/constants'
import Swal from 'sweetalert2'

const route = useRoute()
const router = useRouter()
const productStore = useProductStore()
const reviewStore = useReviewStore()
const cartStore = useCartStore()

const product = computed(() => productStore.getProductDetail)
const selectedImg = ref('')
const selectedOption = ref(null)
const quantity = ref(1)
const shopData = ref(null)
const currentReviewPage = ref(0)
const similarProducts = ref([])
const reviewStatistics = computed(() => reviewStore.statistics)
const avgRating = computed(() => reviewStatistics.value?.averageRating?.toFixed(1) || '0')
const reviewsPerPage = 4;        // số bình luận mỗi trang
const totalReviewPages = computed(() => {
  return reviewStatistics.value?.totalReviews
    ? Math.ceil(reviewStatistics.value.totalReviews / reviewsPerPage)
    : 0;
});

// lifecycle
async function loadData() {
  const id = route.params.id
  await productStore.fetchProductById(id)

  if (product.value?.shopId) {
    try {
      const res = await api.get(API_ENDPOINTS.SHOP.DETAIL(product.value.shopId))
      if (res.data?.data) shopData.value = res.data.data
    } catch (e) { console.error(e) }
  }

  // fetch reviews
 await reviewStore.fetchProductReviews(id, currentReviewPage.value, reviewsPerPage)

  await reviewStore.fetchReviewStatistics(id)

  // ảnh sản phẩm
  if (product.value?.imageUrls?.length) {
    selectedImg.value = product.value.imageUrls[0]
  }
// fetch sản phẩm tương tự
try {
  const res = await api.get(API_ENDPOINTS.PRODUCT.RELATED(id), {
    params: { page: 0, size: 20 }
  })
  similarProducts.value = res.data?.data?.products || []
} catch (e) {
  console.error("Lỗi khi tải sản phẩm tương tự:", e)
  similarProducts.value = []
}
}
onMounted(loadData)
watch(() => route.params.id, () => {
  currentReviewPage.value = 0; // reset page
  loadData();
});


// helpers
function formatPrice(value) {
  if (!value) return 'Liên hệ'
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value)
}
function formatDate(dateString) { return new Date(dateString).toLocaleDateString('vi-VN') }
function stringToColor(str) {
  let hash = 0
  for (let i = 0; i < str.length; i++) { hash = str.charCodeAt(i) + ((hash << 5) - hash) }
  const hue = hash % 360
  return `hsl(${hue}, 70%, 60%)`
}
function getUserInitials(name) { return name ? name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2) : 'US' }
function increaseQty() { quantity.value++ }
function decreaseQty() { if (quantity.value > 1) quantity.value-- }
function handleImageError(e) { e.target.src = '/images/no-image.jpg' }

function getStarCount(star) {
  if (!reviewStatistics.value) return 0
  const map = {
    5: reviewStatistics.value?.fiveStarCount || 0,
    4: reviewStatistics.value?.fourStarCount || 0,
    3: reviewStatistics.value?.threeStarCount || 0,
    2: reviewStatistics.value?.twoStarCount || 0,
    1: reviewStatistics.value?.oneStarCount || 0
  }
  return map[star]
}
function calculateRatingPercentage(star) {
  if (!reviewStatistics.value) return '0%'
  const total = reviewStatistics.value?.totalReviews || 1
  const count = getStarCount(star)
  return `${((count / total) * 100).toFixed(0)}%`
}
function changeReviewPage(page) {
  currentReviewPage.value = page;
  reviewStore.fetchProductReviews(route.params.id, page, reviewsPerPage);
}
const selectedVariant = computed(() => {
  return product.value?.variants?.find(v => v.options === selectedOption.value) || null
})

const minPrice = computed(() => {
  if (!product.value?.variants?.length) return product.value?.basePrice || 0
  return Math.min(...product.value.variants.map(v => v.finalPrice))
})


// cart
async function addToCart() {
  if (!product.value) return
  const variant = product.value.variants?.find(v => v.options === selectedOption.value)
  if (!variant) {
    Swal.fire('Thiếu thuộc tính', 'Vui lòng chọn đầy đủ thuộc tính sản phẩm!', 'warning')
    return
  }

  // ✅ Thêm check hết hàng, không ảnh hưởng code cũ
  if (variant.stockQuantity <= 0) {
    Swal.fire('Hết hàng', 'Sản phẩm này đã hết hàng!', 'error')
    return
  }

  try {
    const result = await cartStore.addToCart(variant.id, quantity.value)
    if (result.success) {
      Swal.fire('Thành công', result.message, 'success')
    } else {
      if (result.message.includes('đăng nhập')) {
        Swal.fire({
          title: 'Vui lòng đăng nhập',
          text: result.message,
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Đăng nhập',
          cancelButtonText: 'Hủy'
        }).then((result) => {
          if (result.isConfirmed) {
            router.push('/login')
          }
        })
      } else {
        Swal.fire('Lỗi', result.message, 'error')
      }
    }
  } catch (e) {
    Swal.fire('Lỗi', 'Không thể thêm vào giỏ hàng', 'error')
  }
}

function goToCheckout() { addToCart(); router.push('/cart') }
function goToDetail(id) { router.push(`/product/${id}`) }
function goToShop(shopId) { router.push({ name: 'shopDetail', params: { shopId } }) }

// similar products
const currentPage = ref(1)
const perPage = 4
const paginatedProducts = computed(() => {
  const start = (currentPage.value - 1) * perPage
  return similarProducts.value.slice(start, start + perPage)
})
const totalPages = computed(() => Math.ceil(similarProducts.value.length / perPage))
</script>

<style scoped>
.product-info-card {
  transition: transform 0.2s, box-shadow 0.2s;
}
.product-info-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 20px rgba(0,0,0,0.15);
}
.section-title-custom {
  color: #0d6efd;
  font-weight: 600;
  padding-bottom: 2px;
}
.product-name {
  color: #212529;
}
.variant-list li {
  font-size: 0.95rem;
  padding: 2px 0;
}
.image-list img {
  max-width: 60px;
  height: 60px;
  object-fit: cover;
}
/* Product image */
.img-fluid.mb-3 {
  max-height: 400px;
  object-fit: contain;
  border-radius: 14px;
  box-shadow: 0 4px 24px 0 rgba(212, 140, 166, 0.08);
}

/* Thumbnail images */
.img-thumbnail {
  border-radius: 8px;
  border: 2px solid #eee;
  transition:
    border-color 0.2s,
    box-shadow 0.2s;
  box-shadow: 0 2px 8px #f7a9c422;
}

.img-thumbnail.border-primary {
  border-color: #f7a9c4 !important;
  box-shadow: 0 4px 16px #f7a9c444;
}

.img-thumbnail:hover {
  border-color: #f368a5;
}

/* Price styling */
.h4.text-danger,
.text-danger.fw-bold {
  font-size: 1.6rem;
}

.badge.bg-light {
  font-size: 1rem;
  color: #888;
  background: #f8f9fa;
  border-radius: 6px;
}

/* Size/color buttons */
.btn-outline-primary {
  border-radius: 8px;
  padding: 0.6rem 1.5rem;
  font-size: 1.1rem;
  margin-bottom: 6px;
  border-width: 2px;
  border-color: #d1d5db;
  color: #222;
  background: #fff;
  font-weight: 500;
  box-shadow: none;
  transition:
    background 0.18s,
    color 0.18s,
    border-color 0.18s;
}

.btn-outline-primary.border-primary,
.btn-outline-primary:focus {
  border-color: #f7a9c4 !important;
  color: #f368a5 !important;
  background: #fff0f6;
}

.btn-outline-primary:hover {
  background: #f7a9c4;
  color: #fff;
  border-color: #f368a5;
}

/* Action buttons */
.btn-pink,
.btn-outline-dark {
  border-radius: 10px;
  font-size: 1.1rem;
  padding: 0.8rem 0;
  box-shadow: 0 2px 8px #f7a9c422;
  transition:
    background 0.18s,
    color 0.18s,
    box-shadow 0.18s;
}

.btn-pink {
  background-color: #f7a9c4;
  color: #fff;
}

.btn-pink:hover {
  background-color: #f368a5;
  color: #fff;
}

.btn-outline-dark:hover {
  background: #757e86;
  color: #fff;
}

/* Shop info */
[alt='Shop avatar'] {
  border-radius: 50%;
  border: 2px solid #f7a9c4;
  box-shadow: 0 2px 12px #f7a9c422;
}

/* Section titles */
.section-title-custom {
  font-size: 1.5rem;
  color: #fff;
  text-align: center;
  font-weight: bold;
  margin-bottom: 1rem;
  background: linear-gradient(90deg, #f7a9c4 0%, #757e86 100%);
  border-radius: 10px;
  padding: 12px 0;
  letter-spacing: 1px;
}

/* Rating bars */
.bg-pink {
  background: #f7a9c4 !important;
}

.badge.bg-secondary {
  background: #f7a9c4 !important;
  color: #fff !important;
}

/* Similar products */
.card {
  border: 1px solid #eee;
  border-radius: 12px;
  transition:
    box-shadow 0.2s,
    transform 0.2s,
    border-color 0.2s;
}

.card:hover {
  box-shadow: 0 8px 32px #f7a9c444;
  border-color: #f368a5;
  transform: translateY(-6px) scale(1.03);
}

/* Image preview modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
}

.modal-content {
  position: relative;
  max-width: 90%;
  max-height: 90vh;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .img-fluid.mb-3 {
    max-height: 300px;
  }

  .h4.text-danger {
    font-size: 1.3rem;
  }

  .btn-pink,
  .btn-outline-dark {
    font-size: 1rem;
    padding: 0.6rem 0;
  }
}

/* Container cho size và color */
.size-color-group {
  display: flex;
  gap: 8px;
  /* khoảng cách giữa các nút */
  overflow-x: auto;
  /* scroll ngang nếu quá dài */
  padding-bottom: 4px;
}

/* Nút size & color nhỏ gọn */
.size-color-group .btn-outline-primary {
  padding: 0.25rem 0.6rem;
  font-size: 0.9rem;
  border-width: 1.5px;
  min-width: 40px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  /* không xuống dòng */
}

.size-color-group .btn-outline-primary span {
  font-size: 0.8rem;
  /* dấu ✓ nhỏ hơn */
}

/* Container cho quantity */
.quantity-group {
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: 150px;
  /* chiều rộng tối đa */
}

/* Nút + / - */
.quantity-group .btn {
  padding: 0.25rem 0.6rem;
  font-size: 0.9rem;
  height: 32px;
}

/* Input số lượng */
.quantity-group input {
  text-align: center;
  font-size: 0.9rem;
  height: 32px;
  padding: 0 6px;
}

/* --- Similar products --- */
.similar-products .card {
  border: 1px solid #f0f0f0;
  border-radius: 14px;
  overflow: hidden;
  transition: all 0.25s ease;
  background: #fff;
  box-shadow: 0 2px 8px rgba(247, 169, 196, 0.15);
}

.similar-products .card:hover {
  transform: translateY(-6px) scale(1.02);
  box-shadow: 0 8px 24px rgba(247, 169, 196, 0.25);
  border-color: #f368a5;
}

.similar-products .card-img-top {
  height: 200px;
  object-fit: cover;
  border-bottom: 1px solid #eee;
  transition: transform 0.25s ease;
}

.similar-products .card:hover .card-img-top {
  transform: scale(1.05);
}

.similar-products .card-title {
  font-size: 1rem;
  font-weight: 600;
  margin-bottom: 4px;
  color: #333;
}

.similar-products .card-title:hover {
  color: #f368a5;
}

.similar-products p {
  margin: 0;
  font-size: 0.9rem;
  font-weight: 500;
  color: #f368a5;
}

.similar-products .btn {
  border-radius: 8px;
  font-size: 0.85rem;
  padding: 0.4rem 0.6rem;
  font-weight: 500;
  transition: all 0.2s ease;
}

.similar-products .btn:hover {
  background-color: #f7a9c4;
  color: #fff;
  border-color: #f7a9c4;
}

.similar-products .card-img-top {
  height: 140px;
  width: 100%;
  object-fit: contain;
  padding: 8px;
  background: #fafafa;
  border-bottom: 1px solid #eee;
}

/* Shop card nhỏ */
.shop-card-small {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 12px;
  margin-bottom: 12px;
}

.shop-logo-small {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
}

/* Nút màu hồng */
.btn-pink {
  background-color: #ff6b81;
  color: #fff;
  border: none;
  transition: 0.3s;
}

.btn-pink:hover {
  background-color: #ff4c61;
}

/* Outline màu hồng */
.btn-outline-pink {
  color: #ff6b81;
  border: 1px solid #ff6b81;
  transition: 0.3s;
}

.btn-outline-pink:hover {
  background-color: #ff6b81;
  color: #fff;
}

/* Quantity input group */
.quantity-group {
  display: flex;
  align-items: center;
  max-width: 150px;
}

.quantity-group input {
  width: 50px;
  text-align: center;
  border: 1px solid #ddd;
  border-left: none;
  border-right: none;
}

.quantity-group button {
  width: 35px;
  height: 35px;
  padding: 0;
}

/* Modal preview hình ảnh */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10000;
}

.modal-content {
  position: relative;
  background-color: #fff;
  padding: 12px;
  border-radius: 8px;
}

.modal-content img {
  max-width: 100%;
  max-height: 90vh;
}

.modal-content .btn-close {
  position: absolute;
  top: 0;
  right: 0;
}

/* Sản phẩm tương tự */
.similar-products .card {
  cursor: pointer;
  transition: transform 0.2s;
}

.similar-products .card:hover {
  transform: translateY(-4px);
}

/* Tiêu đề section */
.section-title-custom {
  font-weight: 600;
  font-size: 1.1rem;
  border-bottom: 2px solid #ff6b81;
  padding-bottom: 4px;
  margin-bottom: 12px;
}

/* Mô tả sản phẩm */
.product-description {
  line-height: 1.5;
}

/* Responsive */
@media (max-width: 768px) {
  .quantity-group {
    max-width: 100%;
  }

  .shop-card-small {
    flex-wrap: wrap;
  }
}
</style>
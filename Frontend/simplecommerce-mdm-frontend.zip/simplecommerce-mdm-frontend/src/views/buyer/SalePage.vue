<template>
  <div class="flash-sale-bg py-3">
    <div class="container">
      <!-- Banner -->
      <b-row class="mb-3">
        <b-col>
          <img
            src="https://i.pinimg.com/736x/b7/ce/d7/b7ced713fbba8749740b15a605854d67.jpg"
            class="img-fluid rounded flash-sale-banner"
            alt="Flash Sale Banner"
          />
        </b-col>
      </b-row>
      <!-- Time Slots -->
      <b-row class="mb-3 flash-sale-times justify-content-between flex-nowrap" no-gutters>
        <b-col v-for="slot in timeSlots" :key="slot.time" class="text-center flash-sale-time-col">
          <div
            :class="['flash-sale-time', activeSlot === slot.time ? 'active' : '']"
            @click="selectSlot(slot.time)"
            style="cursor: pointer"
          >
            <div class="time">{{ slot.time }}</div>
            <div class="desc">{{ slot.desc }}</div>
          </div>
        </b-col>
      </b-row>
      <!-- Tabs -->
      <div class="row g-4 justify-content-center">
        <div
          class="col-12 col-sm-6 col-md-3"
          v-for="(item, idx) in suggestProducts"
          :key="'suggest-' + idx"
        >
          <div class="card h-100 border-0 shadow-sm">
            <img
              :src="item.img"
              class="card-img-top rounded"
              alt=""
              style="height: 240px; object-fit: cover"
            />
            <div class="card-body p-3 text-center">
              <p class="card-text fw-bold mb-2" style="font-size: 1.15rem">{{ item.name }}</p>
              <div class="d-flex justify-content-center align-items-center mb-2" style="gap: 8px">
                <span class="fw-bold text-primary" style="font-size: 1.1rem"
                  >{{ item.price.toLocaleString() }}VND</span
                >
                <span class="badge bg-light border text-secondary" style="font-size: 1rem">{{
                  item.discount
                }}</span>
              </div>
              <div class="d-flex justify-content-center align-items-center" style="gap: 8px">
                <span style="color: #f7a900; font-size: 1.2rem">★</span>
                <span style="font-size: 1.05rem">4.9</span>
                <span class="text-muted" style="font-size: 1rem">Đã bán {{ item.sold }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
const timeSlots = [
  { time: '00:00', desc: 'Đang Diễn Ra' },
  { time: '03:00', desc: 'Sắp Diễn Ra' },
  { time: '09:00', desc: 'Sắp Diễn Ra' },
  { time: '21:00', desc: 'Sắp Diễn Ra' },
];
const activeSlot = ref(timeSlots[0].time);

function selectSlot(time) {
  activeSlot.value = time;
}

const suggestProducts = [
  {
    img: '/src/assets/images/aothuntheu.webp',
    name: 'Áo thun thêu hoa bất tử',
    price: 86000,
    discount: '-49%',
    sold: '3k',
  },
  {
    img: '/src/assets/images/aothunnu.webp',
    name: 'Áo thun nữ dáng ôm',
    price: 82000,
    discount: '-49%',
    sold: '2k',
  },
  {
    img: '/src/assets/images/aothunhoatiet.webp',
    name: 'Áo thun họa tiết nơ',
    price: 65000,
    discount: '-54%',
    sold: '1k',
  },
  {
    img: '/src/assets/images/aothun1.webp',
    name: 'Áo thun HEAVEN BUTTERFLY',
    price: 81000,
    discount: '-44%',
    sold: '1k',
  },
  {
    img: '/src/assets/images/aothunphoi1.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 89000,
    discount: '-49%',
    sold: '2k',
    active: false,
  },
  {
    img: '/src/assets/images/aobabyteee.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 37000,
    discount: '-40%',
    sold: '3k',
    active: false,
  },
  {
    img: '/src/assets/images/aothun.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 35000,
    discount: '-13%',
    sold: '1k',
    active: false,
  },
  {
    img: '/src/assets/images/aothun2.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 35000,
    discount: '-55%',
    sold: '6k',
    active: false,
  },
  {
    img: '/src/assets/images/aothuntheucotton.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 97000,
    discount: '-51%',
    sold: '1k',
    active: false,
  },
  {
    img: '/src/assets/images/aothunin.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 39000,
    discount: '-44%',
    sold: '1k',
    active: false,
  },
  {
    img: '/src/assets/images/aothunso7.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 79000,
    discount: '-41%',
    sold: '1.5k',
    active: false,
  },
  {
    img: '/src/assets/images/aopolo.webp',
    name: 'Áo thun tay lỡ unisex',
    price: 149000,
    discount: '-50%',
    sold: '2k',
    active: false,
  },
];
</script>

<style scoped>
.flash-sale-bg {
  background: #fafafa;
  min-height: 100vh;
}
.flash-sale-banner {
  width: 100%;
  max-height: 350px; /* tăng chiều cao */
  height: 350px; /* đặt chiều cao cố định */
  object-fit: cover;
}
.flash-sale-times {
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 8px #0001;
  padding: 0;
  display: flex;
  flex-wrap: nowrap;
  overflow-x: auto;
}
.flash-sale-time-col {
  flex: 1 1 0;
  min-width: 0;
  padding: 0;
}
.flash-sale-time {
  padding: 16px 0 10px 0;
  border-bottom: 2px solid transparent;
  transition:
    border 0.2s,
    color 0.2s;
}
.flash-sale-time.active {
  color: #fff;
  background: #1976d2 !important;
  font-weight: bold;
}
.flash-sale-time .time {
  font-size: 1.25rem;
}
.flash-sale-time .desc {
  font-size: 0.95rem;
}
.flash-sale-product {
  border: none;
  box-shadow: 0 2px 8px #0001;
  border-radius: 10px;
  overflow: hidden;
  transition: box-shadow 0.2s;
}
.flash-sale-product:hover {
  box-shadow: 0 4px 16px #ee4d2d22;
}

.card-img-top {
  height: 240px;
  object-fit: cover;
}
.card {
  border-radius: 16px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.07);
  padding-bottom: 12px;
  transition:
    box-shadow 0.2s,
    transform 0.2s;
  background: #fff;
}
.card-body {
  background: #fff;
}
.card:hover {
  box-shadow: 0 4px 24px 0 rgba(212, 140, 166, 0.15);
  transform: translateY(-4px) scale(1.03);
}
</style>

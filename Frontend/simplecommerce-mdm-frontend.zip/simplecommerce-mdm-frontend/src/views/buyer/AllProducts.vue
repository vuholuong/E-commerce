<script setup>
import { ref, computed, onMounted } from 'vue';
import { useCategoryStore } from '@/stores/category';
import { useProductStore } from '@/stores/product';

const categoryStore = useCategoryStore();
const productStore = useProductStore();

const selectedCategoryId = ref(null);
const expandedParentId = ref(null);

onMounted(async () => {
  if (!categoryStore.categories.length) {
    await categoryStore.fetchCategories();
  }
  if (!productStore.products.length) {
    await productStore.fetchProducts();
  }
});

// Danh mục cha
const parentCategories = computed(() => categoryStore.categories.filter(c => c.parentId === null));

// Lấy danh mục con của 1 cha
const getChildCategories = parentId =>
  categoryStore.categories.filter(c => c.parentId === parentId);

// Lọc sản phẩm
const filteredProducts = computed(() => {
  if (!selectedCategoryId.value) return productStore.products;

  const childIds = categoryStore.categories
    .filter(c => c.parentId === selectedCategoryId.value)
    .map(c => c.id);

  if (childIds.length > 0) {
    return productStore.products.filter(
      p => p.categoryId === selectedCategoryId.value || childIds.includes(p.categoryId)
    );
  } else {
    return productStore.products.filter(p => p.categoryId === selectedCategoryId.value);
  }
});

// 🔹 Breadcrumb động
const breadcrumbs = computed(() => {
  if (!selectedCategoryId.value) {
    return [{ name: 'Tất cả', id: null }];
  }

  const path = [];
  let current = categoryStore.categories.find(c => c.id === selectedCategoryId.value);

  while (current) {
    path.unshift({ name: current.name, id: current.id });
    current = categoryStore.categories.find(c => c.id === current.parentId);
  }

  return [{ name: 'Tất cả', id: null }, ...path];
});

// Click cha
function toggleParent(parentId) {
  const children = getChildCategories(parentId);
  if (children.length > 0) {
    expandedParentId.value = expandedParentId.value === parentId ? null : parentId;
    selectedCategoryId.value = parentId;
  } else {
    expandedParentId.value = null;
    selectedCategoryId.value = parentId;
  }
}

function selectCategory(catId) {
  selectedCategoryId.value = catId;
}
</script>

<template>
  <div class="container mt-4">
    <!-- Breadcrumb -->
    <div class="breadcrumb mb-3">
      <span v-for="(crumb, index) in breadcrumbs" :key="crumb.id ?? 'all'">
        <a
          href="javascript:void(0)"
          @click="selectCategory(crumb.id)"
          :class="{ 'fw-bold text-primary': selectedCategoryId === crumb.id }"
        >
          {{ crumb.name }}
        </a>
        <span v-if="index < breadcrumbs.length - 1"> / </span>
      </span>
    </div>
    <div class="row">
      <!-- NAV -->
      <div class="col-md-3">
        <nav class="nav flex-column gap-1">
          <a
            class="nav-link"
            :class="{ active: !selectedCategoryId }"
            @click="selectCategory(null)"
            href="javascript:void(0)"
          >
            <i class="fa-solid fa-list"></i> Tất cả
          </a>

          <div v-for="parent in parentCategories" :key="parent.id">
            <a class="nav-link fw-bold" href="javascript:void(0)" @click="toggleParent(parent.id)">
              <i class="fa-solid fa-folder"></i> {{ parent.name }}
            </a>

            <!-- Danh mục con -->
            <div v-if="expandedParentId === parent.id" class="ps-3">
              <a
                v-for="child in getChildCategories(parent.id)"
                :key="child.id"
                class="nav-link"
                href="javascript:void(0)"
                :class="{ active: selectedCategoryId === child.id }"
                @click="selectCategory(child.id)"
              >
                <i class="fa-regular fa-folder"></i> {{ child.name }}
              </a>
            </div>
          </div>
        </nav>
      </div>

      <!-- SẢN PHẨM -->

      <div class="col-md-9">
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <div v-for="p in filteredProducts" :key="p.id" class="col">
            <router-link :to="`/product/${p.id}`" class="product-card h-100 text-decoration-none">
              <img :src="p.imageUrls?.[0] || '/images/no-image.jpg'" class="product-img" />
              <h5 class="mt-2">{{ p.name }}</h5>
              <p class="text-danger fw-bold">
                {{
                  new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(
                    p.basePrice
                  )
                }}
              </p>
            </router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* ===== NAVIGATION ===== */
.nav {
  background: #fff;
  border-radius: 14px;
  padding: 12px;
  border: 1px solid #e5e7eb;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.04);
  display: flex;
  flex-direction: column;
  gap: 6px; /* cách đều item */
}
.nav-link i {
  color: #000 !important; /* icon cũng đen */
}
.nav-link {
  cursor: pointer;
  color: #444;
  font-size: 15px;
  font-weight: 500;
  padding: 10px 14px;
  border-radius: 10px;
  transition: all 0.25s ease;
  display: flex;
  align-items: center;
  gap: 8px;
  background: #f9fafb; /* nền xám nhạt cho item */
  border: 1px solid transparent;
  color: #000 !important; /* ép chữ đen */
  opacity: 1 !important; /* bỏ mờ */
}

.nav-link:hover {
  background: #eef3ff;
  color: #2575fc;
  transform: translateX(3px);
}

.nav-link.active {
  background: linear-gradient(135deg, #2575fc, #6a11cb);
  color: #fff !important;
  font-weight: 600;
  box-shadow: 0 3px 12px rgba(37, 117, 252, 0.25);
  background: linear-gradient(135deg, #2575fc, #6a11cb);
  color: #fff !important; /* active mới trắng */
  opacity: 1 !important;
}

/* Danh mục con */
.ps-3 .nav-link {
  font-size: 14px;
  padding: 8px 12px;
  background: #fdfdfd;
  border: 1px solid #f0f0f0;
}
.ps-3 .nav-link.active {
  background: #2575fc;
  color: #fff;
}

/* ===== BREADCRUMB ===== */
.breadcrumb {
  font-size: 14px;
  font-weight: 500;
  color: #666;
}
.breadcrumb a {
  text-decoration: none;
  color: #555;
  transition: color 0.25s ease;
}
.breadcrumb a:hover {
  color: #2575fc;
}
.breadcrumb .fw-bold.text-primary {
  color: #2575fc !important;
}

/* ===== PRODUCT CARD ===== */
.product-card {
  background: #fff;
  border-radius: 14px;
  text-align: center;
  padding: 16px 12px;
  border: 1px solid #eee;
  box-shadow: 0 4px 12px rgba(37, 117, 252, 0.05);
  transition: all 0.3s ease;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}

.product-card:hover {
  transform: translateY(-6px) scale(1.02);
  box-shadow: 0 8px 22px rgba(37, 117, 252, 0.15);
  border-color: #d1d9ff;
}

/* Ảnh sản phẩm */
.product-img {
  width: 100%;
  height: 200px; /* cố định để ảnh đều nhau */
  object-fit: contain; /* nếu muốn đồng đều + crop thì dùng cover */
  background: #f8f9fc;
  border-radius: 10px;
  padding: 12px;
  transition: transform 0.25s ease;
}
.product-card:hover .product-img {
  transform: scale(1.05);
}

/* Tên sản phẩm */
.product-card h5 {
  font-size: 15px;
  font-weight: 600;
  color: #222;
  margin-top: 12px;
  min-height: 40px;
  line-height: 1.4;
}

/* Giá */
.product-card p.text-danger {
  font-size: 15px;
  font-weight: 700;
  margin: 8px 0 0;
  color: #e63946 !important;
}

/* ===== RESPONSIVE ===== */
@media (max-width: 768px) {
  .nav {
    margin-bottom: 20px;
  }
  .product-img {
    height: 160px;
  }
  .product-card h5 {
    font-size: 14px;
    min-height: auto;
  }
}
</style>

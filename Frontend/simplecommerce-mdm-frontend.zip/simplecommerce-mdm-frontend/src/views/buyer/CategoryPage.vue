<script setup>
import { computed, onMounted, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useProductStore } from '@/stores/product';
import { useCategoryStore } from '@/stores/category';

const route = useRoute();
const router = useRouter();
const categoryStore = useCategoryStore();
const productStore = useProductStore();

const categoryId = computed(() => Number(route.params.id));
const selectedChildId = ref(null);

onMounted(async () => {
  if (!categoryStore.categories.length) {
    await categoryStore.fetchCategories();
  }
  if (!productStore.products.length) {
    await productStore.fetchProducts();
  }
});

function goToDetail(productId) {
  router.push(`/product/${productId}`);
}

const parentCategory = computed(() => {
  return categoryStore.categories.find(c => c.id === categoryId.value) || {};
});

const childCategories = computed(() => {
  return categoryStore.categories.filter(c => c.parentId === categoryId.value);
});

const productsInCategory = computed(() => {
  let idsToFilter = [];

  if (selectedChildId.value) {
    idsToFilter = [selectedChildId.value];
  } else {
    idsToFilter = childCategories.value.map(c => c.id);
  }

  if (!idsToFilter.length) {
    idsToFilter = [categoryId.value];
  }

  return productStore.products.filter(p => idsToFilter.includes(p.categoryId));
});

function selectChildCategory(id) {
  selectedChildId.value = id;
}
// 🔹 Breadcrumb động
const breadcrumbs = computed(() => {
  const path = [];

  // Nếu có child được chọn
  let current = selectedChildId.value
    ? categoryStore.categories.find(c => c.id === selectedChildId.value)
    : categoryStore.categories.find(c => c.id === categoryId.value);

  while (current) {
    path.unshift({ name: current.name, id: current.id });
    current = categoryStore.categories.find(c => c.id === current.parentId);
  }

  return [{ name: 'Tất cả', id: null }, ...path];
});

function goToCategory(catId) {
  if (catId === null) {
    router.push('/products'); // hoặc '/' nếu bạn dùng route gốc
    selectedChildId.value = null;
  } else {
    selectedChildId.value = null; // reset child
    router.push(`/category/${catId}`);
  }
}
</script>

<template>
  <div class="container mt-4">
    <!-- BREADCRUMB -->
    <div class="breadcrumb-wrapper mb-4">
      <span v-for="(crumb, index) in breadcrumbs" :key="crumb.id ?? 'all'">
        <a
          href="javascript:void(0)"
          @click="goToCategory(crumb.id)"
          :class="{ 'active-crumb': selectedChildId === crumb.id || categoryId === crumb.id }"
        >
          {{ crumb.name }}
        </a>
        <span v-if="index < breadcrumbs.length - 1"> / </span>
      </span>
    </div>

    <div class="row">
      <!-- Menu bên trái -->
      <div class="col-md-3">
        <div class="category-menu">
          <h5>{{ parentCategory.name }}</h5>
          <ul>
            <li :class="{ active: selectedChildId === null }" @click="selectChildCategory(null)">
              Tất cả
            </li>
            <li
              v-for="child in childCategories"
              :key="child.id"
              :class="{ active: selectedChildId === child.id }"
              @click="selectChildCategory(child.id)"
            >
              {{ child.name }}
            </li>
          </ul>
        </div>
      </div>

      <!-- Sản phẩm bên phải -->
      <div class="col-md-9">
        <h2>{{ parentCategory.name }}</h2>
        <div v-if="!productsInCategory.length">Không có sản phẩm nào trong danh mục này.</div>

        <div class="row row-cols-1 row-cols-md-3 g-4">
          <div v-for="p in productsInCategory" :key="p.id" class="col">
            <div class="product-card" @click="goToDetail(p.id)" style="cursor: pointer">
              <img :src="p.imageUrls?.[0] || '/images/no-image.jpg'" class="product-img" />
              <h5>{{ p.name }}</h5>
              <p class="text-danger">
                {{
                  new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(
                    p.basePrice
                  )
                }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
/* ===== CATEGORY MENU ===== */
.category-menu {
  background: #ffffff;
  padding: 18px 14px;
  border-radius: 14px;
  border: 1px solid #e6e9f2;
  box-shadow: 0 6px 18px rgba(37, 117, 252, 0.06);
}

.category-menu h5 {
  font-weight: 700;
  font-size: 1.25rem;
  color: #2575fc;
  margin-bottom: 16px;
  border-bottom: 2px solid #eef3ff;
  padding-bottom: 8px;
}

.category-menu ul {
  list-style: none;
  margin: 0;
  padding: 0;
}

.category-menu ul li {
  padding: 10px 14px;
  margin-bottom: 6px;
  cursor: pointer;
  border-radius: 8px;
  font-weight: 500;
  color: #555;
  background: #f9fbff;
  transition: all 0.25s ease;
}

.category-menu ul li:hover {
  background: linear-gradient(90deg, #e3f0ff, #f3e6ff);
  color: #2575fc;
  transform: translateX(6px);
  box-shadow: 0 3px 12px rgba(37, 117, 252, 0.08);
}

.category-menu ul li.active {
  background: linear-gradient(90deg, #2575fc, #6a11cb);
  color: white;
  font-weight: 600;
  box-shadow: 0 4px 14px rgba(37, 117, 252, 0.2);
}

/* ===== PRODUCT CARD ===== */
.product-card {
  background: #ffffff;
  border-radius: 14px;
  border: 1px solid #eef0f5;
  padding: 16px;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  transition:
    transform 0.25s ease,
    box-shadow 0.25s ease;
}

.product-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.08);
}

.product-img {
  width: 100%;
  height: 220px;
  object-fit: contain;
  margin-bottom: 12px;
  background-color: #f9f9fb;
  border-radius: 10px;
  padding: 8px;
  transition: transform 0.3s ease;
}

.product-card:hover .product-img {
  transform: scale(1.05);
}

.product-card h5 {
  font-size: 1rem;
  font-weight: 600;
  color: #333;
  margin: 8px 0;
  min-height: 40px;
}

.product-card p {
  font-size: 1.05rem;
  font-weight: bold;
  color: #e63946;
  margin: 0;
}

/* ===== RESPONSIVE ===== */
@media (max-width: 768px) {
  .category-menu {
    margin-bottom: 20px;
  }
}
</style>

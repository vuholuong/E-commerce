<template>
  <div class="create-shop">
    <div class="form-container">
      <h2>🛒 Đăng ký Shop</h2>
      <p class="subtitle">Bạn chỉ được tạo 1 shop. Vui lòng nhập đầy đủ thông tin.</p>

      <!-- Nếu đã login -->
      <form v-if="isLoggedIn" @submit.prevent="createShop" class="shop-form">
        <!-- Shop Name -->
        <div class="input-group">
          <label>Tên shop</label>
          <input v-model="shop.name" type="text" placeholder="Nhập tên shop" required />
        </div>

        <!-- Description -->
        <div class="input-group">
          <label>Mô tả</label>
          <textarea v-model="shop.description" placeholder="Giới thiệu ngắn gọn về shop..."></textarea>
        </div>

        <!-- Contact Email -->
        <div class="input-group">
          <label>Email liên hệ</label>
          <input v-model="shop.contactEmail" type="email" placeholder="example@email.com" required />
        </div>

        <!-- Contact Phone -->
        <div class="input-group">
          <label>Số điện thoại liên hệ</label>
          <input v-model="shop.contactPhone" type="text" placeholder="0123-456-789" required />
        </div>

        <!-- AddressId -->
        <div class="input-group">
          <label>Địa chỉ Shop</label>
          <select v-model="shop.addressId" required>
            <option value="" disabled>-- Chọn địa chỉ --</option>
            <option v-for="addr in addressStore.addresses" :key="addr.id" :value="addr.id">
              {{ addr.streetAddress1 }}, {{ addr.ward }}, {{ addr.city }}
            </option>
          </select>
        </div>

        <button type="submit" :disabled="loading">
          {{ loading ? "⏳ Đang xử lý..." : "🚀 Tạo Shop" }}
        </button>
      </form>

      <!-- Nếu chưa login -->
      <div v-else>
        <p>Bạn cần đăng nhập để tạo shop.</p>
        <button class="btn-secondary" @click="router.push('/login')">Đăng nhập</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
import api from "@/api/axios";
import { API_ENDPOINTS } from "@/constants";
import Swal from "sweetalert2";
import { useAuthStore } from "@/stores/auth";
import { useAddressStore } from "@/stores/addressStore";

const router = useRouter();
const authStore = useAuthStore();
const addressStore = useAddressStore();

const shop = ref({
  name: "",
  description: "",
  contactEmail: "",
  contactPhone: "",
  addressId: null, // 🔑 sẽ được chọn từ addressStore
});

const isLoggedIn = ref(false);
const loading = ref(false);

onMounted(async () => {
  if (authStore.token) {
    isLoggedIn.value = true;
    await addressStore.fetchAddresses();

    // nếu user có địa chỉ mặc định thì chọn luôn
    const defaultAddr = addressStore.addresses.find(a => a.isDefaultShipping);
    if (defaultAddr) {
      shop.value.addressId = defaultAddr.id;
    }
  } else {
    router.push("/login");
  }
});

const createShop = async () => {
  if (!shop.value.addressId) {
    Swal.fire("Thiếu thông tin", "Vui lòng chọn địa chỉ cho shop", "warning");
    return;
  }

  loading.value = true;
  try {
    await api.post(API_ENDPOINTS.USER.SHOP, shop.value);

    Swal.fire({
      icon: "success",
      title: "🎉 Thành công!",
      text: "Shop của bạn đã được tạo, vui lòng chờ duyệt.",
      confirmButtonColor: "#4f46e5",
    });

    router.push("/my-shop");
  } catch (err) {
    if (err.response?.status === 400) {
      Swal.fire("Thông báo", "Bạn chỉ được tạo 1 shop!", "warning");
    } else if (err.response?.status === 401) {
      Swal.fire("Hết phiên đăng nhập", "Vui lòng đăng nhập lại", "error");
      authStore.logout();
      router.push("/login");
    } else {
      Swal.fire("Lỗi", err.response?.data?.message || "Không thể tạo shop", "error");
    }
  } finally {
    loading.value = false;
  }
};
</script>



<style scoped>
.create-shop {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #f0f4ff, #fafcff);
  padding: 30px;
}

.form-container {
  background: #fff;
  padding: 35px;
  width: 100%;
  max-width: 550px;
  border-radius: 18px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
  animation: fadeIn 0.5s ease-in-out;
}

.form-container h2 {
  font-size: 26px;
  font-weight: 800;
  margin-bottom: 10px;
  text-align: center;
  color: #333;
}

.subtitle {
  text-align: center;
  margin-bottom: 25px;
  font-size: 14px;
  color: #666;
}

.shop-form .input-group {
  margin-bottom: 18px;
  display: flex;
  flex-direction: column;
}

.input-group label {
  font-weight: 600;
  margin-bottom: 6px;
  font-size: 14px;
  color: #444;
}

.input-group input,
.input-group textarea {
  border: 1px solid #ddd;
  border-radius: 12px;
  padding: 12px 14px;
  font-size: 15px;
  transition: all 0.25s ease;
  background: #fafafa;
}

.input-group input:focus,
.input-group textarea:focus {
  border-color: #6366f1;
  box-shadow: 0 0 8px rgba(99, 102, 241, 0.4);
  background: #fff;
  outline: none;
}

textarea {
  resize: none;
  min-height: 80px;
}

button {
  margin-top: 15px;
  width: 100%;
  padding: 14px;
  border: none;
  border-radius: 14px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  background: linear-gradient(90deg, #4f46e5, #7c3aed);
  color: #fff;
  transition: all 0.25s ease;
  box-shadow: 0 8px 20px rgba(79, 70, 229, 0.3);
}

button:hover {
  transform: scale(1.03);
  background: linear-gradient(90deg, #4338ca, #6d28d9);
}

button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.btn-secondary {
  padding: 12px 20px;
  border-radius: 12px;
  background: #ddd;
  color: #333;
  border: none;
  cursor: pointer;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(15px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>

// Views index file - Export all views for better organization

// Auth views
export { default as LoginPage } from './auth/LoginPage.vue';
export { default as RegisterPage } from './auth/RegisterPage.vue';
export { default as ForgotPassword } from './auth/ForgotPassword.vue';

// Buyer views
export { default as ProductDetail } from './buyer/ProductDetail.vue';
export { default as UserProfile } from './buyer/UserProfile.vue';
export { default as ProductCatalog } from './buyer/ProductCatalog.vue';
export { default as OrderHistory } from './buyer/OrderHistory.vue';
export { default as ShopPage } from './buyer/ShopPage.vue';
export { default as CategoryPage } from './buyer/CategoryPage.vue';
export { default as AllProducts } from './buyer/AllProducts.vue';
export { default as VoucherPage } from './buyer/VoucherPage.vue';
export { default as SalePage } from './buyer/SalePage.vue';

// Seller views
export { default as RegisterSeller } from './seller/RegisterSeller.vue';

// Shared views
export { default as ShopDetailPage } from './shared/ShopDetailPage.vue';
export { default as NotFoundPage } from './shared/NotFoundPage.vue';
export { default as ContactPage } from './shared/ContactPage.vue';

// Admin views (to be added)
// export { default as Dashboard } from './admin/Dashboard.vue';
// export { default as UserManagement } from './admin/UserManagement.vue';

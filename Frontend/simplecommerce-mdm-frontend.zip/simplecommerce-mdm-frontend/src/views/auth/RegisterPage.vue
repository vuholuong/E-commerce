<script setup>
import { useRegisterStore } from '@/stores/register.js';
import Swal from 'sweetalert2';
import { useRouter } from 'vue-router';
import { ref } from 'vue';
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

const router = useRouter();
const registerStore = useRegisterStore();

const firstName = ref('');
const lastName = ref('');
const phone = ref('');
const email = ref('');
const password = ref('');
const confirmPassword = ref('');

// Modal OTP
const showOtpModal = ref(false);
const otpCode = ref('');
const verifying = ref(false);

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function handleRegister(e) {
  e.preventDefault();

  // Validate input
  if (
    !firstName.value ||
    !lastName.value ||
    !phone.value ||
    !email.value ||
    !password.value ||
    !confirmPassword.value
  ) {
    Swal.fire({ title: 'Vui lòng nhập đầy đủ thông tin!', icon: 'warning' });
    return;
  }
  if (!/^\d{10}$/.test(phone.value)) {
    Swal.fire({
      title: 'Số điện thoại không hợp lệ!',
      text: 'Phải đúng 10 chữ số.',
      icon: 'error',
    });
    return;
  }
  if (!validateEmail(email.value)) {
    Swal.fire({ title: 'Email không hợp lệ!', icon: 'error' });
    return;
  }
  if (password.value.length < 6) {
    Swal.fire({ title: 'Mật khẩu quá ngắn!', text: 'Ít nhất 6 ký tự.', icon: 'error' });
    return;
  }
  if (password.value !== confirmPassword.value) {
    Swal.fire({ title: 'Mật khẩu xác nhận không khớp!', icon: 'error' });
    return;
  }

  const payload = {
    firstName: firstName.value,
    lastName: lastName.value,
    email: email.value,
    phoneNumber: phone.value,
    password: password.value,
  };

  await registerStore.registerUser(payload);

  if (registerStore.success) {
    Swal.fire({
      title: 'Đăng ký thành công!',
      text: 'Mã OTP đã được gửi đến email, vui lòng nhập để xác thực.',
      icon: 'success',
      confirmButtonText: 'Nhập OTP',
    }).then(() => {
      showOtpModal.value = true;
    });
  } else if (registerStore.error) {
    Swal.fire({ title: registerStore.error, icon: 'error' });
  }
}

async function verifyOtp() {
  if (!otpCode.value) {
    Swal.fire({ title: 'Vui lòng nhập OTP!', icon: 'warning' });
    return;
  }
  verifying.value = true;
  try {
    const res = await api.post(API_ENDPOINTS.AUTH.VERIFY_EMAIL, {
      email: email.value,
      otpCode: otpCode.value,
    });

    if (res.data.statusCode === 200) {
      Swal.fire({
        title: 'Xác thực thành công!',
        text: 'Bạn có thể đăng nhập ngay.',
        icon: 'success',
        timer: 1500,
        showConfirmButton: false,
      }).then(() => {
        showOtpModal.value = false;
        router.push('/login');
      });
    } else {
      Swal.fire({
        title: res.data.message || 'OTP không hợp lệ!',
        icon: 'error',
        confirmButtonText: 'OK',
      });
    }
  } catch (err) {
    Swal.fire({
      title: 'Có lỗi xảy ra!',
      icon: 'error',
      confirmButtonText: 'OK',
    });
  } finally {
    verifying.value = false;
  }
}
</script>

<template>
  <div class="register-bg d-flex align-items-center justify-content-center">
    <div class="register-form bg-white rounded shadow position-relative">
      <div class="decor-shape"></div>
      <div class="text-center mb-3">
        <img src="@/assets/images/logoMuadima2.png" alt="Logo" class="register-logo" />
      </div>

      <!-- Form Đăng ký -->
      <form @submit.prevent="handleRegister">
        <div class="d-flex gap-2">
          <div class="flex-fill">
            <label class="form-label">Họ:</label>
            <input
              type="text"
              class="form-control custom-input"
              placeholder="Nhập họ"
              v-model="firstName"
            />
          </div>
          <div class="flex-fill">
            <label class="form-label">Tên:</label>
            <input
              type="text"
              class="form-control custom-input"
              placeholder="Nhập tên"
              v-model="lastName"
            />
          </div>
        </div>

        <label class="form-label mt-3">Số điện thoại:</label>
        <input
          type="text"
          class="form-control custom-input"
          placeholder="10 chữ số"
          v-model="phone"
        />

        <label class="form-label">Email:</label>
        <input type="email" class="form-control custom-input" placeholder="Email" v-model="email" />

        <label class="form-label">Mật khẩu:</label>
        <input
          type="password"
          class="form-control custom-input"
          placeholder="Mật khẩu (tối thiểu 6 ký tự)"
          v-model="password"
        />

        <label class="form-label">Xác nhận mật khẩu:</label>
        <input
          type="password"
          class="form-control custom-input"
          placeholder="Nhập lại mật khẩu"
          v-model="confirmPassword"
        />

        <button type="submit" class="btn-register-glass w-100 mt-3 mb-2">Đăng ký</button>
      </form>

      <!-- Social Login -->
      <div class="social-login text-center">
        <p class="mb-0">
          Bạn đã có tài khoản?
          <router-link class="text-gradient" to="/login">Đăng nhập ngay</router-link>
        </p>
      </div>
    </div>

    <!-- Modal OTP -->
    <div v-if="showOtpModal" class="otp-modal">
      <div class="otp-box">
        <h4 class="mb-3">Xác thực Email</h4>
        <p>
          Nhập mã OTP đã gửi đến <b>{{ email }}</b>
        </p>
        <input
          v-model="otpCode"
          maxlength="6"
          placeholder="Nhập OTP"
          class="form-control text-center"
        />
        <button @click="verifyOtp" class="btn-register-glass w-100 mt-3" :disabled="verifying">
          {{ verifying ? 'Đang xác thực...' : 'Xác thực' }}
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.register-bg {
  min-height: 100vh;
  min-width: 100vw;
  background: linear-gradient(130deg, #e3f0ff 0%, #f8e7ff 100%);
  position: relative;
  overflow: hidden;
}

.decor-shape {
  position: absolute;
  top: -30px;
  right: -50px;
  width: 160px;
  height: 160px;
  background: radial-gradient(circle, #cbe6ff 60%, #e8cfff 100%);
  opacity: 0.7;
  border-radius: 50%;
  z-index: 0;
}

.register-form {
  box-shadow: 0 8px 32px 0 #c5d8ef6c;
  background: rgba(255, 255, 255, 0.88);
  backdrop-filter: blur(5px);
  border: 1.5px solid #e3e7ef;
  position: relative;
  z-index: 1;
  max-width: 500px;
  width: 100%;
  min-width: 340px;
  padding: 40px 40px 32px 40px !important;
}

.register-logo {
  height: 70px;
  margin-bottom: 6px;
}

.form-label {
  font-weight: 600;
  margin-top: 10px;
  margin-bottom: 3px;
  color: #365886;
}

.custom-input {
  background: #f6faff !important;
  border-radius: 8px !important;
  border: 1px solid #dbeafe !important;
  margin-bottom: 3px;
}

.custom-input:focus {
  border-color: #68a4fc !important;
}

.btn-register-glass {
  background: linear-gradient(90deg, #5eb6ff 0%, #a695f7 100%);
  color: #fff;
  font-weight: bold;
  border-radius: 8px;
  padding: 12px 0;
}

.btn-register-glass:hover {
  background: linear-gradient(90deg, #4a97e7, #7c6df0);
}

.btn-social {
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  padding: 8px 0;
}

.btn-social.google {
  color: #db4437;
  border: 1.5px solid #f6c7c2;
}

.btn-social.facebook {
  color: #3b5998;
  border: 1.5px solid #b6c7e8;
}

.text-gradient {
  background: linear-gradient(90deg, #5eb6ff, #a695f7);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  font-weight: bold;
  text-decoration: underline;
}

.otp-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
}

.otp-box {
  background: white;
  padding: 25px;
  border-radius: 10px;
  width: 340px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
}

.otp-box input {
  font-size: 1.2rem;
  text-align: center;
  margin-top: 10px;
}
</style>

<template>
  <div class="login-bg d-flex align-items-center justify-content-center">
    <div class="login-form p-4 bg-red rounded shadow position-relative">
      <div class="decor-shape"></div>
      <div class="text-center mb-3">
        <img src="@/assets/images/logoMuadima2.png" alt="Logo" style="height: 60px" />
      </div>
      <form @submit.prevent="handleLogin">
        <label for="email" class="form-label">Email</label>
        <input
          id="email"
          type="email"
          class="form-control custom-input"
          placeholder="Email"
          v-model="email"
        />
        <label for="password" class="form-label">Mật khẩu</label>
        <input
          id="password"
          type="password"
          class="form-control custom-input"
          placeholder="Mật khẩu"
          v-model="password"
        /> <br>
        <button type="submit" class="btn-login-glass w-100 mb-3">Đăng nhập</button>
        <p class="mb-0">
          Bạn đã quên tài khoản?
          <router-link class="" to="/forgot-password">Quên mật khẩu</router-link>
        </p>
      </form>
      <div class="social-login text-center">
        <p class="mb-2 text-secondary">hoặc đăng nhập bằng</p>
        <div class="d-flex justify-content-center gap-2 mb-3">
          <div id="g_id_signin"></div>
          <button class="btn-social facebook flex-fill" @click="handleFacebookLogin">
            <i class="bi bi-facebook"></i> Facebook
          </button>
        </div>
        <p class="mb-0">
          Bạn chưa có tài khoản?
          <router-link class="text-gradient" to="/register">Đăng ký ngay</router-link>
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
import Swal from 'sweetalert2';
import { useRouter } from 'vue-router';
import { ref, onMounted } from 'vue';
import { useAuthStore } from '@/stores/auth';

const router = useRouter();
const email = ref('');
const password = ref('');
const auth = useAuthStore();

async function handleLogin(e) {
  e.preventDefault();
  if (!email.value || !password.value) {
    Swal.fire({
      title: 'Vui lòng nhập đầy đủ thông tin!',
      icon: 'warning',
      confirmButtonText: 'OK',
      background: '#fffbe7',
      color: '#d79b00',
    });
    return;
  }
  const success = await auth.login(email.value, password.value);
  if (success) {
    Swal.fire({
      title: 'Đăng nhập thành công!',
      text: 'Chào mừng bạn quay trở lại!',
      icon: 'success',
      showConfirmButton: false,
      timer: 1500,
      timerProgressBar: true,
      background: '#f8faff',
      color: '#222',
      didOpen: () => {
        Swal.showLoading();
      },
    }).then(() => {
      router.push('/');
    });
  } else {
    Swal.fire({
      title: 'Sai tài khoản hoặc mật khẩu!',
      text: auth.error || 'Vui lòng kiểm tra lại.',
      icon: 'error',
      confirmButtonText: 'Thử lại',
      background: '#fff0f0',
      color: '#d33',
    });
    email.value = '';
    password.value = '';
  }
}
// ...existing code...
// Google One Tap/Identity Services integration
onMounted(() => {
  // Thêm script Google Identity nếu chưa có
  if (!document.getElementById('google-identity-script')) {
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.id = 'google-identity-script';
    document.head.appendChild(script);
    script.onload = renderGoogleButton;
  } else {
    renderGoogleButton();
  }
});

// ...existing code...
function renderGoogleButton() {
  if (window.google && window.google.accounts && window.google.accounts.id) {
    window.google.accounts.id.initialize({
      client_id: '1089362795193-65rtu7dqu8ec6frotre6u145drvh87cc.apps.googleusercontent.com',
      callback: handleGoogleCredential,
    });
    window.google.accounts.id.renderButton(document.getElementById('g_id_signin'), {
      theme: 'outline',
      size: 'large',
      width: 220,
    });
  }
}

async function handleGoogleCredential(response) {
  const googleToken = response.credential;
  if (!googleToken) {
    Swal.fire({
      title: 'Không lấy được Google token!',
      icon: 'error',
    });
    return;
  }
  const success = await auth.loginGoogle(googleToken);
  if (success) {
    Swal.fire({
      title: 'Chào Mừng Bạn Dến Với MuaDiMa',
      icon: 'success',
      showConfirmButton: false,
      timer: 1500,
      timerProgressBar: true,
      background: '#f8faff',
      color: '#222',
      didOpen: () => Swal.showLoading(),
    }).then(() => {
      router.push('/');
    });
  } else {
    Swal.fire({
      title: 'Đăng nhập Google thất bại!',
      text: auth.error || 'Vui lòng thử lại.',
      icon: 'error',
      confirmButtonText: 'Thử lại',
      background: '#fff0f0',
      color: '#d33',
    });
  }
}
function handleFacebookLogin() {
  Swal.fire({
    title: 'Tính năng Facebook đang phát triển!',
    icon: 'info',
    confirmButtonText: 'OK',
  });
}
</script>

<style scoped>
.login-bg {
  min-height: 100vh;
  min-width: 100vw;
  background: linear-gradient(130deg, #e3f0ff 0%, #f8e7ff 100%);
  position: relative;
  overflow: hidden;
}

.decor-shape {
  position: absolute;
  top: -30px;
  right: -50px;
  width: 160px;
  height: 160px;
  background: radial-gradient(circle, #cbe6ff 60%, #e8cfff 100%);
  opacity: 0.7;
  border-radius: 50%;
  z-index: 0;
}

.login-form {
  box-shadow: 0 8px 32px 0 #ffffff6c;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(5px);
  border: 1.5px solid #e3e7ef;
  position: relative;
  z-index: 1;
  overflow: hidden;
  transition:
    box-shadow 0.2s,
    background 0.2s;
  max-width: 500px;
  width: 100%;
  min-width: 340px;
  padding: 40px 40px 32px 40px !important;
}

.login-form:hover {
  box-shadow: 0 16px 40px 0 #a6d0e9a8;
  background: rgba(255, 255, 255, 0.92);
}

.custom-input {
  background: #f6faff !important;
  border-radius: 8px !important;
  border: 1px solid #dbeafe !important;
  font-size: 1rem;
  transition: border 0.2s;
}

.custom-input:focus {
  border-color: #68a4fc !important;
  box-shadow: 0 0 0 2px #b3d9ff3e;
}

.btn-login-glass {
  background: linear-gradient(90deg, #5eb6ff 0%, #a695f7 100%);
  color: #fff;
  font-weight: bold;
  font-size: 1.11rem;
  border: none;
  border-radius: 8px;
  box-shadow: 0 2px 18px #b7e0f782;
  transition:
    background 0.2s,
    transform 0.13s;
  letter-spacing: 0.5px;
  padding: 12px 0;
}

.btn-login-glass:hover {
  background: linear-gradient(90deg, #4a97e7 0%, #7c6df0 100%);
  transform: translateY(-2px) scale(1.03);
}

.btn-social {
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  font-weight: 500;
  font-size: 1rem;
  border: none;
  padding: 8px 0;
  background: #f6faff;
  transition:
    box-shadow 0.2s,
    background 0.2s;
  box-shadow: 0 2px 8px #e4e7f7a0;
  gap: 6px;
}

/* Đảm bảo container flex không bị co lại */
.d-flex.justify-content-center.gap-2.mb-3 > * {
  min-width: 220px;
  height: 44px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 12px;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 500;
  margin-top: 24px;
  /* hoặc 32px nếu muốn cách xa hơn */
}

.btn-social.facebook {
  background: #fff;
  border: 1px solid #dee5f0;
  color: #3b5998;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
  transition:
    box-shadow 0.2s,
    background 0.2s,
    transform 0.15s;
}

.btn-social.facebook:hover {
  background: #f1f6ff;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.forgot-link {
  color: #0c0a38;
  font-weight: 500;
  font-size: 0.96rem;
  transition: color 0.2s;
}

.text-gradient {
  background: linear-gradient(90deg, #5eb6ff, #a695f7);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  font-weight: bold;
  text-decoration: underline;
  transition: opacity 0.15s;
}

.text-gradient:hover {
  opacity: 0.6;
}

@media (max-width: 600px) {
  .login-form {
    max-width: 98vw;
    min-width: unset;
    padding: 20px 6vw 14px 6vw !important;
  }
}
</style>

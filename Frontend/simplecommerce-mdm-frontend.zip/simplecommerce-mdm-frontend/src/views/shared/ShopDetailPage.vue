<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRoute } from 'vue-router';
import { useShopStore } from '@/stores/shop';
import { useProductStore } from '@/stores/product';
import { useRouter } from 'vue-router';
const router = useRouter();

const route = useRoute();
const shopId = Number(route.params.shopId);

const shopStore = useShopStore();
const activeTab = ref('products');
function goToDetail(productId) {
  router.push(`/product/${productId}`);
}

const selectTab = tab => {
  activeTab.value = tab;
  if (tab === 'products') shopStore.fetchProducts(shopId);
};
// computed để dùng trong template, tránh lỗi undefined
const shop = computed(() => shopStore.shop);
const products = computed(() => shopStore.products);
const loading = computed(() => shopStore.loadingShop || shopStore.loadingProducts);
const error = computed(() => shopStore.errorShop);
const totalPages = computed(() => shopStore.totalPages);
const currentPage = computed({
  get: () => shopStore.currentPage,
  set: val => (shopStore.currentPage = val),
});
const formatPrice = shopStore.formatPrice;

onMounted(async () => {
  await shopStore.fetchShop(shopId);
  if (activeTab.value === 'products') {
    await shopStore.fetchProducts(shopId);
  }
});
function prevPage() {
  if (shopStore.currentPage > 0) {
    shopStore.currentPage--;
    shopStore.fetchProducts(shopId);
  }
}

function nextPage() {
  if (shopStore.currentPage + 1 < shopStore.totalPages) {
    shopStore.currentPage++;
    shopStore.fetchProducts(shopId);
  }
}
</script>

<template>
  <div class="shop-page">
    <div v-if="loading" class="loading">⏳ Đang tải thông tin shop...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <div v-else-if="shop">
      <div class="banner">
        <img
          :src="shop.coverImageUrl || 'https://via.placeholder.com/800x200'"
          class="banner-img"
        />
        <div class="banner-overlay"></div>
        <div class="shop-card">
          <img :src="shop.logoUrl || 'https://via.placeholder.com/150'" class="shop-logo" />
          <div class="shop-info">
            <h2 class="shop-name">{{ shop.name || 'Tên shop' }}</h2>
            <p class="shop-desc">{{ shop.description || 'Chưa có mô tả' }}</p>
            <div class="shop-meta">
              <span>🛍️ {{ shop.totalProducts ?? 0 }} sản phẩm</span>
              <span v-if="shop.contactEmail">📧 {{ shop.contactEmail }}</span>
              <span v-if="shop.contactPhone">📞 {{ shop.contactPhone }}</span>
            </div>
          </div>

          <div class="shop-actions">
            <button class="follow-btn">+ Theo dõi</button>
            <button class="chat-btn">Chat ngay</button>
          </div>
        </div>
      </div>

      <div class="shop-navbar">
        <div class="navbar-links">
          <button :class="{ active: activeTab === 'products' }" @click="selectTab('products')">
            Sản phẩm
          </button>
          <button :class="{ active: activeTab === 'feedback' }" @click="selectTab('feedback')">
            Feedback
          </button>
          <button :class="{ active: activeTab === 'info' }" @click="selectTab('info')">
            Thông tin shop
          </button>
        </div>
      </div>

      <div class="tab-content">
        <div v-if="activeTab === 'products'" class="products-section">
          <h3>🛒 Sản phẩm của shop</h3>
          <div v-if="products?.length" class="products-grid">
            <div v-for="p in products" :key="p.id" class="product-card">
              <div class="product-card" @click="goToDetail(p.id)">
                <img
                  :src="p.imageUrls?.[0] || 'https://via.placeholder.com/200'"
                  class="product-img"
                />
              </div>
              <div class="product-info">
                <h4 class="product-name">{{ p.name || 'Sản phẩm' }}</h4>
                <p class="product-price">{{ formatPrice(p.basePrice) }}</p>
                <p class="product-sold">Đã bán {{ p.soldCount ?? 0 }}</p>
              </div>
            </div>
          </div>
          <div v-else class="no-products">❌ Shop chưa có sản phẩm nào.</div>

          <div v-if="totalPages > 1" class="pagination">
            <button @click="prevPage" :disabled="currentPage === 0">Prev</button>
            <span>{{ currentPage + 1 }} / {{ totalPages }}</span>
            <button @click="nextPage" :disabled="currentPage + 1 === totalPages">Next</button>
          </div>
        </div>

        <div v-if="activeTab === 'feedback'" class="feedback-section">
          <h3>💬 Feedback khách hàng</h3>
          <p>Chưa có feedback nào. Bạn có thể thêm đánh giá mẫu hoặc form review ở đây.</p>
        </div>

        <!-- Tab Thông tin shop -->
        <div v-if="activeTab === 'info'" class="info-section">
          <h3>📄 Thông tin shop</h3>
          <p v-if="shop.contactEmail"><strong>Email:</strong> {{ shop.contactEmail }}</p>
          <p v-if="shop.contactPhone"><strong>Phone:</strong> {{ shop.contactPhone }}</p>
          <p v-if="shop.addressLine1">
            <strong>Địa chỉ:</strong> {{ shop.addressLine1 }}, {{ shop.city || '' }},
            {{ shop.country || '' }}
          </p>
          <p v-if="shop.approvedAt">
            <strong>Được duyệt từ:</strong> {{ new Date(shop.approvedAt).toLocaleDateString() }}
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* General */
.shop-page {
  font-family: Arial, sans-serif;
  background-color: #f3f4f6;
  min-height: 100vh;
  color: #333;
}

.loading,
.error {
  text-align: center;
  padding: 2rem;
  font-size: 1.2rem;
}

.error {
  color: red;
}

/* Banner */
.banner {
  position: relative;
  width: 100%;
  height: 16rem;
  overflow: hidden;
}

.banner-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.banner-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(0, 0, 0, 0.5), transparent);
}

/* Shop card */
.shop-card {
  position: absolute;
  bottom: -10px;
  left: 50%;
  transform: translateX(-50%);
  background: #fff;
  border-radius: 1rem;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 1.5rem;
  width: 90%;
  max-width: 1000px;
}

@media (min-width: 768px) {
  .shop-card {
    flex-direction: row;
  }
}

.shop-logo {
  width: 112px;
  height: 112px;
  border-radius: 50%;
  border: 4px solid white;
  object-fit: cover;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  margin-bottom: 1rem;
}

@media (min-width: 768px) {
  .shop-logo {
    margin-bottom: 0;
    margin-right: 1.5rem;
  }
}

.shop-info {
  flex: 1;
  text-align: center;
}

@media (min-width: 768px) {
  .shop-info {
    text-align: left;
  }
}

.shop-name {
  font-size: 1.75rem;
  font-weight: bold;
  color: #1f2937;
  margin-bottom: 0.5rem;
}

.shop-desc {
  color: #4b5563;
  margin-bottom: 0.5rem;
}

.shop-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  font-size: 0.875rem;
  color: #6b7280;
}

.shop-actions {
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
}

@media (min-width: 768px) {
  .shop-actions {
    margin-top: 0;
  }
}

.follow-btn {
  background-color: #f97316;
  color: white;
  border: none;
  padding: 0.5rem 1.25rem;
  border-radius: 0.5rem;
  font-weight: bold;
  cursor: pointer;
  transition: background 0.2s;
}

.follow-btn:hover {
  background-color: #ea580c;
}

.chat-btn {
  background: #fff;
  border: 1px solid #d1d5db;
  padding: 0.5rem 1.25rem;
  border-radius: 0.5rem;
  font-weight: bold;
  cursor: pointer;
  transition: background 0.2s;
}

.chat-btn:hover {
  background: #f3f4f6;
}

/* Navbar */
.shop-navbar {
  margin-top: 8rem;
  background: #fff;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
}

.navbar-links {
  max-width: 1000px;
  margin: 0 auto;
  display: flex;
  gap: 2rem;
  padding: 1rem;
}

.navbar-links button {
  background: none;
  border: none;
  font-weight: bold;
  cursor: pointer;
  padding-bottom: 0.25rem;
  border-bottom: 2px solid transparent;
  transition:
    color 0.2s,
    border-color 0.2s;
}

.navbar-links button.active,
.navbar-links button:hover {
  color: #f97316;
  border-bottom-color: #f97316;
}

/* Tab content */
.tab-content {
  max-width: 1000px;
  margin: 2rem auto;
  padding: 0 1rem;
}

/* Products grid */
.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
}

.product-card {
  background: #fff;
  border-radius: 0.75rem;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition:
    transform 0.2s,
    box-shadow 0.2s;
  display: flex;
  flex-direction: column;
}

.product-card:hover {
  transform: scale(1.02);
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.2);
}

.product-img {
  width: 100%;
  height: 150px;
  object-fit: cover;
}

.product-info {
  padding: 0.5rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.product-name {
  font-weight: bold;
  font-size: 0.95rem;
  margin-bottom: 0.25rem;
}

.product-price {
  color: #ef4444;
  font-weight: bold;
  margin-bottom: 0.25rem;
}

.product-sold {
  font-size: 0.75rem;
  color: #6b7280;
}

/* Feedback & Info */
.feedback-section,
.info-section {
  background: #fff;
  padding: 1.5rem;
  border-radius: 0.75rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.no-products {
  text-align: center;
  padding: 2rem;
  color: #6b7280;
}

.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 12px;
  margin-top: 20px;
}

.pagination button {
  background-color: #4caf50;
  /* màu xanh tươi */
  border: none;
  color: white;
  padding: 8px 16px;
  font-size: 14px;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.pagination button:hover:not(:disabled) {
  background-color: #45a049;
  /* hover effect */
  transform: translateY(-2px);
}

.pagination button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

.pagination span {
  font-weight: 500;
  color: #333;
  font-size: 14px;
}
</style>

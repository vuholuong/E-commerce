<template>
  <!-- Background with animated particles -->
  <div class="bg-wrapper">
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
  </div>

  <!-- Wrapper để căn giữa -->
  <div class="container-fluid min-vh-100 d-flex align-items-center justify-content-center py-5">
    <div class="main-card">
      <div class="card-glow"></div>
      <div class="row g-0 h-100">
        <!-- Contact Info Section -->
        <div class="col-lg-5 d-flex">
          <div class="contact-info-section flex-fill">
            <div class="contact-overlay"></div>
            <div class="contact-content">
              <h3 class="text-white mb-4 fw-bold">
                <i class="bi bi-geo-alt me-3"></i>
                Thông tin liên hệ
              </h3>

              <div class="contact-item">
                <div class="contact-icon">
                  <i class="bi bi-building"></i>
                </div>
                <div class="contact-details">
                  <h6>Địa chỉ</h6>
                  <p>QTSC 9 Building, Đường Tô Ký, Tân Chánh Hiệp, Quận 12<br />TP. Hồ Chí Minh, Việt Nam</p>
                </div>
              </div>

              <div class="contact-item">
                <div class="contact-icon">
                  <i class="bi bi-telephone"></i>
                </div>
                <div class="contact-details">
                  <h6>Điện thoại</h6>
                  <p><a href="tel:0123456789" class="contact-link">0123 456 789</a></p>
                </div>
              </div>

              <div class="contact-item">
                <div class="contact-icon">
                  <i class="bi bi-envelope"></i>
                </div>
                <div class="contact-details">
                  <h6>Email</h6>
                  <p><a href="mailto:contact@example.com" class="contact-link">contact@example.com</a></p>
                </div>
              </div>

              <div class="contact-item">
                <div class="contact-icon">
                  <i class="bi bi-clock"></i>
                </div>
                <div class="contact-details">
                  <h6>Giờ làm việc</h6>
                  <p>Thứ 2 - Thứ 6: 8:00 - 18:00<br />Thứ 7: 8:00 - 12:00</p>
                </div>
              </div>

              <!-- Social Media -->
              <div class="social-links mt-4">
                <h6 class="text-white mb-3">Theo dõi chúng tôi</h6>
                <div class="d-flex gap-3">
                  <a href="#" class="social-link"><i class="bi bi-facebook"></i></a>
                  <a href="#" class="social-link"><i class="bi bi-instagram"></i></a>
                  <a href="#" class="social-link"><i class="bi bi-linkedin"></i></a>
                  <a href="#" class="social-link"><i class="bi bi-twitter"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Contact Form Section -->
        <div class="col-lg-7 d-flex align-items-center">
          <div class="form-section p-5 flex-fill">
            <h4 class="fw-bold mb-4 text-gradient text-center">
              <i class="bi bi-chat-dots me-2"></i>
              Gửi tin nhắn cho chúng tôi
            </h4>

            <form id="contactForm" onsubmit="submitForm(event)">
              <div class="row g-4">
                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control modern-input" id="name" placeholder="Họ và tên" required />
                    <label for="name"><i class="bi bi-person me-2"></i>Họ và tên *</label>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="email" class="form-control modern-input" id="email" placeholder="Email" required />
                    <label for="email"><i class="bi bi-envelope me-2"></i>Email *</label>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="tel" class="form-control modern-input" id="phone" placeholder="Số điện thoại" />
                    <label for="phone"><i class="bi bi-telephone me-2"></i>Số điện thoại</label>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-floating">
                    <select class="form-select modern-input" id="subject" required>
                      <option value="">Chọn chủ đề</option>
                      <option value="support">Hỗ trợ khách hàng</option>
                      <option value="complaint">Khiếu nại</option>
                      <option value="suggestion">Đề xuất</option>
                      <option value="business">Hợp tác kinh doanh</option>
                      <option value="other">Khác</option>
                    </select>
                    <label for="subject"><i class="bi bi-tag me-2"></i>Chủ đề *</label>
                  </div>
                </div>

                <div class="col-12">
                  <div class="form-floating">
                    <textarea class="form-control modern-input" id="message" placeholder="Nội dung" style="height: 120px" required></textarea>
                    <label for="message"><i class="bi bi-chat-text me-2"></i>Nội dung tin nhắn *</label>
                  </div>
                </div>

                <div class="col-12">
                  <button type="submit" class="btn modern-btn w-100" id="submitBtn">
                    <span class="btn-text"><i class="bi bi-send me-2"></i>Gửi tin nhắn</span>
                    <span class="btn-loading d-none">
                      <span class="spinner-border spinner-border-sm me-2"></span>Đang gửi...
                    </span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// Form submission
function submitForm(event) {
  event.preventDefault();

  const submitBtn = document.getElementById('submitBtn');
  const btnText = submitBtn.querySelector('.btn-text');
  const btnLoading = submitBtn.querySelector('.btn-loading');

  // Show loading state
  btnText.classList.add('d-none');
  btnLoading.classList.remove('d-none');
  submitBtn.disabled = true;

  // Simulate API call
  setTimeout(() => {
    // Reset form
    document.getElementById('contactForm').reset();

    // Reset button
    btnText.classList.remove('d-none');
    btnLoading.classList.add('d-none');
    submitBtn.disabled = false;

    // Show success modal
    const modal = new bootstrap.Modal(document.getElementById('successModal'));
    modal.show();
  }, 2000);
}

// Add floating animation to particles
function animateParticles() {
  const particles = document.querySelectorAll('.particle');
  particles.forEach((particle, index) => {
    particle.style.animationDelay = `${index * 0.5}s`;
  });
}

// Initialize animations on load
document.addEventListener('DOMContentLoaded', function() {
  animateParticles();

  // Add smooth scroll behavior for better UX
  document.documentElement.style.scrollBehavior = 'smooth';
});
</script>

<style scoped>
.main-card {
  max-width: 1100px;
  width: 100%;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 24px;
  overflow: hidden;
  position: relative;
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  display: flex;
  min-height: 600px;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
  position: relative;
  overflow-x: hidden;
}

/* Background Animation */
.bg-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.particle {
  position: absolute;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 50%;
  animation: float 6s ease-in-out infinite;
}

.particle:nth-child(1) {
  width: 80px;
  height: 80px;
  top: 20%;
  left: 10%;
  animation-duration: 6s;
}

.particle:nth-child(2) {
  width: 60px;
  height: 60px;
  top: 60%;
  left: 80%;
  animation-duration: 8s;
}

.particle:nth-child(3) {
  width: 100px;
  height: 100px;
  top: 40%;
  left: 70%;
  animation-duration: 7s;
}

.particle:nth-child(4) {
  width: 40px;
  height: 40px;
  top: 80%;
  left: 20%;
  animation-duration: 5s;
}

.particle:nth-child(5) {
  width: 120px;
  height: 120px;
  top: 10%;
  left: 60%;
  animation-duration: 9s;
}

@keyframes float {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  33% { transform: translateY(-30px) rotate(120deg); }
  66% { transform: translateY(30px) rotate(240deg); }
}

/* Header Styles */
.header-icon {
  width: 80px;
  height: 80px;
  margin: 0 auto;
  background: linear-gradient(135deg, #fff 0%, #f8f9fa 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.header-icon i {
  font-size: 2.5rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.text-gradient {
  background: linear-gradient(135deg, #333 0%, #666 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* Main Card */
.main-card {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 24px;
  overflow: hidden;
  position: relative;
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  min-height: 600px;
}

.card-glow {
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: conic-gradient(from 0deg, transparent, rgba(102, 126, 234, 0.1), transparent);
  animation: rotate 10s linear infinite;
  z-index: -1;
}

@keyframes rotate {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Contact Info Section */
.contact-info-section {
  position: relative;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  display: flex;
  align-items: center;
}

.contact-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: url('data:image/svg+xml,<svg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><g fill="%23ffffff" fill-opacity="0.05"><circle cx="30" cy="30" r="4"/></g></svg>');
  opacity: 0.3;
}

.contact-content {
  position: relative;
  z-index: 2;
  padding: 3rem;
  width: 100%;
}

.contact-item {
  display: flex;
  align-items: flex-start;
  margin-bottom: 2rem;
  padding: 1rem;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  transition: all 0.3s ease;
}

.contact-item:hover {
  background: rgba(255, 255, 255, 0.15);
  transform: translateX(5px);
}

.contact-icon {
  width: 50px;
  height: 50px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 1rem;
  flex-shrink: 0;
}

.contact-icon i {
  font-size: 1.25rem;
  color: white;
}

.contact-details h6 {
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.9);
}

.contact-details p {
  margin: 0;
  color: rgba(255, 255, 255, 0.8);
  line-height: 1.5;
}

.contact-link {
  color: rgba(255, 255, 255, 0.9);
  text-decoration: none;
  transition: color 0.3s ease;
}

.contact-link:hover {
  color: white;
}

/* Social Links */
.social-links {
  padding-top: 1rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
}

.social-link {
  width: 45px;
  height: 45px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  text-decoration: none;
  transition: all 0.3s ease;
}

.social-link:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-3px);
  color: white;
}

/* Form Section */
.form-section {
  background: white;
}

.modern-input {
  border: 2px solid #e9ecef;
  border-radius: 12px;
  background: #f8f9fa;
  transition: all 0.3s ease;
  font-size: 0.95rem;
  padding: 1rem 1rem 1rem 1rem;
}

.modern-input:focus {
  border-color: #667eea;
  box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.15);
  background: white;
  transform: translateY(-2px);
}

.form-floating > label {
  color: #6c757d;
  font-weight: 500;
}

.form-floating > .form-control:focus ~ label,
.form-floating > .form-control:not(:placeholder-shown) ~ label,
.form-floating > .form-select ~ label {
  color: #667eea;
  font-weight: 600;
}

/* Modern Button */
.modern-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  border-radius: 12px;
  padding: 1rem 2rem;
  font-weight: 600;
  font-size: 1.1rem;
  color: white;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.modern-btn::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
  transition: left 0.5s;
}

.modern-btn:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
  color: white;
}

.modern-btn:hover::before {
  left: 100%;
}

.modern-btn:active {
  transform: translateY(-1px);
}

.modern-btn:disabled {
  opacity: 0.7;
  transform: none;
  cursor: not-allowed;
}

/* Success Modal */
.success-icon {
  width: 80px;
  height: 80px;
  margin: 0 auto;
  background: linear-gradient(135deg, #28a745, #20c997);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: pulse 2s infinite;
}

.success-icon i {
  font-size: 2.5rem;
  color: white;
}

@keyframes pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.1); }
  100% { transform: scale(1); }
}

.modal-content {
  border-radius: 20px;
  background: white;
}

/* Responsive Design */
@media (max-width: 992px) {
  .contact-content {
    padding: 2rem;
  }

  .form-section {
    padding: 2rem !important;
  }
}

@media (max-width: 768px) {
  .contact-info-section {
    min-height: 400px;
  }

  .contact-content {
    padding: 1.5rem;
  }

  .form-section {
    padding: 1.5rem !important;
  }

  .header-icon {
    width: 60px;
    height: 60px;
  }

  .header-icon i {
    font-size: 2rem;
  }
}
</style>

<template>
  <div class="notfound-container">
    <h1>404</h1>
    <p>Không tìm thấy trang bạn yêu cầu.</p>
    <router-link to="/">Quay về trang chủ</router-link>
  </div>
</template>

<script setup>
// Trang 404 đơn giản
</script>

<style scoped>
.notfound-container {
  min-height: 60vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
}
h1 {
  font-size: 5rem;
  color: #2563eb;
  margin-bottom: 1rem;
}
p {
  font-size: 1.3rem;
  margin-bottom: 1.5rem;
}
</style>

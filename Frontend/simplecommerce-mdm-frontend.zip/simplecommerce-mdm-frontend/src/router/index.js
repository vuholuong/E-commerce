import { createRouter, createWebHistory } from 'vue-router';
import MainLayout from '@/layouts/MainLayout.vue';
import AuthLayout from '@/layouts/AuthLayout.vue';
import RegisterSeller from '@/views/seller/RegisterSeller.vue';
import ProductGrid from '@/components/products/ProductGrid.vue';
import LoginPage from '@/views/auth/LoginPage.vue';
import RegisterPage from '@/views/auth/RegisterPage.vue';
import ForgotPassword from '@/views/auth/ForgotPassword.vue';
import ProductDetail from '@/views/buyer/ProductDetail.vue';
import Order from '@/components/orders/Order.vue';
import ShoppingCart from '@/components/cart/ShoppingCart.vue';
import UserProfile from '@/views/buyer/UserProfile.vue';
import ProductCatalog from '@/views/buyer/ProductCatalog.vue';
import OrderHistory from '@/views/buyer/OrderHistory.vue';
import ShopPage from '@/views/buyer/ShopPage.vue';
import CategoryPage from '@/views/buyer/CategoryPage.vue';
import AllProducts from '@/views/buyer/AllProducts.vue';

const routes = [
  {
    path: '/',
    component: MainLayout,
    children: [
      {
        path: '',
        name: 'home',
        component: ProductGrid,
      },
    ],
  },
  {
    path: '/',
    component: AuthLayout,
    children: [
      // Authentication routes
      {
        path: 'login',
        name: 'login',
        component: LoginPage,
      },
      {
        path: 'register',
        name: 'register',
        component: RegisterPage,
      },
      {
        path: 'register-seller',
        name: 'registerSeller',
        component: RegisterSeller,
      },
      {
        path: 'forgot-password',
        name: 'forgotPassword',
        component: ForgotPassword,
      },

      // Product routes
      {
        path: 'products',
        name: 'productCatalog',
        component: ProductCatalog,
      },
      {
        path: 'product/:id',
        name: 'productDetail',
        component: ProductDetail,
      },
      {
        path: 'products/all',
        name: 'allProducts',
        component: AllProducts,
      },
      {
        path: 'category/:id',
        name: 'category',
        component: CategoryPage,
        props: true,
      },

      // Shopping routes
      {
        path: 'cart',
        name: 'shoppingCart',
        component: ShoppingCart,
      },
      {
        path: 'order',
        name: 'order',
        component: Order,
      },
      {
        path: 'order-history',
        name: 'orderHistory',
        component: OrderHistory,
      },

      // User routes
      {
        path: 'profile',
        name: 'userProfile',
        component: UserProfile,
      },

      // Shop routes
      {
        path: 'shop',
        name: 'shopPage',
        component: ShopPage,
      },
      {
        path: 'shop/:shopId',
        name: 'shopDetail',
        component: () => import('@/views/shared/ShopDetailPage.vue'),
        props: true,
      },

      // Additional pages
      {
        path: 'sale',
        name: 'salePage',
        component: () => import('@/views/buyer/SalePage.vue'),
      },
      {
        path: 'contact',
        name: 'contactPage',
        component: () => import('@/views/shared/ContactPage.vue'),
      },

      // Legacy routes (for backward compatibility)
      {
        path: 'dn',
        redirect: { name: 'login' },
      },
      {
        path: 'dk',
        redirect: { name: 'register' },
      },
      {
        path: 'RegisterSeller',
        redirect: { name: 'registerSeller' },
      },
      {
        path: 'all',
        redirect: { name: 'productCatalog' },
      },
      {
        path: 'dh',
        redirect: { name: 'order' },
      },
      {
        path: 'gh',
        redirect: { name: 'shoppingCart' },
      },
      {
        path: 'info',
        redirect: { name: 'userProfile' },
      },
      {
        path: 'dhct',
        redirect: { name: 'orderHistory' },
      },
      {
        path: 'cuahang',
        redirect: { name: 'shopPage' },
      },
      {
        path: 'Allsanpham',
        redirect: { name: 'allProducts' },
      },

      // 404 route
      {
        path: '/:pathMatch(.*)*',
        name: 'NotFound',
        component: () => import('@/views/shared/NotFoundPage.vue'),
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;

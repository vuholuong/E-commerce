// services/forgotPasswordService.js
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

export const forgotPasswordService = {
  async sendOTP(email) {
    try {
      const response = await api.post(API_ENDPOINTS.AUTH.FORGOT_PASSWORD, {
        email: email.trim().toLowerCase(),
      });

      // Không tự gắn success nếu backend không có — nhưng vẫn trả về object chuẩn
      return {
        success: true,
        data: response.data?.data,
        message: response.data?.message || 'OTP đã được gửi thành công',
      };
    } catch (error) {
      if (error.response) {
        const status = error.response.status;
        const message = error.response.data?.message || error.response.data?.error;

        switch (status) {
          case 400:
            throw new Error(message || 'Dữ liệu không hợp lệ');
          case 404:
            throw new Error('Email không tồn tại trong hệ thống');
          case 429:
            throw new Error('Quá nhiều yêu cầu. Vui lòng thử lại sau');
          case 500:
            throw new Error('Lỗi server. Vui lòng thử lại sau');
          default:
            throw new Error(message || 'Có lỗi xảy ra khi gửi OTP');
        }
      } else if (error.request) {
        throw new Error('Không thể kết nối đến server. Vui lòng kiểm tra kết nối mạng');
      } else {
        // ⚠️ Quan trọng: giữ nguyên lỗi gốc nếu là lỗi mình ném ra từ try
        throw error;
      }
    }
  },

  async changePassword(email, otpCode, newPassword) {
    try {
      const response = await api.post(API_ENDPOINTS.AUTH.CHANGE_PASSWORD, {
        email: email.trim().toLowerCase(),
        otpCode: otpCode.trim(),
        newPassword,
      });

      // Fix: check cả statusCode lẫn status trong body
      const okFromBody =
          (typeof response.data?.statusCode === 'number' && response.data.statusCode === 200) ||
          (typeof response.data?.status === 'number' && response.data.status === 200);

      if (!okFromBody) {
        throw new Error(response.data?.message || 'Đổi mật khẩu thất bại');
      }

      return {
        success: true,
        data: response.data?.data,
        message: response.data?.message || 'Mật khẩu đã được đổi thành công',
      };
    } catch (error) {
      if (error.response) {
        const status = error.response.status;
        const message = error.response.data?.message || error.response.data?.error;

        switch (status) {
          case 400:
            if (message?.toLowerCase().includes('otp')) {
              throw new Error('Mã OTP không hợp lệ hoặc đã hết hạn');
            } else if (message?.toLowerCase().includes('password')) {
              throw new Error('Mật khẩu không đủ mạnh');
            }
            throw new Error(message || 'Dữ liệu không hợp lệ');
          case 404:
            throw new Error('Email không tồn tại trong hệ thống');
          case 409:
            if (message === 'Invalid or expired OTP code') {
              throw new Error('Mã OTP không hợp lệ hoặc đã hết hạn');
            }
            throw new Error(message || 'Mã OTP sai hoặc đã hết hạn');

          case 429:
            throw new Error('Quá nhiều yêu cầu. Vui lòng thử lại sau');
          case 500:
            throw new Error('Lỗi server. Vui lòng thử lại sau');
          default:
            throw new Error(message || 'Có lỗi xảy ra khi đổi mật khẩu');
        }
      } else if (error.request) {
        throw new Error('Không thể kết nối đến server. Vui lòng kiểm tra kết nối mạng');
      } else {
        throw error;
      }
    }
  },

  async resetPassword(email, otpCode, newPassword) {
    return this.changePassword(email, otpCode, newPassword);
  },

  validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  validatePassword(password) {
    const result = { isValid: false, errors: [] };
    if (!password || password.length < 8) result.errors.push('Mật khẩu phải có ít nhất 8 ký tự');
    if (!/(?=.*[a-z])/.test(password)) result.errors.push('Mật khẩu phải chứa ít nhất 1 chữ thường');
    if (!(/(?=.*[A-Z])/.test(password))) result.errors.push('Mật khẩu phải chứa ít nhất 1 chữ hoa');
    if (!/(?=.*\d)/.test(password)) result.errors.push('Mật khẩu phải chứa ít nhất 1 số');
    if (!/(?=.*[!@#$%^&*(),.?":{}|<>])/.test(password)) result.errors.push('Mật khẩu phải chứa ít nhất 1 ký tự đặc biệt');
    result.isValid = result.errors.length === 0;
    return result;
  },

  validateOTP(otp) {
    const otpRegex = /^\d{6}$/;
    return otpRegex.test(otp);
  },
};

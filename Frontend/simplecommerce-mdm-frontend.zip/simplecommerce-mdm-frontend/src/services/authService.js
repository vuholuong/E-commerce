import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

export const authService = {
  async register(payload) {
    return api.post(API_ENDPOINTS.AUTH.REGISTER, payload);
  },
  
  async createShop(shopPayload, token) {
    return api.post(API_ENDPOINTS.USER.SHOP, shopPayload, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
};

// src/services/addressService.js
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';
import { useAuthStore } from '@/stores/auth';

// đọc token từ Pinia hoặc localStorage
const authHeaders = () => {
  const token = useAuthStore()?.app_access_token || localStorage.getItem('app_access_token');
  return {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  };
};

export const getAddresses = () => api.get(API_ENDPOINTS.ADDRESS.LIST, authHeaders());
export const createAddress = payload => api.post(API_ENDPOINTS.ADDRESS.CREATE, payload, authHeaders());
export const updateAddress = (id, payload) =>
  api.put(API_ENDPOINTS.ADDRESS.UPDATE(id), payload, authHeaders());
export const deleteAddress = id => api.delete(API_ENDPOINTS.ADDRESS.DELETE(id), authHeaders());

// (tuỳ chọn) hỗ trợ đổi mặc định để xoá được địa chỉ đang là default
export const setDefaultShipping = id =>
  api.patch(API_ENDPOINTS.ADDRESS.SET_DEFAULT_SHIPPING(id), null, authHeaders());
export const setDefaultBilling = id =>
  api.patch(API_ENDPOINTS.ADDRESS.SET_DEFAULT_BILLING(id), null, authHeaders());

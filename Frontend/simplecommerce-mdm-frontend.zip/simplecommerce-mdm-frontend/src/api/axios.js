import axios from 'axios';
import { useAuthStore } from '@/stores/auth';
import router from '@/router';

// Lấy API base URL từ biến môi trường
const getApiBaseUrl = () => {
  // Trong development, sử dụng proxy Vite
  if (import.meta.env.DEV) {
    return '/api';
  }
  
  // Trong production, sử dụng biến môi trường
  const productionUrl = import.meta.env.VITE_API_BASE_URL;
  
  if (productionUrl) {
    return productionUrl;
  }
  
  // Fallback URL nếu không có biến môi trường
  console.warn('⚠️ VITE_API_BASE_URL không được cấu hình, sử dụng fallback URL');
  return 'https://sc-mdm-api.nammai.id.vn/api/v1';
};

// Tạo axios instance với cấu hình tập trung
const api = axios.create({
  baseURL: getApiBaseUrl(),
  timeout: parseInt(import.meta.env.VITE_API_TIMEOUT) || 10000,
  withCredentials: true, // Thay đổi về true để sử dụng credentials
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

// Interceptor cho request
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('app_access_token');

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    // Log request trong development
    if (import.meta.env.DEV) {
      console.log('API Request:', config.method?.toUpperCase(), config.url);
    }
    
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// Interceptor cho response
api.interceptors.response.use(
  response => {
    // Log response trong development
    if (import.meta.env.DEV) {
      console.log('API Response:', response.status, response.config.url);
    }
    return response;
  },
  error => {
    const msg = error.response?.data?.message || '';
    const status = error.response?.status;

    // Log error trong development
    if (import.meta.env.DEV) {
      console.error('API Error:', status, error.config?.url, msg);
    }

    // Xử lý lỗi 401 hoặc JWT expired
    if (status === 401 || msg.includes('JWT expired')) {
      const authStore = useAuthStore();
      authStore.logout();
      router.push({ name: 'login' });
    }

    return Promise.reject(error);
  }
);

export default api;

import { defineStore } from 'pinia'
import { ref } from 'vue'
import api from '@/api/axios'
import { API_ENDPOINTS } from '@/constants'
import { useAuthStore } from '@/stores/auth'

export const useReviewStore = defineStore('review', () => {
  const reviews = ref([])
  const statistics = ref({
    totalReviews: 0,
    averageRating: 0,
    fiveStarCount: 0,
    fourStarCount: 0,
    threeStarCount: 0,
    twoStarCount: 0,
    oneStarCount: 0
  })
  const isLoading = ref(false)
  const error = ref(null)

  // Lấy danh sách đánh giá theo productId
  const fetchProductReviews = async (productId, page = 0, size = 10) => {
    isLoading.value = true
    error.value = null
    try {
      const response = await api.get(API_ENDPOINTS.REVIEW.BY_PRODUCT(productId), {
        params: { page, size, sortBy: 'createdAt', sortDir: 'desc' }
      })
      const data = response.data.data
      reviews.value = data.reviews || []

      // Luôn gọi thống kê riêng
      await fetchReviewStatistics(productId)

    } catch (err) {
      // Nếu lỗi 403, có thể do chưa đăng nhập - không hiển thị error
      if (err.response?.status === 403) {
        console.log('Reviews API yêu cầu authentication, bỏ qua lỗi này');
        error.value = null; // Không hiển thị error cho user
        reviews.value = []; // Reset reviews
      } else {
        error.value = err.response?.data?.message || 'Lỗi khi tải đánh giá'
        console.error('Lỗi fetch reviews:', err)
      }
    } finally {
      isLoading.value = false
    }
  }

  // Lấy thống kê đánh giá
  const fetchReviewStatistics = async (productId) => {
    try {
      const response = await api.get(API_ENDPOINTS.REVIEW.STATISTICS(productId))
      statistics.value = response.data.data
    } catch (err) {
      // Nếu lỗi 403, có thể do chưa đăng nhập - giữ giá trị mặc định
      if (err.response?.status === 403) {
        console.log('Reviews API yêu cầu authentication, giữ giá trị mặc định');
        // Giữ nguyên giá trị mặc định đã khởi tạo
      } else {
        console.error('Lỗi fetch statistics:', err)
      }
    }
  }

  // Tạo đánh giá mới
  const createReview = async (reviewData) => {
    try {
      const response = await api.post(API_ENDPOINTS.REVIEW.CREATE, reviewData)
      return response.data
    } catch (err) {
      throw new Error(err.response?.data?.message || 'Lỗi khi tạo đánh giá')
    }
  }

  return {
    reviews,
    statistics,
    isLoading,
    error,
    fetchProductReviews,
    fetchReviewStatistics,
    createReview
  }
})
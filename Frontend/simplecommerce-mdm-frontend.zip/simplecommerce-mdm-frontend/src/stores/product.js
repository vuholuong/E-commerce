// src/stores/product.js
import { defineStore } from 'pinia';
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

export const useProductStore = defineStore('product', {
  state: () => ({
    products: [],
    featuredProducts: [],
    productDetail: null,
    shopDetail: null,
    similarProducts: [],
    loading: false,
    error: null,
    categories: [],
    currentCategory: null,
  }),

  getters: {
    allProducts: state => state.products,
    isLoading: state => state.loading,
    getProductDetail: state => state.productDetail,
    getFeaturedProducts: state => state.featuredProducts,
    getShopDetail: state => state.shopDetail,
  },

  actions: {
    // Lấy tất cả sản phẩm
    async fetchProducts(params = {}) {
      try {
        this.loading = true;
        const queryParams = {
          sortBy: this.validateSortBy(params.sortBy),
          sortDirection: params.sortDirection || 'desc',
          size: params.size || 9999,
          searchTerm: params.searchTerm || '',
        };
        const res = await api.get(API_ENDPOINTS.PRODUCT.LIST, { params: queryParams });
        this.products = Array.isArray(res.data?.data?.products)
          ? res.data.data.products
          : Array.isArray(res.data?.data)
            ? res.data.data
            : [];
      } catch (err) {
        this.error = err.response?.data?.message || err.message;
      } finally {
        this.loading = false;
      }
    },

    // Lấy danh sách sản phẩm nổi bật
    async fetchFeaturedProducts() {
      try {
        this.loading = true;
        let products = [];
        try {
          const res = await api.get(API_ENDPOINTS.PRODUCT.FEATURED, {
            params: { sortBy: 'publishedAt', sortDirection: 'desc', size: 9999 },
          });
          products = Array.isArray(res.data?.data?.products)
            ? res.data.data.products
            : Array.isArray(res.data?.data)
              ? res.data.data
              : [];
        } catch {
          products = this.products.filter(p => Boolean(p.isFeatured));
        }
        this.featuredProducts = products;
      } catch (err) {
        this.error = err.response?.data?.message || err.message;
      } finally {
        this.loading = false;
      }
    },

    // Lấy chi tiết sản phẩm
    async fetchProductById(id) {
      try {
        this.loading = true;
        const res = await api.get(API_ENDPOINTS.PRODUCT.DETAIL(id));
        this.productDetail = res.data.data;
      } catch (err) {
        this.error = err.response?.data?.message || err.message;
        this.productDetail = null;
      } finally {
        this.loading = false;
      }
    },

    // Sản phẩm theo category
    async fetchProductsByCategory(categoryId, params = {}) {
      try {
        this.loading = true;
        const queryParams = {
          sortBy: this.validateSortBy(params.sortBy),
          sortDirection: params.sortDirection || 'desc',
          size: params.size || 9999,
        };
        const res = await api.get(API_ENDPOINTS.PRODUCT.BY_CATEGORY(categoryId), {
          params: queryParams,
        });
        this.products = res.data.data?.products || res.data.data || [];
        this.currentCategory = categoryId;
      } catch (err) {
        this.error = err.response?.data?.message || err.message;
      } finally {
        this.loading = false;
      }
    },

    // Sản phẩm liên quan
    async fetchRelatedProducts(productId, params = { page: 0, size: 10 }) {
      try {
        this.loading = true;
        const res = await api.get(API_ENDPOINTS.PRODUCT.RELATED(productId), { params });
        const products = res.data?.data?.products || [];
        this.similarProducts = Array.isArray(products) ? products : [];
      } catch (error) {
        this.error = error.response?.data?.message || error.message;
        this.similarProducts = [];
      } finally {
        this.loading = false;
      }
    },

    clearProducts() {
      this.products = [];
    },

    clearError() {
      this.error = null;
    },

    validateSortBy(value) {
      const allowed = ['publishedAt', 'name', 'basePrice', 'approvedAt', 'isFeatured'];
      return allowed.includes(value) ? value : 'publishedAt';
    },
  },
});

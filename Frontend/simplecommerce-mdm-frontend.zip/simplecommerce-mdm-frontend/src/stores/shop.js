// src/stores/shop.js
import { defineStore } from 'pinia';
import { ref } from 'vue';
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

export const useShopStore = defineStore('shop', () => {
  const shop = ref(null);
  const products = ref([]);
  const loadingShop = ref(false);
  const loadingProducts = ref(false);
  const errorShop = ref(null);
  const totalPages = ref(0);
  const currentPage = ref(0);
  const pageSize = 20;
  const searchTerm = ref('');

  const formatPrice = value => {
    if (!value) return 'Liên hệ';
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
  };

  const fetchShop = async shopId => {
    if (!shopId) return;
    loadingShop.value = true;
    try {
      const res = await api.get(API_ENDPOINTS.SHOP.DETAIL(shopId));
      shop.value = res.data.data;
    } catch (err) {
      console.error('Lấy thông tin shop thất bại', err);
      errorShop.value = 'Không load được thông tin shop';
    } finally {
      loadingShop.value = false;
    }
  };

  const fetchProducts = async shopId => {
    if (!shopId) return;
    loadingProducts.value = true;
    try {
      const res = await api.get(API_ENDPOINTS.PRODUCT.BY_SHOP(shopId), {
        params: {
          page: currentPage.value,
          size: pageSize,
          searchTerm: searchTerm.value,
          sortBy: 'createdAt',
          sortDirection: 'desc',
        },
      });

      if (res.data?.data?.products) {
        products.value = res.data.data.products;
      } else if (Array.isArray(res.data?.data)) {
        products.value = res.data.data;
      } else if (Array.isArray(res.data)) {
        products.value = res.data;
      } else {
        products.value = [];
        console.warn('Không tìm thấy sản phẩm trong response');
      }

      totalPages.value = res.data?.data?.totalPages || 1;
    } catch (err) {
      console.error('Lấy sản phẩm thất bại:', err);
      products.value = [];
    } finally {
      loadingProducts.value = false;
    }
  };

  return {
    shop,
    products,
    loadingShop,
    loadingProducts,
    errorShop,
    totalPages,
    currentPage,
    pageSize,
    searchTerm,
    formatPrice,
    fetchShop,
    fetchProducts,
  };
});

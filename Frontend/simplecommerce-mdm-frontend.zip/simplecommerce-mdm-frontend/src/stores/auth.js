import { defineStore } from 'pinia';
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';
import router from '@/router';

function decodeToken(token) {
  try {
    const base64Payload = token.split('.')[1];
    const payload = atob(base64Payload);
    return JSON.parse(payload);
  } catch (e) {
    console.error('Lỗi khi decode token:', e);
    return null;
  }
}

export const useAuthStore = defineStore('auth', {
  state: () => ({
    app_access_token: localStorage.getItem('app_access_token') || null,
    app_refresh_token: localStorage.getItem('app_refresh_token') || null,
    user: JSON.parse(localStorage.getItem('app_user_session')) || null,
    profile: null, // Always fetched from backend, never persisted locally
    error: null,
    loading: false, // ✅ thêm loading để dùng trong các action
  }),

  getters: {
    // Getter để lấy token (backward compatibility)
    get token() {
      return this.app_access_token;
    },
    
    // Getter để kiểm tra đã đăng nhập
    isAuthenticated() {
      return !!this.app_access_token;
    }
  },

  actions: {
    async login(email, password) {
      this.loading = true;
      this.error = null;
      try {
        const res = await api.post(API_ENDPOINTS.AUTH.LOGIN, { email, password });
        const accessToken = res.data?.data?.accessToken;
        const refreshToken = res.data?.data?.refreshToken;
        
        if (accessToken) {
          this.app_access_token = accessToken;
          this.app_refresh_token = refreshToken;
          this.user = decodeToken(accessToken);
          
          // Lưu vào localStorage với tên mới
          localStorage.setItem('app_access_token', accessToken);
          if (refreshToken) {
            localStorage.setItem('app_refresh_token', refreshToken);
          }
          localStorage.setItem('app_user_session', JSON.stringify(this.user));
          
          await this.fetchProfile();
          return true;
        }
        this.error = res.data?.message || 'Tài khoản hoặc mật khẩu sai';
        return false;
      } catch (err) {
        this.error = err.response?.data?.message || 'Đăng nhập thất bại';
        return false;
      } finally {
        this.loading = false;
      }
    },

    async fetchProfile() {
      if (!this.app_access_token) return;
      try {
        const res = await api.get(API_ENDPOINTS.USER.PROFILE);
        const profile = res.data?.data;
        if (profile) {
          this.profile = profile; // do not persist
        }
      } catch (err) {
        console.error(err.response?.data || err.message);
      }
    },

    async updateProfile(updateRequest, avatarFile = null) {
      if (!this.app_access_token) return false;
      try {
        const formData = new FormData();

        // Nếu updateRequest có metadata, đảm bảo nó được xử lý đúng
        const profileData = {
          firstName: updateRequest.firstName,
          lastName: updateRequest.lastName,
          phoneNumber: updateRequest.phoneNumber,
          avatarUrl: updateRequest.avatarUrl,
        };

        // Thêm metadata nếu có
        if (updateRequest.metadata) {
          profileData.metadata = updateRequest.metadata;
        }

        formData.append(
          'profile',
          new Blob([JSON.stringify(profileData)], { type: 'application/json' })
        );

        if (avatarFile) {
          formData.append('avatar', avatarFile);
        }

        await api.put(API_ENDPOINTS.USER.PROFILE, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });

        await this.fetchProfile();
        return true;
      } catch (err) {
        this.error = err.response?.data?.message || 'Cập nhật profile thất bại';
        return false;
      }
    },

    async logoutWithAPI() {
      const token = this.app_access_token || localStorage.getItem('app_access_token');
      if (!token) return this.logout();
      try {
        await api.post(API_ENDPOINTS.AUTH.LOGOUT);
      } catch (err) {
        console.warn(err.response?.data || err.message);
      } finally {
        this.logout();
      }
    },
    
    logout() {
      this.app_access_token = null;
      this.app_refresh_token = null;
      this.user = null;
      this.profile = null;
      localStorage.removeItem('app_access_token');
      localStorage.removeItem('app_refresh_token');
      localStorage.removeItem('app_user_session');
    },
    
    async changePassword(oldPassword, newPassword, confirmPassword) {
      this.error = null;
      try {
        const res = await api.post(
          API_ENDPOINTS.USER.CHANGE_PASSWORD,
          { oldPassword, newPassword, confirmPassword }
        );
        const message = res.data?.message || '';
        if (message.toLowerCase().includes('success')) return true;
        this.error = message || 'Đổi mật khẩu thất bại';
        return false;
      } catch (err) {
        this.error = err.response?.data?.message || 'Đổi mật khẩu thất bại';
        return false;
      }
    },
    
    async loginGoogle(googleToken) {
      try {
        const res = await api.post(API_ENDPOINTS.AUTH.GOOGLE, { token: googleToken });
        const accessToken = res.data?.data?.accessToken || res.data?.data?.token;
        if (!accessToken) {
          this.error = 'Không nhận được token từ server';
          return false;
        }
        this.app_access_token = accessToken;
        this.user = decodeToken(accessToken);
        localStorage.setItem('app_access_token', accessToken);
        localStorage.setItem('app_user_session', JSON.stringify(this.user));
        await this.fetchProfile();
        return true;
      } catch (err) {
        this.error = err.response?.data?.message || err.message;
        return false;
      }
    },
    
    // ✅ NEW: Đăng ký seller (register → login → tạo shop)
    async registerSeller(registerRequest, shopRequest) {
      try {
        // 1. Tạo user
        await api.post(API_ENDPOINTS.AUTH.REGISTER, registerRequest);

        // 2. Đăng nhập để lấy token
        const ok = await this.login(registerRequest.email, registerRequest.password);
        if (!ok) throw new Error('Đăng nhập thất bại sau khi đăng ký');

        // 3. Gửi yêu cầu tạo shop (sẽ pending chờ admin duyệt)
        await api.post(API_ENDPOINTS.USER.SHOP, shopRequest);

        return true;
      } catch (err) {
        this.error = err.response?.data?.message || err.message;
        return false;
      }
    },
  },
});
export function setupAxiosInterceptors() {
  const authStore = useAuthStore();

  // Request: tự động thêm Authorization nếu có token
  api.interceptors.request.use(
      (config) => {
        if (authStore.app_access_token) {
          config.headers.Authorization = `Bearer ${authStore.app_access_token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
  );

  // Response: bắt lỗi 401
  api.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          authStore.logout();
          router.push('/login');
        }
        return Promise.reject(error);
      }
  );
}
/**
 * 🚀 Hàm kiểm tra token còn hạn không (theo exp trong JWT)
 */
export function checkTokenExpiry() {
  const authStore = useAuthStore();
  if (!authStore.app_access_token) return;

  const payload = decodeToken(authStore.app_access_token);
  if (payload?.exp) {
    const now = Math.floor(Date.now() / 1000); // giây
    if (payload.exp < now) {
      console.warn('Token đã hết hạn!');
      authStore.logout();
      router.push('/login');
    }
  }
}

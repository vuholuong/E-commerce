// src/stores/category.js
import { defineStore } from 'pinia';
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

export const useCategoryStore = defineStore('category', {
  state: () => ({
    categories: [],
  }),
  getters: {
    allCategories: state => state.categories,
    parentCategories: state => state.categories.filter(cat => !cat.parentId), // chỉ lấy category cha
  },
  actions: {
    async fetchCategories() {
      try {
        const res = await api.get(API_ENDPOINTS.CATEGORY.LIST);
        this.categories = res.data.data || [];
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    },
  },
});

// src/stores/cart.js
import { defineStore } from "pinia";
import { ref, computed } from "vue";
import api from "@/api/axios";
import { API_ENDPOINTS } from "@/constants";
import { useAuthStore } from "@/stores/auth";

export const useCartStore = defineStore("cart", () => {
  const items = ref([]);
  const count = ref(0);
  const isLoading = ref(false);
  const error = ref(null);

  const authStore = useAuthStore();

  const isAuthenticated = computed(() => !!authStore.app_access_token);

  const actions = {
    async fetchCart() {
      if (!isAuthenticated.value) {
        console.log('Chưa đăng nhập, không thể tải giỏ hàng');
        return;
      }

      try {
        this.isLoading = true;
        const res = await api.get(API_ENDPOINTS.CART.LIST);
        this.items = res.data.data?.items || [];
      } catch (err) {
        this.error = err.response?.data?.message || err.message;
        if (err.response?.status === 403) {
          this.error = 'Vui lòng đăng nhập để xem giỏ hàng';
        }
      } finally {
        this.isLoading = false;
      }
    },

    async fetchCount() {
      if (!isAuthenticated.value) {
        console.log('Chưa đăng nhập, không thể tải số lượng giỏ hàng');
        return;
      }

      try {
        const res = await api.get(API_ENDPOINTS.CART.COUNT);
        this.count = res.data.data ?? 0;
      } catch (err) {
        console.error("❌ fetchCount:", err);
        if (err.response?.status === 403) {
          console.log('Cart API yêu cầu authentication');
        }
      }
    },

    async addToCart(variantId, quantity = 1) {
      if (!isAuthenticated.value) {
        console.log('Chưa đăng nhập, không thể thêm vào giỏ hàng');
        return { success: false, message: 'Vui lòng đăng nhập để thêm vào giỏ hàng' };
      }

      try {
        await api.post(API_ENDPOINTS.CART.ADD_ITEM, { variantId, quantity });
        // Luôn fetch lại cart và count
        await this.fetchCart();
        await this.fetchCount();
        return { success: true, message: 'Đã thêm vào giỏ hàng thành công' };
      } catch (err) {
        console.error("❌ addToCart:", err.response?.data || err.message);
        return { success: false, message: err.response?.data?.message || 'Không thể thêm vào giỏ hàng' };
      }
    },

    async removeItem(itemId) {
      if (!isAuthenticated.value) {
        console.log('Chưa đăng nhập, không thể xóa item');
        return;
      }

      try {
        await api.delete(API_ENDPOINTS.CART.UPDATE_ITEM(itemId));
        await this.fetchCart();
        await this.fetchCount();
      } catch (err) {
        console.error("❌ removeItem:", err);
      }
    },

    async clearCart() {
      if (!isAuthenticated.value) {
        console.log('Chưa đăng nhập, không thể xóa giỏ hàng');
        return;
      }

      try {
        await api.delete(API_ENDPOINTS.CART.REMOVE_ITEM);
        this.items = [];
        this.count = 0;
      } catch (err) {
        console.error("❌ clearCart:", err);
      }
    },

    async updateItem(itemId, { quantity, variantId }) {
      if (!isAuthenticated.value) {
        console.log('Chưa đăng nhập, không thể cập nhật item');
        return;
      }

      try {
        await api.put(API_ENDPOINTS.CART.UPDATE_ITEM(itemId), { quantity, variantId });
        await this.fetchCart();
        await this.fetchCount();
      } catch (err) {
        console.error("❌ updateItem:", err);
      }
    }
  };

  return {
    items,
    count,
    isLoading,
    error,
    isAuthenticated,
    ...actions
  };
});

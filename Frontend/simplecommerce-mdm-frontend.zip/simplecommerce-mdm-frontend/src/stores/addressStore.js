import { defineStore } from 'pinia';
import {
  getAddresses,
  createAddress,
  updateAddress,
  deleteAddress,
} from '@/services/addressService';

export const useAddressStore = defineStore('address', {
  state: () => ({
    addresses: [],
    loading: false,
    error: null,
  }),

  actions: {
    async fetchAddresses() {
      this.loading = true;
      this.error = null;
      try {
        const res = await getAddresses();
        const data = res.data.data || res.data;
        this.addresses = data;
      } catch (e) {
        this.error = 'Không lấy được danh sách địa chỉ';
      } finally {
        this.loading = false;
      }
    },

    async createAddress(address) {
      try {
        await createAddress(address);
        await this.fetchAddresses();
      } catch (e) {
        this.error = e.response?.data?.message || 'Không thêm được địa chỉ';
        throw e;
      }
    },

    async updateAddress(id, address) {
      try {
        await updateAddress(id, address);
        await this.fetchAddresses();
      } catch (e) {
        this.error = e.response?.data?.message || 'Không cập nhật được địa chỉ';
        throw e;
      }
    },

    async deleteAddress(id) {
      try {
        await deleteAddress(id);
        // Refresh addresses after successful deletion
        await this.fetchAddresses();
      } catch (e) {
        // Map backend error messages to Vietnamese
        const backendMsg = e.response?.data?.message || '';
        let vnMsg = 'Không xóa được địa chỉ';
        
        if (backendMsg.includes('only address')) {
          vnMsg = 'Không thể xóa địa chỉ duy nhất. Bạn phải có ít nhất một địa chỉ.';
        } else if (backendMsg.includes('default address')) {
          vnMsg = 'Không thể xóa địa chỉ mặc định. Vui lòng đặt địa chỉ khác làm mặc định trước.';
        } else if (backendMsg.includes('not found')) {
          vnMsg = 'Không tìm thấy địa chỉ cần xóa.';
        } else if (backendMsg) {
          vnMsg = backendMsg;
        }
        
        this.error = vnMsg;
        throw e;
      }
    },
  },
});

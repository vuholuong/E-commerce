import { defineStore } from 'pinia';
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';

export const useRegisterStore = defineStore('register', {
  state: () => ({
    loading: false,
    success: false,
    error: null,
  }),

  actions: {
    async registerUser(payload) {
      this.loading = true;
      this.error = null;
      this.success = false;

      try {
        const response = await api.post(API_ENDPOINTS.AUTH.REGISTER, payload);

        // Nếu backend vẫn trả status 200 nhưng chứa lỗi bên trong body
        if (response.data?.status === 500 || response.data?.error === 'Internal Server Error') {
          const message = response.data?.message || '';
          if (message.includes('email')) {
            this.error = 'Email đã được sử dụng.';
          } else if (message.includes('phone_number')) {
            this.error = 'Số điện thoại đã được sử dụng.';
          } else if (message.includes('duplicate key')) {
            this.error = 'Email hoặc số điện thoại đã được sử dụng.';
          } else {
            this.error = message || 'Đăng ký thất bại. Vui lòng thử lại.';
          }
          this.success = false;
        } else {
          // Nếu đăng ký thành công thực sự
          this.success = true;
        }
      } catch (err) {
        const message = err.response?.data?.message || '';

        if (message.includes('email')) {
          this.error = 'Email đã được sử dụng.';
        } else if (message.includes('phone_number')) {
          this.error = 'Số điện thoại đã được sử dụng.';
        } else if (message.includes('duplicate key')) {
          this.error = 'Email hoặc số điện thoại đã được sử dụng.';
        } else {
          this.error = 'Đăng ký thất bại. Vui lòng thử lại.';
        }

        this.success = false;
      } finally {
        this.loading = false;
      }
    },
  },
});

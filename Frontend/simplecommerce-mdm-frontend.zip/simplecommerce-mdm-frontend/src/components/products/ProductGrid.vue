<script setup>
import { computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { useProductStore } from '@/stores/product';
import { useCategoryStore } from '@/stores/category';
import { useCartStore } from '@/stores/cart';
import Swal from 'sweetalert2';

const router = useRouter();

const fallbackImage = '/images/no-image.jpg';
const productStore = useProductStore();
const categoryStore = useCategoryStore();
const cart = useCartStore();
onMounted(async () => {
  await categoryStore.fetchCategories();
  await productStore.fetchProducts();
});

const parentCategories = computed(() => {
  return (categoryStore.categories || []).filter(c => c.parentId === null);
});

function getChildCategoryIds(parentId) {
  return (categoryStore.categories || []).filter(c => c.parentId === parentId).map(c => c.id);
}

function getProductsByParentId(parentId) {
  const childIds = getChildCategoryIds(parentId);

  if (childIds.length > 0) {
    return (productStore.products || []).filter(p => childIds.includes(p.categoryId));
  } else {
    return (productStore.products || []).filter(p => p.categoryId === parentId);
  }
}

function formatPrice(value) {
  if (value == null) return 'Liên hệ';
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(value);
}

function goToCategory(categoryId) {
  router.push(`/category/${categoryId}`);
}

function goToDetail(productId) {
  router.push(`/product/${productId}`);
}

async function addToCart(product) {
  const result = await cart.addToCart(product.variantId, 1);
  
  if (result.success) {
    Swal.fire('Thành công', result.message, 'success');
  } else {
    if (result.message.includes('đăng nhập')) {
      Swal.fire({
        title: 'Vui lòng đăng nhập',
        text: result.message,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Đăng nhập',
        cancelButtonText: 'Hủy'
      }).then((result) => {
        if (result.isConfirmed) {
          router.push('/login');
        }
      });
    } else {
      Swal.fire('Lỗi', result.message, 'error');
    }
  }
}
</script>

<template>
  <div class="container mt-4">
    <h2 class="mb-3">Danh sách sản phẩm</h2>

    <div v-if="productStore.isLoading" class="text-center">
      <span class="spinner-border text-primary"></span>
      <p>Đang tải dữ liệu...</p>
    </div>

    <div v-else-if="productStore.error" class="alert alert-danger">
      {{ productStore.error }}
    </div>

    <div v-else>
      <div v-for="parent in parentCategories" :key="parent.id" class="section-wrapper">
        <div class="d-flex justify-content-between align-items-center">
          <h5>{{ parent.name }}</h5>
          <button class="btn-view-more" @click="goToCategory(parent.id)">Xem thêm</button>
        </div>

        <div class="row row-cols-1 row-cols-md-5 g-4">
          <div v-for="product in getProductsByParentId(parent.id).slice(0, 5)" :key="product.id" class="col">
            <div class="product-card" @click="goToDetail(product.id)">
              <img :src="product.imageUrls?.[0] || fallbackImage" alt="Sản phẩm" />
              <p>{{ product.name }}</p>
              <strong class="text-danger">{{ formatPrice(product.basePrice) }}</strong>
              <a class="btn-cart" @click="addToCart(product)">🛒 Thêm vào giỏ</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.section-wrapper {
  background: #fff;
  border-radius: 20px;
  margin-bottom: 32px;
  padding: 28px 22px 20px 22px;
  box-shadow: 0 4px 24px rgba(37, 117, 252, 0.07);
}

.d-flex.justify-content-between.align-items-center {
  border-bottom: 2px solid #e6e6ec;
  padding-bottom: 12px;
  margin-bottom: 18px;
}

.section-wrapper h5 {
  font-weight: 800;
  color: #2575fc;
  margin-bottom: 0;
  letter-spacing: 0.5px;
  font-size: 1.35rem;
}

.btn-view-more {
  font-size: 14px;
  font-weight: 600;
  padding: 6px 14px;
  border-radius: 20px;
  background: linear-gradient(90deg, #2575fc 0%, #6a11cb 100%);
  color: #fff;
  border: none;
  transition: all 0.25s ease;
  box-shadow: 0 2px 8px rgba(37, 117, 252, 0.15);
}

.btn-view-more:hover {
  background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%);
  box-shadow: 0 4px 12px rgba(37, 117, 252, 0.25);
  transform: translateY(-2px) scale(1.05);
}

.btn-view-more:active {
  transform: scale(0.96);
}

.product-card {
  background: #f8faff;
  border-radius: 18px;
  border: 1.5px solid #e3e8f0;
  box-shadow: 0 2px 12px rgba(37, 117, 252, 0.06);
  height: 100%;
  margin-bottom: 18px;
  padding: 16px 12px 20px 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  transition:
    box-shadow 0.18s,
    transform 0.18s,
    border-color 0.18s,
    background 0.18s;
}

.product-card:hover {
  box-shadow: 0 12px 36px rgba(37, 117, 252, 0.16);
  transform: translateY(-6px) scale(1.04);
  border-color: #b5c9f9;
  background: #fff;
}

.product-card img {
  width: 100%;
  height: 180px;
  object-fit: contain;
  margin-bottom: 10px;
  border-radius: 10px;
  background: #fff;
  box-shadow: 0 2px 10px rgba(231, 231, 231, 0.6);
  transition:
    transform 0.18s,
    box-shadow 0.18s;
}

.product-card:hover img {
  transform: scale(1.06) rotate(-1.5deg);
  box-shadow: 0 6px 24px rgba(37, 117, 252, 0.1);
}

.product-card p {
  font-size: 15px;
  font-weight: 500;
  color: #222;
  margin-bottom: 6px;
  min-height: 42px;
  text-align: center;
}

.product-card strong.text-danger {
  font-size: 1.15rem;
  font-weight: 800;
  letter-spacing: 0.5px;
}

a.btn-cart {
  font-size: 14px;
  font-weight: 600;
  border-radius: 8px;
  margin-top: 8px;
  width: 100%;
  background: linear-gradient(90deg, #f7d6ee 0%, #d6e6fa 100%);
  color: #d63384;
  border: 1px solid #f7d6ee;
  transition:
    background 0.18s,
    color 0.18s,
    box-shadow 0.18s,
    transform 0.18s;
  box-shadow: 0 2px 8px rgba(214, 54, 132, 0.06);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 8px 0;
}

a.btn-cart:hover {
  background: linear-gradient(90deg, #e45c99 0%, #2575fc 100%);
  color: #fff;
  border-color: #e45c99;
  box-shadow: 0 4px 16px rgba(228, 92, 153, 0.13);
  transform: translateY(-2px) scale(1.04);
}

@media (max-width: 768px) {
  .product-card p {
    font-size: 13px;
    min-height: 24px;
  }

  .product-card img {
    max-height: 120px;
  }

  .section-wrapper {
    padding: 12px 4px 8px 4px;
  }
}
</style>

<template>
  <div class="bg-light min-vh-100 py-4">
    <div class="container rounded-0 shadow-none bg-white p-0 px-4">
      <div class="row g-0">
        <!-- Sidebar -->
        <aside class="col-12 col-md-2 sidebar-bhx p-3 sidebar-fixed">
          <div v-for="cat in categories" :key="cat.id" class="mb-3">
            <div
              class="bhx-menu-item d-flex justify-content-between align-items-center"
              @click="toggleCategory(cat.id)"
            >
              <span>{{ cat.name }}</span>
              <span
                class="fs-5"
                style="transition: transform 0.2s"
                :style="{ transform: cat.open ? 'rotate(90deg)' : 'rotate(0deg)' }"
              >
                ▶
              </span>
            </div>
            <ul class="list-unstyled ps-3 mb-1" v-show="cat.open">
              <li
                v-for="sub in cat.children"
                :key="sub.id"
                :class="[
                  'py-1 rounded-2',
                  { 'bg-primary text-white fw-bold': sub.id === selectedSubCategory },
                ]"
                style="cursor: pointer"
                @click="selectSubCategory(sub.id)"
              >
                {{ sub.name }}
              </li>
            </ul>
          </div>
        </aside>
        <!-- Main content -->
        <section class="col-12 col-md-9 p-4" style="margin-left: 35px">
          <div
            class="d-flex gap-3 mb-3 overflow-auto align-items-center justify-content-between sticky-category-bar"
          >
            <div class="d-flex gap-2">
              <div
                v-for="sub in currentSubCategories"
                :key="sub.id"
                :class="[
                  'text-center px-2 py-1 rounded-2 border',
                  { 'border-primary bg-light fw-bold': sub.id === selectedSubCategory },
                ]"
                style="min-width: 70px; cursor: pointer"
                @click="selectSubCategory(sub.id)"
              >
                <img
                  v-if="sub.icon"
                  :src="sub.icon"
                  class="mb-1"
                  style="width: 28px; height: 28px"
                />
                <div style="font-size: 0.97rem">{{ sub.name }}</div>
              </div>
            </div>
            <div class="filter-btn-bhx" @click="showFilter = true">
              <svg
                width="28"
                height="28"
                fill="none"
                stroke="#4caf50"
                stroke-width="2"
                viewBox="0 0 24 24"
              >
                <path d="M4 4h16M6 8h12M8 12h8M10 16h4M12 20h0" />
              </svg>
              <span>Bộ lọc</span>
            </div>
          </div>
          <!-- Modal bộ lọc -->
          <div v-if="showFilter" class="filter-modal-bhx">
            <div class="filter-modal-content">
              <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0 fw-bold">Tất cả bộ lọc</h5>
                <button class="btn-close" @click="showFilter = false"></button>
              </div>
              <hr />
              <div class="mb-3">
                <div class="fw-bold mb-2">Đánh giá</div>
                <div class="d-flex gap-4 flex-wrap">
                  <label
                    v-for="star in [5, 4, 3]"
                    :key="star"
                    class="form-check-label d-flex align-items-center gap-1"
                  >
                    <input
                      type="checkbox"
                      class="form-check-input"
                      v-model="filter.rating"
                      :value="star"
                    />
                    <span class="text-warning">&#9733;</span> từ {{ star }} sao
                  </label>
                </div>
              </div>
              <div class="mb-3">
                <div class="fw-bold mb-2">Giá</div>
                <div class="d-flex gap-2 flex-wrap mb-2">
                  <button
                    v-for="(g, idx) in priceRanges"
                    :key="idx"
                    class="btn btn-outline-primary btn-sm"
                    :class="{ active: filter.price === g }"
                    @click="filter.price = g"
                  >
                    {{ g }}
                  </button>
                </div>
                <div class="d-flex gap-2 align-items-center mb-2">
                  <input
                    type="number"
                    class="form-control form-control-sm"
                    v-model="filter.priceFrom"
                    placeholder="Từ"
                    style="max-width: 100px"
                  />
                  <span>-</span>
                  <input
                    type="number"
                    class="form-control form-control-sm"
                    v-model="filter.priceTo"
                    placeholder="Đến"
                    style="max-width: 100px"
                  />
                  <button
                    class="btn btn-link p-0 text-danger"
                    @click="
                      filter.priceFrom = '';
                      filter.priceTo = '';
                    "
                  >
                    Xoá
                  </button>
                </div>
              </div>
              <div class="mb-3">
                <div class="fw-bold mb-2">Remote điều khiển</div>
                <div class="d-flex gap-3 flex-wrap">
                  <label class="form-check-label d-flex align-items-center gap-1">
                    <input
                      type="checkbox"
                      class="form-check-input"
                      v-model="filter.remote"
                      value="no"
                    />
                    Không có remote điều khiển
                  </label>
                  <label class="form-check-label d-flex align-items-center gap-1">
                    <input
                      type="checkbox"
                      class="form-check-input"
                      v-model="filter.remote"
                      value="yes"
                    />
                    Có remote điều khiển
                  </label>
                </div>
              </div>
              <div class="d-flex justify-content-between mt-4">
                <button class="btn btn-outline-secondary" @click="resetFilter">Xoá tất cả</button>
                <button class="btn btn-primary" @click="applyFilter">Xem kết quả</button>
              </div>
            </div>
          </div>
          <!-- Suggested products -->
          <div class="mb-6">
            <div class="row g-4 justify-content-center">
              <div
                class="col-5th d-flex"
                v-for="(item, idx) in suggestProducts"
                :key="'suggest-' + idx"
              >
                <div class="card h-100 border-0 flex-fill shadow-sm">
                  <img
                    :src="item.img"
                    class="card-img-top rounded"
                    alt=""
                    style="height: 240px; object-fit: cover"
                  />
                  <div class="card-body p-4 text-center">
                    <p class="card-text fw-bold mb-2" style="font-size: 1.15rem">{{ item.name }}</p>
                    <div class="card-price-row">
                      <span class="fw-bold text-primary" style="font-size: 1.1rem"
                        >{{ item.price.toLocaleString() }}VND</span
                      >
                      <span class="badge bg-light border text-secondary" style="font-size: 1rem">{{
                        item.discount
                      }}</span>
                    </div>
                    <div class="d-flex justify-content-center align-items-center" style="gap: 8px">
                      <span style="color: #f7a900; font-size: 1.2rem">★</span>
                      <span style="font-size: 1.05rem">4.9</span>
                      <span class="text-muted" style="font-size: 1rem">Đã bán {{ item.sold }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';

// Dữ liệu mẫu, bạn thay bằng API thực tế
const categories = ref([
  {
    id: 1,
    name: 'Điện thoại',
    open: false,
    children: [
      { id: 1, name: 'Điện thoại', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 2, name: 'ốp lưng', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      {
        id: 3,
        name: 'Bảo vệ màn hình',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      { id: 4, name: 'Tai nghe', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      {
        id: 5,
        name: 'Sạc dự phòng',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      { id: 6, name: 'Thẻ nhớ', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 7, name: 'Sim', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
    ],
  },
  {
    id: 2,
    name: 'Laptop',
    open: false,
    children: [
      { id: 11, name: 'Mac', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 12, name: 'ASUS', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 13, name: 'Lenovo', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 14, name: 'Dell', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 15, name: 'HP', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 16, name: 'Acer', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 17, name: 'MSI', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
    ],
  },
  {
    id: 3,
    name: 'Mẹ và bé',
    open: false,
    children: [
      {
        id: 21,
        name: 'Chăm sóc sức khỏe mẹ',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      { id: 22, name: 'Sữa', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 23, name: 'Bỉm', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      {
        id: 24,
        name: 'Đồ dùng phòng ngủ',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      { id: 25, name: 'Đồ chơi', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 26, name: 'Xe đẩy', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      {
        id: 27,
        name: 'Chăm sóc cơ thể bé',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
    ],
  },
  {
    id: 4,
    name: 'Giày dép nam',
    open: false,
    children: [
      {
        id: 31,
        name: 'Giày thể thao',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 32,
        name: 'Giày công sở',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 33,
        name: 'Giày Dép sandal',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      { id: 34, name: 'Giày lười', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 35, name: 'Bốt', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 36, name: 'Giày sục ', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      {
        id: 37,
        name: 'Phụ kiện Giày Dép',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
    ],
  },
  {
    id: 5,
    name: 'Giày dép nữ',
    open: false,
    children: [
      {
        id: 41,
        name: 'Giày thể thao',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 42,
        name: 'Giày đế bằng',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 43,
        name: 'Giày cao gót',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 44,
        name: 'Giày đế xuồng',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 45,
        name: 'Giày Dép sandal',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 46,
        name: 'Phụ kiện Giày Dép',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
    ],
  },
  {
    id: 7,
    name: 'Thời trang nam',
    open: false,
    children: [
      { id: 61, name: 'Áo khoác', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 62, name: 'Áo vest', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 63, name: 'Áo hoodie', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 64, name: 'Áo', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 65, name: 'Quần jeans', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 66, name: 'Quần tây', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 67, name: 'Quần short', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 68, name: 'Đồ bộ', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
    ],
  },
  {
    id: 6,
    name: 'Thời trang nữ',
    open: false,
    children: [
      { id: 51, name: 'Quần', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 52, name: 'Quần đùi', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 53, name: 'Chân váy', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 54, name: 'Đầm', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 55, name: 'Áo len', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 56, name: 'Áo choàng', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 57, name: 'Đồ bộ', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 58, name: 'Đồ bầu', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
    ],
  },
  {
    id: 8,
    name: 'Balo túi ví',
    open: false,
    children: [
      { id: 71, name: 'Balo nam', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      {
        id: 72,
        name: 'Túi đeo hông',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 73,
        name: 'Túi đeo chéo',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      { id: 74, name: 'Bóp/ví', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      {
        id: 75,
        name: 'Cặp/Balo đựng laptop',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
    ],
  },
  {
    id: 9,
    name: 'Trang sức phụ kiện',
    open: false,
    children: [
      { id: 81, name: 'Nhẫn', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 82, name: 'Dây chuyền', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 83, name: 'Bông tai', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 84, name: 'Lắc tay', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 85, name: 'Vòng cổ', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 86, name: 'Kính', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
      { id: 87, name: 'Đồng hồ', icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png' },
    ],
  },
  {
    id: 10,
    name: 'Nhà cửa đời sống',
    open: false,
    children: [
      {
        id: 91,
        name: 'Đồ nội thất',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 92,
        name: 'Chăn, ga, gối nệm',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 93,
        name: 'Đồ trang trí',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
      {
        id: 94,
        name: 'Chăm sóc nhà cửa',
        icon: 'https://cdn-icons-png.flaticon.com/128/616/616408.png',
      },
    ],
  },
  // ... các danh mục khác
]);

const selectedSubCategory = ref(11);
const currentSubCategories = computed(() => {
  const cat = categories.value.find(c =>
    c.children.some(sub => sub.id === selectedSubCategory.value)
  );
  return cat ? cat.children : [];
});

function toggleCategory(id) {
  categories.value.forEach(cat => {
    cat.open = cat.id === id ? !cat.open : cat.open;
  });
}
function selectSubCategory(id) {
  selectedSubCategory.value = id;
}

// Dữ liệu sản phẩm mẫu
const suggestProducts = [
  {
    img: '/src/assets/images/aothuntheu.webp',
    name: 'Áo thun thêu hoa',
    price: 86000,
    discount: '-49%',
    sold: '3k',
  },
  {
    img: '/src/assets/images/aothunnu.webp',
    name: 'Áo thun nữ dáng ôm',
    price: 82000,
    discount: '-49%',
    sold: '2k',
  },
  {
    img: '/src/assets/images/aothunhoatiet.webp',
    name: 'Áo thun họa tiết nơ',
    price: 65000,
    discount: '-54%',
    sold: '1k',
  },
  {
    img: '/src/assets/images/aobabylove.webp',
    name: 'Áo thun body thuê',
    price: 65000,
    discount: '-54%',
    sold: '1.5k',
  },
  {
    img: '/src/assets/images/aothuntheu.webp',
    name: 'Áo thun thêu hoa',
    price: 86000,
    discount: '-49%',
    sold: '3k',
  },
  {
    img: '/src/assets/images/aothunnu.webp',
    name: 'Áo thun nữ dáng ôm',
    price: 82000,
    discount: '-49%',
    sold: '2k',
  },
  {
    img: '/src/assets/images/aothunhoatiet.webp',
    name: 'Áo thun họa tiết nơ',
    price: 65000,
    discount: '-54%',
    sold: '1k',
  },
  {
    img: '/src/assets/images/aobabylove.webp',
    name: 'Áo thun body thuê',
    price: 65000,
    discount: '-54%',
    sold: '1.5k',
  },
  {
    img: '/src/assets/images/aothuntheu.webp',
    name: 'Áo thun thêu hoa',
    price: 86000,
    discount: '-49%',
    sold: '3k',
  },
  {
    img: '/src/assets/images/aothunnu.webp',
    name: 'Áo thun nữ dáng ôm',
    price: 82000,
    discount: '-49%',
    sold: '2k',
  },
  {
    img: '/src/assets/images/aothunhoatiet.webp',
    name: 'Áo thun họa tiết nơ',
    price: 65000,
    discount: '-54%',
    sold: '1k',
  },
  {
    img: '/src/assets/images/aobabylove.webp',
    name: 'Áo thun body thuê',
    price: 65000,
    discount: '-54%',
    sold: '1.5k',
  },
  {
    img: '/src/assets/images/aothuntheu.webp',
    name: 'Áo thun thêu hoa',
    price: 86000,
    discount: '-49%',
    sold: '3k',
  },
  {
    img: '/src/assets/images/aothunnu.webp',
    name: 'Áo thun nữ dáng ôm',
    price: 82000,
    discount: '-49%',
    sold: '2k',
  },
  {
    img: '/src/assets/images/aothunhoatiet.webp',
    name: 'Áo thun họa tiết nơ',
    price: 65000,
    discount: '-54%',
    sold: '1k',
  },
  {
    img: '/src/assets/images/aobabylove.webp',
    name: 'Áo thun body thuê',
    price: 65000,
    discount: '-54%',
    sold: '1.5k',
  },
];

const showFilter = ref(false);
const filter = ref({ rating: [], price: '', priceFrom: '', priceTo: '', remote: [] });
const priceRanges = [
  'Dưới 500.000',
  '500.000 → 2.500.000',
  '2.500.000 → 11.500.000',
  'Trên 11.500.000',
];

// Lock scroll when modal filter is open
watch(showFilter, val => {
  if (val) {
    document.body.classList.add('modal-open-bhx');
  } else {
    document.body.classList.remove('modal-open-bhx');
  }
});

function resetFilter() {
  filter.value = { rating: [], price: '', priceFrom: '', priceTo: '', remote: [] };
}
function applyFilter() {
  showFilter.value = false;
  // Xử lý lọc sản phẩm ở đây nếu muốn
}
</script>

<style scoped>
.card:hover {
  box-shadow: 0 4px 24px 0 rgba(212, 140, 166, 0.15);
  transform: translateY(-4px) scale(1.03);
}
.col-5th {
  flex: 0 0 25%;
  max-width: 25%;
}
.sidebar-fixed {
  position: sticky;
  top: 72px;
  height: calc(100vh - 1px);
  max-height: calc(100vh - 32px);
  overflow-y: auto;
  z-index: 100;
  padding-right: 4px;
  width: 280px;
  background: #ffff;
}
.sidebar-bhx {
  background: transparent;
  padding-bottom: 8px;
}
.bhx-menu-item {
  background: #5cb6ff;
  color: #fff;
  font-weight: 100;
  font-size: 1rem;
  border-radius: 12px;
  padding: 2px 20px;
  margin-bottom: 2px;
  box-shadow: 0 1px 1px #0001;
  cursor: pointer;
  transition:
    background 0.18s,
    color 0.18s,
    box-shadow 0.18s;
  display: flex;
  align-items: center;
  min-height: 3px;
}
.bhx-menu-item:hover,
.bhx-menu-item:active {
  background: #e3f2fd !important;
  color: #1565c0 !important;
  box-shadow: 0 4px 16px #2165c322;
}
.filter-btn-bhx {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border: 2px solid #2165c3;
  border-radius: 16px;
  padding: 5px 12px 5px 12px;
  color: #fff;
  font-weight: 6;
  font-size: 1.13rem;
  background: #fff;
  min-width: 80px;
  cursor: pointer;
  transition: box-shadow 0.18s;
  box-shadow: 0 2px 8px #0001;
}
.filter-btn-bhx span {
  margin-top: 2px;
  font-size: 1.08rem;
  color: #0d0c0c;
  font-weight: 600;
}
.filter-modal-bhx {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.18);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
}
.filter-modal-content {
  background: #fff;
  border-radius: 16px;
  max-width: 700px;
  width: 100%;
  padding: 40px 40px 32px 40px;
  box-shadow: 0 8px 32px #0002;
  animation: filterModalShow 0.18s;
}
.filter-modal-content .btn-outline-primary.btn-sm {
  border-radius: 12px;
  font-size: 1.08rem;
  padding: 14px 28px 12px 28px;
  background: linear-gradient(90deg, #7b1fa2 0%, #1976d2 100%);
  color: #fff;
  border: none;
  margin-bottom: 6px;
  min-width: 100px;
  min-height: 54px;
  font-weight: 600;
  box-shadow: 0 2px 8px #0001;
  transition:
    background 0.18s,
    color 0.18s,
    box-shadow 0.18s;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
@keyframes filterModalShow {
  from {
    transform: translateY(40px);
    opacity: 0;
  }
  to {
    transform: none;
    opacity: 1;
  }
}
.btn-close {
  background: none;
  border: none;
  font-size: 1.6rem;
  color: #888;
  cursor: pointer;
  line-height: 1;
}
.card {
  background: #fff !important;
  min-height: 360px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}
.card-img-top {
  width: 100%;
  height: 180px;
  object-fit: cover;
  border-radius: 12px 12px 0 0;
}
.card-body {
  flex: 1 1 auto;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  background: #fff !important;
  padding: 1.25rem 1rem;
}
.card-text {
  text-align: left;
  margin-left: 8px;
  margin-bottom: 8px;
  font-size: 1.15rem;
  font-weight: bold;
  white-space: pre-line;
  text-align: center;
}
.card-price-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
  margin-left: 8px;
  margin-top: auto;
}
.card-meta-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-left: 8px;
}
.sticky-category-bar {
  position: sticky;
  top: 64px;
  z-index: 150;
  background: #fff;
  padding-top: 10px;
  padding-bottom: 10px;
  border-bottom: 2px solid #e3e3e3;
  box-shadow: 0 2px 8px #0001;
}
/* Lock scroll when modal filter is open */
:global(body.modal-open-bhx) {
  overflow: hidden !important;
  position: fixed;
  width: 100vw;
}
</style>

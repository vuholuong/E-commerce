<script setup>
import { ref, onMounted, reactive, computed } from "vue"
import { useCartStore } from "@/stores/cart"
import { useAddressStore } from "@/stores/addressStore"
import Swal from "sweetalert2"
import api from "@/api/axios"
import { API_ENDPOINTS } from "@/constants"
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()
const cartStore = useCartStore()
const addressStore = useAddressStore()
const productImages = reactive({});

const checkoutItems = ref([])
const selectedCartItemIds = ref([])
const shippingAddressId = ref(null)
const billingAddressId = ref(null)
const customerPhone = ref("")
const notesToSeller = ref("")
const paymentMethodCode = ref("COD")
const isLoading = ref(false)

// ✅ Phí vận chuyển cố định
const shippingFee = ref(30000)

// ✅ Tính tổng tiền hàng
const subtotal = computed(() =>
    checkoutItems.value.reduce((sum, item) => sum + item.currentPrice * item.quantity, 0)
)

// ✅ Tính tổng thanh toán (tiền hàng + phí vận chuyển)
const totalPrice = computed(() => subtotal.value + shippingFee.value)

// ✅ Lấy selectedCartItemIds và thông tin sản phẩm từ query params
onMounted(async () => {
  try {
    // Lấy selectedItems từ query params
    const selectedItemsParam = route.query.selectedItems
    if (!selectedItemsParam) {
      Swal.fire("Lỗi", "Không có sản phẩm nào được chọn", "error")
      router.push('/cart')
      return
    }

    checkoutItems.value = JSON.parse(selectedItemsParam)
    selectedCartItemIds.value = checkoutItems.value.map(item => item.id)

    console.log('Checkout items:', checkoutItems.value)

    await addressStore.fetchAddresses()
    cartStore.items.forEach(item => fetchProductImage(item.productId));
    if (addressStore.addresses.length) {
      shippingAddressId.value = addressStore.addresses[0].id
      billingAddressId.value = addressStore.addresses[0].id
      customerPhone.value = addressStore.addresses[0].contactPhoneNumber
    }
  } catch (err) {
    console.error("Error in mounted:", err)
    Swal.fire("Lỗi", "Có lỗi xảy ra khi tải trang đặt hàng", "error")
    router.push('/cart')
  }
})

// ✅ Hủy đặt hàng
function cancelCheckout() {
  Swal.fire({
    title: "Bạn có chắc chắn?",
    text: "Hủy đặt hàng?",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Có, hủy đặt hàng!",
    cancelButtonText: "Không, giữ lại"
  }).then((result) => {
    if (result.isConfirmed) {
      router.push('/cart')
    }
  })
}

// ✅ Đặt hàng
async function placeOrder() {
  if (!shippingAddressId.value) {
    Swal.fire("Lỗi", "Bạn chưa chọn địa chỉ giao hàng", "error")
    return
  }
  if (!customerPhone.value) {
    Swal.fire("Lỗi", "Bạn chưa nhập số điện thoại", "error")
    return
  }
  if (selectedCartItemIds.value.length === 0) {
    Swal.fire("Lỗi", "Không có sản phẩm nào để đặt hàng", "error")
    return
  }

  isLoading.value = true

  const body = {
    selectedCartItemIds: selectedCartItemIds.value,
    shippingAddressId: shippingAddressId.value,
    billingAddressId: billingAddressId.value,
    customerPhone: customerPhone.value,
    notesToSeller: notesToSeller.value.trim(),
    paymentMethodCode: paymentMethodCode.value,
    shippingMethodId: 1
  }

  console.log("📦 Body gửi đi:", body)

  try {
    const res = await api.post(API_ENDPOINTS.ORDER.CREATE, body)

    if (res.data.statusCode === 201) {
      // ✅ Xóa các sản phẩm đã đặt hàng khỏi giỏ hàng
      for (const itemId of selectedCartItemIds.value) {
        await cartStore.removeItem(itemId);
      }
      await cartStore.fetchCart();

      Swal.fire({
        title: "Thành công",
        text: "Đặt hàng thành công!",
        icon: "success",
        confirmButtonText: "Xem đơn hàng"
      }).then((result) => {
        if (result.isConfirmed) {
          router.push('/order-history')
        } else {
          router.push('/cart')
        }
      })

      console.log("✅ Order created:", res.data)
    } else {
      throw new Error(res.data.message || "Không thể đặt hàng")
    }
  } catch (e) {
    const errorMsg = e.response?.data?.message || "Không thể đặt hàng"
    Swal.fire("Lỗi", errorMsg, "error")
    console.error("❌ Order error:", e.response?.data)
  } finally {
    isLoading.value = false
  }
}
async function fetchProductImage(productId) {
  if (!productImages[productId]) {
    try {
      const res = await api.get(API_ENDPOINTS.PRODUCT.DETAIL(productId));
      productImages[productId] = res.data.data.imageUrls?.[0] || '/images/no-image.jpg';
    } catch (err) {
      console.error('Fetch product image error:', err);
      productImages[productId] = '/images/no-image.jpg';
    }
  }
}
// format tiền
function formatPrice(value) {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
}
</script>

<template>
  <div class="checkout-shopee">
    <div v-if="isLoading" class="loading-overlay">
      <div class="spinner"></div>
      <p>Đang xử lý đơn hàng...</p>
    </div>

    <!-- Địa chỉ nhận hàng -->
    <div class="mb-3">
      <h6 class="text-danger">Địa chỉ nhận hàng</h6>
      <div v-if="addressStore.addresses.length">
        <select v-model="shippingAddressId" class="form-select">
          <option
              v-for="addr in addressStore.addresses"
              :key="addr.id"
              :value="addr.id"
          >
            {{ addr.contactFullName }} - {{ addr.contactPhoneNumber }}
            ({{ addr.streetAddress1 }}, {{ addr.ward }}, {{ addr.district }}, {{ addr.city }})
          </option>
        </select>
      </div>
      <div v-else>
        <p>Bạn chưa có địa chỉ. Vui lòng thêm địa chỉ trong trang hồ sơ.</p>
      </div>
    </div>

    <!-- Địa chỉ hóa đơn -->
    <div class="mb-3" v-if="addressStore.addresses.length > 1">
      <h6 class="text-info">Địa chỉ hóa đơn (nếu khác)</h6>
      <select v-model="billingAddressId" class="form-select">
        <option
            v-for="addr in addressStore.addresses"
            :key="addr.id"
            :value="addr.id"
        >
          {{ addr.contactFullName }} - {{ addr.contactPhoneNumber }}
          ({{ addr.streetAddress1 }}, {{ addr.ward }}, {{ addr.district }}, {{ addr.city }})
        </option>
      </select>
    </div>
    <!-- Danh sách sản phẩm -->
    <div class="product-section" v-for="item in checkoutItems" :key="item.id">
      <div class="product-card">
        <div class="product-header">Shop: {{ item.shopName }}</div>
        <div class="product-body">
          <img
              :src="productImages[item.productId] || '/images/no-image.jpg'"
              alt="product"
              class="product-img"
          />
          <div class="product-details">
            <h3 class="product-name">{{ item.productName }}</h3>
            <p class="product-variant">Loại: {{ item.variantOptions || "Không có" }}</p>
            <p class="product-price">
              Đơn Giá: <span>{{ formatPrice(item.currentPrice) }}</span>
            </p>
            <p class="product-quantity">Số lượng: {{ item.quantity }}</p>
            <p class="product-subtotal">
              Tổng: <span>{{ formatPrice(item.currentPrice * item.quantity) }}</span>
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Ghi chú -->
    <div class="mb-3">
      <h6 class="text-secondary">Ghi chú cho người bán</h6>
      <textarea
          v-model="notesToSeller"
          class="form-select"
          placeholder="Lưu ý cho người bán..."
          rows="3"
      ></textarea>
    </div>

    <!-- Tổng cộng -->
    <div class="checkout-row summary-row">
      <div class="summary-labels">
        <div>Tổng tiền hàng</div>
        <div>Tổng phí vận chuyển</div>
        <div class="order-total-label">Tổng thanh toán</div>
      </div>
      <div class="summary-values">
        <div>{{ formatPrice(subtotal) }}</div>
        <div>{{ formatPrice(shippingFee) }}</div>
        <div class="total-price">{{ formatPrice(totalPrice) }}</div>
      </div>
    </div>

    <!-- Phương thức thanh toán -->
    <div class="checkout-row payment-row">
      <div>Phương thức thanh toán:</div>
      <div class="payment-method">
        <select v-model="paymentMethodCode" class="border p-2 rounded">
          <option value="COD">Thanh toán khi nhận hàng</option>
          <option value="BANK_TRANSFER">Chuyển khoản ngân hàng</option>
          <option value="MOMO">Ví MoMo</option>
        </select>
      </div>
    </div>

    <!-- Nút đặt hàng -->
    <div class="checkout-row order-action-row">
      <div class="policy-text">
        Nhấn "Đặt hàng" đồng nghĩa với việc bạn đồng ý tuân theo Điều khoản của shop
      </div>
      <div class="action-buttons">
        <button
            @click="cancelCheckout"
            class="btn-cancel-shopee"
            :disabled="isLoading"
        >
          Hủy đặt hàng
        </button>
        <button
            @click="placeOrder"
            class="btn-order-shopee"
            :disabled="!shippingAddressId || !customerPhone || isLoading"
        >
          {{ isLoading ? 'Đang xử lý...' : 'Đặt hàng' }}
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.8);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #56b8e6;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.checkout-shopee {
  background: #fff;
  border-radius: 10px;
  max-width: 820px;
  margin: 32px auto;
  box-shadow: 0 4px 24px #1976d211;
  font-family: 'Segoe UI', Arial, sans-serif;
  font-size: 1.05rem;
  padding: 20px;
  position: relative;
}

.product-card {
  background-color: #f9faff;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 20px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.product-header {
  font-weight: 600;
  color: #334155;
  margin-bottom: 12px;
  font-size: 1.1rem;
}

.product-body {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}

.product-img {
  width: 120px;
  height: 120px;
  object-fit: cover;
  border-radius: 8px;
  border: 1px solid #d1d5db;
}

.product-details {
  flex: 1;
}

.product-name {
  font-size: 1.2rem;
  font-weight: 600;
  color: #1e293b;
  margin-bottom: 6px;
}

.product-variant,
.product-price,
.product-quantity,
.product-subtotal {
  font-size: 0.95rem;
  margin-bottom: 4px;
  color: #475569;
}

.product-price span,
.product-subtotal span {
  font-weight: 600;
  color: #dc2626;
}

.checkout-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 18px 28px;
  border-bottom: 1px solid #f0f0f0;
  background: #fafbfc;
}

.summary-row {
  background: #fff;
}
.summary-labels,
.summary-values {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.summary-values {
  align-items: flex-end;
  min-width: 120px;
}
.total-price {
  color: #f44336;
  font-weight: bold;
  font-size: 1.15rem;
}
.payment-row {
  background: #fff;
}
.order-action-row {
  background: #fff;
  flex-direction: column;
  align-items: flex-end;
  gap: 10px;
  padding-bottom: 28px;
}
.policy-text {
  color: #888;
  font-size: 0.95rem;
}

.btn-cancel-shopee {
  background: #dc3545;
  color: #fff;
  font-weight: bold;
  font-size: 1.1rem;
  border: none;
  border-radius: 6px;
  padding: 12px 24px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-cancel-shopee:hover {
  background: #c82333;
}

.btn-order-shopee {
  background: #56b8e6;
  color: #fff;
  font-weight: bold;
  font-size: 1.1rem;
  border: none;
  border-radius: 6px;
  padding: 12px 38px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-order-shopee:hover:not(:disabled) {
  background: #4aa8d6;
}

.btn-order-shopee:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.form-select {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;
  margin-bottom: 10px;
}

.form-select:focus {
  outline: none;
  border-color: #56b8e6;
  box-shadow: 0 0 0 2px rgba(86, 184, 230, 0.2);
}
</style>
<script setup>
import { reactive, ref, onMounted, computed } from 'vue';
import { useCartStore } from '@/stores/cart';
import api from '@/api/axios';
import { API_ENDPOINTS } from '@/constants';
import { useRouter } from 'vue-router';
import Swal from 'sweetalert2';

const router = useRouter();
const cartStore = useCartStore();
const selectedItems = ref([]);
const productImages = reactive({});

// Computed property để đếm số sản phẩm được chọn
const selectedItemsCount = computed(() => selectedItems.value.length);

function toggleSelect(itemId) {
  if (selectedItems.value.includes(itemId)) {
    selectedItems.value = selectedItems.value.filter(id => id !== itemId);
  } else {
    selectedItems.value.push(itemId);
  }
}

function selectAll() {
  if (selectedItems.value.length === cartStore.items.length) {
    selectedItems.value = [];
  } else {
    selectedItems.value = cartStore.items.map(i => i.id);
  }
}

// Xóa các sản phẩm đã chọn
async function removeSelectedItems() {
  if (selectedItems.value.length === 0) {
    Swal.fire('Thông báo', 'Bạn chưa chọn sản phẩm nào để xóa!', 'info');
    return;
  }

  const result = await Swal.fire({
    title: 'Xác nhận',
    text: `Bạn có chắc muốn xóa ${selectedItems.value.length} sản phẩm đã chọn không?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy',
  });

  if (!result.isConfirmed) return;

  try {
    // Gọi API xóa từng item
    for (const id of selectedItems.value) {
      await cartStore.removeItem(id);
    }
    await cartStore.fetchCart();
    selectedItems.value = [];

    Swal.fire('Đã xóa!', 'Các sản phẩm đã chọn đã được xóa.', 'success');
  } catch (err) {
    console.error('Xóa sản phẩm lỗi:', err);
    Swal.fire('Lỗi', 'Không thể xóa sản phẩm. Vui lòng thử lại.', 'error');
  }
}

// Lấy hình sản phẩm theo productId
async function fetchProductImage(productId) {
  if (!productImages[productId]) {
    try {
      const res = await api.get(API_ENDPOINTS.PRODUCT.DETAIL(productId));
      productImages[productId] = res.data.data.imageUrls?.[0] || '/images/no-image.jpg';
    } catch (err) {
      console.error('Fetch product image error:', err);
      productImages[productId] = '/images/no-image.jpg';
    }
  }
}

async function removeAllItems() {
  const result = await Swal.fire({
    title: 'Bạn có chắc chắn?',
    text: 'Thao tác này sẽ xóa toàn bộ giỏ hàng!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Xóa tất cả',
    cancelButtonText: 'Hủy',
  });

  if (!result.isConfirmed) return;

  try {
    await api.delete(API_ENDPOINTS.CART.REMOVE_ITEM);
    await cartStore.fetchCart();
    selectedItems.value = [];

    Swal.fire({
      title: 'Đã xóa!',
      text: 'Giỏ hàng của bạn đã được xóa.',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
    });
  } catch (err) {
    console.error('Xóa tất cả sản phẩm lỗi:', err);
    Swal.fire('Lỗi', 'Không thể xóa giỏ hàng. Vui lòng thử lại.', 'error');
  }
}

// Thay đổi số lượng sản phẩm
function changeQuantity(item, delta) {
  const newQty = item.quantity + delta;
  if (newQty < 1) return;
  if (newQty > item.stockQuantity) return;
  cartStore.updateItem(item.id, { quantity: newQty, variantId: item.variantId });
}

// Khi mounted, fetch giỏ và hình
onMounted(async () => {
  await cartStore.fetchCart();
  cartStore.items.forEach(item => fetchProductImage(item.productId));
});

// format tiền
function formatPrice(value) {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
}

// Tổng tiền CHỈ cho các sản phẩm được chọn
function totalPrice() {
  return cartStore.items
      .filter(item => selectedItems.value.includes(item.id))
      .reduce((sum, i) => sum + (i.currentPrice * i.quantity), 0);
}

// Xóa sản phẩm
async function removeItem(id) {
  const result = await Swal.fire({
    title: 'Bạn có chắc chắn?',
    text: 'Sản phẩm này sẽ bị xóa khỏi giỏ hàng!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Xóa',
    cancelButtonText: 'Hủy',
  });

  if (!result.isConfirmed) return;

  try {
    await cartStore.removeItem(id);
    await cartStore.fetchCart();
    // Xóa khỏi danh sách chọn nếu có
    selectedItems.value = selectedItems.value.filter(itemId => itemId !== id);

    Swal.fire({
      title: 'Đã xóa!',
      text: 'Sản phẩm đã được xóa khỏi giỏ hàng.',
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
    });
  } catch (err) {
    console.error('Xóa sản phẩm lỗi:', err);
    Swal.fire('Lỗi', 'Không thể xóa sản phẩm. Vui lòng thử lại.', 'error');
  }
}
// chuyển sang trang thanh toán
function goToCheckout() {
  if (selectedItems.value.length === 0) {
    Swal.fire('Thông báo', 'Vui lòng chọn ít nhất một sản phẩm để mua!', 'info');
    return;
  }

  // Lấy danh sách sản phẩm được chọn với đầy đủ thông tin
  const selectedProducts = cartStore.items.filter(item =>
      selectedItems.value.includes(item.id)
  );

  // Chuyển hướng sang trang order và truyền selectedItems qua query params
  router.push({
    name: 'order',
    query: {
      selectedItems: JSON.stringify(selectedProducts)
    }
  });
}
</script>

<template>
  <div class="container">
    <h3 class="mb-4">Giỏ hàng của bạn</h3>

    <div v-if="cartStore.items.length === 0" class="alert alert-info">Giỏ hàng trống</div>

    <div v-else class="cart-table-wrapper">
      <table class="cart-table">
        <thead>
        <tr>
          <th>Chọn</th>
          <th>Sản phẩm</th>
          <th>Đơn giá</th>
          <th>Số lượng</th>
          <th>Thành tiền</th>
          <th>Thao tác</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="item in cartStore.items" :key="item.id">
          <!-- Checkbox -->
          <td>
            <input
                type="checkbox"
                :checked="selectedItems.includes(item.id)"
                @change="toggleSelect(item.id)"
            />
          </td>
          <!-- Sản phẩm -->
          <td class="product-col">
            <img
                :src="productImages[item.productId] || '/images/no-image.jpg'"
                alt="product"
                class="product-img"
            />
            <div class="product-info">
              <div class="product-name fw-bold">{{ item.productName || 'Sản phẩm' }}</div>
              <small class="text-muted d-block">Shop: {{ item.shopName }}</small>

              <!-- Thể loại -->
              <p class="mb-1">
                <span class="fw-bold">Phân loại:</span> {{ item.variantOptions || 'Không có' }}
              </p>
            </div>
          </td>

          <!-- Đơn giá -->
          <td class="price-col">{{ formatPrice(item.currentPrice) }}</td>

          <!-- Số lượng -->
          <td class="qty-col">
            <button class="qty-btn" @click="changeQuantity(item, -1)">-</button>
            <input type="number" :value="item.quantity" class="qty-input" readonly />
            <button class="qty-btn" @click="changeQuantity(item, 1)">+</button>
          </td>

          <!-- Thành tiền -->
          <td class="subtotal-col text-danger fw-bold">{{ formatPrice(item.currentPrice * item.quantity) }}</td>

          <!-- Thao tác -->
          <td>
            <button @click="removeItem(item.id)" class="remove-btn">Xóa</button>
          </td>
        </tr>
        </tbody>
      </table>

      <!-- Tổng tiền -->
      <div class="cart-footer">
        <label>
          <input
              type="checkbox"
              :checked="selectedItems.length === cartStore.items.length && cartStore.items.length > 0"
              @change="selectAll"
          />
          Chọn Tất Cả
        </label>
        <div class="total">
          <p>Tổng thanh toán ({{ selectedItemsCount }} Sản Phẩm)</p>
          <h4 class="text-danger">{{ formatPrice(totalPrice()) }}</h4>
          <div class="footer-actions">
            <button class="remove-all-btn" @click="removeSelectedItems">
              Xóa sản phẩm đã chọn
            </button>
            <button class="remove-all-btn" @click="removeAllItems">Xóa tất cả</button>
            <button @click="goToCheckout" class="buy-now-btn">
              Mua ngay ({{ selectedItemsCount }})
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.cart-table-wrapper {
  border: 1px solid #eee;
  border-radius: 10px;
  padding: 15px;
  background: #fff;
}

.cart-table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 15px;
}

.cart-table th,
.cart-table td {
  padding: 12px;
  text-align: center;
  border-bottom: 1px solid #f0f0f0;
  vertical-align: middle;
}

.cart-table th {
  background: #f9f9f9;
  font-weight: 600;
}

.product-col {
  display: flex;
  align-items: center;
  gap: 10px;
  text-align: left;
}

.product-img {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 6px;
  border: 1px solid #ddd;
}

.product-info {
  display: flex;
  flex-direction: column;
}

.product-name {
  font-weight: 500;
  margin-bottom: 5px;
}

.qty-col {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
}

.qty-btn {
  border: 1px solid #ccc;
  padding: 5px 10px;
  background: #fff;
  cursor: pointer;
  border-radius: 4px;
}

.qty-btn:hover {
  background: #f1f1f1;
}

.qty-input {
  width: 50px;
  text-align: center;
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
}

.remove-btn {
  color: red;
  border: none;
  background: transparent;
  cursor: pointer;
  font-size: 14px;
  padding: 5px 10px;
}

.remove-btn:hover {
  text-decoration: underline;
}

.cart-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 15px;
  border-top: 1px solid #eee;
}

.total {
  text-align: right;
}

.footer-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  margin-top: 10px;
}

.buy-now-btn {
  background: linear-gradient(135deg, #ff7800 0%, #ff5000 100%);
  color: white;
  border: none;
  border-radius: 4px;
  padding: 12px 24px;
  font-weight: 600;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(255, 120, 0, 0.3);
}

.buy-now-btn:hover {
  background: linear-gradient(135deg, #ff5000 0%, #ff3000 100%);
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(255, 120, 0, 0.4);
}

.buy-now-btn:active {
  transform: translateY(0);
  box-shadow: 0 2px 6px rgba(255, 120, 0, 0.3);
}

.buy-now-btn:disabled {
  background: #ccc;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.remove-all-btn {
  padding: 10px 15px;
  background: #ffffff;
  border: 1px solid red;
  border-radius: 4px;
  color: red;
  font-weight: 500;
  cursor: pointer;
}

.remove-all-btn:hover {
  background: #ffe6e6;
}

.alert-info {
  padding: 15px;
  border-radius: 8px;
  background-color: #e3f2fd;
  border: 1px solid #bbdefb;
  color: #1565c0;
}
</style>
// Components index file - Export all components for better organization

// Product components
export { default as ProductGrid } from './products/ProductGrid.vue';
export { default as CategoryProducts } from './products/CategoryProducts.vue';

// Cart components
export { default as ShoppingCart } from './cart/ShoppingCart.vue';

// Order components
export { default as Order } from './orders/Order.vue';

// Icon components
export * from './icons';

// Common components (to be added)
// export { default as Button } from './common/Button.vue'
// export { default as Modal } from './common/Modal.vue'

// Form components (to be added)
// export { default as LoginForm } from './forms/LoginForm.vue'
// export { default as RegisterForm } from './forms/RegisterForm.vue'

// UI components (to be added)
// export { default as Card } from './ui/Card.vue'
// export { default as Badge } from './ui/Badge.vue'

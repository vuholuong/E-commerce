import { CURRENCY, DATE_FORMAT, VALIDATION } from '@/constants';

/**
 * Utility functions for the application
 */

/**
 * Format currency to Vietnamese Dong
 * @param {number} amount - Amount to format
 * @param {string} currency - Currency code (default: VND)
 * @returns {string} Formatted currency string
 */
export const formatCurrency = (amount, currency = CURRENCY.DEFAULT) => {
  return new Intl.NumberFormat(CURRENCY.LOCALE, {
    style: 'currency',
    currency,
  }).format(amount);
};

/**
 * Format date to Vietnamese locale
 * @param {string|Date} date - Date to format
 * @param {string} format - Format type ('display' or 'short')
 * @returns {string} Formatted date string
 */
export const formatDate = (date, format = 'display') => {
  const options = DATE_FORMAT[format.toUpperCase()] || DATE_FORMAT.DISPLAY;
  return new Intl.DateTimeFormat(DATE_FORMAT.LOCALE, options).format(new Date(date));
};

/**
 * Truncate text to specified length
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length
 * @returns {string} Truncated text
 */
export const truncateText = (text, maxLength = 100) => {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

/**
 * Generate random ID
 * @returns {string} Random ID
 */
export const generateId = () => {
  return Math.random().toString(36).substr(2, 9);
};

/**
 * Debounce function
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
export const debounce = (func, wait) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} Is valid email
 */
export const isValidEmail = email => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Validate password strength
 * @param {string} password - Password to validate
 * @returns {object} Validation result with isValid and message
 */
export const validatePassword = password => {
  if (password.length < VALIDATION.PASSWORD_MIN_LENGTH) {
    return {
      isValid: false,
      message: `Mật khẩu phải có ít nhất ${VALIDATION.PASSWORD_MIN_LENGTH} ký tự`,
    };
  }

  if (password.length > VALIDATION.PASSWORD_MAX_LENGTH) {
    return {
      isValid: false,
      message: `Mật khẩu không được quá ${VALIDATION.PASSWORD_MAX_LENGTH} ký tự`,
    };
  }

  return { isValid: true, message: 'Mật khẩu hợp lệ' };
};

/**
 * Capitalize first letter of string
 * @param {string} str - String to capitalize
 * @returns {string} Capitalized string
 */
export const capitalizeFirst = str => {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

/**
 * Convert string to slug
 * @param {string} str - String to convert
 * @returns {string} Slug string
 */
export const toSlug = str => {
  return str
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
};

/**
 * Check if value is empty (null, undefined, empty string, empty array, empty object)
 * @param {any} value - Value to check
 * @returns {boolean} Is empty
 */
export const isEmpty = value => {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string') return value.trim().length === 0;
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') {
    return Object.keys(value).length === 0;
  }
  return false;
};

/**
 * Deep clone object
 * @param {any} obj - Object to clone
 * @returns {any} Cloned object
 */
export const deepClone = obj => {
  if (obj === null || typeof obj !== 'object') return obj;
  if (obj instanceof Date) return new Date(obj.getTime());
  if (obj instanceof Array) return obj.map(item => deepClone(item));
  if (typeof obj === 'object') {
    const clonedObj = {};
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        clonedObj[key] = deepClone(obj[key]);
      }
    }
    return clonedObj;
  }
  return obj;
};

// Token Management Utilities
export const tokenUtils = {
  // Lấy access token
  getAccessToken() {
    return localStorage.getItem('app_access_token');
  },

  // Lấy refresh token
  getRefreshToken() {
    return localStorage.getItem('app_refresh_token');
  },

  // Lấy user session
  getUserSession() {
    const session = localStorage.getItem('app_user_session');
    return session ? JSON.parse(session) : null;
  },

  // Lưu tokens
  setTokens(accessToken, refreshToken = null) {
    localStorage.setItem('app_access_token', accessToken);
    if (refreshToken) {
      localStorage.setItem('app_refresh_token', refreshToken);
    }
  },

  // Lưu user session
  setUserSession(user) {
    localStorage.setItem('app_user_session', JSON.stringify(user));
  },

  // Xóa tất cả tokens
  clearTokens() {
    localStorage.removeItem('app_access_token');
    localStorage.removeItem('app_refresh_token');
    localStorage.removeItem('app_user_session');
  },

  // Kiểm tra đã đăng nhập
  isAuthenticated() {
    return !!this.getAccessToken();
  },

  // Kiểm tra token có hết hạn không
  isTokenExpired() {
    const token = this.getAccessToken();
    if (!token) return true;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const now = Math.floor(Date.now() / 1000);
      return payload.exp < now;
    } catch (error) {
      console.error('Error parsing token:', error);
      return true;
    }
  }
};

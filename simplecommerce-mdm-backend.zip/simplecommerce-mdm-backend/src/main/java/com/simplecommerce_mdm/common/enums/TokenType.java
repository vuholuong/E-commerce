package com.simplecommerce_mdm.common.enums;

public enum TokenType {
    ACCESS_TOKEN,
    REFRESH_TOKEN,
}


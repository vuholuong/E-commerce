package com.simplecommerce_mdm.common.enums;

public enum PromotionDiscountType {
    PERCENTAGE,
    FIXED_AMOUNT,
    FREE_SHIPPING,
    BUY_X_GET_Y
} 
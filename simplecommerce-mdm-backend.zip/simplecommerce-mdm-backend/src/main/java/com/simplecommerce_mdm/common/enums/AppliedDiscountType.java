package com.simplecommerce_mdm.common.enums;

public enum AppliedDiscountType {
    ITEM_DISCOUNT,
    SHIPPING_DISCOUNT
} 
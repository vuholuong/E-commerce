package com.simplecommerce_mdm.common.enums;

public enum ImageTargetType {
    PRODUCT,
    VARIANT,
    CATEGORY
} 
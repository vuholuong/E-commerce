package com.simplecommerce_mdm.common.enums;

public enum AddressType {
    HOME,
    WORK,
    SHIPPING,
    BILLING,
    OTHER
} 